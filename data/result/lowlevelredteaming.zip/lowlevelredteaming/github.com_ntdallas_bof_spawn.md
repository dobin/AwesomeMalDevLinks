# https://github.com/NtDallas/BOF_Spawn/

[Skip to content](https://github.com/NtDallas/BOF_Spawn/#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/NtDallas/BOF_Spawn/) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/NtDallas/BOF_Spawn/) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/NtDallas/BOF_Spawn/) to refresh your session.Dismiss alert

{{ message }}

[NtDallas](https://github.com/NtDallas)/ **[BOF\_Spawn](https://github.com/NtDallas/BOF_Spawn)** Public

- [Notifications](https://github.com/login?return_to=%2FNtDallas%2FBOF_Spawn) You must be signed in to change notification settings
- [Fork\\
24](https://github.com/login?return_to=%2FNtDallas%2FBOF_Spawn)
- [Star\\
151](https://github.com/login?return_to=%2FNtDallas%2FBOF_Spawn)


Cobalt Strike BOF for beacon/shellcode injection using fork & run technique with Draugr synthetic stack frames


[151\\
stars](https://github.com/NtDallas/BOF_Spawn/stargazers) [24\\
forks](https://github.com/NtDallas/BOF_Spawn/forks) [Branches](https://github.com/NtDallas/BOF_Spawn/branches) [Tags](https://github.com/NtDallas/BOF_Spawn/tags) [Activity](https://github.com/NtDallas/BOF_Spawn/activity)

[Star](https://github.com/login?return_to=%2FNtDallas%2FBOF_Spawn)

[Notifications](https://github.com/login?return_to=%2FNtDallas%2FBOF_Spawn) You must be signed in to change notification settings

# NtDallas/BOF\_Spawn

main

[**1** Branch](https://github.com/NtDallas/BOF_Spawn/branches) [**0** Tags](https://github.com/NtDallas/BOF_Spawn/tags)

[Go to Branches page](https://github.com/NtDallas/BOF_Spawn/branches)[Go to Tags page](https://github.com/NtDallas/BOF_Spawn/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>RtlDallas<br>[Updates CNA scripts and Makefile](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be)<br>3 months agoNov 23, 2025<br>[1d911d0](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be) · 3 months agoNov 23, 2025<br>## History<br>[6 Commits](https://github.com/NtDallas/BOF_Spawn/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/NtDallas/BOF_Spawn/commits/main/) 6 Commits |
| [Bin](https://github.com/NtDallas/BOF_Spawn/tree/main/Bin "Bin") | [Bin](https://github.com/NtDallas/BOF_Spawn/tree/main/Bin "Bin") | [Updates CNA scripts and Makefile](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be "Updates CNA scripts and Makefile") | 3 months agoNov 23, 2025 |
| [Src](https://github.com/NtDallas/BOF_Spawn/tree/main/Src "Src") | [Src](https://github.com/NtDallas/BOF_Spawn/tree/main/Src "Src") | [zob](https://github.com/NtDallas/BOF_Spawn/commit/7cb79a7dcfa2d9a7e75c95e1fa6015cb1559b07f "zob  zob") | 4 months agoNov 1, 2025 |
| [BOF\_spawn.cna](https://github.com/NtDallas/BOF_Spawn/blob/main/BOF_spawn.cna "BOF_spawn.cna") | [BOF\_spawn.cna](https://github.com/NtDallas/BOF_Spawn/blob/main/BOF_spawn.cna "BOF_spawn.cna") | [Updates CNA scripts and Makefile](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be "Updates CNA scripts and Makefile") | 3 months agoNov 23, 2025 |
| [Dockerfile](https://github.com/NtDallas/BOF_Spawn/blob/main/Dockerfile "Dockerfile") | [Dockerfile](https://github.com/NtDallas/BOF_Spawn/blob/main/Dockerfile "Dockerfile") | [Add files via upload](https://github.com/NtDallas/BOF_Spawn/commit/4f0210bb0c3cae5cdc7966d69f80c9082502ea78 "Add files via upload") | 4 months agoNov 1, 2025 |
| [Makefile](https://github.com/NtDallas/BOF_Spawn/blob/main/Makefile "Makefile") | [Makefile](https://github.com/NtDallas/BOF_Spawn/blob/main/Makefile "Makefile") | [Updates CNA scripts and Makefile](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be "Updates CNA scripts and Makefile") | 3 months agoNov 23, 2025 |
| [README.md](https://github.com/NtDallas/BOF_Spawn/blob/main/README.md "README.md") | [README.md](https://github.com/NtDallas/BOF_Spawn/blob/main/README.md "README.md") | [Updates CNA scripts and Makefile](https://github.com/NtDallas/BOF_Spawn/commit/1d911d0d967843af40f541f15b89b1da87ccc5be "Updates CNA scripts and Makefile") | 3 months agoNov 23, 2025 |
| View all files |

## Repository files navigation

# BOF Spawn - Process Injection

[Permalink: BOF Spawn - Process Injection](https://github.com/NtDallas/BOF_Spawn/#bof-spawn---process-injection)

## Update

[Permalink: Update](https://github.com/NtDallas/BOF_Spawn/#update)

### 11/23/25

[Permalink: 11/23/25](https://github.com/NtDallas/BOF_Spawn/#112325)

- Update `Makefile` and add `.gitkeep` in `Bin/` and `Bin/temp`, thanks @0xTriboulet for issues
- Update `BOF_spawn.cna` to fix initialization, thanks @D1sAbl4 for issues

## Overview

[Permalink: Overview](https://github.com/NtDallas/BOF_Spawn/#overview)

**BOF Spawn** is a Beacon Object File for Cobalt Strike that implements process spawning and shellcode injection Draugr stack spoofing with indirect syscalls. This tool combines multiple evasion techniques to bypass userland hooks, call stack analysis, and memory scanners.

**Architecture**: x64 only

### Core Architecture

[Permalink: Core Architecture](https://github.com/NtDallas/BOF_Spawn/#core-architecture)

```
┌──────────────────────────────────────────────────────────────┐
│                    Cobalt Strike Beacon                      │
│                    (Parent Process)                          │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         │ beacon_inline_execute()
                         │
                         ▼
          ┌──────────────────────────────┐
          │      BOF Spawn (Bof.c)       │
          │  ┌────────────────────────┐  │
          │  │  VxTable Initialization │ │
          │  │  (Syscall Resolution)   │ │
          │  └──────────┬─────────────┘  │
          │             │                │
          │  ┌──────────▼─────────────┐  │
          │  │  Draugr Framework      │  │
          │  │  - Stack Spoofing      │  │
          │  │  - Indirect Syscalls   │  │
          │  └──────────┬─────────────┘  │
          │             │                │
          │  ┌──────────▼─────────────┐  │
          │  │  SpawnAndRun()         │  │
          │  │  - Process Creation    │  │
          │  │  - Memory Allocation   │  │
          │  │  - Shellcode Injection │  │
          │  │  - Execution           │  │
          │  └────────────────────────┘  │
          └──────────────┬───────────────┘
                         │
                         ▼
          ┌──────────────────────────────┐
          │     Target Process           │
          │  (Suspended → Executing)     │
          │                              │
          │  ┌────────────────────────┐  │
          │  │  Injected Shellcode    │  │
          │  └────────────────────────┘  │
          └──────────────────────────────┘
```

## Configuration Options

[Permalink: Configuration Options](https://github.com/NtDallas/BOF_Spawn/#configuration-options)

The BOF provides extensive customization through the CNA script configuration dialog:

| Option | Description | Format/Notes |
| --- | --- | --- |
| **Process Name** | Executable path to spawn | NT path format: `\??\C:\Windows\System32\rundll32.exe` |
| **Working Directory** | Current directory for spawned process | Standard path: `C:\Windows\System32` |
| **PPID Spoof Process** | Parent process name for PPID spoofing | Process name only (e.g., `explorer.exe`) |
| **Command Line** | Arguments for spawned process | Full command line string |
| **Block DLL Policy** | Restrict to Microsoft-signed DLLs only | Boolean |
| **Disable CFG** | Disable Control Flow Guard | Boolean - Required for callback execution method |
| **Use RWX** | Allocate memory as RWX vs RW→RX | Boolean - RW→RX recommended for stealth |
| **Execution Method** | Shellcode execution technique | See section below |

**Note on Process Path Format**: The BOF uses NT path format (`\??\C:\...`) for the process name. This is the native format used by `NtCreateUserProcess` and bypasses some Win32 path parsing mechanisms.

## Shellcode Execution Methods

[Permalink: Shellcode Execution Methods](https://github.com/NtDallas/BOF_Spawn/#shellcode-execution-methods)

### 1\. Direct RIP Hijacking

[Permalink: 1. Direct RIP Hijacking](https://github.com/NtDallas/BOF_Spawn/#1-direct-rip-hijacking)

```
Original State:          Modified State:
┌──────────────┐        ┌──────────────┐
│ RIP: ntdll   │   →    │ RIP: 0x7FFE  │ (shellcode)
│ RAX: ...     │        │ RAX: ...     │
└──────────────┘        └──────────────┘
```

**Advantage**: Simple and reliable.

**Detection Risk**: High - RIP directly pointing to non-module memory is easily detected by EDR thread scanning.

### 2\. JMP RAX Gadget

[Permalink: 2. JMP RAX Gadget](https://github.com/NtDallas/BOF_Spawn/#2-jmp-rax-gadget)

```
Step 1: Find Gadget               Step 2: Set Context
┌──────────────────┐             ┌──────────────────┐
│ Scan ntdll.dll   │             │ RIP: ntdll!gadget│ (0xFF 0xE0)
│ for 0xFF 0xE0    │    →        │ RAX: shellcode   │
└──────────────────┘             └──────────────────┘
```

**Advantage**: RIP points to legitimate ntdll.dll, more stealthy than direct hijacking.

**Detection Risk**: Medium - Suspicious RAX value and unusual gadget execution may trigger heuristics.

### 3\. JMP RBX Gadget

[Permalink: 3. JMP RBX Gadget](https://github.com/NtDallas/BOF_Spawn/#3-jmp-rbx-gadget)

```
Step 1: Find Gadget               Step 2: Set Context
┌──────────────────┐             ┌──────────────────┐
│ Scan ntdll.dll   │             │ RIP: ntdll!gadget│ (0xFF 0xE3)
│ for 0xFF 0xE3    │    →        │ RBX: shellcode   │
└──────────────────┘             └──────────────────┘
```

**Advantage**: Similar to JMP RAX, RIP remains in legitimate module space.

**Detection Risk**: Medium - Same as JMP RAX, slightly different register makes detection signatures less common.

### 4\. Callback Function Hijacking

[Permalink: 4. Callback Function Hijacking](https://github.com/NtDallas/BOF_Spawn/#4-callback-function-hijacking)

```
EnumResourceTypesW(hModule, lpEnumFunc, lParam)
                              ↓
                    RCX = NULL
                    RDX = shellcode address
                    R8  = NULL
```

**Advantage**: Leverages legitimate callback mechanism, appears as normal Windows API usage.

**Detection Risk**: Low-Medium - Requires CFG disabled. NULL module handle and callback validation may trigger alerts.

## Mitigation Policies: Benefits and Risks

[Permalink: Mitigation Policies: Benefits and Risks](https://github.com/NtDallas/BOF_Spawn/#mitigation-policies-benefits-and-risks)

### Disable CFG (Control Flow Guard)

[Permalink: Disable CFG (Control Flow Guard)](https://github.com/NtDallas/BOF_Spawn/#disable-cfg-control-flow-guard)

**Purpose**: Required for callback function execution method. CFG validates indirect call targets and would block shellcode execution.

**Risk**: Disabling CFG is a strong indicator of malicious intent. Very few legitimate applications disable CFG during process creation.

**Recommendation**: Only enable when using callback execution method.

### Block DLL Policy

[Permalink: Block DLL Policy](https://github.com/NtDallas/BOF_Spawn/#block-dll-policy)

**Purpose**: Prevents loading of non-Microsoft-signed DLLs, blocking security product hooks and monitoring DLLs from being injected.

**Risk**: Unusual mitigation policy for typical processes. May trigger EDR alerts on process creation with this attribute.

**Recommendation**: Use selectively - effective against DLL-based EDR hooks but creates detection artifact.

### RWX Memory Allocation

[Permalink: RWX Memory Allocation](https://github.com/NtDallas/BOF_Spawn/#rwx-memory-allocation)

**Purpose**: Simplifies injection by allocating memory with Read-Write-Execute permissions directly.

**Risk**: RWX memory is a critical indicator for memory scanners.
**Recommendation**: Use RW→RX transition instead (default). Allocate as RW, write shellcode, then change to RX.

## Detection Vectors

[Permalink: Detection Vectors](https://github.com/NtDallas/BOF_Spawn/#detection-vectors)

### ETW-TI (Threat Intelligence) Callbacks

[Permalink: ETW-TI (Threat Intelligence) Callbacks](https://github.com/NtDallas/BOF_Spawn/#etw-ti-threat-intelligence-callbacks)

**NtGetContextThread / NtSetContextThread**:

- ETW-TI provides callbacks for thread context manipulation via `EtwTiLogReadWriteVm`
- Modifying RIP register on suspended threads is a strong injection indicator
- Detection: Context modifications are logged with thread ID, process ID, and modified registers

### Kernel Callbacks

[Permalink: Kernel Callbacks](https://github.com/NtDallas/BOF_Spawn/#kernel-callbacks)

**Process Creation (PsSetCreateProcessNotifyRoutine)**:

- `NtCreateUserProcess` triggers kernel callbacks visible to EDR drivers
- Suspended process creation followed by cross-process operations is suspicious
- Detection: Process creation with unusual parent (PPID spoofing), mitigation policies (BlockDLL, CFG disabled)

**Memory Allocation**:

- RWX memory allocations are monitored at kernel level via process callbacks
- Even without ETW-TI, kernel drivers can detect RWX via `MmProtectMdlSystemAddress` events
- Detection: Unbacked executable memory (not mapped from disk file)

## Evasion Techniques

[Permalink: Evasion Techniques](https://github.com/NtDallas/BOF_Spawn/#evasion-techniques)

| Technique | Bypasses |
| --- | --- |
| **Indirect Syscalls** | Userland API hooks (EDR/AV) |
| **Draugr Stack Spoofing** | Call stack inspection tools |
| **PPID Spoofing** | Process tree analysis |
| **Gadget-based Execution** | Direct RIP detection |

## Usage

[Permalink: Usage](https://github.com/NtDallas/BOF_Spawn/#usage)

### Load Script

[Permalink: Load Script](https://github.com/NtDallas/BOF_Spawn/#load-script)

```
Cobalt Strike → Script Manager → Load → BOF_spawn.cna
```

### Configure

[Permalink: Configure](https://github.com/NtDallas/BOF_Spawn/#configure)

```
Menu: Additionals postex → Spawn Process Config
```

### Execute

[Permalink: Execute](https://github.com/NtDallas/BOF_Spawn/#execute)

```
beacon> spawn_beacon <listener_name>
beacon> spawn_shellcode /path/to/payload.bin
```

## Compilation

[Permalink: Compilation](https://github.com/NtDallas/BOF_Spawn/#compilation)

With Dockerfile:

```
sudo docker build -t ubuntu-gcc-13 .
sudo docker run --rm -it -v "$PWD":/work -w /work ubuntu-gcc-13:latest make
```

Or, if you have nasm, make, and mingw-w64 (compatible with gcc-14) on your system

```
make
```

Output: `Bin/bof.o`

## Limitations

[Permalink: Limitations](https://github.com/NtDallas/BOF_Spawn/#limitations)

- **CET (Control-flow Enforcement Technology)**: Synthetic stack frames may trigger violations in CET-enabled processes
- **Architecture**: x64 only - no x86 support
- **Kernel Visibility**: Process creation still visible to kernel callbacks despite userland evasion

## Credit

[Permalink: Credit](https://github.com/NtDallas/BOF_Spawn/#credit)

- **RastaMouse** : [https://offensivedefence.co.uk/authors/rastamouse/](https://offensivedefence.co.uk/authors/rastamouse/)
- **Capt. Meelo**: [https://captmeelo.com/redteam/maldev/2022/05/10/ntcreateuserprocess.html](https://captmeelo.com/redteam/maldev/2022/05/10/ntcreateuserprocess.html)
- **Sektor7**: [https://institute.sektor7.net/view/courses/rto-win-evasion](https://institute.sektor7.net/view/courses/rto-win-evasion)

## About

Cobalt Strike BOF for beacon/shellcode injection using fork & run technique with Draugr synthetic stack frames


### Resources

[Readme](https://github.com/NtDallas/BOF_Spawn/#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/NtDallas/BOF_Spawn/).

[Activity](https://github.com/NtDallas/BOF_Spawn/activity)

### Stars

[**151**\\
stars](https://github.com/NtDallas/BOF_Spawn/stargazers)

### Watchers

[**2**\\
watching](https://github.com/NtDallas/BOF_Spawn/watchers)

### Forks

[**24**\\
forks](https://github.com/NtDallas/BOF_Spawn/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FNtDallas%2FBOF_Spawn&report=NtDallas+%28user%29)

## [Releases](https://github.com/NtDallas/BOF_Spawn/releases)

No releases published

## [Packages\  0](https://github.com/users/NtDallas/packages?repo_name=BOF_Spawn)

No packages published

## Languages

- [C++83.0%](https://github.com/NtDallas/BOF_Spawn/search?l=c%2B%2B)
- [C14.8%](https://github.com/NtDallas/BOF_Spawn/search?l=c)
- [Assembly1.7%](https://github.com/NtDallas/BOF_Spawn/search?l=assembly)
- Other0.5%

You can’t perform that action at this time.