# https://github.com/skelsec/evilrdp

[Skip to content](https://github.com/skelsec/evilrdp#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/skelsec/evilrdp) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/skelsec/evilrdp) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/skelsec/evilrdp) to refresh your session.Dismiss alert

{{ message }}

[skelsec](https://github.com/skelsec)/ **[evilrdp](https://github.com/skelsec/evilrdp)** Public

- [Notifications](https://github.com/login?return_to=%2Fskelsec%2Fevilrdp) You must be signed in to change notification settings
- [Fork\\
33](https://github.com/login?return_to=%2Fskelsec%2Fevilrdp)
- [Star\\
307](https://github.com/login?return_to=%2Fskelsec%2Fevilrdp)


[307\\
stars](https://github.com/skelsec/evilrdp/stargazers) [33\\
forks](https://github.com/skelsec/evilrdp/forks) [Branches](https://github.com/skelsec/evilrdp/branches) [Tags](https://github.com/skelsec/evilrdp/tags) [Activity](https://github.com/skelsec/evilrdp/activity)

[Star](https://github.com/login?return_to=%2Fskelsec%2Fevilrdp)

[Notifications](https://github.com/login?return_to=%2Fskelsec%2Fevilrdp) You must be signed in to change notification settings

# skelsec/evilrdp

main

[**1** Branch](https://github.com/skelsec/evilrdp/branches) [**0** Tags](https://github.com/skelsec/evilrdp/tags)

[Go to Branches page](https://github.com/skelsec/evilrdp/branches)[Go to Tags page](https://github.com/skelsec/evilrdp/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>SkelSec<br>[remove setup.py for aiocmd package](https://github.com/skelsec/evilrdp/commit/b4dbbcf422c9fb06f7f98ae286663a42abbfbc44)<br>success<br>11 months agoMar 15, 2025<br>[b4dbbcf](https://github.com/skelsec/evilrdp/commit/b4dbbcf422c9fb06f7f98ae286663a42abbfbc44) · 11 months agoMar 15, 2025<br>## History<br>[15 Commits](https://github.com/skelsec/evilrdp/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/skelsec/evilrdp/commits/main/) 15 Commits |
| [.github/workflows](https://github.com/skelsec/evilrdp/tree/main/.github/workflows "This path skips through empty directories") | [.github/workflows](https://github.com/skelsec/evilrdp/tree/main/.github/workflows "This path skips through empty directories") | [upping readme, gh actions](https://github.com/skelsec/evilrdp/commit/3006aa374808ef4c9af016819baf991fd5d57039 "upping readme, gh actions") | 3 years agoNov 30, 2023 |
| [builder/pyinstaller](https://github.com/skelsec/evilrdp/tree/main/builder/pyinstaller "This path skips through empty directories") | [builder/pyinstaller](https://github.com/skelsec/evilrdp/tree/main/builder/pyinstaller "This path skips through empty directories") | [changing name of builder](https://github.com/skelsec/evilrdp/commit/b7d9c5f02c90950dd2ae96dafa37944e997b6007 "changing name of builder") | 3 years agoFeb 21, 2023 |
| [evilrdp](https://github.com/skelsec/evilrdp/tree/main/evilrdp "evilrdp") | [evilrdp](https://github.com/skelsec/evilrdp/tree/main/evilrdp "evilrdp") | [remove setup.py for aiocmd package](https://github.com/skelsec/evilrdp/commit/b4dbbcf422c9fb06f7f98ae286663a42abbfbc44 "remove setup.py for aiocmd package") | 11 months agoMar 15, 2025 |
| [.gitignore](https://github.com/skelsec/evilrdp/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/skelsec/evilrdp/blob/main/.gitignore ".gitignore") | [updating gitignore](https://github.com/skelsec/evilrdp/commit/111feffbe400801879c4fd6357a5999a97551ce7 "updating gitignore") | 3 years agoFeb 22, 2023 |
| [MANIFEST.in](https://github.com/skelsec/evilrdp/blob/main/MANIFEST.in "MANIFEST.in") | [MANIFEST.in](https://github.com/skelsec/evilrdp/blob/main/MANIFEST.in "MANIFEST.in") | [adding static file include](https://github.com/skelsec/evilrdp/commit/4510f96ab974e9d8e487de3c9e1c8d273d7c3046 "adding static file include") | 3 years agoJan 21, 2023 |
| [Makefile](https://github.com/skelsec/evilrdp/blob/main/Makefile "Makefile") | [Makefile](https://github.com/skelsec/evilrdp/blob/main/Makefile "Makefile") | [initial comet](https://github.com/skelsec/evilrdp/commit/7f438e9467456b9fc4d630ec1c3d923c2abe86f5 "initial comet") | 3 years agoJan 21, 2023 |
| [README.md](https://github.com/skelsec/evilrdp/blob/main/README.md "README.md") | [README.md](https://github.com/skelsec/evilrdp/blob/main/README.md "README.md") | [upping readme, gh actions](https://github.com/skelsec/evilrdp/commit/3006aa374808ef4c9af016819baf991fd5d57039 "upping readme, gh actions") | 3 years agoNov 30, 2023 |
| [pyproject.toml](https://github.com/skelsec/evilrdp/blob/main/pyproject.toml "pyproject.toml") | [pyproject.toml](https://github.com/skelsec/evilrdp/blob/main/pyproject.toml "pyproject.toml") | [final builder](https://github.com/skelsec/evilrdp/commit/70b36688f012a984113f56e373e3074482b3dd08 "final builder") | 3 years agoFeb 21, 2023 |
| [setup.py](https://github.com/skelsec/evilrdp/blob/main/setup.py "setup.py") | [setup.py](https://github.com/skelsec/evilrdp/blob/main/setup.py "setup.py") | [adding static file include](https://github.com/skelsec/evilrdp/commit/4510f96ab974e9d8e487de3c9e1c8d273d7c3046 "adding static file include") | 3 years agoJan 21, 2023 |
| View all files |

## Repository files navigation

[![Supported Python versions](https://camo.githubusercontent.com/b413597d37ccc8eae784ee4f9979e61fe739bbdcd0f6247e4aa0d68c6f1659ca/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f707974686f6e2d332e372b2d626c75652e737667)](https://camo.githubusercontent.com/b413597d37ccc8eae784ee4f9979e61fe739bbdcd0f6247e4aa0d68c6f1659ca/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f707974686f6e2d332e372b2d626c75652e737667)[![Twitter](https://camo.githubusercontent.com/d09613ebfce74304ed4919c06f05689dae72c7c61e71a4444292a4df500d0db8/68747470733a2f2f696d672e736869656c64732e696f2f747769747465722f666f6c6c6f772f736b656c7365633f6c6162656c3d736b656c736563267374796c653d736f6369616c)](https://twitter.com/intent/follow?screen_name=skelsec)

## 🚩 Sponsors

[Permalink: :triangular_flag_on_post: Sponsors](https://github.com/skelsec/evilrdp#triangular_flag_on_post-sponsors)

If you like this project, consider sponsoring it on GitHub! [Sponsors](https://github.com/sponsors/skelsec/)

# EVILRDP - More control over RDP

[Permalink: EVILRDP - More control over RDP](https://github.com/skelsec/evilrdp#evilrdp---more-control-over-rdp)

Th evil twin of [`aardwolfgui`](https://github.com/skelsec/aardwolfgui) using the [`aardwolf`](https://github.com/skelsec/aardwolf) RDP client library that gives you extended control over the target and additional scripting capabilities from the command line.

# Features

[Permalink: Features](https://github.com/skelsec/evilrdp#features)

- Control mouse and keyboard in an automated way from command line
- Control clipboard in an automated way from command line
- Spawn a SOCKS proxy from the client that channels network communication to the target via RDP
- Execute arbitrary SHELL and PowerShell commands on the target without uploading files
- Upload and download files to/from the target even when file transfers are disabled on the target

# Scripts

[Permalink: Scripts](https://github.com/skelsec/evilrdp#scripts)

- `evilrdp` \- GUI + command line RDP client

# Usage

[Permalink: Usage](https://github.com/skelsec/evilrdp#usage)

After installing this package, a new executable will be available called `evilrdp`.

Upon making a successful connection to the target you'll be presented with a GUI just like a normal RDP client as well as the command line from where you executed `evilrdp` will turn into an interactive shell.

There will be two groups of commands available to you, as follows:

- Commands that can be issues any time. This include commands like:
  - mousemove
  - rightclick
  - doubleclick
  - type
  - typefile
  - return/enter
  - invokerun
  - clipboardset
  - clipboardsetfile
  - clipboardget
  - powershell
  - screenshot
- Commands which only work when the `PSCMD` channel is established

  - pscmdchannel - Changes the `PSCMD` channel name from the default. Use this when you changed the channelname in agent script file
  - **startpscmd - This tries to automatically start the remote agent which allows further commands to be used**
  - pscmd - Executes a powershell command
  - getfile - Downloads remote file
  - shell - Executes a shell command
  - socksproxy - Starts a SOCKS4a/5 proxy

As it is with all things RDP, automatic command execution doesn't always work mostly because of timing issues therefore the `startpscmd` might need to be used 2 times, OR you might need to start the `PSCMD` channel manually.

When `PSCMD` channel starts, you'll get a notification in your client shell.

# URL format

[Permalink: URL format](https://github.com/skelsec/evilrdp#url-format)

As usual the scripts take the target/scredentials in URL format. Below some examples

- `rdp+kerberos-password://TEST\Administrator:Passw0rd!1@win2016ad.test.corp/?dc=10.10.10.2&proxytype=socks5&proxyhost=127.0.0.1&proxyport=1080`


CredSSP (aka `HYBRID`) auth using Kerberos auth + password via `socks5` to `win2016ad.test.corp`, the domain controller (kerberos service) is at `10.10.10.2`. The socks proxy is on `127.0.0.1:1080`
- `rdp+ntlm-password://TEST\Administrator:Passw0rd!1@10.10.10.103`


CredSSP (aka `HYBRID`) auth using NTLM auth + password connecting to RDP server `10.10.10.103`
- `rdp+ntlm-password://TEST\Administrator:<NThash>@10.10.10.103`


CredSSP (aka `HYBRID`) auth using Pass-the-Hash (NTLM) auth connecting to RDP server `10.10.10.103`
- `rdp+plain://Administrator:Passw0rd!1@10.10.10.103`


Plain authentication (No SSL, encryption is RC4) using password connecting to RDP server `10.10.10.103`
- See `-h` for more

# Kudos

[Permalink: Kudos](https://github.com/skelsec/evilrdp#kudos)

- Balazs Bucsay ( [@xoreipeip](https://twitter.com/xoreipeip)) [`SocksOverRDP`](https://github.com/nccgroup/SocksOverRDP). The base idea for covert comms over RDP

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/skelsec/evilrdp#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/skelsec/evilrdp).

[Activity](https://github.com/skelsec/evilrdp/activity)

### Stars

[**307**\\
stars](https://github.com/skelsec/evilrdp/stargazers)

### Watchers

[**3**\\
watching](https://github.com/skelsec/evilrdp/watchers)

### Forks

[**33**\\
forks](https://github.com/skelsec/evilrdp/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fskelsec%2Fevilrdp&report=skelsec+%28user%29)

## [Releases](https://github.com/skelsec/evilrdp/releases)

No releases published

## [Packages\  0](https://github.com/users/skelsec/packages?repo_name=evilrdp)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/skelsec/evilrdp).

## Languages

- [Python55.4%](https://github.com/skelsec/evilrdp/search?l=python)
- [PowerShell41.5%](https://github.com/skelsec/evilrdp/search?l=powershell)
- [Batchfile2.6%](https://github.com/skelsec/evilrdp/search?l=batchfile)
- [Makefile0.5%](https://github.com/skelsec/evilrdp/search?l=makefile)

You can’t perform that action at this time.