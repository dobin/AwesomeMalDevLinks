# https://github.com/5w0rdfi5h/Torpedo

[Skip to content](https://github.com/5w0rdfi5h/Torpedo#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/5w0rdfi5h/Torpedo) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/5w0rdfi5h/Torpedo) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/5w0rdfi5h/Torpedo) to refresh your session.Dismiss alert

{{ message }}

[5w0rdfi5h](https://github.com/5w0rdfi5h)/ **[Torpedo](https://github.com/5w0rdfi5h/Torpedo)** Public

- [Notifications](https://github.com/login?return_to=%2F5w0rdfi5h%2FTorpedo) You must be signed in to change notification settings
- [Fork\\
1](https://github.com/login?return_to=%2F5w0rdfi5h%2FTorpedo)
- [Star\\
13](https://github.com/login?return_to=%2F5w0rdfi5h%2FTorpedo)


A C# based Red Team utility, to execute commands on a remote windows system using SMB/SCCM


### License

[MIT license](https://github.com/5w0rdfi5h/Torpedo/blob/main/LICENSE)

[13\\
stars](https://github.com/5w0rdfi5h/Torpedo/stargazers) [1\\
fork](https://github.com/5w0rdfi5h/Torpedo/forks) [Branches](https://github.com/5w0rdfi5h/Torpedo/branches) [Tags](https://github.com/5w0rdfi5h/Torpedo/tags) [Activity](https://github.com/5w0rdfi5h/Torpedo/activity)

[Star](https://github.com/login?return_to=%2F5w0rdfi5h%2FTorpedo)

[Notifications](https://github.com/login?return_to=%2F5w0rdfi5h%2FTorpedo) You must be signed in to change notification settings

# 5w0rdfi5h/Torpedo

main

[**1** Branch](https://github.com/5w0rdfi5h/Torpedo/branches) [**1** Tag](https://github.com/5w0rdfi5h/Torpedo/tags)

[Go to Branches page](https://github.com/5w0rdfi5h/Torpedo/branches)[Go to Tags page](https://github.com/5w0rdfi5h/Torpedo/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![5w0rdfi5h](https://avatars.githubusercontent.com/u/97876763?v=4&size=40)](https://github.com/5w0rdfi5h)[5w0rdfi5h](https://github.com/5w0rdfi5h/Torpedo/commits?author=5w0rdfi5h)<br>[Create LICENSE](https://github.com/5w0rdfi5h/Torpedo/commit/f438014e1df460fbee9b51e750ca88a9166cdf2f)<br>5 months agoSep 12, 2025<br>[f438014](https://github.com/5w0rdfi5h/Torpedo/commit/f438014e1df460fbee9b51e750ca88a9166cdf2f) · 5 months agoSep 12, 2025<br>## History<br>[4 Commits](https://github.com/5w0rdfi5h/Torpedo/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/5w0rdfi5h/Torpedo/commits/main/) 4 Commits |
| [.vs/Torpedo](https://github.com/5w0rdfi5h/Torpedo/tree/main/.vs/Torpedo "This path skips through empty directories") | [.vs/Torpedo](https://github.com/5w0rdfi5h/Torpedo/tree/main/.vs/Torpedo "This path skips through empty directories") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| [Torpedo](https://github.com/5w0rdfi5h/Torpedo/tree/main/Torpedo "Torpedo") | [Torpedo](https://github.com/5w0rdfi5h/Torpedo/tree/main/Torpedo "Torpedo") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| [TorpedoPayload](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoPayload "TorpedoPayload") | [TorpedoPayload](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoPayload "TorpedoPayload") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| [TorpedoService\_net3.5](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoService_net3.5 "TorpedoService_net3.5") | [TorpedoService\_net3.5](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoService_net3.5 "TorpedoService_net3.5") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| [TorpedoService\_net4.5](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoService_net4.5 "TorpedoService_net4.5") | [TorpedoService\_net4.5](https://github.com/5w0rdfi5h/Torpedo/tree/main/TorpedoService_net4.5 "TorpedoService_net4.5") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| [LICENSE](https://github.com/5w0rdfi5h/Torpedo/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/5w0rdfi5h/Torpedo/blob/main/LICENSE "LICENSE") | [Create LICENSE](https://github.com/5w0rdfi5h/Torpedo/commit/f438014e1df460fbee9b51e750ca88a9166cdf2f "Create LICENSE") | 5 months agoSep 12, 2025 |
| [README.md](https://github.com/5w0rdfi5h/Torpedo/blob/main/README.md "README.md") | [README.md](https://github.com/5w0rdfi5h/Torpedo/blob/main/README.md "README.md") | [Create README.md](https://github.com/5w0rdfi5h/Torpedo/commit/9cdbe997dddb7418abfc89a0dc1e2a515b1c8ac0 "Create README.md") | 5 months agoSep 12, 2025 |
| [Torpedo.sln](https://github.com/5w0rdfi5h/Torpedo/blob/main/Torpedo.sln "Torpedo.sln") | [Torpedo.sln](https://github.com/5w0rdfi5h/Torpedo/blob/main/Torpedo.sln "Torpedo.sln") | [v1.0-Beta](https://github.com/5w0rdfi5h/Torpedo/commit/671afd01231b134a4a891413b99ebcf35e6e7f26 "v1.0-Beta") | 5 months agoSep 12, 2025 |
| View all files |

## Repository files navigation

# Torpedo ⚡ PsExec on Steroids

[Permalink: Torpedo ⚡ PsExec on Steroids](https://github.com/5w0rdfi5h/Torpedo#torpedo--psexec-on-steroids)

## 🚀 Overview

[Permalink: 🚀 Overview](https://github.com/5w0rdfi5h/Torpedo#-overview)

**Torpedo** is a powerful, stealth-enhanced reimagining of the classic Sysinternals PsExec, implemented natively in C#. It brings all the familiar features of PsExec’s remote execution and token impersonation, upgraded with modern offensive engineering for red teams and security researchers.

If you know PsExec, Torpedo feels instantly familiar, just way more flexible, resilient, and battle-tested against modern endpoint defenses.

## ✨ Key Features (Quite Simple, Nothing Too Fancy!)

[Permalink: ✨ Key Features (Quite Simple, Nothing Too Fancy!)](https://github.com/5w0rdfi5h/Torpedo#-key-features-quite-simple-nothing-too-fancy)

- 🔐 **Token Manipulation**


Duplicate tokens from target processes by PID or create tokens from credentials.

- 🔍 **Target Enumeration**


Discover the .NET Framework version remotely over admin$ SMB.

- 📦 **Service Deployment & Execution**


Pushes an obfuscated, packed service binary to the target and launches it remotely via SCCM, running with elevated privileges.

- 🛡️ **Fileless DLL Payload Delivery**


Transmits encrypted DLL payloads over named pipes, loading and executing them entirely in-memory with C# reflection and zero disk footprint.

- 🌀 **Polymorphic Runtime Encryption**


Both ends encrypt and decrypt code at runtime, morphing payloads to evade static and behavioral detection engines.

- 🧹 **Artifact Cleanup**


After execution, the service binary is deleted, the service unregistered, and files shredded to avoid forensic footprints.


## 🛠️ Workflow At a Glance

[Permalink: 🛠️ Workflow At a Glance](https://github.com/5w0rdfi5h/Torpedo#%EF%B8%8F-workflow-at-a-glance)

1. **Select Target:** Specify PID or credentials to impersonate.
2. **Impersonation:** Duplicate token or create token from creds via P/Invoke.
3. **Deploy Service:** Push and launch obfuscated service using admin$ and SCCM.
4. **Pipe Communication:** Opens a named pipe, transmit encrypted DLL payload.
5. **Fileless Execution:** Load and run DLL entirely in-memory without touching disk.
6. **Output Delivery & Cleanup:** Encrypted result sent back; service and binaries removed.

## 🛡️ Comparison: Classic PsExec vs Torpedo

[Permalink: 🛡️ Comparison: Classic PsExec vs Torpedo](https://github.com/5w0rdfi5h/Torpedo#%EF%B8%8F-comparison-classic-psexec-vs-torpedo)

| Feature | Classic PsExec | PsExecX Enhancement |
| --- | --- | --- |
| Named Pipe Names | Fixed | Can be Randomized per execution (In Next Update) |
| Service Binary | Plain, unprotected | Packed, obfuscated binary |
| Network Traffic | Unmasked SMB calls | Cloaked, timed SMB to blend traffic |
| Payload Delivery | On-disk DLL injection | Encrypted, fileless in-memory payload |
| Token Duplication | Win32 API calls | P/Invoke for Now, D/Invoke Next in Pipeline |
| Output Data | Plaintext | Encrypted |

## ⚠️ Ethical Use

[Permalink: ⚠️ Ethical Use](https://github.com/5w0rdfi5h/Torpedo#%EF%B8%8F-ethical-use)

Torpedo is designed **only for authorized penetration testing, red team engagements, and research** on assets you have permission to assess. Unauthorized or malicious use is strongly discouraged.

## 📖 Usage

[Permalink: 📖 Usage](https://github.com/5w0rdfi5h/Torpedo#-usage)

If you are familiar with PsExec, Torpedo keeps the operational paradigm intact while delivering a stealthier, more powerful toolset. Detailed explanation and examples will be provided in my blog.

```
C:\Dev>Torpedo.exe /h

Torpedo :: PsExec on Steroids

Usage ::

Create Token With Creds & Execute       Steal Token and Execute             Just Execute
args[0] = switch (/ctok)                args[0] = switch (/stok)            args[0] = switch (/default)
args[1] = domain                        args[1] = pid                       args[2] = host
args[2] = username                      args[2] = host                      args[3] = process
args[3] = password                      args[3] = process                   args[4] = processArgs
args[4] = host                          args[4] = processArgs
args[5] = process
args[6] = processArgs

Example 1 :: Create Token & Execute :: Torpedo.exe /ctok EvilCorp.Net Administartor SecretPassword 127.0.0.1 cmd dir C:\
                                       Torpedo.exe /ctok EvilCorp.Net Administartor SecretPassword 127.0.0.1 powershell Get-PSDrive
                                       Torpedo.exe /ctok EvilCorp.Net Administartor SecretPassword 127.0.0.1 execute C:\Windows\Temp\PE.exe arg1 arg2

Example 2 :: Steal Token & Execute ::  Torpedo.exe /stok 5643 127.0.0.1 cmd dir C:\
                                       Torpedo.exe /stok 5643 127.0.0.1 powershell Get-PSDrive
                                       Torpedo.exe /stok 5643 127.0.0.1 execute C:\Windows\Temp\PE.exe arg1 arg2

Example 3 :: Just Execute          ::  Torpedo.exe /default 127.0.0.1 cmd dir C:\
                                       Torpedo.exe /default 127.0.0.1 powershell Get-PSDrive
                                       Torpedo.exe /default 127.0.0.1 execute C:\Windows\Temp\PE.exe arg1 arg2
```

## 📄 License

[Permalink: 📄 License](https://github.com/5w0rdfi5h/Torpedo#-license)

Distributed under a responsible open-source license. See `LICENSE.md` for full terms.

## 🙏 Acknowledgments

[Permalink: 🙏 Acknowledgments](https://github.com/5w0rdfi5h/Torpedo#-acknowledgments)

Inspired and built on the foundations laid by Sysinternals PsExec, The OG, Tim Malcomvetter's CsExec and the offensive security community’s ongoing efforts to advance red team tools with modern evasion.

For questions, issues, or contributions, please open an issue or start a discussion on this repo. ⭐️ If this tool helps your assessments, consider leaving a star!

## About

A C# based Red Team utility, to execute commands on a remote windows system using SMB/SCCM


### Topics

[offensive-security](https://github.com/topics/offensive-security "Topic: offensive-security") [redteaming](https://github.com/topics/redteaming "Topic: redteaming") [redteam](https://github.com/topics/redteam "Topic: redteam") [redteam-tools](https://github.com/topics/redteam-tools "Topic: redteam-tools") [offensive-ops](https://github.com/topics/offensive-ops "Topic: offensive-ops") [redteaming-tools](https://github.com/topics/redteaming-tools "Topic: redteaming-tools")

### Resources

[Readme](https://github.com/5w0rdfi5h/Torpedo#readme-ov-file)

### License

[MIT license](https://github.com/5w0rdfi5h/Torpedo#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/5w0rdfi5h/Torpedo).

[Activity](https://github.com/5w0rdfi5h/Torpedo/activity)

### Stars

[**13**\\
stars](https://github.com/5w0rdfi5h/Torpedo/stargazers)

### Watchers

[**2**\\
watching](https://github.com/5w0rdfi5h/Torpedo/watchers)

### Forks

[**1**\\
fork](https://github.com/5w0rdfi5h/Torpedo/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2F5w0rdfi5h%2FTorpedo&report=5w0rdfi5h+%28user%29)

## [Releases\  1](https://github.com/5w0rdfi5h/Torpedo/releases)

[Release-v1.0\\
Latest\\
\\
on Sep 12, 2025Sep 12, 2025](https://github.com/5w0rdfi5h/Torpedo/releases/tag/v1.0)

## [Packages\  0](https://github.com/users/5w0rdfi5h/packages?repo_name=Torpedo)

No packages published

## Languages

- [C#100.0%](https://github.com/5w0rdfi5h/Torpedo/search?l=c%23)

You can’t perform that action at this time.