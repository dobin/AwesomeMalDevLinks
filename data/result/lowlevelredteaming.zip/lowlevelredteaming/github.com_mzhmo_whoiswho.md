# https://github.com/MzHmO/WhoIsWho

[Skip to content](https://github.com/MzHmO/WhoIsWho#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/MzHmO/WhoIsWho) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/MzHmO/WhoIsWho) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/MzHmO/WhoIsWho) to refresh your session.Dismiss alert

{{ message }}

[MzHmO](https://github.com/MzHmO)/ **[WhoIsWho](https://github.com/MzHmO/WhoIsWho)** Public

- [Notifications](https://github.com/login?return_to=%2FMzHmO%2FWhoIsWho) You must be signed in to change notification settings
- [Fork\\
21](https://github.com/login?return_to=%2FMzHmO%2FWhoIsWho)
- [Star\\
141](https://github.com/login?return_to=%2FMzHmO%2FWhoIsWho)


Amazing whoami alternatives


[141\\
stars](https://github.com/MzHmO/WhoIsWho/stargazers) [21\\
forks](https://github.com/MzHmO/WhoIsWho/forks) [Branches](https://github.com/MzHmO/WhoIsWho/branches) [Tags](https://github.com/MzHmO/WhoIsWho/tags) [Activity](https://github.com/MzHmO/WhoIsWho/activity)

[Star](https://github.com/login?return_to=%2FMzHmO%2FWhoIsWho)

[Notifications](https://github.com/login?return_to=%2FMzHmO%2FWhoIsWho) You must be signed in to change notification settings

# MzHmO/WhoIsWho

main

[**1** Branch](https://github.com/MzHmO/WhoIsWho/branches) [**0** Tags](https://github.com/MzHmO/WhoIsWho/tags)

[Go to Branches page](https://github.com/MzHmO/WhoIsWho/branches)[Go to Tags page](https://github.com/MzHmO/WhoIsWho/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![MzHmO](https://avatars.githubusercontent.com/u/92790655?v=4&size=40)](https://github.com/MzHmO)[MzHmO](https://github.com/MzHmO/WhoIsWho/commits?author=MzHmO)<br>[Update README.md](https://github.com/MzHmO/WhoIsWho/commit/2837daa76cc95dac4361d121baf194479412da75)<br>2 years agoMar 23, 2024<br>[2837daa](https://github.com/MzHmO/WhoIsWho/commit/2837daa76cc95dac4361d121baf194479412da75) · 2 years agoMar 23, 2024<br>## History<br>[39 Commits](https://github.com/MzHmO/WhoIsWho/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/MzHmO/WhoIsWho/commits/main/) 39 Commits |
| [0x0 - GetUserNameW](https://github.com/MzHmO/WhoIsWho/tree/main/0x0%20-%20GetUserNameW "0x0 - GetUserNameW") | [0x0 - GetUserNameW](https://github.com/MzHmO/WhoIsWho/tree/main/0x0%20-%20GetUserNameW "0x0 - GetUserNameW") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x1 - GetEnvironmentVariableW](https://github.com/MzHmO/WhoIsWho/tree/main/0x1%20-%20GetEnvironmentVariableW "0x1 - GetEnvironmentVariableW") | [0x1 - GetEnvironmentVariableW](https://github.com/MzHmO/WhoIsWho/tree/main/0x1%20-%20GetEnvironmentVariableW "0x1 - GetEnvironmentVariableW") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x2 - LookupAcccountSidW](https://github.com/MzHmO/WhoIsWho/tree/main/0x2%20-%20LookupAcccountSidW "0x2 - LookupAcccountSidW") | [0x2 - LookupAcccountSidW](https://github.com/MzHmO/WhoIsWho/tree/main/0x2%20-%20LookupAcccountSidW "0x2 - LookupAcccountSidW") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x3 - LsaLookupSids](https://github.com/MzHmO/WhoIsWho/tree/main/0x3%20-%20LsaLookupSids "0x3 - LsaLookupSids") | [0x3 - LsaLookupSids](https://github.com/MzHmO/WhoIsWho/tree/main/0x3%20-%20LsaLookupSids "0x3 - LsaLookupSids") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x4 - RTL\_USER\_PROCESS\_PARAMETERS](https://github.com/MzHmO/WhoIsWho/tree/main/0x4%20-%20RTL_USER_PROCESS_PARAMETERS "0x4 - RTL_USER_PROCESS_PARAMETERS") | [0x4 - RTL\_USER\_PROCESS\_PARAMETERS](https://github.com/MzHmO/WhoIsWho/tree/main/0x4%20-%20RTL_USER_PROCESS_PARAMETERS "0x4 - RTL_USER_PROCESS_PARAMETERS") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x5 - NpGetUserName](https://github.com/MzHmO/WhoIsWho/tree/main/0x5%20-%20NpGetUserName "0x5 - NpGetUserName") | [0x5 - NpGetUserName](https://github.com/MzHmO/WhoIsWho/tree/main/0x5%20-%20NpGetUserName "0x5 - NpGetUserName") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x6 - WinNTSystemInfo](https://github.com/MzHmO/WhoIsWho/tree/main/0x6%20-%20WinNTSystemInfo "0x6 - WinNTSystemInfo") | [0x6 - WinNTSystemInfo](https://github.com/MzHmO/WhoIsWho/tree/main/0x6%20-%20WinNTSystemInfo "0x6 - WinNTSystemInfo") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x7 - ADSystemInfo](https://github.com/MzHmO/WhoIsWho/tree/main/0x7%20-%20ADSystemInfo "0x7 - ADSystemInfo") | [0x7 - ADSystemInfo](https://github.com/MzHmO/WhoIsWho/tree/main/0x7%20-%20ADSystemInfo "0x7 - ADSystemInfo") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0x8 - IEnumWbemClassObject](https://github.com/MzHmO/WhoIsWho/tree/main/0x8%20-%20IEnumWbemClassObject "0x8 - IEnumWbemClassObject") | [0x8 - IEnumWbemClassObject](https://github.com/MzHmO/WhoIsWho/tree/main/0x8%20-%20IEnumWbemClassObject "0x8 - IEnumWbemClassObject") | [Add files via upload](https://github.com/MzHmO/WhoIsWho/commit/cc22b07f26d8211fbe7709456a8ee3a34c6b4bfc "Add files via upload") | 2 years agoMar 22, 2024 |
| [0x9 - WTSQuerySessionInformation](https://github.com/MzHmO/WhoIsWho/tree/main/0x9%20-%20WTSQuerySessionInformation "0x9 - WTSQuerySessionInformation") | [0x9 - WTSQuerySessionInformation](https://github.com/MzHmO/WhoIsWho/tree/main/0x9%20-%20WTSQuerySessionInformation "0x9 - WTSQuerySessionInformation") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0xA - ADsComputer](https://github.com/MzHmO/WhoIsWho/tree/main/0xA%20-%20ADsComputer "0xA - ADsComputer") | [0xA - ADsComputer](https://github.com/MzHmO/WhoIsWho/tree/main/0xA%20-%20ADsComputer "0xA - ADsComputer") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0xB - PipeWhoami](https://github.com/MzHmO/WhoIsWho/tree/main/0xB%20-%20PipeWhoami "0xB - PipeWhoami") | [0xB - PipeWhoami](https://github.com/MzHmO/WhoIsWho/tree/main/0xB%20-%20PipeWhoami "0xB - PipeWhoami") | [Small Fixes](https://github.com/MzHmO/WhoIsWho/commit/5541efba210221e83aa86a4101afff6e7311c694 "Small Fixes") | 2 years agoMar 23, 2024 |
| [0xC - CertGetNameString](https://github.com/MzHmO/WhoIsWho/tree/main/0xC%20-%20CertGetNameString "0xC - CertGetNameString") | [0xC - CertGetNameString](https://github.com/MzHmO/WhoIsWho/tree/main/0xC%20-%20CertGetNameString "0xC - CertGetNameString") | [COM Fix](https://github.com/MzHmO/WhoIsWho/commit/5dec2e3b0f9ff96eb4df356c35d71125a5a869bc "COM Fix") | 2 years agoMar 23, 2024 |
| [0xD - IWSMan](https://github.com/MzHmO/WhoIsWho/tree/main/0xD%20-%20IWSMan "0xD - IWSMan") | [0xD - IWSMan](https://github.com/MzHmO/WhoIsWho/tree/main/0xD%20-%20IWSMan "0xD - IWSMan") | [Add files via upload](https://github.com/MzHmO/WhoIsWho/commit/cc382ae4a6a0ebb8406b3c47b5b91e9523557732 "Add files via upload") | 2 years agoMar 23, 2024 |
| [0xE - GetUserProfileDirectory](https://github.com/MzHmO/WhoIsWho/tree/main/0xE%20-%20GetUserProfileDirectory "0xE - GetUserProfileDirectory") | [0xE - GetUserProfileDirectory](https://github.com/MzHmO/WhoIsWho/tree/main/0xE%20-%20GetUserProfileDirectory "0xE - GetUserProfileDirectory") | [Add files via upload](https://github.com/MzHmO/WhoIsWho/commit/ebf24423acee0500a5c3777a96663667d0a0bba1 "Add files via upload") | 2 years agoMar 23, 2024 |
| [0xF - QueryCredentialAttributes](https://github.com/MzHmO/WhoIsWho/tree/main/0xF%20-%20QueryCredentialAttributes "0xF - QueryCredentialAttributes") | [0xF - QueryCredentialAttributes](https://github.com/MzHmO/WhoIsWho/tree/main/0xF%20-%20QueryCredentialAttributes "0xF - QueryCredentialAttributes") | [Add files via upload](https://github.com/MzHmO/WhoIsWho/commit/e200f7a2afb8e19df871099559e08230193fb593 "Add files via upload") | 2 years agoMar 23, 2024 |
| [README.md](https://github.com/MzHmO/WhoIsWho/blob/main/README.md "README.md") | [README.md](https://github.com/MzHmO/WhoIsWho/blob/main/README.md "README.md") | [Update README.md](https://github.com/MzHmO/WhoIsWho/commit/2837daa76cc95dac4361d121baf194479412da75 "Update README.md") | 2 years agoMar 23, 2024 |
| View all files |

## Repository files navigation

# WhoIsWho

[Permalink: WhoIsWho](https://github.com/MzHmO/WhoIsWho#whoiswho)

Alternatives to the command whoami

I recently saw a funny meme about the whoami command. So, that's why i decided to collect all my POC whoami alternatives in one repository.

[![изображение](https://private-user-images.githubusercontent.com/92790655/316228150-9fd72955-efad-4932-97f7-dbcac9feb96a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIzNjYsIm5iZiI6MTc3MTQxMjA2NiwicGF0aCI6Ii85Mjc5MDY1NS8zMTYyMjgxNTAtOWZkNzI5NTUtZWZhZC00OTMyLTk3ZjctZGJjYWM5ZmViOTZhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNTQyNlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTBjYmRiMmQ2MDVhZDMyZTM1NzYwZGQ2NzUyY2M5NWI4MjFiZmU5NjNiNTMxYzFiZDA4NGVjNzhmMjg0Y2VhMDkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.9DFZUoNHz8OPaIe3YwP3yG7QOpSsqHJuaaUqbEOH7uc)](https://private-user-images.githubusercontent.com/92790655/316228150-9fd72955-efad-4932-97f7-dbcac9feb96a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIzNjYsIm5iZiI6MTc3MTQxMjA2NiwicGF0aCI6Ii85Mjc5MDY1NS8zMTYyMjgxNTAtOWZkNzI5NTUtZWZhZC00OTMyLTk3ZjctZGJjYWM5ZmViOTZhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNTQyNlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTBjYmRiMmQ2MDVhZDMyZTM1NzYwZGQ2NzUyY2M5NWI4MjFiZmU5NjNiNTMxYzFiZDA4NGVjNzhmMjg0Y2VhMDkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.9DFZUoNHz8OPaIe3YwP3yG7QOpSsqHJuaaUqbEOH7uc)

## About

Amazing whoami alternatives


### Resources

[Readme](https://github.com/MzHmO/WhoIsWho#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/MzHmO/WhoIsWho).

[Activity](https://github.com/MzHmO/WhoIsWho/activity)

### Stars

[**141**\\
stars](https://github.com/MzHmO/WhoIsWho/stargazers)

### Watchers

[**2**\\
watching](https://github.com/MzHmO/WhoIsWho/watchers)

### Forks

[**21**\\
forks](https://github.com/MzHmO/WhoIsWho/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FMzHmO%2FWhoIsWho&report=MzHmO+%28user%29)

## [Releases](https://github.com/MzHmO/WhoIsWho/releases)

No releases published

## [Packages\  0](https://github.com/users/MzHmO/packages?repo_name=WhoIsWho)

No packages published

## Languages

- [C++100.0%](https://github.com/MzHmO/WhoIsWho/search?l=c%2B%2B)

You can’t perform that action at this time.