# https://github.com/NtDallas/BOF_RunPe

[Skip to content](https://github.com/NtDallas/BOF_RunPe#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/NtDallas/BOF_RunPe) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/NtDallas/BOF_RunPe) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/NtDallas/BOF_RunPe) to refresh your session.Dismiss alert

{{ message }}

[NtDallas](https://github.com/NtDallas)/ **[BOF\_RunPe](https://github.com/NtDallas/BOF_RunPe)** Public

- [Notifications](https://github.com/login?return_to=%2FNtDallas%2FBOF_RunPe) You must be signed in to change notification settings
- [Fork\\
26](https://github.com/login?return_to=%2FNtDallas%2FBOF_RunPe)
- [Star\\
186](https://github.com/login?return_to=%2FNtDallas%2FBOF_RunPe)


BOF to run PE in Cobalt Strike Beacon without console creation


[186\\
stars](https://github.com/NtDallas/BOF_RunPe/stargazers) [26\\
forks](https://github.com/NtDallas/BOF_RunPe/forks) [Branches](https://github.com/NtDallas/BOF_RunPe/branches) [Tags](https://github.com/NtDallas/BOF_RunPe/tags) [Activity](https://github.com/NtDallas/BOF_RunPe/activity)

[Star](https://github.com/login?return_to=%2FNtDallas%2FBOF_RunPe)

[Notifications](https://github.com/login?return_to=%2FNtDallas%2FBOF_RunPe) You must be signed in to change notification settings

# NtDallas/BOF\_RunPe

main

[**1** Branch](https://github.com/NtDallas/BOF_RunPe/branches) [**0** Tags](https://github.com/NtDallas/BOF_RunPe/tags)

[Go to Branches page](https://github.com/NtDallas/BOF_RunPe/branches)[Go to Tags page](https://github.com/NtDallas/BOF_RunPe/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>RtlDallas<br>[Fix problem](https://github.com/NtDallas/BOF_RunPe/commit/9486648a804df46616ad1faba1250124ea1f8252)<br>3 months agoNov 23, 2025<br>[9486648](https://github.com/NtDallas/BOF_RunPe/commit/9486648a804df46616ad1faba1250124ea1f8252) · 3 months agoNov 23, 2025<br>## History<br>[5 Commits](https://github.com/NtDallas/BOF_RunPe/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/NtDallas/BOF_RunPe/commits/main/) 5 Commits |
| [Bin](https://github.com/NtDallas/BOF_RunPe/tree/main/Bin "Bin") | [Bin](https://github.com/NtDallas/BOF_RunPe/tree/main/Bin "Bin") | [Small updates](https://github.com/NtDallas/BOF_RunPe/commit/04502c644bef5a6921e0a75c6b6b8a4e25a271c8 "Small updates") | 3 months agoNov 23, 2025 |
| [Src](https://github.com/NtDallas/BOF_RunPe/tree/main/Src "Src") | [Src](https://github.com/NtDallas/BOF_RunPe/tree/main/Src "Src") | [Add files via upload](https://github.com/NtDallas/BOF_RunPe/commit/41a67642d2c59ece56bc478a65487c48bff5555f "Add files via upload") | 3 months agoNov 22, 2025 |
| [img](https://github.com/NtDallas/BOF_RunPe/tree/main/img "img") | [img](https://github.com/NtDallas/BOF_RunPe/tree/main/img "img") | [Add files via upload](https://github.com/NtDallas/BOF_RunPe/commit/41a67642d2c59ece56bc478a65487c48bff5555f "Add files via upload") | 3 months agoNov 22, 2025 |
| [BOF\_RunPe.cna](https://github.com/NtDallas/BOF_RunPe/blob/main/BOF_RunPe.cna "BOF_RunPe.cna") | [BOF\_RunPe.cna](https://github.com/NtDallas/BOF_RunPe/blob/main/BOF_RunPe.cna "BOF_RunPe.cna") | [Add RunPe.cna](https://github.com/NtDallas/BOF_RunPe/commit/fc4a8ff1b27748d6747dd3e96005dd337ec288ee "Add RunPe.cna") | 3 months agoNov 22, 2025 |
| [Dockerfile](https://github.com/NtDallas/BOF_RunPe/blob/main/Dockerfile "Dockerfile") | [Dockerfile](https://github.com/NtDallas/BOF_RunPe/blob/main/Dockerfile "Dockerfile") | [Add files via upload](https://github.com/NtDallas/BOF_RunPe/commit/41a67642d2c59ece56bc478a65487c48bff5555f "Add files via upload") | 3 months agoNov 22, 2025 |
| [Makefile](https://github.com/NtDallas/BOF_RunPe/blob/main/Makefile "Makefile") | [Makefile](https://github.com/NtDallas/BOF_RunPe/blob/main/Makefile "Makefile") | [Fix problem](https://github.com/NtDallas/BOF_RunPe/commit/9486648a804df46616ad1faba1250124ea1f8252 "Fix problem") | 3 months agoNov 23, 2025 |
| [README.md](https://github.com/NtDallas/BOF_RunPe/blob/main/README.md "README.md") | [README.md](https://github.com/NtDallas/BOF_RunPe/blob/main/README.md "README.md") | [Fix problem](https://github.com/NtDallas/BOF_RunPe/commit/9486648a804df46616ad1faba1250124ea1f8252 "Fix problem") | 3 months agoNov 23, 2025 |
| View all files |

## Repository files navigation

# BOF\_RunPE

[Permalink: BOF_RunPE](https://github.com/NtDallas/BOF_RunPe#bof_runpe)

BOF RunPE is a Beacon Object File for Cobalt Strike that executes PE files entirely in-memory within the beacon process. Unlike traditional fork&run, **no child process is spawned, no console is created, and no pipe is used** \- all output is captured via IAT hooking and redirected to the beacon console.

**Architecture:** x64 only

## Overview

[Permalink: Overview](https://github.com/NtDallas/BOF_RunPe#overview)

```
┌──────────────────────────────────────────────────────────────┐
│                   Cobalt Strike Beacon                       │
│                    (Current Process)                         │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         │  beacon_inline_execute()
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│                    BOF RunPE                                 │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  VxTable + Draugr Initialization                       │  │
│  │  (Syscall Resolution + Stack Spoofing)                 │  │
│  └──────────────────────┬─────────────────────────────────┘  │
│                         │                                    │
│  ┌──────────────────────▼─────────────────────────────────┐  │
│  │  PE Mapping                                            │  │
│  │  - Section Copy    - IAT Patching (with hooks)         │  │
│  │  - Relocations     - Memory Protection                 │  │
│  └──────────────────────┬─────────────────────────────────┘  │
│                         │                                    │
│  ┌──────────────────────▼─────────────────────────────────┐  │
│  │  Thread Execution                                      │  │
│  │  - Spoofed Start Address                               │  │
│  │  - RIP Hijacking to Entry Point                        │  │
│  │  - Output Redirection via Hooks                        │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

## Key Features

[Permalink: Key Features](https://github.com/NtDallas/BOF_RunPe#key-features)

- **No Process Creation**: PE runs inside the beacon process
- **No Console/Pipe**: Output captured via `printf`/`WriteConsole` hooks
- **Multiple Allocation Methods**: Heap, VirtualAlloc, Module Stomping
- **Proxy Loading**: Timer Queue, RegisterWait, or direct calls
- **Ntdll Unhooking**: Optional fresh copy from disk
- **RWX** : Optional allocate memory in RWX
- **Thread Start Spoofing**: Legitimate start address with RIP hijacking

## Configuration Options

[Permalink: Configuration Options](https://github.com/NtDallas/BOF_RunPe#configuration-options)

The behaviorus of BOF can be edited in `Additionals postex` -\> `RunPe Config`

[![Custom BOF](https://github.com/NtDallas/BOF_RunPe/raw/main/img/custom_bof.png)](https://github.com/NtDallas/BOF_RunPe/blob/main/img/custom_bof.png)

### Proxy Methods

[Permalink: Proxy Methods](https://github.com/NtDallas/BOF_RunPe#proxy-methods)

| Method | Description |
| --- | --- |
| `None` | Direct API calls |
| `Draugr` | Stack spoofed API calls |
| `Regwait` | RegisterWaitForSingleObject callback |
| `Timer` | Timer Queue callback |

### Allocation Methods

[Permalink: Allocation Methods](https://github.com/NtDallas/BOF_RunPe#allocation-methods)

| Method | Description |
| --- | --- |
| `Heap` | Private heap via RtlCreateHeap with Draugr |
| `VirtualAlloc` | NtAllocateVirtualMemory with Draugr |
| `Module stomping` | Overwrites legitimate DLL .text section |

### General Options

[Permalink: General Options](https://github.com/NtDallas/BOF_RunPe#general-options)

| Option | Description |
| --- | --- |
| `AllocRWX` | Allocate as RWX (vs RW→RX transition) |
| `UnhookNtdll` | Replace ntdll.dll .text with fresh copy from disk |
| `Timeout` | Execution timeout in milliseconds (0 = infinite) |
| `StompModule` | DLL path for module stomping (e.g., `chakra.dll`) |

### Thread Spoofing

[Permalink: Thread Spoofing](https://github.com/NtDallas/BOF_RunPe#thread-spoofing)

| Option | Description |
| --- | --- |
| `ModuleName` | Legitimate module for start address (e.g., `Kernel32.dll`) |
| `ProcedureName` | Function name within module (e.g., `BaseThreadInitThunk`) |
| `Offset` | Offset from function start |

## Output Capture

[Permalink: Output Capture](https://github.com/NtDallas/BOF_RunPe#output-capture)

All PE output is redirected to the beacon console via IAT hooks. **No console window or named pipe is created.**

| Hooked Function | Target |
| --- | --- |
| `GetCommandLineA/W` | Returns spoofed arguments |
| `__getmainargs` / `__wgetmainargs` | CRT argument initialization |
| `printf` / `wprintf` | BeaconPrintf redirection |
| `WriteConsoleA/W` | BeaconPrintf redirection |
| `__stdio_common_vfprintf` | UCRT print functions |
| `ExitProcess` / `exit` | Converted to ExitThread |

## Evasion Techniques

[Permalink: Evasion Techniques](https://github.com/NtDallas/BOF_RunPe#evasion-techniques)

| Technique | Bypasses |
| --- | --- |
| Indirect Syscalls | Userland API hooks (EDR/AV) |
| Draugr Stack Spoofing | Call stack inspection |
| Thread Start Spoofing | Thread start address analysis |
| Module Stomping | Unbacked memory detection |
| Private Heap Allocation | VirtualAlloc monitoring |
| Ntdll Unhooking | Overwrite in memory ntdll with Ntdll on a disk |
| IAT Hooking (no pipes) | Named pipe monitoring |

## Detection Vectors

[Permalink: Detection Vectors](https://github.com/NtDallas/BOF_RunPe#detection-vectors)

### Kernel Telemetry (ETW-TI)

[Permalink: Kernel Telemetry (ETW-TI)](https://github.com/NtDallas/BOF_RunPe#kernel-telemetry-etw-ti)

NtGetContextThread / NtSetContextThread:

- Thread context manipulation on suspended threads then resume it

Memory Operations:

- NtAllocateMemory allocation, can be in RWX (depend with config)
- NtProtectVirtualMemory transitions (RW → RX)
- Executable memory in heap regions is suspicious (depend with config)
- Module stomping detectable via section hash mismatch (depend with config)

### Behavioral Indicators

[Permalink: Behavioral Indicators](https://github.com/NtDallas/BOF_RunPe#behavioral-indicators)

- Suspended thread created, take the context then change the value of RIP
- Heap memory marked as executable (if memory allocator is heap)
- DLL loaded with `DONT_RESOLVE_DLL_REFERENCES` (if memory allocator is module stomping)
- Ntdll .text section modified (if unhooking enabled)

## Usage

[Permalink: Usage](https://github.com/NtDallas/BOF_RunPe#usage)

### Loading the Script

[Permalink: Loading the Script](https://github.com/NtDallas/BOF_RunPe#loading-the-script)

```
Cobalt Strike → Script Manager → Load → BOF_RunPe.cna
```

### Aggressor Commands

[Permalink: Aggressor Commands](https://github.com/NtDallas/BOF_RunPe#aggressor-commands)

```
beacon> runpe /path/to/binary.exe --arg1 value1
```

[![Mimikatz](https://github.com/NtDallas/BOF_RunPe/raw/main/img/mimikatz_coffee.png)](https://github.com/NtDallas/BOF_RunPe/blob/main/img/mimikatz_coffee.png)

```
beacon> help runpe
```

[![Help](https://github.com/NtDallas/BOF_RunPe/raw/main/img/runpe_help.png)](https://github.com/NtDallas/BOF_RunPe/blob/main/img/runpe_help.png)

## Compilation

[Permalink: Compilation](https://github.com/NtDallas/BOF_RunPe#compilation)

Requires GCC 13 (mingw-w64). Use provided Dockerfile:

```
sudo docker build -t ubuntu-gcc-13 .
sudo docker run --rm -it -v "$PWD":/work -w /work ubuntu-gcc-13:latest make
```

Output: `Bin/runpe.o`

## Limitations

[Permalink: Limitations](https://github.com/NtDallas/BOF_RunPe#limitations)

| Limitation | Description |
| --- | --- |
| **CET** | Control-flow Enforcement Technology may block synthetic stack frames |
| **x64 Only** | No x86/WoW64 support |
| **Kernel Visibility** | Thread creation visible to kernel callbacks |
| **.NET** | Managed executables not supported |

## Credits / Ressources use for dev

[Permalink: Credits / Ressources use for dev](https://github.com/NtDallas/BOF_RunPe#credits--ressources-use-for-dev)

## Repos/blogpost

[Permalink: Repos/blogpost](https://github.com/NtDallas/BOF_RunPe#reposblogpost)

- [https://github.com/susMdT/LoudSunRun](https://github.com/susMdT/LoudSunRun)
- [https://github.com/Octoberfest7/Inline-Execute-PE](https://github.com/Octoberfest7/Inline-Execute-PE)
- [https://www.coresecurity.com/core-labs/articles/running-pes-inline-without-console](https://www.coresecurity.com/core-labs/articles/running-pes-inline-without-console)
- [https://0xdarkvortex.dev/proxying-dll-loads-for-hiding-etwti-stack-tracing/](https://0xdarkvortex.dev/proxying-dll-loads-for-hiding-etwti-stack-tracing/)

## Books

[Permalink: Books](https://github.com/NtDallas/BOF_RunPe#books)

- `Windows Native API Programming` by _Pavel Yosifovich_
- `Windows Internals, Part 1` by _Pavel Yosifovich_
- `Windows Internals, Part 2` by _Andrea Allievi_

## About

BOF to run PE in Cobalt Strike Beacon without console creation


### Resources

[Readme](https://github.com/NtDallas/BOF_RunPe#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/NtDallas/BOF_RunPe).

[Activity](https://github.com/NtDallas/BOF_RunPe/activity)

### Stars

[**186**\\
stars](https://github.com/NtDallas/BOF_RunPe/stargazers)

### Watchers

[**2**\\
watching](https://github.com/NtDallas/BOF_RunPe/watchers)

### Forks

[**26**\\
forks](https://github.com/NtDallas/BOF_RunPe/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FNtDallas%2FBOF_RunPe&report=NtDallas+%28user%29)

## [Releases](https://github.com/NtDallas/BOF_RunPe/releases)

No releases published

## [Packages\  0](https://github.com/users/NtDallas/packages?repo_name=BOF_RunPe)

No packages published

## Languages

- [C++73.4%](https://github.com/NtDallas/BOF_RunPe/search?l=c%2B%2B)
- [C24.6%](https://github.com/NtDallas/BOF_RunPe/search?l=c)
- [Assembly1.5%](https://github.com/NtDallas/BOF_RunPe/search?l=assembly)
- Other0.5%

You can’t perform that action at this time.