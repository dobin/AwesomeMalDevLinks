# https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file

[Skip to content](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file) to refresh your session.Dismiss alert

{{ message }}

[jdu2600](https://github.com/jdu2600)/ **[Windows10EtwEvents](https://github.com/jdu2600/Windows10EtwEvents)** Public

- [Notifications](https://github.com/login?return_to=%2Fjdu2600%2FWindows10EtwEvents) You must be signed in to change notification settings
- [Fork\\
66](https://github.com/login?return_to=%2Fjdu2600%2FWindows10EtwEvents)
- [Star\\
329](https://github.com/login?return_to=%2Fjdu2600%2FWindows10EtwEvents)


Events from all manifest-based and mof-based ETW providers across Windows 10 versions


[329\\
stars](https://github.com/jdu2600/Windows10EtwEvents/stargazers) [66\\
forks](https://github.com/jdu2600/Windows10EtwEvents/forks) [Branches](https://github.com/jdu2600/Windows10EtwEvents/branches) [Tags](https://github.com/jdu2600/Windows10EtwEvents/tags) [Activity](https://github.com/jdu2600/Windows10EtwEvents/activity)

[Star](https://github.com/login?return_to=%2Fjdu2600%2FWindows10EtwEvents)

[Notifications](https://github.com/login?return_to=%2Fjdu2600%2FWindows10EtwEvents) You must be signed in to change notification settings

# jdu2600/Windows10EtwEvents

main

[**1** Branch](https://github.com/jdu2600/Windows10EtwEvents/branches) [**0** Tags](https://github.com/jdu2600/Windows10EtwEvents/tags)

[Go to Branches page](https://github.com/jdu2600/Windows10EtwEvents/branches)[Go to Tags page](https://github.com/jdu2600/Windows10EtwEvents/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![jdu2600](https://avatars.githubusercontent.com/u/53329154?v=4&size=40)](https://github.com/jdu2600)[jdu2600](https://github.com/jdu2600/Windows10EtwEvents/commits?author=jdu2600)<br>[Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da)<br>5 years agoOct 26, 2021<br>[8a8a66f](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da) · 5 years agoOct 26, 2021<br>## History<br>[16 Commits](https://github.com/jdu2600/Windows10EtwEvents/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/jdu2600/Windows10EtwEvents/commits/main/) 16 Commits |
| [\_src](https://github.com/jdu2600/Windows10EtwEvents/tree/main/_src "_src") | [\_src](https://github.com/jdu2600/Windows10EtwEvents/tree/main/_src "_src") | [add source code](https://github.com/jdu2600/Windows10EtwEvents/commit/04f4f5287c35795f172fefe768124f5ee7e9df28 "add source code") | 6 years agoMay 16, 2020 |
| [manifest](https://github.com/jdu2600/Windows10EtwEvents/tree/main/manifest "manifest") | [manifest](https://github.com/jdu2600/Windows10EtwEvents/tree/main/manifest "manifest") | [Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da "Windows 11 21H2") | 5 years agoOct 26, 2021 |
| [mof](https://github.com/jdu2600/Windows10EtwEvents/tree/main/mof "mof") | [mof](https://github.com/jdu2600/Windows10EtwEvents/tree/main/mof "mof") | [Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da "Windows 11 21H2") | 5 years agoOct 26, 2021 |
| [unknown](https://github.com/jdu2600/Windows10EtwEvents/tree/main/unknown "unknown") | [unknown](https://github.com/jdu2600/Windows10EtwEvents/tree/main/unknown "unknown") | [Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da "Windows 11 21H2") | 5 years agoOct 26, 2021 |
| [README.md](https://github.com/jdu2600/Windows10EtwEvents/blob/main/README.md "README.md") | [README.md](https://github.com/jdu2600/Windows10EtwEvents/blob/main/README.md "README.md") | [Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da "Windows 11 21H2") | 5 years agoOct 26, 2021 |
| [version.txt](https://github.com/jdu2600/Windows10EtwEvents/blob/main/version.txt "version.txt") | [version.txt](https://github.com/jdu2600/Windows10EtwEvents/blob/main/version.txt "version.txt") | [Windows 11 21H2](https://github.com/jdu2600/Windows10EtwEvents/commit/8a8a66f7a4becc0cabaa1640d4e874f7a75af3da "Windows 11 21H2") | 5 years agoOct 26, 2021 |
| View all files |

## Repository files navigation

# Windows 10 ETW Events

[Permalink: Windows 10 ETW Events](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file#windows-10-etw-events)

Events from all manifest-based and mof-based ETW providers across Windows 10 versions

| Version | Events | Manifest Providers | MOF Providers | Unknown Providers |
| --- | --- | --- | --- | --- |
| 1511 | 43,319 | 811 | 195 | 24 |
| 1607 | 45,569 | 830 | 193 | 23 |
| 1703 | 46,532 | 842 | 194 | 31 |
| 1709 | 47,687 | 854 | 193 | 28 |
| 1803 | 48,226 | 855 | 192 | 29 |
| 1809 | 49,080 | 863 | 190 | 25 |
| 1903 | 49,734 | 867 | 187 | 24 |
| 1909 | 49,773 | 868 | 187 | 24 |
| 2004 | 50,391 | 871 | 187 | 25 |
| 2009 | 50,399 | 872 | 187 | 25 |
| 21H1 | 50,505 | 871 | 187 | 28 |
| 21H2 | 51,696 | 876 | 187 | 25 |

## Want the data in a different format?

[Permalink: Want the data in a different format?](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file#want-the-data-in-a-different-format)

Roberto Rodriguez [@Cyb3rWard0g](https://twitter.com/Cyb3rWard0g)

- [https://github.com/hunters-forge/OSSEM/tree/master/data\_dictionaries/windows/etw/json](https://github.com/hunters-forge/OSSEM/tree/master/data_dictionaries/windows/etw/json) \- JSON
- [https://github.com/hunters-forge/OSSEM/tree/yaml/data\_dictionaries/yaml/windows](https://github.com/hunters-forge/OSSEM/tree/yaml/data_dictionaries/yaml/windows) \- YAML

## Useful references

[Permalink: Useful references](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file#useful-references)

Microsoft

- [https://docs.microsoft.com/en-us/windows/win32/etw/event-metadata-overview](https://docs.microsoft.com/en-us/windows/win32/etw/event-metadata-overview)
- [https://github.com/microsoft/perfview](https://github.com/microsoft/perfview)
- [https://github.com/microsoft/krabsetw](https://github.com/microsoft/krabsetw)

Matt Graeber [@mattifestation](https://twitter.com/mattifestation)

- [https://medium.com/palantir/tampering-with-windows-event-tracing-background-offense-and-defense-4be7ac62ac63](https://medium.com/palantir/tampering-with-windows-event-tracing-background-offense-and-defense-4be7ac62ac63)
- [https://posts.specterops.io/data-source-analysis-and-dynamic-windows-re-using-wpp-and-tracelogging-e465f8b653f7](https://posts.specterops.io/data-source-analysis-and-dynamic-windows-re-using-wpp-and-tracelogging-e465f8b653f7)
- [How do I detect technique X in Windows?](https://drive.google.com/file/d/19AhMG0ZCOt0IVsPZgn4JalkdcUOGq4DK/view), DerbyCon 2019
- [https://github.com/mattifestation/WindowsEventLogMetadata](https://github.com/mattifestation/WindowsEventLogMetadata)
- [https://gist.github.com/mattifestation/04e8299d8bc97ef825affe733310f7bd](https://gist.github.com/mattifestation/04e8299d8bc97ef825affe733310f7bd) \- NiftyETWProviders.json
- [https://gist.github.com/mattifestation/edbac1614694886c8ef4583149f53658](https://gist.github.com/mattifestation/edbac1614694886c8ef4583149f53658) \- TLGMetadataParser.psm1

Nasreddine Bencherchali [@nasbench](https://twitter.com/nas_bench)

- [https://github.com/nasbench/ETW-Resources#blogs--research-httpsnasbenchmediumcom](https://github.com/nasbench/ETW-Resources#blogs--research-httpsnasbenchmediumcom)
- [https://github.com/nasbench/ETW-Resources](https://github.com/nasbench/ETW-Resources) \- XML manifests

Pat H [@pathtofile](https://twitter.com/pathtofile)

- [https://blog.tofile.dev/categories/#etw](https://blog.tofile.dev/categories/#etw)
- [https://github.com/pathtofile/Sealighter](https://github.com/pathtofile/Sealighter)
- [https://github.com/pathtofile/SealighterTI](https://github.com/pathtofile/SealighterTI)

Zac Brown [@zacbrown](https://twitter.com/zacbrown)

- [https://zacbrown.org/2017/04/11/hidden-treasure-intrusion-detection-with-etw-part-1](https://zacbrown.org/2017/04/11/hidden-treasure-intrusion-detection-with-etw-part-1)
- [https://zacbrown.org/2017/05/9/hidden-treasure-intrusion-detection-with-etw-part-2](https://zacbrown.org/2017/05/9/hidden-treasure-intrusion-detection-with-etw-part-2)
- [https://github.com/zacbrown/hiddentreasure-etw-demo](https://github.com/zacbrown/hiddentreasure-etw-demo)

Ruben Boonen [@FuzzySec](https://twitter.com/FuzzySec)

- [https://www.fireeye.com/blog/threat-research/2019/03/silketw-because-free-telemetry-is-free.html](https://www.fireeye.com/blog/threat-research/2019/03/silketw-because-free-telemetry-is-free.html)
- [https://github.com/fireeye/SilkETW](https://github.com/fireeye/SilkETW)

Pavel Yosifovich [@zodiacon](https://twitter.com/zodiacon)

- [https://github.com/zodiacon/EtwExplorer](https://github.com/zodiacon/EtwExplorer)
- [https://github.com/zodiacon/ProcMonX](https://github.com/zodiacon/ProcMonX)

Elias Bachaalany [@0xeb](https://twitter.com/0xeb)

- [https://github.com/lallousx86/WinTools/tree/master/WEPExplorer](https://github.com/lallousx86/WinTools/tree/master/WEPExplorer)

## About

Events from all manifest-based and mof-based ETW providers across Windows 10 versions


### Resources

[Readme](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file).

[Activity](https://github.com/jdu2600/Windows10EtwEvents/activity)

### Stars

[**329**\\
stars](https://github.com/jdu2600/Windows10EtwEvents/stargazers)

### Watchers

[**11**\\
watching](https://github.com/jdu2600/Windows10EtwEvents/watchers)

### Forks

[**66**\\
forks](https://github.com/jdu2600/Windows10EtwEvents/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fjdu2600%2FWindows10EtwEvents&report=jdu2600+%28user%29)

## [Releases](https://github.com/jdu2600/Windows10EtwEvents/releases)

No releases published

## [Packages\  0](https://github.com/users/jdu2600/packages?repo_name=Windows10EtwEvents)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/jdu2600/Windows10EtwEvents?tab=readme-ov-file).

## Languages

- [C#100.0%](https://github.com/jdu2600/Windows10EtwEvents/search?l=c%23)

You can’t perform that action at this time.