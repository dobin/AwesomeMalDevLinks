# https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src/ETW

[Skip to content](https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src/ETW#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src/ETW) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src/ETW) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src/ETW) to refresh your session.Dismiss alert

{{ message }}

[jdu2600](https://github.com/jdu2600)/ **[Etw-SyscallMonitor](https://github.com/jdu2600/Etw-SyscallMonitor)** Public

- [Notifications](https://github.com/login?return_to=%2Fjdu2600%2FEtw-SyscallMonitor) You must be signed in to change notification settings
- [Fork\\
11](https://github.com/login?return_to=%2Fjdu2600%2FEtw-SyscallMonitor)
- [Star\\
87](https://github.com/login?return_to=%2Fjdu2600%2FEtw-SyscallMonitor)


## Collapse file tree

## Files

main

Search this repository

/

# ETW

/

Copy path

## Directory actions

## More options

More options

## Directory actions

## More options

More options

## Latest commit

![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)

John Uhlmann

[BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b)

3 years agoMay 17, 2023

[62a2dfb](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b) · 3 years agoMay 17, 2023

## History

[History](https://github.com/jdu2600/Etw-SyscallMonitor/commits/main/src/ETW)

Open commit details

[View commit history for this file.](https://github.com/jdu2600/Etw-SyscallMonitor/commits/main/src/ETW) History

/

# ETW

/

Top

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ### parent directory<br> [..](https://github.com/jdu2600/Etw-SyscallMonitor/tree/main/src) |
| [EtwUserTrace.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/EtwUserTrace.cs "EtwUserTrace.cs") | [EtwUserTrace.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/EtwUserTrace.cs "EtwUserTrace.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [EtwUserTraceProvider.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/EtwUserTraceProvider.cs "EtwUserTraceProvider.cs") | [EtwUserTraceProvider.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/EtwUserTraceProvider.cs "EtwUserTraceProvider.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [MIcrosoft-Windows-Threat-Intelligence.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/MIcrosoft-Windows-Threat-Intelligence.cs "MIcrosoft-Windows-Threat-Intelligence.cs") | [MIcrosoft-Windows-Threat-Intelligence.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/MIcrosoft-Windows-Threat-Intelligence.cs "MIcrosoft-Windows-Threat-Intelligence.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-Audit-API-Calls.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Audit-API-Calls.cs "Microsoft-Windows-Kernel-Audit-API-Calls.cs") | [Microsoft-Windows-Kernel-Audit-API-Calls.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Audit-API-Calls.cs "Microsoft-Windows-Kernel-Audit-API-Calls.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-EventTracing.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-EventTracing.cs "Microsoft-Windows-Kernel-EventTracing.cs") | [Microsoft-Windows-Kernel-EventTracing.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-EventTracing.cs "Microsoft-Windows-Kernel-EventTracing.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-File.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-File.cs "Microsoft-Windows-Kernel-File.cs") | [Microsoft-Windows-Kernel-File.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-File.cs "Microsoft-Windows-Kernel-File.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-Network.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Network.cs "Microsoft-Windows-Kernel-Network.cs") | [Microsoft-Windows-Kernel-Network.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Network.cs "Microsoft-Windows-Kernel-Network.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-Process.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Process.cs "Microsoft-Windows-Kernel-Process.cs") | [Microsoft-Windows-Kernel-Process.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Process.cs "Microsoft-Windows-Kernel-Process.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Kernel-Registry.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Registry.cs "Microsoft-Windows-Kernel-Registry.cs") | [Microsoft-Windows-Kernel-Registry.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Kernel-Registry.cs "Microsoft-Windows-Kernel-Registry.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Security-Auditing.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Security-Auditing.cs "Microsoft-Windows-Security-Auditing.cs") | [Microsoft-Windows-Security-Auditing.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Security-Auditing.cs "Microsoft-Windows-Security-Auditing.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-WFP.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-WFP.cs "Microsoft-Windows-WFP.cs") | [Microsoft-Windows-WFP.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-WFP.cs "Microsoft-Windows-WFP.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| [Microsoft-Windows-Win32k.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Win32k.cs "Microsoft-Windows-Win32k.cs") | [Microsoft-Windows-Win32k.cs](https://github.com/jdu2600/Etw-SyscallMonitor/blob/main/src/ETW/Microsoft-Windows-Win32k.cs "Microsoft-Windows-Win32k.cs") | [BHASIA2023](https://github.com/jdu2600/Etw-SyscallMonitor/commit/62a2dfbeaca6bacad6247799d504e29078ca334b "BHASIA2023") | 3 years agoMay 17, 2023 |
| View all files |

You can’t perform that action at this time.