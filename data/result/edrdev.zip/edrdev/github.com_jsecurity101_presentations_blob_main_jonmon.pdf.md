# https://github.com/jsecurity101/Presentations/blob/main/JonMon.pdf

[Skip to content](https://github.com/jonny-jhnson/Presentations/blob/main/JonMon.pdf#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/jonny-jhnson/Presentations/blob/main/JonMon.pdf) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/jonny-jhnson/Presentations/blob/main/JonMon.pdf) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/jonny-jhnson/Presentations/blob/main/JonMon.pdf) to refresh your session.Dismiss alert

{{ message }}

[jonny-jhnson](https://github.com/jonny-jhnson)/ **[Presentations](https://github.com/jonny-jhnson/Presentations)** Public

- [Notifications](https://github.com/login?return_to=%2Fjonny-jhnson%2FPresentations) You must be signed in to change notification settings
- [Fork\\
2](https://github.com/login?return_to=%2Fjonny-jhnson%2FPresentations)
- [Star\\
9](https://github.com/login?return_to=%2Fjonny-jhnson%2FPresentations)


## Collapse file tree

## Files

main

Search this repository

/

# JonMon.pdf

Copy path

More file actions

More file actions

## Latest commit

[![jonny-jhnson](https://avatars.githubusercontent.com/u/29631806?v=4&size=40)](https://github.com/jonny-jhnson)[jonny-jhnson](https://github.com/jonny-jhnson/Presentations/commits?author=jonny-jhnson)

[Add files via upload](https://github.com/jonny-jhnson/Presentations/commit/44be89517f6cdfaa0fd556e73f09dbc106807101)

3 years agoSep 28, 2023

[44be895](https://github.com/jonny-jhnson/Presentations/commit/44be89517f6cdfaa0fd556e73f09dbc106807101) · 3 years agoSep 28, 2023

## History

[History](https://github.com/jonny-jhnson/Presentations/commits/main/JonMon.pdf)

Open commit details

[View commit history for this file.](https://github.com/jonny-jhnson/Presentations/commits/main/JonMon.pdf) History

2.54 MB

/

# JonMon.pdf

Top

## File metadata and controls

2.54 MB

Download raw file

Edit and raw actions

Loading

Render

You can’t perform that action at this time.