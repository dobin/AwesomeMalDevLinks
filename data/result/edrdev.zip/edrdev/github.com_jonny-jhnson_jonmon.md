# https://github.com/jonny-jhnson/JonMon

[Skip to content](https://github.com/jonny-jhnson/JonMon#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/jonny-jhnson/JonMon) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/jonny-jhnson/JonMon) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/jonny-jhnson/JonMon) to refresh your session.Dismiss alert

{{ message }}

[jonny-jhnson](https://github.com/jonny-jhnson)/ **[JonMon](https://github.com/jonny-jhnson/JonMon)** Public

- [Notifications](https://github.com/login?return_to=%2Fjonny-jhnson%2FJonMon) You must be signed in to change notification settings
- [Fork\\
32](https://github.com/login?return_to=%2Fjonny-jhnson%2FJonMon)
- [Star\\
251](https://github.com/login?return_to=%2Fjonny-jhnson%2FJonMon)


### License

[MIT license](https://github.com/jonny-jhnson/JonMon/blob/main/LICENSE)

[251\\
stars](https://github.com/jonny-jhnson/JonMon/stargazers) [32\\
forks](https://github.com/jonny-jhnson/JonMon/forks) [Branches](https://github.com/jonny-jhnson/JonMon/branches) [Tags](https://github.com/jonny-jhnson/JonMon/tags) [Activity](https://github.com/jonny-jhnson/JonMon/activity)

[Star](https://github.com/login?return_to=%2Fjonny-jhnson%2FJonMon)

[Notifications](https://github.com/login?return_to=%2Fjonny-jhnson%2FJonMon) You must be signed in to change notification settings

# jonny-jhnson/JonMon

main

[Branches](https://github.com/jonny-jhnson/JonMon/branches) [Tags](https://github.com/jonny-jhnson/JonMon/tags)

[Go to Branches page](https://github.com/jonny-jhnson/JonMon/branches)[Go to Tags page](https://github.com/jonny-jhnson/JonMon/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![jonny-jhnson](https://avatars.githubusercontent.com/u/29631806?v=4&size=40)](https://github.com/jonny-jhnson)[jonny-jhnson](https://github.com/jonny-jhnson/JonMon/commits?author=jonny-jhnson)<br>[Updating to FltGetRequestorProcessId](https://github.com/jonny-jhnson/JonMon/commit/ce5de1c7c647b972da096acee57540bb72854dd5)<br>8 months agoJun 7, 2025<br>[ce5de1c](https://github.com/jonny-jhnson/JonMon/commit/ce5de1c7c647b972da096acee57540bb72854dd5) · 8 months agoJun 7, 2025<br>## History<br>[17 Commits](https://github.com/jonny-jhnson/JonMon/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/jonny-jhnson/JonMon/commits/main/) 17 Commits |
| [.github/ISSUE\_TEMPLATE](https://github.com/jonny-jhnson/JonMon/tree/main/.github/ISSUE_TEMPLATE "This path skips through empty directories") | [.github/ISSUE\_TEMPLATE](https://github.com/jonny-jhnson/JonMon/tree/main/.github/ISSUE_TEMPLATE "This path skips through empty directories") | [Initial commit for TCS](https://github.com/jonny-jhnson/JonMon/commit/a4a067d16f7f4dd10fad94c05697f3feb2e0239e "Initial commit for TCS") | 3 years agoSep 26, 2023 |
| [Extensions/Extension1/JonMon-Ext1](https://github.com/jonny-jhnson/JonMon/tree/main/Extensions/Extension1/JonMon-Ext1 "This path skips through empty directories") | [Extensions/Extension1/JonMon-Ext1](https://github.com/jonny-jhnson/JonMon/tree/main/Extensions/Extension1/JonMon-Ext1 "This path skips through empty directories") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| [JonMon-Service](https://github.com/jonny-jhnson/JonMon/tree/main/JonMon-Service "JonMon-Service") | [JonMon-Service](https://github.com/jonny-jhnson/JonMon/tree/main/JonMon-Service "JonMon-Service") | [Updating VS Config](https://github.com/jonny-jhnson/JonMon/commit/cc519d90f12e8fc447a6a8507838e50c660aaa48 "Updating VS Config") | last yearJan 27, 2025 |
| [JonMon](https://github.com/jonny-jhnson/JonMon/tree/main/JonMon "JonMon") | [JonMon](https://github.com/jonny-jhnson/JonMon/tree/main/JonMon "JonMon") | [Updating to FltGetRequestorProcessId](https://github.com/jonny-jhnson/JonMon/commit/ce5de1c7c647b972da096acee57540bb72854dd5 "Updating to FltGetRequestorProcessId") | 8 months agoJun 7, 2025 |
| [JonMonProvider](https://github.com/jonny-jhnson/JonMon/tree/main/JonMonProvider "JonMonProvider") | [JonMonProvider](https://github.com/jonny-jhnson/JonMon/tree/main/JonMonProvider "JonMonProvider") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| [Libs/nlohmann](https://github.com/jonny-jhnson/JonMon/tree/main/Libs/nlohmann "This path skips through empty directories") | [Libs/nlohmann](https://github.com/jonny-jhnson/JonMon/tree/main/Libs/nlohmann "This path skips through empty directories") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| [deployment/Azure](https://github.com/jonny-jhnson/JonMon/tree/main/deployment/Azure "This path skips through empty directories") | [deployment/Azure](https://github.com/jonny-jhnson/JonMon/tree/main/deployment/Azure "This path skips through empty directories") | [image not used](https://github.com/jonny-jhnson/JonMon/commit/59c9f361c4491302e229d4bdc8287f78c8104b22 "image not used") | 3 years agoSep 29, 2023 |
| [.gitignore](https://github.com/jonny-jhnson/JonMon/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/jonny-jhnson/JonMon/blob/main/.gitignore ".gitignore") | [Update .gitignore](https://github.com/jonny-jhnson/JonMon/commit/6f5cbe82db1f9721ce811d5cf46d175ed792269a "Update .gitignore") | last yearJan 27, 2025 |
| [JonMonConfig.json](https://github.com/jonny-jhnson/JonMon/blob/main/JonMonConfig.json "JonMonConfig.json") | [JonMonConfig.json](https://github.com/jonny-jhnson/JonMon/blob/main/JonMonConfig.json "JonMonConfig.json") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| [JonMonv2.0-official.jpg](https://github.com/jonny-jhnson/JonMon/blob/main/JonMonv2.0-official.jpg "JonMonv2.0-official.jpg") | [JonMonv2.0-official.jpg](https://github.com/jonny-jhnson/JonMon/blob/main/JonMonv2.0-official.jpg "JonMonv2.0-official.jpg") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| [LICENSE](https://github.com/jonny-jhnson/JonMon/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/jonny-jhnson/JonMon/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/jonny-jhnson/JonMon/commit/0fb20b4cb26227b354c61eae46a8f0ce23c90c2b "Initial commit") | 3 years agoSep 26, 2023 |
| [README.md](https://github.com/jonny-jhnson/JonMon/blob/main/README.md "README.md") | [README.md](https://github.com/jonny-jhnson/JonMon/blob/main/README.md "README.md") | [JonMon2.0](https://github.com/jonny-jhnson/JonMon/commit/a8bc7ca6ae2e990c1613610d6d43dac18bf195e6 "JonMon2.0") | last yearJan 27, 2025 |
| View all files |

## Repository files navigation

# JonMon v2.0

[Permalink: JonMon v2.0](https://github.com/jonny-jhnson/JonMon#jonmon-v20)

JonMon is a research project I started to help me learn how to code and understand telemetry mechanisms. It is a collection of open-source telemetry sensors designed to provide users with visibility into the operations and activity of their Windows systems. JonMon has a kernel-level driver component, which is designed to collect information related to system operations such as process creation, registry operations, file creates and more.

In addition to the kernel-level driver component, JonMon also features a user-mode component that collects information about .NET, RPC, network activity, and other important system events. By combining data from both the kernel-level and user-mode components, JonMon provides users with a comprehensive view of their security activity.

The data collected by both components is made easily accessible to users through the Windows event log, allowing users to quickly and easily query the data and gain insights into their system operations.

JonMon started and will continue to be a research project that allows for easy telemetry testing and verification.

## Disclaimer

[Permalink: Disclaimer](https://github.com/jonny-jhnson/JonMon#disclaimer)

JonMon v2.0 is a research project and is not meant to run in production environments and is not guaranteed to work. Any issues you might have, please submit a detailed issue and I will take a look when I have time.

Being that this is a project to help me learn how to code, I understand some things will not be perfect and there will be bugs. Issues are welcome, but may not always be addressed.

# JonMon Guide

[Permalink: JonMon Guide](https://github.com/jonny-jhnson/JonMon#jonmon-guide)

For all things on JonMon, please visit the [wiki](https://github.com/jsecurity101/JonMon/wiki#installation).

### Quick Links

[Permalink: Quick Links](https://github.com/jonny-jhnson/JonMon#quick-links)

- [Installation](https://github.com/jsecurity101/JonMon/wiki#installation)
- [Event Mapping](https://github.com/jsecurity101/JonMon/wiki/Event-Mapping)
- [JonMon Configuration File](https://github.com/jsecurity101/JonMon/wiki/JonMon-Configuration-File)

### JonMon Diagram

[Permalink: JonMon Diagram](https://github.com/jonny-jhnson/JonMon#jonmon-diagram)

[![alt text](https://github.com/jonny-jhnson/JonMon/raw/main/JonMonv2.0-official.jpg)](https://github.com/jonny-jhnson/JonMon/blob/main/JonMonv2.0-official.jpg)

# External Libraries

[Permalink: External Libraries](https://github.com/jonny-jhnson/JonMon#external-libraries)

- [json by nlohmann](https://github.com/nlohmann/json)

# Acknowledgement

[Permalink: Acknowledgement](https://github.com/jonny-jhnson/JonMon#acknowledgement)

A special thanks to the following people for either testing out JonMon or giving programming/debugging guidance:

- [Olaf Hartong](https://x.com/olafhartong)
- [Connor McGarr](https://x.com/33y0re)

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/jonny-jhnson/JonMon#readme-ov-file)

### License

[MIT license](https://github.com/jonny-jhnson/JonMon#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/jonny-jhnson/JonMon).

[Activity](https://github.com/jonny-jhnson/JonMon/activity)

### Stars

[**251**\\
stars](https://github.com/jonny-jhnson/JonMon/stargazers)

### Watchers

[**4**\\
watching](https://github.com/jonny-jhnson/JonMon/watchers)

### Forks

[**32**\\
forks](https://github.com/jonny-jhnson/JonMon/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fjonny-jhnson%2FJonMon&report=jonny-jhnson+%28user%29)

## [Releases\  4](https://github.com/jonny-jhnson/JonMon/releases)

[JonMon v2.0.1\\
Latest\\
\\
on Jun 7, 2025Jun 7, 2025](https://github.com/jonny-jhnson/JonMon/releases/tag/2.0.1)

[\+ 3 releases](https://github.com/jonny-jhnson/JonMon/releases)

## [Packages\  0](https://github.com/users/jonny-jhnson/packages?repo_name=JonMon)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/jonny-jhnson/JonMon).

## [Contributors\  2](https://github.com/jonny-jhnson/JonMon/graphs/contributors)

- [![@jonny-jhnson](https://avatars.githubusercontent.com/u/29631806?s=64&v=4)](https://github.com/jonny-jhnson)[**jonny-jhnson** Jonathan Johnson](https://github.com/jonny-jhnson)
- [![@Cyb3rWard0g](https://avatars.githubusercontent.com/u/9653181?s=64&v=4)](https://github.com/Cyb3rWard0g)[**Cyb3rWard0g** Roberto Rodriguez](https://github.com/Cyb3rWard0g)

## Languages

- [C++79.9%](https://github.com/jonny-jhnson/JonMon/search?l=c%2B%2B)
- [C13.8%](https://github.com/jonny-jhnson/JonMon/search?l=c)
- [Roff6.3%](https://github.com/jonny-jhnson/JonMon/search?l=roff)

You can’t perform that action at this time.