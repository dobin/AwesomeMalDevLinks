# https://github.com/sensepost/mydumbedr

[Skip to content](https://github.com/sensepost/mydumbedr#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/sensepost/mydumbedr) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/sensepost/mydumbedr) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/sensepost/mydumbedr) to refresh your session.Dismiss alert

{{ message }}

[sensepost](https://github.com/sensepost)/ **[mydumbedr](https://github.com/sensepost/mydumbedr)** Public

- [Notifications](https://github.com/login?return_to=%2Fsensepost%2Fmydumbedr) You must be signed in to change notification settings
- [Fork\\
17](https://github.com/login?return_to=%2Fsensepost%2Fmydumbedr)
- [Star\\
120](https://github.com/login?return_to=%2Fsensepost%2Fmydumbedr)


### License

[GPL-3.0 license](https://github.com/sensepost/mydumbedr/blob/main/LICENSE)

[120\\
stars](https://github.com/sensepost/mydumbedr/stargazers) [17\\
forks](https://github.com/sensepost/mydumbedr/forks) [Branches](https://github.com/sensepost/mydumbedr/branches) [Tags](https://github.com/sensepost/mydumbedr/tags) [Activity](https://github.com/sensepost/mydumbedr/activity)

[Star](https://github.com/login?return_to=%2Fsensepost%2Fmydumbedr)

[Notifications](https://github.com/login?return_to=%2Fsensepost%2Fmydumbedr) You must be signed in to change notification settings

# sensepost/mydumbedr

main

[**1** Branch](https://github.com/sensepost/mydumbedr/branches) [**0** Tags](https://github.com/sensepost/mydumbedr/tags)

[Go to Branches page](https://github.com/sensepost/mydumbedr/branches)[Go to Tags page](https://github.com/sensepost/mydumbedr/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Dfte](https://avatars.githubusercontent.com/u/23189983?v=4&size=40)](https://github.com/Dfte)[Dfte](https://github.com/sensepost/mydumbedr/commits?author=Dfte)<br>[Update README.md](https://github.com/sensepost/mydumbedr/commit/cc84163d4138f59324f5c2a56ba896dc3a285240)<br>2 years agoJan 30, 2024<br>[cc84163](https://github.com/sensepost/mydumbedr/commit/cc84163d4138f59324f5c2a56ba896dc3a285240) · 2 years agoJan 30, 2024<br>## History<br>[7 Commits](https://github.com/sensepost/mydumbedr/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/sensepost/mydumbedr/commits/main/) 7 Commits |
| [MyDumbEDRDLL](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRDLL "MyDumbEDRDLL") | [MyDumbEDRDLL](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRDLL "MyDumbEDRDLL") | [Remove x64 directories](https://github.com/sensepost/mydumbedr/commit/6a844f1fff3a0538c2e5afdd68a3698eb09ba011 "Remove x64 directories") | 2 years agoJan 30, 2024 |
| [MyDumbEDRDriver](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRDriver "MyDumbEDRDriver") | [MyDumbEDRDriver](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRDriver "MyDumbEDRDriver") | [Remove x64 directories](https://github.com/sensepost/mydumbedr/commit/6a844f1fff3a0538c2e5afdd68a3698eb09ba011 "Remove x64 directories") | 2 years agoJan 30, 2024 |
| [MyDumbEDRRemoteInjector](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRRemoteInjector "MyDumbEDRRemoteInjector") | [MyDumbEDRRemoteInjector](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRRemoteInjector "MyDumbEDRRemoteInjector") | [Remove x64 directories](https://github.com/sensepost/mydumbedr/commit/6a844f1fff3a0538c2e5afdd68a3698eb09ba011 "Remove x64 directories") | 2 years agoJan 30, 2024 |
| [MyDumbEDRStaticAnalyzer](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRStaticAnalyzer "MyDumbEDRStaticAnalyzer") | [MyDumbEDRStaticAnalyzer](https://github.com/sensepost/mydumbedr/tree/main/MyDumbEDRStaticAnalyzer "MyDumbEDRStaticAnalyzer") | [Remove x64 directories](https://github.com/sensepost/mydumbedr/commit/6a844f1fff3a0538c2e5afdd68a3698eb09ba011 "Remove x64 directories") | 2 years agoJan 30, 2024 |
| [ShellcodeInject](https://github.com/sensepost/mydumbedr/tree/main/ShellcodeInject "ShellcodeInject") | [ShellcodeInject](https://github.com/sensepost/mydumbedr/tree/main/ShellcodeInject "ShellcodeInject") | [Remove x64 directories](https://github.com/sensepost/mydumbedr/commit/6a844f1fff3a0538c2e5afdd68a3698eb09ba011 "Remove x64 directories") | 2 years agoJan 30, 2024 |
| [LICENSE](https://github.com/sensepost/mydumbedr/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/sensepost/mydumbedr/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/sensepost/mydumbedr/commit/c91e6753864ed148c735120302a28be771fbe24f "Initial commit") | 2 years agoJan 30, 2024 |
| [MyDumbEDR.sln](https://github.com/sensepost/mydumbedr/blob/main/MyDumbEDR.sln "MyDumbEDR.sln") | [MyDumbEDR.sln](https://github.com/sensepost/mydumbedr/blob/main/MyDumbEDR.sln "MyDumbEDR.sln") | [First commit](https://github.com/sensepost/mydumbedr/commit/2c3defd1a1e455b56e4bdc645f9054b0065c9fbd "First commit") | 2 years agoJan 30, 2024 |
| [README.md](https://github.com/sensepost/mydumbedr/blob/main/README.md "README.md") | [README.md](https://github.com/sensepost/mydumbedr/blob/main/README.md "README.md") | [Update README.md](https://github.com/sensepost/mydumbedr/commit/cc84163d4138f59324f5c2a56ba896dc3a285240 "Update README.md") | 2 years agoJan 30, 2024 |
| [create.bat](https://github.com/sensepost/mydumbedr/blob/main/create.bat "create.bat") | [create.bat](https://github.com/sensepost/mydumbedr/blob/main/create.bat "create.bat") | [First commit](https://github.com/sensepost/mydumbedr/commit/2c3defd1a1e455b56e4bdc645f9054b0065c9fbd "First commit") | 2 years agoJan 30, 2024 |
| [launch.bat](https://github.com/sensepost/mydumbedr/blob/main/launch.bat "launch.bat") | [launch.bat](https://github.com/sensepost/mydumbedr/blob/main/launch.bat "launch.bat") | [First commit](https://github.com/sensepost/mydumbedr/commit/2c3defd1a1e455b56e4bdc645f9054b0065c9fbd "First commit") | 2 years agoJan 30, 2024 |
| View all files |

## Repository files navigation

# MyDumbEDR

[Permalink: MyDumbEDR](https://github.com/sensepost/mydumbedr#mydumbedr)

This repo contains all the necessary files to run the MyDumbEDR and try to bypass.

## To run the project

[Permalink: To run the project](https://github.com/sensepost/mydumbedr#to-run-the-project)

First you'll have to open the .sln file in Visual Studio 2019 and compile the projects (required stuffs is described in the blogpsot.)

Then you can open the create.bat file and replace absolute links and finally run the bat script which will launch everything :)

For more information about building the project, please take a look at \[URL BLOG\]

## Rules

[Permalink: Rules](https://github.com/sensepost/mydumbedr#rules)

The game is simple, bypass the EDR. I wrote code that is voluntary buggued so I strongly encourage you reading the source code of the differents components. This bugued code mimics things that you can encounter while fighting against real EDR's so... Have fun :)

Happy hacking!

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/sensepost/mydumbedr#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/sensepost/mydumbedr#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/sensepost/mydumbedr).

[Activity](https://github.com/sensepost/mydumbedr/activity)

[Custom properties](https://github.com/sensepost/mydumbedr/custom-properties)

### Stars

[**120**\\
stars](https://github.com/sensepost/mydumbedr/stargazers)

### Watchers

[**3**\\
watching](https://github.com/sensepost/mydumbedr/watchers)

### Forks

[**17**\\
forks](https://github.com/sensepost/mydumbedr/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fsensepost%2Fmydumbedr&report=sensepost+%28user%29)

## [Releases](https://github.com/sensepost/mydumbedr/releases)

No releases published

## [Packages\  0](https://github.com/orgs/sensepost/packages?repo_name=mydumbedr)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/sensepost/mydumbedr).

## [Contributors\  2](https://github.com/sensepost/mydumbedr/graphs/contributors)

- [![@Dfte](https://avatars.githubusercontent.com/u/23189983?s=64&v=4)](https://github.com/Dfte)[**Dfte** Deft\_](https://github.com/Dfte)
- [![@leonjza](https://avatars.githubusercontent.com/u/1148127?s=64&v=4)](https://github.com/leonjza)[**leonjza** Leon Jacobs](https://github.com/leonjza)

## Languages

- [C81.2%](https://github.com/sensepost/mydumbedr/search?l=c)
- [C++18.4%](https://github.com/sensepost/mydumbedr/search?l=c%2B%2B)
- [Batchfile0.4%](https://github.com/sensepost/mydumbedr/search?l=batchfile)

You can’t perform that action at this time.