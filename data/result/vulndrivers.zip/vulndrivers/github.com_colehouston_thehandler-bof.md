# https://github.com/ColeHouston/theHandler-BOF

[Skip to content](https://github.com/ColeHouston/theHandler-BOF#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ColeHouston/theHandler-BOF) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ColeHouston/theHandler-BOF) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ColeHouston/theHandler-BOF) to refresh your session.Dismiss alert

{{ message }}

[ColeHouston](https://github.com/ColeHouston)/ **[theHandler-BOF](https://github.com/ColeHouston/theHandler-BOF)** Public

- [Notifications](https://github.com/login?return_to=%2FColeHouston%2FtheHandler-BOF) You must be signed in to change notification settings
- [Fork\\
3](https://github.com/login?return_to=%2FColeHouston%2FtheHandler-BOF)
- [Star\\
38](https://github.com/login?return_to=%2FColeHouston%2FtheHandler-BOF)


Dump protected process memory by using BYOVD to tamper with handle objects in the kernel.


### License

[MIT license](https://github.com/ColeHouston/theHandler-BOF/blob/main/LICENSE)

[38\\
stars](https://github.com/ColeHouston/theHandler-BOF/stargazers) [3\\
forks](https://github.com/ColeHouston/theHandler-BOF/forks) [Branches](https://github.com/ColeHouston/theHandler-BOF/branches) [Tags](https://github.com/ColeHouston/theHandler-BOF/tags) [Activity](https://github.com/ColeHouston/theHandler-BOF/activity)

[Star](https://github.com/login?return_to=%2FColeHouston%2FtheHandler-BOF)

[Notifications](https://github.com/login?return_to=%2FColeHouston%2FtheHandler-BOF) You must be signed in to change notification settings

# ColeHouston/theHandler-BOF

main

[**1** Branch](https://github.com/ColeHouston/theHandler-BOF/branches) [**0** Tags](https://github.com/ColeHouston/theHandler-BOF/tags)

[Go to Branches page](https://github.com/ColeHouston/theHandler-BOF/branches)[Go to Tags page](https://github.com/ColeHouston/theHandler-BOF/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![ColeHouston](https://avatars.githubusercontent.com/u/42840319?v=4&size=40)](https://github.com/ColeHouston)[ColeHouston](https://github.com/ColeHouston/theHandler-BOF/commits?author=ColeHouston)<br>[added error handling for new versions of win11 to avoid BSOD](https://github.com/ColeHouston/theHandler-BOF/commit/3450190dfa259c059811a9ae4d3c707fc16dc41d)<br>6 months agoAug 4, 2025<br>[3450190](https://github.com/ColeHouston/theHandler-BOF/commit/3450190dfa259c059811a9ae4d3c707fc16dc41d) · 6 months agoAug 4, 2025<br>## History<br>[3 Commits](https://github.com/ColeHouston/theHandler-BOF/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ColeHouston/theHandler-BOF/commits/main/) 3 Commits |
| [images](https://github.com/ColeHouston/theHandler-BOF/tree/main/images "images") | [images](https://github.com/ColeHouston/theHandler-BOF/tree/main/images "images") | [added code and updated docs](https://github.com/ColeHouston/theHandler-BOF/commit/9e6e6f4cfee84c28c29fea4227dbe9d31c1a39e8 "added code and updated docs") | 7 months agoJul 28, 2025 |
| [src](https://github.com/ColeHouston/theHandler-BOF/tree/main/src "src") | [src](https://github.com/ColeHouston/theHandler-BOF/tree/main/src "src") | [added error handling for new versions of win11 to avoid BSOD](https://github.com/ColeHouston/theHandler-BOF/commit/3450190dfa259c059811a9ae4d3c707fc16dc41d "added error handling for new versions of win11 to avoid BSOD") | 6 months agoAug 4, 2025 |
| [theHandler](https://github.com/ColeHouston/theHandler-BOF/tree/main/theHandler "theHandler") | [theHandler](https://github.com/ColeHouston/theHandler-BOF/tree/main/theHandler "theHandler") | [added code and updated docs](https://github.com/ColeHouston/theHandler-BOF/commit/9e6e6f4cfee84c28c29fea4227dbe9d31c1a39e8 "added code and updated docs") | 7 months agoJul 28, 2025 |
| [LICENSE](https://github.com/ColeHouston/theHandler-BOF/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/ColeHouston/theHandler-BOF/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/ColeHouston/theHandler-BOF/commit/861b11062e8086867b1f69c001423a1b1369430a "Initial commit") | 7 months agoJul 28, 2025 |
| [README.md](https://github.com/ColeHouston/theHandler-BOF/blob/main/README.md "README.md") | [README.md](https://github.com/ColeHouston/theHandler-BOF/blob/main/README.md "README.md") | [added code and updated docs](https://github.com/ColeHouston/theHandler-BOF/commit/9e6e6f4cfee84c28c29fea4227dbe9d31c1a39e8 "added code and updated docs") | 7 months agoJul 28, 2025 |
| [dbutil\_2\_3.sys](https://github.com/ColeHouston/theHandler-BOF/blob/main/dbutil_2_3.sys "dbutil_2_3.sys") | [dbutil\_2\_3.sys](https://github.com/ColeHouston/theHandler-BOF/blob/main/dbutil_2_3.sys "dbutil_2_3.sys") | [added code and updated docs](https://github.com/ColeHouston/theHandler-BOF/commit/9e6e6f4cfee84c28c29fea4227dbe9d31c1a39e8 "added code and updated docs") | 7 months agoJul 28, 2025 |
| [decryptMinidump.py](https://github.com/ColeHouston/theHandler-BOF/blob/main/decryptMinidump.py "decryptMinidump.py") | [decryptMinidump.py](https://github.com/ColeHouston/theHandler-BOF/blob/main/decryptMinidump.py "decryptMinidump.py") | [added code and updated docs](https://github.com/ColeHouston/theHandler-BOF/commit/9e6e6f4cfee84c28c29fea4227dbe9d31c1a39e8 "added code and updated docs") | 7 months agoJul 28, 2025 |
| View all files |

## Repository files navigation

# theHandler

[Permalink: theHandler](https://github.com/ColeHouston/theHandler-BOF#thehandler)

BOF to dump process memory with handle manipulation features using Bring Your Own Vulnerable Driver (BYOVD).

Feel free to update the kernel driver exploit in this code to use it on machines that employ Microsoft's [driver block list](https://learn.microsoft.com/en-us/windows/security/application-security/application-control/app-control-for-business/design/microsoft-recommended-driver-block-rules). This public release uses CVE-2021-21551.

**The driver block list will NOT apply if the target machine does not have VBS/HVCI enabled, making it possible to install and exploit this vulnerable driver on up-to-date systems.**

Example screenshots:

[![theHandler_1.png](https://github.com/ColeHouston/theHandler-BOF/raw/main/images/theHandler_1.png)](https://github.com/ColeHouston/theHandler-BOF/blob/main/images/theHandler_1.png)

This BOF has been tested on the following Windows builds:

- Windows 10 build 19045
- Windows Server 2019 build 17763
- Windows Server 2012 build 9600

This BOF has been tested with these C2 frameworks:

- Cobalt Strike

_You can try running theHandler a second time if it outputs kernel memory addresses (starting in ffff) but fails to dump your target process. Kernel address output means the exploit works to read/write memory on your target system but theHander could not find your handle in the kernel._

## Requirements

[Permalink: Requirements](https://github.com/ColeHouston/theHandler-BOF#requirements)

The vulnerable [dbutil\_2\_3.sys](https://github.com/ColeHouston/theHandler-BOF/blob/main/dbutil_2_3.sys) driver must be running on the target. Download it from this repository, then install it:

```
sc create dellserv binPath= C:\dbutil_2_3.sys type= kernel
sc start dellserv
```

Note: This driver is in Microsoft's block list. Installation is blocked on many systems.

Execute theHandler from medium integrity or higher. You must be in high integrity to install the vulnerable driver.

## Usage

[Permalink: Usage](https://github.com/ColeHouston/theHandler-BOF#usage)

**Important Notes:**

- Avoid the DECOY\_PID option if the TARGET\_PID process might be exited before or during the Minidump (May cause BSOD).
- Fileless minidumps are a work in progress. Large minidump files causes it to fail currently; opt to save dumps to disk.

After downloading your minidump file, decrypt it with [decryptMinidump.py](https://github.com/ColeHouston/theHandler-BOF/blob/main/decryptMinidump.py) (`python3 decryptMinidump.py <minidump_file>`).

```
Create a memory dump of a target process and download it filelessly through beacon. Use the elevate and/or decoy arguments to bypass PPL with a vulnerable driver.
NOTE: The vulnerable driver you use MUST be manually uploaded and installed on the target machine.

[TARGET_PID]     = Target PID for memory dump. Use this argument alone for a standard minidump without kernel manipulation
[ELEVATE_HANDLE] = Set to 1 to open a low privilege handle and increase its access through the kernel. Set to 0 to open a normal handle
[DECOY_PID]      = Set to the PID of a benign process. Thehandler will open this process and tamper with its handle to dump your target process
[DUMP_FILENAME]  = (WIP) Filename to save encrypted minidump on disk. The dump will be downloaded in your current working directory.

Run thehandler without arguments to retrieve the Windows build number of the target system.

Usage:
thehandler [TARGET_PID] [ELEVATE_HANDLE] [DECOY_PID] [DUMP_FILENAME]
```

## Examples

[Permalink: Examples](https://github.com/ColeHouston/theHandler-BOF#examples)

Standard Minidump for PID 423:

```
thehandler 423 0 0 dumpfile.log
```

Fileless Minidump for PID 423:

```
thehandler 423
```

Fileless Minidump with decoy process for PID 423:

```
thehandler 423 0 1139
```

Fileless Minidump with decoy process AND elevated handle for PID 423:

```
thehandler 423 1 1139
```

## Stability

[Permalink: Stability](https://github.com/ColeHouston/theHandler-BOF#stability)

TheHandler uses an offset table that covers kernel offsets for most Windows builds (thanks to the [Vergilius Project](https://www.vergiliusproject.com/) for documentation on offsets). Execute theHandler without supplying arguments to check if the current machine is a supported build or not.

**NOTE: This tool reads and writes in kernel memory, meaning there is an inherent risk of Blue Screen of Death (BSOD) during execution. Always test this tool in a lab environment on the exact version of Windows you plan to execute on.**

The exploit used (CVE-2021-21551) is highly stable.

## About

Dump protected process memory by using BYOVD to tamper with handle objects in the kernel.


### Topics

[ppl](https://github.com/topics/ppl "Topic: ppl") [credential](https://github.com/topics/credential "Topic: credential") [bof](https://github.com/topics/bof "Topic: bof") [minidump](https://github.com/topics/minidump "Topic: minidump") [lsass](https://github.com/topics/lsass "Topic: lsass") [byovd](https://github.com/topics/byovd "Topic: byovd")

### Resources

[Readme](https://github.com/ColeHouston/theHandler-BOF#readme-ov-file)

### License

[MIT license](https://github.com/ColeHouston/theHandler-BOF#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ColeHouston/theHandler-BOF).

[Activity](https://github.com/ColeHouston/theHandler-BOF/activity)

### Stars

[**38**\\
stars](https://github.com/ColeHouston/theHandler-BOF/stargazers)

### Watchers

[**0**\\
watching](https://github.com/ColeHouston/theHandler-BOF/watchers)

### Forks

[**3**\\
forks](https://github.com/ColeHouston/theHandler-BOF/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FColeHouston%2FtheHandler-BOF&report=ColeHouston+%28user%29)

## [Releases](https://github.com/ColeHouston/theHandler-BOF/releases)

No releases published

## [Packages\  0](https://github.com/users/ColeHouston/packages?repo_name=theHandler-BOF)

No packages published

## Languages

- [C97.3%](https://github.com/ColeHouston/theHandler-BOF/search?l=c)
- [Python2.5%](https://github.com/ColeHouston/theHandler-BOF/search?l=python)
- [Batchfile0.2%](https://github.com/ColeHouston/theHandler-BOF/search?l=batchfile)

You can’t perform that action at this time.