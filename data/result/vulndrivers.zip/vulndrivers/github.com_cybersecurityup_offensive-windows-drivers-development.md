# https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development

[Skip to content](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development) to refresh your session.Dismiss alert

{{ message }}

[CyberSecurityUP](https://github.com/CyberSecurityUP)/ **[Offensive-Windows-Drivers-Development](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development)** Public

- [Notifications](https://github.com/login?return_to=%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development) You must be signed in to change notification settings
- [Fork\\
27](https://github.com/login?return_to=%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development)
- [Star\\
165](https://github.com/login?return_to=%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development)


[165\\
stars](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/stargazers) [27\\
forks](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/forks) [Branches](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/branches) [Tags](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tags) [Activity](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/activity)

[Star](https://github.com/login?return_to=%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development)

[Notifications](https://github.com/login?return_to=%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development) You must be signed in to change notification settings

# CyberSecurityUP/Offensive-Windows-Drivers-Development

main

[**1** Branch](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/branches) [**0** Tags](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tags)

[Go to Branches page](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/branches)[Go to Tags page](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![CyberSecurityUP](https://avatars.githubusercontent.com/u/34966120?v=4&size=40)](https://github.com/CyberSecurityUP)[CyberSecurityUP](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commits?author=CyberSecurityUP)<br>[Update Resources.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/89e87f04359325688ba5453623b5374e6671fc50)<br>last yearMar 4, 2025<br>[89e87f0](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/89e87f04359325688ba5453623b5374e6671fc50) · last yearMar 4, 2025<br>## History<br>[21 Commits](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commits/main/) 21 Commits |
| [Introduction/Project](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/Introduction/Project "This path skips through empty directories") | [Introduction/Project](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/Introduction/Project "This path skips through empty directories") | [Update Driver.c](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/60196e31fb79a01a9d5cc60f7cd9ac61e790019a "Update Driver.c") | last yearJan 14, 2025 |
| [PrivilegeEscalation/GetSystem](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/PrivilegeEscalation/GetSystem "This path skips through empty directories") | [PrivilegeEscalation/GetSystem](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/PrivilegeEscalation/GetSystem "This path skips through empty directories") | [Add files via upload](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/ef9e3381424cde03083c08c009ebc59e4f43806d "Add files via upload") | last yearMar 4, 2025 |
| [Ransomware/Project1](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/Ransomware/Project1 "This path skips through empty directories") | [Ransomware/Project1](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/tree/main/Ransomware/Project1 "This path skips through empty directories") | [Add files via upload](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/ad25158db1a1690aa6f6344d837db79d431a1ebc "Add files via upload") | last yearJan 14, 2025 |
| [README.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/blob/main/README.md "README.md") | [README.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/blob/main/README.md "README.md") | [Update README.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/f950551bb633b8d20a8a52165998dd231d66e3c7 "Update README.md") | last yearFeb 5, 2025 |
| [Resources.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/blob/main/Resources.md "Resources.md") | [Resources.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/blob/main/Resources.md "Resources.md") | [Update Resources.md](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/commit/89e87f04359325688ba5453623b5374e6671fc50 "Update Resources.md") | last yearMar 4, 2025 |
| View all files |

## Repository files navigation

# Offensive-Windows-Drivers-Development

[Permalink: Offensive-Windows-Drivers-Development](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#offensive-windows-drivers-development)

## Overview

[Permalink: Overview](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#overview)

**Offensive-Windows-Drivers-Development** is a research project designed to explore the development of Windows kernel-mode and user-mode drivers for offensive security purposes. The project focuses on techniques for low-level interaction with the Windows operating system, including file system interception, process manipulation, and advanced memory operations.

The goal is to provide insights into Windows internals and practical implementations that can aid red teamers, penetration testers and researchers in understanding how kernel-mode and user-mode drivers can be used in offensive scenarios, while also emphasizing the importance of defensive mechanisms to counter such techniques.

## Features

[Permalink: Features](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#features)

- **File System Interception**: Monitor and modify file I/O operations.
- **File Encryption**: Implement AES-based encryption at the kernel level.
- **Process Injection**: Advanced techniques for process manipulation from kernel space.
- **EDR Evasion**: Techniques for bypassing endpoint detection and response (EDR) solutions.
- **Memory Operations**: Direct manipulation of memory at the kernel level.
- **Proof-of-Concept (PoC) Drivers**: Examples for educational purposes.

## Prerequisites

[Permalink: Prerequisites](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#prerequisites)

- **Operating System**: Windows 10/11 (x64) with a kernel debugger (e.g., WinDbg).
- **Development Environment**: Visual Studio with Windows Driver Kit (WDK).
- **Tools**:

  - [WinDbg](https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/)
  - [Process Hacker](https://processhacker.sourceforge.io/)
  - [Sysinternals Suite](https://learn.microsoft.com/en-us/sysinternals/)

## References

[Permalink: References](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#references)

[https://www.blackhat.com/docs/eu-17/materials/eu-17-Corina-Difuzzing-Android-Kernel-Drivers.pdf](https://www.blackhat.com/docs/eu-17/materials/eu-17-Corina-Difuzzing-Android-Kernel-Drivers.pdf)

[https://voidsec.com/windows-drivers-reverse-engineering-methodology/](https://voidsec.com/windows-drivers-reverse-engineering-methodology/)

[https://github.com/koutto/ioctlbf](https://github.com/koutto/ioctlbf)

[https://github.com/otavioarj/SIOCTLBF](https://github.com/otavioarj/SIOCTLBF)

[https://v1k1ngfr.github.io/winkernel-reverse-ida-ghidra/](https://v1k1ngfr.github.io/winkernel-reverse-ida-ghidra/)

[https://infosecwriteups.com/understanding-ioctls-for-windows-vulnerability-research-exploit-development-c49229b38d8d](https://infosecwriteups.com/understanding-ioctls-for-windows-vulnerability-research-exploit-development-c49229b38d8d)

[https://guidedhacking.com/threads/how-to-find-vulnerable-drivers-with-ioctlance.20824/](https://guidedhacking.com/threads/how-to-find-vulnerable-drivers-with-ioctlance.20824/)

[https://exploitreversing.com/2024/01/03/exploiting-reversing-er-series-article-02/](https://exploitreversing.com/2024/01/03/exploiting-reversing-er-series-article-02/)

[https://www.cyberark.com/resources/threat-research-blog/inglourious-drivers-a-journey-of-finding-vulnerabilities-in-drivers](https://www.cyberark.com/resources/threat-research-blog/inglourious-drivers-a-journey-of-finding-vulnerabilities-in-drivers)

[https://www.cyberark.com/resources/threat-research-blog/finding-bugs-in-windows-drivers-part-1-wdm](https://www.cyberark.com/resources/threat-research-blog/finding-bugs-in-windows-drivers-part-1-wdm)

[https://research.checkpoint.com/2024/breaking-boundaries-investigating-vulnerable-drivers-and-mitigating-risks/](https://research.checkpoint.com/2024/breaking-boundaries-investigating-vulnerable-drivers-and-mitigating-risks/)

[https://blogs.vmware.com/security/2023/10/hunting-vulnerable-kernel-drivers.html](https://blogs.vmware.com/security/2023/10/hunting-vulnerable-kernel-drivers.html)

[https://www.unknowncheats.me/forum/general-programming-and-reversing/461976-methodology-static-reverse-engineering-windows-kernel-drivers.html](https://www.unknowncheats.me/forum/general-programming-and-reversing/461976-methodology-static-reverse-engineering-windows-kernel-drivers.html)

[https://www.youtube.com/watch?v=7Trgnw7HkeE&ab\_channel=OffByOneSecurity](https://www.youtube.com/watch?v=7Trgnw7HkeE&ab_channel=OffByOneSecurity)

[https://www.youtube.com/watch?v=ViWLMfSwGVA&ab\_channel=OALabs](https://www.youtube.com/watch?v=ViWLMfSwGVA&ab_channel=OALabs)

[https://www.youtube.com/watch?v=cabuolISweY&ab\_channel=NirLichtman](https://www.youtube.com/watch?v=cabuolISweY&ab_channel=NirLichtman)

## About

No description or website provided.


### Topics

[offensive-security](https://github.com/topics/offensive-security "Topic: offensive-security") [malware-development](https://github.com/topics/malware-development "Topic: malware-development") [windows-driver-kit](https://github.com/topics/windows-driver-kit "Topic: windows-driver-kit") [redteam](https://github.com/topics/redteam "Topic: redteam") [windows-drivers](https://github.com/topics/windows-drivers "Topic: windows-drivers")

### Resources

[Readme](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development).

[Activity](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/activity)

### Stars

[**165**\\
stars](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/stargazers)

### Watchers

[**1**\\
watching](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/watchers)

### Forks

[**27**\\
forks](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FCyberSecurityUP%2FOffensive-Windows-Drivers-Development&report=CyberSecurityUP+%28user%29)

## [Releases](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/releases)

No releases published

## [Packages\  0](https://github.com/users/CyberSecurityUP/packages?repo_name=Offensive-Windows-Drivers-Development)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development).

## Languages

- [C94.6%](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/search?l=c)
- [C++5.4%](https://github.com/CyberSecurityUP/Offensive-Windows-Drivers-Development/search?l=c%2B%2B)

You can’t perform that action at this time.