# https://github.com/0xJs/BYOVD_read_write_primitive

[Skip to content](https://github.com/0xJs/BYOVD_read_write_primitive#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/0xJs/BYOVD_read_write_primitive) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/0xJs/BYOVD_read_write_primitive) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/0xJs/BYOVD_read_write_primitive) to refresh your session.Dismiss alert

{{ message }}

[0xJs](https://github.com/0xJs)/ **[BYOVD\_read\_write\_primitive](https://github.com/0xJs/BYOVD_read_write_primitive)** Public

- [Notifications](https://github.com/login?return_to=%2F0xJs%2FBYOVD_read_write_primitive) You must be signed in to change notification settings
- [Fork\\
29](https://github.com/login?return_to=%2F0xJs%2FBYOVD_read_write_primitive)
- [Star\\
204](https://github.com/login?return_to=%2F0xJs%2FBYOVD_read_write_primitive)


Proof of Concepts code for Bring Your Own Vulnerable Driver techniques


[204\\
stars](https://github.com/0xJs/BYOVD_read_write_primitive/stargazers) [29\\
forks](https://github.com/0xJs/BYOVD_read_write_primitive/forks) [Branches](https://github.com/0xJs/BYOVD_read_write_primitive/branches) [Tags](https://github.com/0xJs/BYOVD_read_write_primitive/tags) [Activity](https://github.com/0xJs/BYOVD_read_write_primitive/activity)

[Star](https://github.com/login?return_to=%2F0xJs%2FBYOVD_read_write_primitive)

[Notifications](https://github.com/login?return_to=%2F0xJs%2FBYOVD_read_write_primitive) You must be signed in to change notification settings

# 0xJs/BYOVD\_read\_write\_primitive

main

[**1** Branch](https://github.com/0xJs/BYOVD_read_write_primitive/branches) [**0** Tags](https://github.com/0xJs/BYOVD_read_write_primitive/tags)

[Go to Branches page](https://github.com/0xJs/BYOVD_read_write_primitive/branches)[Go to Tags page](https://github.com/0xJs/BYOVD_read_write_primitive/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![0xJs](https://avatars.githubusercontent.com/u/43987245?v=4&size=40)](https://github.com/0xJs)[0xJs](https://github.com/0xJs/BYOVD_read_write_primitive/commits?author=0xJs)<br>[Update README.md](https://github.com/0xJs/BYOVD_read_write_primitive/commit/7ea7883573932edc9d952affa083aa816a6292db)<br>Open commit details<br>6 months agoAug 21, 2025<br>[7ea7883](https://github.com/0xJs/BYOVD_read_write_primitive/commit/7ea7883573932edc9d952affa083aa816a6292db) · 6 months agoAug 21, 2025<br>## History<br>[9 Commits](https://github.com/0xJs/BYOVD_read_write_primitive/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/0xJs/BYOVD_read_write_primitive/commits/main/) 9 Commits |
| [DSERemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/DSERemover "DSERemover") | [DSERemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/DSERemover "DSERemover") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [ETwTiRemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/ETwTiRemover "ETwTiRemover") | [ETwTiRemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/ETwTiRemover "ETwTiRemover") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [KernelCallbackRemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/KernelCallbackRemover "KernelCallbackRemover") | [KernelCallbackRemover](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/KernelCallbackRemover "KernelCallbackRemover") | [Update kernelCallbacks.c](https://github.com/0xJs/BYOVD_read_write_primitive/commit/c53a0cbb6903412a4ec48feb15936b9e11cd68c3 "Update kernelCallbacks.c  Fix elastic driver name .sys") | 6 months agoAug 17, 2025 |
| [ProtectionChanger](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/ProtectionChanger "ProtectionChanger") | [ProtectionChanger](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/ProtectionChanger "ProtectionChanger") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [RTCore\_read](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/RTCore_read "RTCore_read") | [RTCore\_read](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/RTCore_read "RTCore_read") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [RTCore\_write](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/RTCore_write "RTCore_write") | [RTCore\_write](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/RTCore_write "RTCore_write") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [TokenChanger](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/TokenChanger "TokenChanger") | [TokenChanger](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/TokenChanger "TokenChanger") | [Fix memory leak in process enumeration](https://github.com/0xJs/BYOVD_read_write_primitive/commit/f4af25420bfd28268591c0a77a8babceac109d74 "Fix memory leak in process enumeration") | 6 months agoAug 18, 2025 |
| [helper](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/helper "helper") | [helper](https://github.com/0xJs/BYOVD_read_write_primitive/tree/main/helper "helper") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [.gitignore](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/.gitignore ".gitignore") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [README.md](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/README.md "README.md") | [README.md](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/README.md "README.md") | [Update README.md](https://github.com/0xJs/BYOVD_read_write_primitive/commit/7ea7883573932edc9d952affa083aa816a6292db "Update README.md  Updated disclaimer") | 6 months agoAug 21, 2025 |
| [RTCore.sln](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/RTCore.sln "RTCore.sln") | [RTCore.sln](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/RTCore.sln "RTCore.sln") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [RTCore64.sys](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/RTCore64.sys "RTCore64.sys") | [RTCore64.sys](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/RTCore64.sys "RTCore64.sys") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| [cleanup.bat](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/cleanup.bat "cleanup.bat") | [cleanup.bat](https://github.com/0xJs/BYOVD_read_write_primitive/blob/main/cleanup.bat "cleanup.bat") | [First release](https://github.com/0xJs/BYOVD_read_write_primitive/commit/475076a3348e2d790fcdfcda223ba9888d6def83 "First release") | 6 months agoAug 12, 2025 |
| View all files |

## Repository files navigation

# BYOVD Read Write primitive

[Permalink: BYOVD Read Write primitive](https://github.com/0xJs/BYOVD_read_write_primitive#byovd-read-write-primitive)

## Disclaimer

[Permalink: Disclaimer](https://github.com/0xJs/BYOVD_read_write_primitive#disclaimer)

⚠️ This project is provided exclusively for educational purposes and is intended to be used only in authorized environments. You may only run or deploy this project on systems you own or have explicit, documented permission to test. Any unauthorized use of this project against systems without consent is strictly prohibited and may be illegal.

By using this project, you agree to use it responsibly and ethically. The author assumes no liability for misuse or any consequences arising from the use of this project.

This project involves reading from or writing to kernel memory. Such operations can cause system instability, crashes, or Blue Screen of Death (BSOD) if used incorrectly. Proceed with caution, and ensure you fully understand the potential impact before running the code.

Tested on:

- Windows 11 (24H2)
- Windows Server 2022 (21H2)

# General

[Permalink: General](https://github.com/0xJs/BYOVD_read_write_primitive#general)

To practice Bring Your Own Vulnerable Driver (BYOVD) techniques from the CETP course, I set out to develop a toolkit leveraging a kernel-level read/write primitive to bypass security mechanisms such as LSASS’s RunasPPL protection and to enumerate and remove EDR telemetry via kernel callback manipulation. For the vulnerable driver, I used the well-known [RTCore64.sys](https://www.loldrivers.io/drivers/e32bc3da-4db1-4858-a62c-6fbe4db6afbd/) from MSI Afterburner.

# Proof of Concept code examples

[Permalink: Proof of Concept code examples](https://github.com/0xJs/BYOVD_read_write_primitive#proof-of-concept-code-examples)

This `C` project includes multiple proof-of-concept (POC) code examples that perform the following exploitation concepts:

- Changing Process Protection Levels
  - Disable Runasppl LSASS protection
- Removing Kernel Callbacks
- Disabling ETW providers
- Change process token
  - Privilege escalation to system
  - Downgrade EDR's token
- Disable DSE in case VBS is disabled and load unsigned driver

Requirements:

- All these attacks require local administrative privileges to load the vulnerable driver.

## Kernel Callback Remover

[Permalink: Kernel Callback Remover](https://github.com/0xJs/BYOVD_read_write_primitive#kernel-callback-remover)

- What does it do
  - Calculates and prints offsets by downloading symbols from the internet as in EDRSandBlast project for all kernel callbacks and their structures.
  - Writes vulnerable RTCore64 driver to `C:\Windows\System32\Drivers\RTCore64.sys` and loads the driver.
  - Enumerate all loaded kernel drivers on the system
  - Enumerates all kernel callbacks and if `-d` selected also removes or unlinks them using the read and write IOCTL

    - Process Creation Kernel Callbacks - Removed through overwriting the callback address with `0x0`
    - Thread Creation Kernel Callbacks - Removed through overwriting the callback address with \`0x0
    - Image Loading Kernel Callbacks - Removed through overwriting the callback address with \`0x0
    - Registry Operations Kernel Callbacks - Removed through pointing the flink and blink to dwListHead (itself)
    - Object Creation Kernel Callbacks
      - Process - Removed through pointing the flink and blink to dwListHead (itself)
      - Thread - Removed through pointing the flink and blink to dwListHead (itself)
    - Minifilter Kernel Callbacks and their callbacknodes - Removed through unlinking the callbacknodes
  - Compare callback addresses with the loaded kernel drivers to check to which driver the callback belongs
  - Unloads the RTCore64 driver and removes the file from `C:\Windows\System32\Drivers\RTCore64.sys`
- Filenames can be configured in `config.h`

```
PS C:\ > .\KernelCallbackRemover.exe
Usage: KernelCallbackRemover.exe -l / -d
Options:
  -l List Kernel Callbacks       - Lists all kernel callbacks through vulnerable driver
  -d Disable Kernel Callbacks    - Lists and remove all kernel callbacks through vulnerable driver
  -h Display this help message.
```

#### Example removing kernel callbacks

[Permalink: Example removing kernel callbacks](https://github.com/0xJs/BYOVD_read_write_primitive#example-removing-kernel-callbacks)

```
PS C:\ > .\KernelCallbackRemover.exe -d
```

## Protection Changer

[Permalink: Protection Changer](https://github.com/0xJs/BYOVD_read_write_primitive#protection-changer)

- What does it do
  - Calculates and prints offsets by enumerating windows version with `RtlGetVersion`, offsets are hardcoded.

    - Update offsets with [vergiliusproject](https://www.vergiliusproject.com/kernels/x64/windows-11/24h2/_EPROCESS)
  - Writes vulnerable RTCore64 driver to `C:\Windows\System32\Drivers\RTCore64.sys` and loads the driver
  - Gets base address of `Ntoskrnl.exe` and calculates `PsInitialSystemProcess` offset
  - Changes the protection using the read and write IOCTL, writing the chosen protection value to the `_PS_PROTECTION Protection` struct in the `E_PROCESS`
  - Unloads the RTCore64 driver and removes the file from `C:\Windows\System32\Drivers\RTCore64.sys`
- Filenames and service names can be configured in `config.h`

```
PS C:\ > .\ProtectionChanger.exe
Usage: ProtectionChanger.exe -p <PID> -v <NEW PROTECTION LEVEL>
Options:
  -p <pid>              Specify the process ID (PID) of the process to change the protection level.
  -v <protection_level> Specify the protection level value in hexadecimal (e.g., 0x00 for NO_PROTECTION).
  -h                    Display this help message.

Possible protection level values:
  0x72  PS_PROTECTED_SYSTEM               System protected process
  0x62  PS_PROTECTED_WINTCB               Windows TCB protected process
  0x52  PS_PROTECTED_WINDOWS              Windows protected process
  0x12  PS_PROTECTED_AUTHENTICODE         Authenticode protected process
  0x61  PS_PROTECTED_WINTCB_LIGHT         Windows TCB light protected process
  0x51  PS_PROTECTED_WINDOWS_LIGHT        Windows light protected process
  0x41  PS_PROTECTED_LSA_LIGHT            LSA light protected process
  0x31  PS_PROTECTED_ANTIMALWARE_LIGHT    Antimalware light protected process
  0x11  PS_PROTECTED_AUTHENTICODE_LIGHT   Authenticode light protected process
  0x00  NO_PROTECTION for no protection
```

#### Example lsass

[Permalink: Example lsass](https://github.com/0xJs/BYOVD_read_write_primitive#example-lsass)

- Example removing runasppl from LSASS process by setting the protection value to `0x00`

```
PS C:\ > .\ProtectionChanger.exe -v 0x00 -p (Get-Process -Name lsass).id
```

## ETwTi Remover

[Permalink: ETwTi Remover](https://github.com/0xJs/BYOVD_read_write_primitive#etwti-remover)

- What does it do
  - Calculates and prints offsets by downloading symbols from the internet as in EDRSandBlast project
  - Writes vulnerable RTCore64 driver to `C:\Windows\System32\Drivers\RTCore64.sys` and loads the driver
  - Disables or enables ETwTi using the read and write IOCTL writing to the `ProviderEnableInfo` field
  - Unloads the RTCore64 driver and removes the file from `C:\Windows\System32\Drivers\RTCore64.sys`
- Filenames can be configured in `config.h`

```
PS C:\ > .\ETwTiRemover.exe
Usage: ETwTiRemover.exe -e / -d
Options:
  -e Enable ETwTi     - set ProviderEnableInfo field within the GUID entry to 0x1
  -d Disable ETwTi    - set ProviderEnableInfo field within the GUID entry to 0x0
  -h Display this help message.
```

#### Example Disabling ETwTi

[Permalink: Example Disabling ETwTi](https://github.com/0xJs/BYOVD_read_write_primitive#example-disabling-etwti)

```
PS C:\ > .\ETwTiRemover.exe -d
```

## Token Changer

[Permalink: Token Changer](https://github.com/0xJs/BYOVD_read_write_primitive#token-changer)

- What does it do
  - Calculates and prints offsets by enumerating windows version with `RtlGetVersion`
    - Update offsets with [vergiliusproject](https://www.vergiliusproject.com/kernels/x64/windows-11/24h2/_EPROCESS)
  - Writes vulnerable RTCore64 driver to `C:\Windows\System32\Drivers\RTCore64.sys` and loads the driver
  - Gets base address of `Ntoskrnl.exe` and calculates `PsInitialSystemProcess` offset
  - Changes the token value by reading the `_EX_FAST_REF Token` value and writing it into the other process using the read and write IOCTL
  - Unloads the RTCore64 driver and removes the file from \`C:\\Windows\\System32\\Drivers\\RTCore64.sys

```
PS C:\ > .\TokenChanger.exe
Usage: TokenChanger.exe --tp <PID> --sp <PID>
Usage: TokenChanger.exe --edr
Usage: TokenChanger.exe --edr --sp <PID>
Options:
  --tp <pid>             Specify the target process ID (PID) to replace the token of
  --sp <pid>             Specify the source process ID (PID) to clone the token from
  --edr                  Specify to downgrade the token of all EDR processes
  --spawnsystem          Specify to spawn a new process and steal token from system
  -h                     Display this help message.
```

#### Example disabling EDR by downgrading token from explorer

[Permalink: Example disabling EDR by downgrading token from explorer](https://github.com/0xJs/BYOVD_read_write_primitive#example-disabling-edr-by-downgrading-token-from-explorer)

```
PS C:\ > .\TokenChanger.exe --edr --sp (Get-Process -Name explorer).id
```

#### Example spawning system shell

[Permalink: Example spawning system shell](https://github.com/0xJs/BYOVD_read_write_primitive#example-spawning-system-shell)

```
PS C:\ > .\TokenChanger.exe --spawnsystem
```

## DSERemover

[Permalink: DSERemover](https://github.com/0xJs/BYOVD_read_write_primitive#dseremover)

- What does it do
  - Checks if DSE protection is enabled or if test signing is enabled
  - Calculates and prints offsets by downloading symbols from the internet as in EDRSandBlast project
  - Writes vulnerable RTCore64 driver to `C:\Windows\System32\Drivers\RTCore64.sys` and loads the driver
  - Disables DSE using the read and write IOCTL, writing `0xe` (testsigning) into the kernel global variable `g_CiOptions`
  - Writes and loads a simple unsigned driver example code from my [FirstDriver](https://github.com/0xJs/FirstDriver) project to \`C:\\Windows\\System32\\Drivers'
  - Enables DSE again using the read and write IOCTL, writing `0x6` (DSE Enabled mode) to `g_CiOptions`
  - Unloads the RTCore64 driver and removes the file from `C:\Windows\System32\Drivers\RTCore64.sys`
- Requirements;
  - Virtualized Based Security (VBS) to be disabled
- Filenames and service names can be configured in `config.h`

```
PS C:\ > .\DSERemover.exe
```

# Cleanup

[Permalink: Cleanup](https://github.com/0xJs/BYOVD_read_write_primitive#cleanup)

- The PE file should unload and remove the RTCORE driver. If it didn't then manually remove it or run the `cleanup.bat` script.
- Also removes the ROOTKIT service and driver from the DSERemover project incase its there

```
sc stop RTCORE
sc delete RTCORE
sc stop ROOTKIT
sc delete ROOTKIT

del C:\Windows\System32\Drivers\RTCore64.sys
del C:\Windows\System32\Drivers\FirstDriver.sys
```

## Credits

[Permalink: Credits](https://github.com/0xJs/BYOVD_read_write_primitive#credits)

I got inspired to expand upon the tools provided in the Evasion Lab (CETP from [Altered Security](https://www.alteredsecurity.com/evasionlab)), taught by [Saad Ahla](https://www.linkedin.com/in/saad-ahla/).

The \[EDRSandblast)( [https://github.com/wavestone-cdt/EDRSandblast](https://github.com/wavestone-cdt/EDRSandblast)) project for some of their code, espacially around downloading and parsing the Symbol files for offsets and the listing and removing of MiniFilters.\
\
## About\
\
Proof of Concepts code for Bring Your Own Vulnerable Driver techniques\
\
\
### Resources\
\
[Readme](https://github.com/0xJs/BYOVD_read_write_primitive#readme-ov-file)\
\
### Uh oh!\
\
There was an error while loading. [Please reload this page](https://github.com/0xJs/BYOVD_read_write_primitive).\
\
[Activity](https://github.com/0xJs/BYOVD_read_write_primitive/activity)\
\
### Stars\
\
[**204**\\
stars](https://github.com/0xJs/BYOVD_read_write_primitive/stargazers)\
\
### Watchers\
\
[**2**\\
watching](https://github.com/0xJs/BYOVD_read_write_primitive/watchers)\
\
### Forks\
\
[**29**\\
forks](https://github.com/0xJs/BYOVD_read_write_primitive/forks)\
\
[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2F0xJs%2FBYOVD_read_write_primitive&report=0xJs+%28user%29)\
\
## [Releases](https://github.com/0xJs/BYOVD_read_write_primitive/releases)\
\
No releases published\
\
## [Packages\  0](https://github.com/users/0xJs/packages?repo_name=BYOVD_read_write_primitive)\
\
No packages published\
\
## Languages\
\
- [C99.9%](https://github.com/0xJs/BYOVD_read_write_primitive/search?l=c)\
- Other0.1%\
\
You can’t perform that action at this time.