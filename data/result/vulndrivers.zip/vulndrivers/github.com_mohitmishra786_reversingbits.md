# https://github.com/mohitmishra786/reversingBits

[Skip to content](https://github.com/mohitmishra786/reversingBits#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/mohitmishra786/reversingBits) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/mohitmishra786/reversingBits) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/mohitmishra786/reversingBits) to refresh your session.Dismiss alert

{{ message }}

[mohitmishra786](https://github.com/mohitmishra786)/ **[reversingBits](https://github.com/mohitmishra786/reversingBits)** Public

- [Notifications](https://github.com/login?return_to=%2Fmohitmishra786%2FreversingBits) You must be signed in to change notification settings
- [Fork\\
68](https://github.com/login?return_to=%2Fmohitmishra786%2FreversingBits)
- [Star\\
610](https://github.com/login?return_to=%2Fmohitmishra786%2FreversingBits)


A comprehensive collection of cheatsheets for reverse engineering, binary analysis, and assembly programming tools. This repository serves as a one-stop reference for security researchers, reverse engineers, and low-level programmers.


[mohitmishra786.github.io/reversingBits/](https://mohitmishra786.github.io/reversingBits/ "https://mohitmishra786.github.io/reversingBits/")

### License

[MIT license](https://github.com/mohitmishra786/reversingBits/blob/main/LICENSE)

[610\\
stars](https://github.com/mohitmishra786/reversingBits/stargazers) [68\\
forks](https://github.com/mohitmishra786/reversingBits/forks) [Branches](https://github.com/mohitmishra786/reversingBits/branches) [Tags](https://github.com/mohitmishra786/reversingBits/tags) [Activity](https://github.com/mohitmishra786/reversingBits/activity)

[Star](https://github.com/login?return_to=%2Fmohitmishra786%2FreversingBits)

[Notifications](https://github.com/login?return_to=%2Fmohitmishra786%2FreversingBits) You must be signed in to change notification settings

# mohitmishra786/reversingBits

main

[**1** Branch](https://github.com/mohitmishra786/reversingBits/branches) [**0** Tags](https://github.com/mohitmishra786/reversingBits/tags)

[Go to Branches page](https://github.com/mohitmishra786/reversingBits/branches)[Go to Tags page](https://github.com/mohitmishra786/reversingBits/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![mohitmishra786](https://avatars.githubusercontent.com/u/71754779?v=4&size=40)](https://github.com/mohitmishra786)[mohitmishra786](https://github.com/mohitmishra786/reversingBits/commits?author=mohitmishra786)<br>[goat counter changes](https://github.com/mohitmishra786/reversingBits/commit/8f5628675094afc2446dbf2cfec20832717e6847)<br>success<br>7 months agoJul 21, 2025<br>[8f56286](https://github.com/mohitmishra786/reversingBits/commit/8f5628675094afc2446dbf2cfec20832717e6847) · 7 months agoJul 21, 2025<br>## History<br>[59 Commits](https://github.com/mohitmishra786/reversingBits/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/mohitmishra786/reversingBits/commits/main/) 59 Commits |
| [src](https://github.com/mohitmishra786/reversingBits/tree/main/src "src") | [src](https://github.com/mohitmishra786/reversingBits/tree/main/src "src") | [goat counter changes](https://github.com/mohitmishra786/reversingBits/commit/04604a94d489352c6aaf375209eac78c35f0e481 "goat counter changes") | 7 months agoJul 21, 2025 |
| [.gitignore](https://github.com/mohitmishra786/reversingBits/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/mohitmishra786/reversingBits/blob/main/.gitignore ".gitignore") | [added website for github pages](https://github.com/mohitmishra786/reversingBits/commit/d8e352a9f6a4080f9a7b14f230a8651978b82119 "added website for github pages") | 2 years agoNov 1, 2024 |
| [CODE\_OF\_CONDUCT.md](https://github.com/mohitmishra786/reversingBits/blob/main/CODE_OF_CONDUCT.md "CODE_OF_CONDUCT.md") | [CODE\_OF\_CONDUCT.md](https://github.com/mohitmishra786/reversingBits/blob/main/CODE_OF_CONDUCT.md "CODE_OF_CONDUCT.md") | [Create CODE\_OF\_CONDUCT.md](https://github.com/mohitmishra786/reversingBits/commit/88170b14632d8b5e4b91d8f628f8c6f1a47d594c "Create CODE_OF_CONDUCT.md") | 2 years agoNov 1, 2024 |
| [CONTRIBUTING.md](https://github.com/mohitmishra786/reversingBits/blob/main/CONTRIBUTING.md "CONTRIBUTING.md") | [CONTRIBUTING.md](https://github.com/mohitmishra786/reversingBits/blob/main/CONTRIBUTING.md "CONTRIBUTING.md") | [Create CONTRIBUTING.md](https://github.com/mohitmishra786/reversingBits/commit/82302054daae4fe9b9ba9e8644662f5df6a2ab90 "Create CONTRIBUTING.md") | 2 years agoNov 1, 2024 |
| [LICENSE](https://github.com/mohitmishra786/reversingBits/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/mohitmishra786/reversingBits/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/mohitmishra786/reversingBits/commit/9dcc5c13d87f8c9995b8135308cc0309d0ca2101 "Initial commit") | 2 years agoNov 1, 2024 |
| [README.md](https://github.com/mohitmishra786/reversingBits/blob/main/README.md "README.md") | [README.md](https://github.com/mohitmishra786/reversingBits/blob/main/README.md "README.md") | [Update README.md](https://github.com/mohitmishra786/reversingBits/commit/f4a1e5e4356ff87ff59168b8af37e9466a75a03c "Update README.md") | 2 years agoNov 20, 2024 |
| [index.html](https://github.com/mohitmishra786/reversingBits/blob/main/index.html "index.html") | [index.html](https://github.com/mohitmishra786/reversingBits/blob/main/index.html "index.html") | [goat counter changes](https://github.com/mohitmishra786/reversingBits/commit/8f5628675094afc2446dbf2cfec20832717e6847 "goat counter changes") | 7 months agoJul 21, 2025 |
| View all files |

## Repository files navigation

# Reversing Bits Cheatsheets

[Permalink: Reversing Bits Cheatsheets](https://github.com/mohitmishra786/reversingBits#reversing-bits-cheatsheets)

Welcome to the Reversing Bits Cheatsheets repository! This collection provides comprehensive guides on various tools essential for assembly programming, reverse engineering, and binary analysis. Each cheatsheet offers installation instructions, usage examples, and advanced tips for different operating systems.

Website: [https://mohitmishra786.github.io/reversingBits/](https://mohitmishra786.github.io/reversingBits/)

## Tools Included

[Permalink: Tools Included](https://github.com/mohitmishra786/reversingBits#tools-included)

### Assembly & Basic Analysis

[Permalink: Assembly & Basic Analysis](https://github.com/mohitmishra786/reversingBits#assembly--basic-analysis)

- [NASM](https://github.com/mohitmishra786/reversingBits/blob/main/src/nasm.md): A popular assembler for the x86 and x86-64 architectures.
- [GAS](https://github.com/mohitmishra786/reversingBits/blob/main/src/gas.md): GNU Assembler, part of the GNU Binutils project, used for assembling AT&T syntax assembly.
- [objdump](https://github.com/mohitmishra786/reversingBits/blob/main/src/objdump.md): A powerful tool for displaying information about object files.
- [Hexdump](https://github.com/mohitmishra786/reversingBits/blob/main/src/hexdump.md): Used to display or dump binary data in hexadecimal format.
- [strings](https://github.com/mohitmishra786/reversingBits/blob/main/src/strings.md): Extracts printable strings from files, useful for quick analysis.
- [file](https://github.com/mohitmishra786/reversingBits/blob/main/src/file.md): Determines file type by examining its contents.
- [nm](https://github.com/mohitmishra786/reversingBits/blob/main/src/nm.md): Lists symbols from object files.
- [readelf](https://github.com/mohitmishra786/reversingBits/blob/main/src/readelf.md): Displays information about ELF (Executable and Linkable Format) files.

### Debuggers & Dynamic Analysis

[Permalink: Debuggers & Dynamic Analysis](https://github.com/mohitmishra786/reversingBits#debuggers--dynamic-analysis)

- [GDB](https://github.com/mohitmishra786/reversingBits/blob/main/src/gdb.md): The GNU Debugger for debugging programs at the source or assembly level.
- [OllyDbg](https://github.com/mohitmishra786/reversingBits/blob/main/src/ollydbg.md): A 32-bit assembler level debugger for Windows.
- [WinDbg](https://github.com/mohitmishra786/reversingBits/blob/main/src/windbg.md): Microsoft's debugger for Windows applications.
- [QEMU](https://github.com/mohitmishra786/reversingBits/blob/main/src/qemu.md): Emulator and virtualizer for cross-platform analysis.
- [Valgrind](https://github.com/mohitmishra786/reversingBits/blob/main/src/valgrind.md): Tool suite for debugging and profiling Linux programs.
- [Unicorn](https://github.com/mohitmishra786/reversingBits/blob/main/src/unicorn.md): Lightweight, multi-platform CPU emulator framework.

### Disassemblers & Decompilers

[Permalink: Disassemblers & Decompilers](https://github.com/mohitmishra786/reversingBits#disassemblers--decompilers)

- [IDA Pro](https://github.com/mohitmishra786/reversingBits/blob/main/src/idapro.md): Industry-standard disassembler and debugger.
- [Ghidra](https://github.com/mohitmishra786/reversingBits/blob/main/src/ghidra.md): NSA's software reverse engineering suite.
- [Binary Ninja](https://github.com/mohitmishra786/reversingBits/blob/main/src/binaryninja.md): Modern reverse engineering platform.
- [Hopper](https://github.com/mohitmishra786/reversingBits/blob/main/src/hopper.md): Reverse engineering tool for macOS and Linux.
- [RetDec](https://github.com/mohitmishra786/reversingBits/blob/main/src/retdec.md): Retargetable machine-code decompiler.
- [Radare2](https://github.com/mohitmishra786/reversingBits/blob/main/src/radare2.md): Complete framework for reverse-engineering.
- [Rizin](https://github.com/mohitmishra786/reversingBits/blob/main/src/rizin.md): Fork of radare2 with enhanced features.

### Binary Analysis Frameworks

[Permalink: Binary Analysis Frameworks](https://github.com/mohitmishra786/reversingBits#binary-analysis-frameworks)

- [Angr](https://github.com/mohitmishra786/reversingBits/blob/main/src/angr.md): Python framework for binary analysis.
- [BAP](https://github.com/mohitmishra786/reversingBits/blob/main/src/bap.md): Binary Analysis Platform for reverse engineering.
- [Capstone](https://github.com/mohitmishra786/reversingBits/blob/main/src/capstone.md): Lightweight multi-architecture disassembly framework.
- [Dyninst](https://github.com/mohitmishra786/reversingBits/blob/main/src/dyninst.md): Binary instrumentation and analysis library.
- [Frida](https://github.com/mohitmishra786/reversingBits/blob/main/src/frida.md): Dynamic instrumentation toolkit.
- [PIN](https://github.com/mohitmishra786/reversingBits/blob/main/src/pin.md): Intel's dynamic binary instrumentation framework.
- [Binary Ninja Cloud](https://github.com/mohitmishra786/reversingBits/blob/main/src/binaryninjacloud.md): Cloud-based reverse engineering platform by Vector 35.
- [Cutter](https://github.com/mohitmishra786/reversingBits/blob/main/src/cutter.md): A free and open-source reverse engineering platform based on the QEMU emulator and the Capstone disassembly engine.
- [Binary Analysis Tool (BAT)](https://github.com/mohitmishra786/reversingBits/blob/main/src/binaryanalysistool.md): A framework for automated binary code analysis, providing a unified interface for various binary analysis tools.
- [Miasm](https://github.com/mohitmishra786/reversingBits/blob/main/src/miasm.md): A reverse engineering framework written in Python, focused on advanced binary analysis and code instrumentation.
- [Triton](https://github.com/mohitmishra786/reversingBits/blob/main/src/triton.md): A dynamic binary analysis framework based on PIN, providing a powerful constraint solver for symbolic execution.
- [PEDA](https://github.com/mohitmishra786/reversingBits/blob/main/src/peda.md): Python Exploit Development Assistance for GDB, enhancing the GDB debugger with additional functionality for reverse engineering.
- [.NET IL Viewer](https://github.com/mohitmishra786/reversingBits/blob/main/src/dotnetILviewer.md): A tool for analyzing .NET assemblies, allowing you to view the disassembled code and metadata.
- [Snowman](https://github.com/mohitmishra786/reversingBits/blob/main/src/snowman.md): A decompiler for x86/x64 binaries, providing a graphical user interface and support for multiple file formats.

### Malware Analysis & Security

[Permalink: Malware Analysis & Security](https://github.com/mohitmishra786/reversingBits#malware-analysis--security)

- [YARA](https://github.com/mohitmishra786/reversingBits/blob/main/src/yara.md): Pattern matching tool for malware analysis.
- [Zynamics](https://github.com/mohitmishra786/reversingBits/blob/main/src/zynamics.md): Binary difference analysis tools.
- [Intel XED](https://github.com/mohitmishra786/reversingBits/blob/main/src/intelXed.md): X86 encoder decoder library.
- [Spike](https://github.com/mohitmishra786/reversingBits/blob/main/src/spike.md): Network protocol fuzzer.
- [FrEEdom](https://github.com/mohitmishra786/reversingBits/blob/main/src/freedom.md): Binary analysis framework.
- [Diaphora](https://github.com/mohitmishra786/reversingBits/blob/main/src/diaphora.md): Advanced binary diffing tool for IDA Pro.

## Star History

[Permalink: Star History](https://github.com/mohitmishra786/reversingBits#star-history)

[![Star History Chart](https://camo.githubusercontent.com/20ecff0e4de433e6845b98a1e6183778762d7980be6515d616f2cfc572650d44/68747470733a2f2f6170692e737461722d686973746f72792e636f6d2f7376673f7265706f733d6d6f6869746d69736872613738362f726576657273696e674269747326747970653d44617465)](https://star-history.com/#mohitmishra786/reversingBits&Date)

## How to Use

[Permalink: How to Use](https://github.com/mohitmishra786/reversingBits#how-to-use)

- **Installation:** Follow the OS-specific instructions in each cheatsheet for tool installation.
- **Usage:** Each file contains usage examples, common commands, and advanced tips.
- **Contributing:** If you have improvements or additional tools to add, please fork the repository, make your changes, and submit a pull request.

## License

[Permalink: License](https://github.com/mohitmishra786/reversingBits#license)

This repository is licensed under the MIT License - see the [LICENSE](https://github.com/mohitmishra786/reversingBits/blob/main/LICENSE) file for details.

## Acknowledgements

[Permalink: Acknowledgements](https://github.com/mohitmishra786/reversingBits#acknowledgements)

- Thanks to the developers and communities behind these tools for their invaluable resources.
- Contributions are always appreciated! Check the [CONTRIBUTING.md](https://github.com/mohitmishra786/reversingBits/blob/main/CONTRIBUTING.md) for guidelines on how to contribute.

## About

A comprehensive collection of cheatsheets for reverse engineering, binary analysis, and assembly programming tools. This repository serves as a one-stop reference for security researchers, reverse engineers, and low-level programmers.


[mohitmishra786.github.io/reversingBits/](https://mohitmishra786.github.io/reversingBits/ "https://mohitmishra786.github.io/reversingBits/")

### Topics

[debugging](https://github.com/topics/debugging "Topic: debugging") [assembly](https://github.com/topics/assembly "Topic: assembly") [x86-64](https://github.com/topics/x86-64 "Topic: x86-64") [static-analysis](https://github.com/topics/static-analysis "Topic: static-analysis") [reverse-engineering](https://github.com/topics/reverse-engineering "Topic: reverse-engineering") [cybersecurity](https://github.com/topics/cybersecurity "Topic: cybersecurity") [penetration-testing](https://github.com/topics/penetration-testing "Topic: penetration-testing") [dynamic-analysis](https://github.com/topics/dynamic-analysis "Topic: dynamic-analysis") [malware-analysis](https://github.com/topics/malware-analysis "Topic: malware-analysis") [binary-analysis](https://github.com/topics/binary-analysis "Topic: binary-analysis") [program-analysis](https://github.com/topics/program-analysis "Topic: program-analysis") [binary-exploitation](https://github.com/topics/binary-exploitation "Topic: binary-exploitation") [disassembly](https://github.com/topics/disassembly "Topic: disassembly") [ctf-tools](https://github.com/topics/ctf-tools "Topic: ctf-tools") [reversing](https://github.com/topics/reversing "Topic: reversing") [system-security](https://github.com/topics/system-security "Topic: system-security") [security-tools](https://github.com/topics/security-tools "Topic: security-tools") [vulnerability-research](https://github.com/topics/vulnerability-research "Topic: vulnerability-research") [x86-assembly](https://github.com/topics/x86-assembly "Topic: x86-assembly") [cybersecurity-tools](https://github.com/topics/cybersecurity-tools "Topic: cybersecurity-tools")

### Resources

[Readme](https://github.com/mohitmishra786/reversingBits#readme-ov-file)

### License

[MIT license](https://github.com/mohitmishra786/reversingBits#MIT-1-ov-file)

### Code of conduct

[Code of conduct](https://github.com/mohitmishra786/reversingBits#coc-ov-file)

### Contributing

[Contributing](https://github.com/mohitmishra786/reversingBits#contributing-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mohitmishra786/reversingBits).

[Activity](https://github.com/mohitmishra786/reversingBits/activity)

### Stars

[**610**\\
stars](https://github.com/mohitmishra786/reversingBits/stargazers)

### Watchers

[**9**\\
watching](https://github.com/mohitmishra786/reversingBits/watchers)

### Forks

[**68**\\
forks](https://github.com/mohitmishra786/reversingBits/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fmohitmishra786%2FreversingBits&report=mohitmishra786+%28user%29)

## [Releases](https://github.com/mohitmishra786/reversingBits/releases)

No releases published

## [Packages\  0](https://github.com/users/mohitmishra786/packages?repo_name=reversingBits)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mohitmishra786/reversingBits).

## [Contributors\  2](https://github.com/mohitmishra786/reversingBits/graphs/contributors)

- [![@mohitmishra786](https://avatars.githubusercontent.com/u/71754779?s=64&v=4)](https://github.com/mohitmishra786)[**mohitmishra786** chessMan](https://github.com/mohitmishra786)
- [![@actions-user](https://avatars.githubusercontent.com/u/65916846?s=64&v=4)](https://github.com/actions-user)[**actions-user**](https://github.com/actions-user)

## Languages

- [HTML100.0%](https://github.com/mohitmishra786/reversingBits/search?l=html)

You can’t perform that action at this time.