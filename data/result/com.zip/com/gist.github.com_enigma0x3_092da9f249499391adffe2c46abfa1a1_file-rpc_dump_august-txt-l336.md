# https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1#file-rpc_dump_august-txt-L336

[Skip to content](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1#start-of-content)

[Gist Homepage ](https://gist.github.com/)

Search Gists

Search Gists

[Gist Homepage ](https://gist.github.com/)

[Sign in](https://gist.github.com/auth/github?return_to=https%3A%2F%2Fgist.github.com%2Fenigma0x3%2F092da9f249499391adffe2c46abfa1a1) [Sign up](https://gist.github.com/join?return_to=https%3A%2F%2Fgist.github.com%2Fenigma0x3%2F092da9f249499391adffe2c46abfa1a1&source=header-gist)

You signed in with another tab or window. [Reload](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1) to refresh your session.You signed out in another tab or window. [Reload](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1) to refresh your session.You switched accounts on another tab or window. [Reload](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1) to refresh your session.Dismiss alert

{{ message }}

Instantly share code, notes, and snippets.


[![@enigma0x3](https://avatars.githubusercontent.com/u/6264733?s=64&v=4)](https://gist.github.com/enigma0x3)

# [enigma0x3](https://gist.github.com/enigma0x3)/ **[rpc\_dump\_august.txt](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1)**

Forked from [masthoon/rpc\_dump\_rs4.txt](https://gist.github.com/masthoon/510dd757b21f04da47431e9d4e0a3f6e)

Created
8 years agoOctober 23, 2018 17:20

Show Gist options

- [Download ZIP](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1/archive/70b6bac53157663398c251a1680929e56fc869d7.zip)

- [Star7(7)](https://gist.github.com/login?return_to=https%3A%2F%2Fgist.github.com%2Fenigma0x3%2F092da9f249499391adffe2c46abfa1a1) You must be signed in to star a gist
- [Fork1(1)](https://gist.github.com/login?return_to=https%3A%2F%2Fgist.github.com%2Fenigma0x3%2F092da9f249499391adffe2c46abfa1a1) You must be signed in to fork a gist

- Embed








# Select an option





























  - Embed
    Embed this gist in your website.
  - Share
    Copy sharable link for this gist.
  - Clone via HTTPS
    Clone using the web URL.

## No results found

[Learn more about clone URLs](https://docs.github.com/articles/which-remote-url-should-i-use)

Clone this repository at &lt;script src=&quot;https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1.js&quot;&gt;&lt;/script&gt;

- Save enigma0x3/092da9f249499391adffe2c46abfa1a1 to your computer and use it in GitHub Desktop.

Embed

# Select an option

- Embed
Embed this gist in your website.
- Share
Copy sharable link for this gist.
- Clone via HTTPS
Clone using the web URL.

## No results found

[Learn more about clone URLs](https://docs.github.com/articles/which-remote-url-should-i-use)

Clone this repository at &lt;script src=&quot;https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1.js&quot;&gt;&lt;/script&gt;

Save enigma0x3/092da9f249499391adffe2c46abfa1a1 to your computer and use it in GitHub Desktop.

[Download ZIP](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1/archive/70b6bac53157663398c251a1680929e56fc869d7.zip)

RPC interfaces dump August 2018


[Raw](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1/raw/70b6bac53157663398c251a1680929e56fc869d7/rpc_dump_august.txt)

[**rpc\_dump\_august.txt**](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1#file-rpc_dump_august-txt)

This file contains hidden or bidirectional Unicode text that may be interpreted or compiled differently than what appears below. To review, open the file in an editor that reveals hidden Unicode characters.
[Learn more about bidirectional Unicode characters](https://github.co/hiddenchars)

[Show hidden characters](https://gist.github.com/enigma0x3/092da9f249499391adffe2c46abfa1a1)

|     |     |
| --- | --- |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "smss.exe" pid 520 at 0x5db0c50L> |
|  | 64 |
|  | \[!!\] Invalid rpcrt4 base: 0x0 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "csrss.exe" pid 776 at 0x5db0908L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "wininit.exe" pid 876 at 0x5db0e48L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC 76f226c3-ec14-4325-8a99-6a46348418ae (1.0) -- C:\\WINDOWS\\system32\\wininit.exe |
|  | 0 -> I\_WMsgkSendMessage |
|  | 1 -> I\_WMsgkSendPSPMessage |
|  | RPC 894de0c0-0d55-11d3-a322-00c04fa321a1 (1.0) -- C:\\WINDOWS\\system32\\wininit.exe |
|  | 0 -> s\_BaseInitiateShutdown |
|  | 1 -> s\_BaseAbortShutdown |
|  | 2 -> s\_BaseInitiateShutdownEx |
|  | RPC d95afe70-a6d5-4259-822e-2c84da1ddb0d (1.0) -- C:\\WINDOWS\\system32\\wininit.exe |
|  | 0 -> s\_WsdrInitiateShutdown |
|  | 1 -> s\_WsdrAbortShutdown |
|  | 2 -> s\_WsdrCheckForHiberboot |
|  | RPC 76f226c3-ec14-4325-8a99-6a46348418af (1.0) -- C:\\WINDOWS\\system32\\wininit.exe |
|  | 0 -> I\_WMsgSendMessage |
|  | 1 -> I\_WMsgSendPSPMessage |
|  | 2 -> I\_WMsgSendNotifyMessage |
|  | 3 -> I\_WMsgSendReconnectionUpdateMessage |
|  | Endpoints : |
|  | ncalrpc : WMsgKRpc017ED30 |
|  | ncacn\_np : \\PIPE\\InitShutdown |
|  | ncalrpc : WindowsShutdown |
|  | ncacn\_ip\_tcp : 1536 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "services.exe" pid 948 at 0x5db0f28L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC 367abb81-9844-35f1-ad32-98f038001003 (2.0) -- C:\\WINDOWS\\system32\\services.exe |
|  | 0 -> RCloseServiceHandle |
|  | 1 -> RControlService |
|  | 2 -> RDeleteService |
|  | 3 -> RLockServiceDatabase |
|  | 4 -> RQueryServiceObjectSecurity |
|  | 5 -> RSetServiceObjectSecurity |
|  | 6 -> RQueryServiceStatus |
|  | 7 -> RSetServiceStatus |
|  | 8 -> RUnlockServiceDatabase |
|  | 9 -> RNotifyBootConfigStatus |
|  | 10 -> RI\_ScSetServiceBitsW |
|  | 11 -> RChangeServiceConfigW |
|  | 12 -> RCreateServiceW |
|  | 13 -> REnumDependentServicesW |
|  | 14 -> REnumServicesStatusW |
|  | 15 -> ROpenSCManagerW |
|  | 16 -> ROpenServiceW |
|  | 17 -> RQueryServiceConfigW |
|  | 18 -> RQueryServiceLockStatusW |
|  | 19 -> RStartServiceW |
|  | 20 -> RGetServiceDisplayNameW |
|  | 21 -> RGetServiceKeyNameW |
|  | 22 -> CServiceRecord::GetStatusInternal |
|  | 23 -> RChangeServiceConfigA |
|  | 24 -> RCreateServiceA |
|  | 25 -> REnumDependentServicesA |
|  | 26 -> REnumServicesStatusA |
|  | 27 -> ROpenSCManagerA |
|  | 28 -> ROpenServiceA |
|  | 29 -> RQueryServiceConfigA |
|  | 30 -> RQueryServiceLockStatusA |
|  | 31 -> RStartServiceA |
|  | 32 -> RGetServiceDisplayNameA |
|  | 33 -> RGetServiceKeyNameA |
|  | 34 -> CServiceRecord::GetStatusInternal |
|  | 35 -> REnumServiceGroupW |
|  | 36 -> RChangeServiceConfig2A |
|  | 37 -> RChangeServiceConfig2W |
|  | 38 -> RQueryServiceConfig2A |
|  | 39 -> RQueryServiceConfig2W |
|  | 40 -> RQueryServiceStatusEx |
|  | 41 -> REnumServicesStatusExA |
|  | 42 -> REnumServicesStatusExW |
|  | 43 -> RI\_ScBroadcastServiceControlMessage |
|  | 44 -> RCreateServiceWOW64A |
|  | 45 -> RCreateServiceWOW64W |
|  | 46 -> RI\_ScQueryServiceTagInfo |
|  | 47 -> RNotifyServiceStatusChange |
|  | 48 -> RGetNotifyResults |
|  | 49 -> RCloseNotifyHandle |
|  | 50 -> RControlServiceExA |
|  | 51 -> RControlServiceExW |
|  | 52 -> RI\_ScSendPnPMessage |
|  | 53 -> RI\_ScValidatePnPService |
|  | 54 -> RI\_ScOpenServiceStatusHandle |
|  | 55 -> RI\_ScQueryServiceConfig |
|  | 56 -> RQueryServiceConfigEx |
|  | 57 -> RI\_ScRegisterPreshutdownRestart |
|  | 58 -> RI\_ScReparseServiceDatabase |
|  | 59 -> RQueryUserServiceName |
|  | 60 -> RCreateWowService |
|  | 61 -> RGetServiceRegistryStateKey |
|  | 62 -> RGetServiceDirectory |
|  | RPC a2c45f7c-7d32-46ad-96f5-adafb486be74 (1.0) -- C:\\WINDOWS\\system32\\services.exe |
|  | 0 -> RI\_ScOpenServiceChannelHandle |
|  | 1 -> RI\_ScSendResponseReceiveControls |
|  | 2 -> RI\_ScCloseServiceChannelHandle |
|  | RPC 93149ca2-973b-11d1-8c39-00c04fb984f9 (0.0) -- C:\\WINDOWS\\SYSTEM32\\scesrv.dll |
|  | 0 -> SceSvcRpcQueryInfo |
|  | 1 -> SceSvcRpcSetInfo |
|  | 2 -> SceRpcSetupUpdateObject |
|  | 3 -> SceRpcSetupMoveFile |
|  | 4 -> SceRpcGenerateTemplate |
|  | 5 -> SceRpcConfigureSystem |
|  | 6 -> SceRpcGetDatabaseInfo |
|  | 7 -> SceRpcGetObjectChildren |
|  | 8 -> SceRpcOpenDatabase |
|  | 9 -> SceRpcCloseDatabase |
|  | 10 -> SceRpcGetDatabaseDescription |
|  | 11 -> SceRpcGetDBTimeStamp |
|  | 12 -> SceRpcGetObjectSecurity |
|  | 13 -> SceRpcGetAnalysisSummary |
|  | 14 -> SceRpcAnalyzeSystem |
|  | 15 -> SceRpcUpdateDatabaseInfo |
|  | 16 -> SceRpcUpdateObjectInfo |
|  | 17 -> SceRpcStartTransaction |
|  | 18 -> SceRpcCommitTransaction |
|  | 19 -> SceRpcRollbackTransaction |
|  | 20 -> SceRpcGetServerProductType |
|  | 21 -> SceSvcRpcUpdateInfo |
|  | 22 -> SceRpcCopyObjects |
|  | 23 -> SceRpcSetupResetLocalPolicy |
|  | 24 -> SceRpcNotifySaveChangesInGP |
|  | 25 -> SceRpcControlNotificationQProcess |
|  | 26 -> SceRpcBrowseDatabaseTable |
|  | 27 -> SceRpcGetSystemSecurity |
|  | 28 -> SceRpcGetSystemSecurity |
|  | 29 -> SceRpcSetSystemSecurity |
|  | 30 -> SceRpcSetSystemSecurity |
|  | 31 -> SceRpcSetDatabaseSetting |
|  | 32 -> SceRpcGetDatabaseSetting |
|  | 33 -> SceRpcConfigureConvertedFileSecurityImmediately |
|  | Endpoints : |
|  | ncalrpc : ntsvcs |
|  | ncacn\_np : \\pipe\\ntsvcs |
|  | ncacn\_np : \\PIPE\\scerpc |
|  | ncacn\_ip\_tcp : 1543 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "LsaIso.exe" pid 968 at 0x5db0c88L> |
|  | 64 |
|  | \[!!\] Invalid rpcrt4 base: 0x0 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "lsass.exe" pid 980 at 0x5e18358L> |
|  | 64 |
|  | \['KeyIso', 'SamSs', 'VaultSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 12345778-1234-abcd-ef00-0123456789ab (0.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> LsarClose |
|  | 1 -> CredrRename |
|  | 2 -> LsarEnumeratePrivileges |
|  | 3 -> LsarQuerySecurityObject |
|  | 4 -> LsarSetSecurityObject |
|  | 5 -> LsaITestCall |
|  | 6 -> LsarOpenPolicyRPC |
|  | 7 -> LsarQueryInformationPolicy |
|  | 8 -> LsarSetInformationPolicy |
|  | 9 -> LsaITestCall |
|  | 10 -> LsarCreateAccount |
|  | 11 -> LsarEnumerateAccounts |
|  | 12 -> LsarCreateTrustedDomain |
|  | 13 -> LsarEnumerateTrustedDomains |
|  | 14 -> LsarLookupNames |
|  | 15 -> LsarLookupSids |
|  | 16 -> LsarCreateSecret |
|  | 17 -> LsarOpenAccount |
|  | 18 -> LsarEnumeratePrivilegesAccount |
|  | 19 -> LsarAddPrivilegesToAccount |
|  | 20 -> LsarRemovePrivilegesFromAccount |
|  | 21 -> LsarGetQuotasForAccount |
|  | 22 -> LsarSetQuotasForAccount |
|  | 23 -> LsarGetSystemAccessAccount |
|  | 24 -> LsarSetSystemAccessAccount |
|  | 25 -> LsarOpenTrustedDomain |
|  | 26 -> LsarQueryInfoTrustedDomain |
|  | 27 -> LsarSetInformationTrustedDomain |
|  | 28 -> LsarOpenSecret |
|  | 29 -> LsarSetSecret |
|  | 30 -> LsarQuerySecret |
|  | 31 -> LsarLookupPrivilegeValue |
|  | 32 -> LsarLookupPrivilegeName |
|  | 33 -> LsarLookupPrivilegeDisplayName |
|  | 34 -> LsarDeleteObject |
|  | 35 -> LsarEnumerateAccountsWithUserRight |
|  | 36 -> LsarEnumerateAccountRights |
|  | 37 -> LsarAddAccountRights |
|  | 38 -> LsarRemoveAccountRights |
|  | 39 -> LsarQueryTrustedDomainInfo |
|  | 40 -> LsarSetTrustedDomainInfo |
|  | 41 -> LsarDeleteTrustedDomain |
|  | 42 -> LsarStorePrivateData |
|  | 43 -> LsarRetrievePrivateData |
|  | 44 -> LsarOpenPolicy2 |
|  | 45 -> LsarGetUserName |
|  | 46 -> LsarQueryInformationPolicy2 |
|  | 47 -> LsarSetInformationPolicy2 |
|  | 48 -> LsarQueryTrustedDomainInfoByName |
|  | 49 -> LsarSetTrustedDomainInfoByName |
|  | 50 -> LsarEnumerateTrustedDomainsEx |
|  | 51 -> LsarCreateTrustedDomainEx |
|  | 52 -> LsaITestCall |
|  | 53 -> LsarQueryDomainInformationPolicy |
|  | 54 -> LsarSetDomainInformationPolicy |
|  | 55 -> LsarOpenTrustedDomainByName |
|  | 56 -> LsaITestCall |
|  | 57 -> LsarLookupSids2 |
|  | 58 -> LsarLookupNames2 |
|  | 59 -> LsarCreateTrustedDomainEx2 |
|  | 60 -> CredrWrite |
|  | 61 -> CredrRead |
|  | 62 -> CredrEnumerate |
|  | 63 -> CredrWriteDomainCredentials |
|  | 64 -> CredrReadDomainCredentials |
|  | 65 -> CredrDelete |
|  | 66 -> CredrGetTargetInfo |
|  | 67 -> CredrProfileLoaded |
|  | 68 -> LsarLookupNames3 |
|  | 69 -> CredrGetSessionTypes |
|  | 70 -> LsarRegisterAuditEvent |
|  | 71 -> LsarGenAuditEvent |
|  | 72 -> LsarUnregisterAuditEvent |
|  | 73 -> LsarQueryForestTrustInformation |
|  | 74 -> LsarSetForestTrustInformation |
|  | 75 -> CredrRename |
|  | 76 -> LsarLookupSids3 |
|  | 77 -> LsarLookupNames4 |
|  | 78 -> LsarOpenPolicySce |
|  | 79 -> LsarAdtRegisterSecurityEventSource |
|  | 80 -> LsarAdtUnregisterSecurityEventSource |
|  | 81 -> LsarAdtReportSecurityEvent |
|  | 82 -> CredrFindBestCredential |
|  | 83 -> LsarSetAuditPolicy |
|  | 84 -> LsarQueryAuditPolicy |
|  | 85 -> LsarEnumerateAuditPolicy |
|  | 86 -> LsarEnumerateAuditCategories |
|  | 87 -> LsarEnumerateAuditSubCategories |
|  | 88 -> LsarLookupAuditCategoryName |
|  | 89 -> LsarLookupAuditSubCategoryName |
|  | 90 -> LsarSetAuditSecurity |
|  | 91 -> LsarQueryAuditSecurity |
|  | 92 -> CredrReadByTokenHandle |
|  | 93 -> CredrRestoreCredentials |
|  | 94 -> CredrBackupCredentials |
|  | 95 -> LsarManageSidNameMapping |
|  | 96 -> CredrProfileUnloaded |
|  | 97 -> CredrRename |
|  | 98 -> CredrRename |
|  | 99 -> CredrRename |
|  | 100 -> CredrRename |
|  | 101 -> CredrRename |
|  | 102 -> LsarEfsGetSmartcardCredentials |
|  | 103 -> LsarAuditSetGlobalSacl |
|  | 104 -> LsarAuditQueryGlobalSacl |
|  | 105 -> CredrProfileLoadedEx |
|  | 106 -> LsarInteractiveSessionIsLoggedOff |
|  | 107 -> LsarConfigureAutoLogonCredentials |
|  | 108 -> LsarGetDeviceRegistrationInfo |
|  | 109 -> LsaITestCall |
|  | 110 -> LsarProfileDeleted |
|  | 111 -> LsaITestCall |
|  | 112 -> LsarMakeLogonSessionsSiblings |
|  | 113 -> LsarValidateProcUniqueLuid |
|  | 114 -> LsarIsArsoAllowedByPolicy |
|  | 115 -> LsarIsArsoAllowedByConsent |
|  | 116 -> LsarEnableArsoConsent |
|  | 117 -> LsarDisableArsoConsent |
|  | 118 -> LsarIsArsoAllowedByPolicy |
|  | 119 -> LsarIsUserArsoEnabled |
|  | 120 -> LsarEnableUserArso |
|  | 121 -> LsarDisableUserArso |
|  | 122 -> LsarConfigureUserArso |
|  | 123 -> LsarGetInprocDispatchTable |
|  | 124 -> LsarSetSharedUserSession |
|  | 125 -> LsarClearSharedUserSession |
|  | RPC ace1c026-8b3f-4711-8918-f345d17f5bff (1.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> S\_RPC\_LspUpdatePrivateData |
|  | 1 -> S\_RPC\_LspReadPrivateData |
|  | RPC afc07e2e-311c-4435-808c-c483ffeec7c9 (1.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> LsarGetAvailableCAPIDs |
|  | 1 -> LsarSetCAPs |
|  | 2 -> LsarQueryCAPs |
|  | RPC c0d930f0-b787-4124-99bc-21f0ecb642ce (0.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> LsarConnectLocalUser |
|  | 1 -> LsarDisconnectLocalUser |
|  | 2 -> LsarCreateConnectedUser |
|  | 3 -> LsarIsCurrentUserConnected |
|  | 4 -> LsarRenewCertificate |
|  | 5 -> LsarGetSSOAccountType |
|  | 6 -> LsarIsUserMSA |
|  | RPC d25576e4-00d2-43f7-98f9-b4c0724158f9 (0.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> LsarEasMarkUserControlled |
|  | 1 -> LsarEasGetCallerPasswordComplexity |
|  | 2 -> LsarEasGetControlledUsersInfo |
|  | RPC c681d488-d850-11d0-8c52-00c04fd90f7e (1.0) -- C:\\WINDOWS\\system32\\efslsaext.dll |
|  | 0 -> EfsRpcOpenFileRaw\_Downlevel |
|  | 1 -> EfsRpcReadFileRaw\_Downlevel |
|  | 2 -> EfsRpcWriteFileRaw\_Downlevel |
|  | 3 -> EfsRpcCloseRaw\_Downlevel |
|  | 4 -> EfsRpcEncryptFileSrv\_Downlevel |
|  | 5 -> EfsRpcDecryptFileSrv\_Downlevel |
|  | 6 -> EfsRpcQueryUsersOnFile\_Downlevel |
|  | 7 -> EfsRpcQueryRecoveryAgents\_Downlevel |
|  | 8 -> EfsRpcRemoveUsersFromFile\_Downlevel |
|  | 9 -> EfsRpcAddUsersToFile\_Downlevel |
|  | 10 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 11 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 12 -> EfsRpcFileKeyInfo\_Downlevel |
|  | 13 -> EfsRpcDuplicateEncryptionInfoFile\_Downlevel |
|  | 14 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 15 -> EfsRpcAddUsersToFileEx\_Downlevel |
|  | 16 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 17 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 18 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 19 -> EfsRpcFileKeyInfoEx\_Downlevel |
|  | 20 -> EfsRpcFlushEfsCache\_Downlevel |
|  | RPC fb8a0729-2d04-4658-be93-27b4ad553fac (1.0) -- C:\\WINDOWS\\system32\\lsass.exe |
|  | 0 -> LsaLookuprOpenPolicy2 |
|  | 1 -> LsaLookuprClose |
|  | 2 -> LsaLookuprTranslateSids2 |
|  | 3 -> LsaLookuprTranslateNames3 |
|  | 4 -> LsaLookuprManageCache |
|  | 5 -> LsaLookuprGetDomainInfo |
|  | 6 -> LsaLookuprUserAccountType |
|  | RPC 4f32adc8-6052-4a04-8701-293ccf2096f0 (1.0) -- C:\\WINDOWS\\SYSTEM32\\SspiSrv.dll |
|  | 0 -> SspirConnectRpc |
|  | 1 -> SspirDisconnectRpc |
|  | 2 -> SspirDisconnectRpc |
|  | 3 -> SspirCallRpc |
|  | 4 -> SspirAcquireCredentialsHandle |
|  | 5 -> SspirFreeCredentialsHandle |
|  | 6 -> SspirProcessSecurityContext |
|  | 7 -> SspirDeleteSecurityContext |
|  | 8 -> SspirSslQueryCredentialsAttributes |
|  | 9 -> SspirNegQueryContextAttributes |
|  | 10 -> SspirSslSetCredentialsAttributes |
|  | 11 -> SspirApplyControlToken |
|  | 12 -> SspirLogonUser |
|  | 13 -> SspirLookupAccountSid |
|  | 14 -> SspirGetUserName |
|  | 15 -> SspirGetInprocDispatchTable |
|  | RPC 11220835-5b26-4d94-ae86-c3e475a809de (1.0) -- C:\\WINDOWS\\system32\\dpapisrv.dll |
|  | 0 -> s\_SSCryptProtectData |
|  | 1 -> s\_SSCryptUnprotectData |
|  | 2 -> s\_SSCryptUpdateProtectedState |
|  | RPC 5cbe92cb-f4be-45c9-9fc9-33e73e557b20 (1.0) -- C:\\WINDOWS\\system32\\dpapisrv.dll |
|  | 0 -> s\_SSRecoverQueryStatus |
|  | 1 -> s\_SSRecoverImportRecoveryKey |
|  | 2 -> s\_SSRecoverPassword |
|  | RPC 7f1317a8-4dea-4fa2-a551-df5516ff8879 (1.0) -- C:\\WINDOWS\\system32\\dpapisrv.dll |
|  | 0 -> s\_LRpcSIDKeyProtect |
|  | 1 -> s\_LRpcSIDKeyUnprotect |
|  | RPC 3919286a-b10c-11d0-9ba8-00c04fd92ef5 (0.0) -- C:\\WINDOWS\\system32\\lsasrv.dll |
|  | 0 -> DsRolerGetPrimaryDomainInformation |
|  | RPC 12345778-1234-abcd-ef00-0123456789ac (1.0) -- C:\\WINDOWS\\SYSTEM32\\samsrv.dll |
|  | 0 -> SamrConnect |
|  | 1 -> SamrCloseHandle |
|  | 2 -> SamrSetSecurityObject |
|  | 3 -> SamrQuerySecurityObject |
|  | 4 -> SamrShutdownSamServer |
|  | 5 -> SamrLookupDomainInSamServer |
|  | 6 -> SamrEnumerateDomainsInSamServer |
|  | 7 -> SamrOpenDomain |
|  | 8 -> SamrQueryInformationDomain |
|  | 9 -> SamrSetInformationDomain |
|  | 10 -> SamrCreateGroupInDomain |
|  | 11 -> SamrEnumerateGroupsInDomain |
|  | 12 -> SamrCreateUserInDomain |
|  | 13 -> SamrEnumerateUsersInDomain |
|  | 14 -> SamrCreateAliasInDomain |
|  | 15 -> SamrEnumerateAliasesInDomain |
|  | 16 -> SamrGetAliasMembership |
|  | 17 -> SamrLookupNamesInDomain |
|  | 18 -> SamrLookupIdsInDomain |
|  | 19 -> SamrOpenGroup |
|  | 20 -> SamrQueryInformationGroup |
|  | 21 -> SamrSetInformationGroup |
|  | 22 -> SamrAddMemberToGroup |
|  | 23 -> SamrDeleteGroup |
|  | 24 -> SamrRemoveMemberFromGroup |
|  | 25 -> SamrGetMembersInGroup |
|  | 26 -> SamrSetMemberAttributesOfGroup |
|  | 27 -> SamrOpenAlias |
|  | 28 -> SamrQueryInformationAlias |
|  | 29 -> SamrSetInformationAlias |
|  | 30 -> SamrDeleteAlias |
|  | 31 -> SamrAddMemberToAlias |
|  | 32 -> SamrRemoveMemberFromAlias |
|  | 33 -> SamrGetMembersInAlias |
|  | 34 -> SamrOpenUser |
|  | 35 -> SamrDeleteUser |
|  | 36 -> SamrQueryInformationUser |
|  | 37 -> SamrSetInformationUser |
|  | 38 -> SamrChangePasswordUser |
|  | 39 -> SamrGetGroupsForUser |
|  | 40 -> SamrQueryDisplayInformation |
|  | 41 -> SamrGetDisplayEnumerationIndex |
|  | 42 -> SamrTestPrivateFunctionsDomain |
|  | 43 -> SamrTestPrivateFunctionsUser |
|  | 44 -> SamrGetUserDomainPasswordInformation |
|  | 45 -> SamrRemoveMemberFromForeignDomain |
|  | 46 -> SamrQueryInformationDomain2 |
|  | 47 -> SamrQueryInformationUser2 |
|  | 48 -> SamrQueryDisplayInformation2 |
|  | 49 -> SamrGetDisplayEnumerationIndex2 |
|  | 50 -> SamrCreateUser2InDomain |
|  | 51 -> SamrQueryDisplayInformation3 |
|  | 52 -> SamrAddMultipleMembersToAlias |
|  | 53 -> SamrRemoveMultipleMembersFromAlias |
|  | 54 -> SamrOemChangePasswordUser2 |
|  | 55 -> SamrUnicodeChangePasswordUser2 |
|  | 56 -> SamrGetDomainPasswordInformation |
|  | 57 -> SamrConnect2 |
|  | 58 -> SamrSetInformationUser2 |
|  | 59 -> SamrSetBootKeyInformation |
|  | 60 -> SamrGetBootKeyInformation |
|  | 61 -> SamrConnect3 |
|  | 62 -> SamrConnect4 |
|  | 63 -> SamrUnicodeChangePasswordUser3 |
|  | 64 -> SamrConnect5 |
|  | 65 -> SamrRidToSid |
|  | 66 -> SamrSetDSRMPassword |
|  | 67 -> SamrValidatePassword |
|  | 68 -> SamrQueryLocalizableAccountsInDomain |
|  | 69 -> SamrPerformGenericOperation |
|  | 70 -> SamrSyncDSRMPasswordFromAccount |
|  | 71 -> SamrLookupNamesInDomain2 |
|  | 72 -> SamrEnumerateUsersInDomain2 |
|  | RPC b25a52bf-e5dd-4f4a-aea6-8ca7272a0e86 (2.0) -- C:\\WINDOWS\\system32\\keyiso.dll |
|  | 0 -> s\_SrvRpcCreateContext |
|  | 1 -> s\_SrvRpcReleaseContext |
|  | 2 -> s\_SrvRpcCryptOpenStorageProvider |
|  | 3 -> s\_SrvRpcCryptIsAlgSupported |
|  | 4 -> s\_SrvRpcCryptEnumAlgorithms |
|  | 5 -> s\_SrvRpcCryptEnumKeys |
|  | 6 -> s\_SrvRpcCryptFreeBuffer |
|  | 7 -> s\_SrvRpcCryptFreeProvider |
|  | 8 -> s\_SrvRpcCryptFreeKey |
|  | 9 -> s\_SrvRpcCryptOpenKey |
|  | 10 -> s\_SrvRpcCryptCreatePersistedKey |
|  | 11 -> s\_SrvRpcCryptGetProviderProperty |
|  | 12 -> s\_SrvRpcCryptSetProviderProperty |
|  | 13 -> s\_SrvRpcCryptGetKeyProperty |
|  | 14 -> s\_SrvRpcCryptSetKeyProperty |
|  | 15 -> s\_SrvRpcCryptFinalizeKey |
|  | 16 -> s\_SrvRpcCryptEncrypt |
|  | 17 -> s\_SrvRpcCryptDecrypt |
|  | 18 -> s\_SrvRpcCryptImportKey |
|  | 19 -> s\_SrvRpcCryptExportKey |
|  | 20 -> s\_SrvRpcCryptSignHash |
|  | 21 -> s\_SrvRpcCryptVerifySignature |
|  | 22 -> s\_SrvRpcCryptDeleteKey |
|  | 23 -> s\_SrvRpcCryptNotifyChangeKey |
|  | 24 -> s\_SrvRpcCryptSecretAgreement |
|  | 25 -> s\_SrvRpcCryptDeriveKey |
|  | 26 -> s\_SrvRpcCryptFreeSecret |
|  | 27 -> s\_SrvRpcCryptCipherEncrypt |
|  | 28 -> s\_SrvRpcCryptCipherDecrypt |
|  | 29 -> s\_SrvRpcCryptKeyDerivation |
|  | 30 -> s\_SrvRpcCryptCreateClaim |
|  | 31 -> s\_SrvRpcCryptVerifyClaim |
|  | RPC 8fb74744-b2ff-4c00-be0d-9ef9a191fe1b (1.0) -- C:\\WINDOWS\\system32\\keyiso.dll |
|  | 0 -> s\_GetSymmetricPopKeyTransportKey |
|  | 1 -> s\_GetSymmetricPopKeyTransportKeyName |
|  | 2 -> s\_DeleteSymmetricPopKeyTransportKey |
|  | 3 -> s\_ImportSymmetricPopKey |
|  | 4 -> s\_SignWithSymmetricPopKey |
|  | 5 -> s\_VerifyWithSymmetricPopKey |
|  | 6 -> s\_DecryptWithSymmetricPopKey |
|  | 7 -> s\_EncryptWithSymmetricPopKey |
|  | 8 -> s\_GetKeyAttestationForContainerService |
|  | 9 -> s\_RenewKeyAttestation |
|  | 10 -> s\_GetPregenUserKey |
|  | 11 -> s\_GetPregenKeyState |
|  | RPC 51a227ae-825b-41f2-b4a9-1ac9557a1018 (1.0) -- C:\\WINDOWS\\system32\\keyiso.dll |
|  | 0 -> s\_TokenBindingGenerateTpmKeyFromSoftware |
|  | RPC bb8b98e8-84dd-45e7-9f34-c3fb6155eeed (1.0) -- C:\\Windows\\System32\\vaultsvc.dll |
|  | 0 -> VltCreateItemType |
|  | 1 -> VltDeleteItemType |
|  | 2 -> VltEnumerateItemTypes |
|  | 3 -> VltAddItem |
|  | 4 -> VltFindItems |
|  | 5 -> VltEnumerateItems |
|  | 6 -> VltGetItem |
|  | 7 -> VltRemoveItem |
|  | 8 -> VltGetItemType |
|  | 9 -> VltOpenVault |
|  | 10 -> VltCloseVault |
|  | 11 -> VltGetInformation |
|  | 12 -> VltEnumerateVaults |
|  | 13 -> VltEnumerateSettingUnits |
|  | 14 -> VltGetSettingUnit |
|  | 15 -> VltApplySettingUnit |
|  | 16 -> VltRemoveSettingUnit |
|  | 17 -> VltTriggerSync |
|  | 18 -> VltGetSettingUnitInfo |
|  | Endpoints : |
|  | ncacn\_np : \\pipe\\lsass |
|  | ncalrpc : audit |
|  | ncalrpc : securityevent |
|  | ncalrpc : LSARPC\_ENDPOINT |
|  | ncalrpc : lsacap |
|  | ncalrpc : LSA\_IDPEXT\_ENDPOINT |
|  | ncalrpc : LSA\_EAS\_ENDPOINT |
|  | ncalrpc : lsapolicylookup |
|  | ncalrpc : lsasspirpc |
|  | ncalrpc : protected\_storage |
|  | ncalrpc : SidKey Local End Point |
|  | ncalrpc : samss lpc |
|  | ncacn\_ip\_tcp : 1635 |
|  | ncalrpc : Vault |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 672 at 0x5e18a90L> |
|  | 64 |
|  | \['PlugPlay'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 748 at 0x5e18d68L> |
|  | 64 |
|  | \['BrokerInfrastructure', 'DcomLaunch', 'Power', 'SystemEventsBroker'\] |
|  |  |
|  | Interfaces : |
|  | RPC 6c9b7b96-45a8-4cca-9eb3-e21ccf8b5a89 (1.1) -- c:\\windows\\system32\\umpo.dll |
|  | 0 -> UmpoRpcGetPowerConfiguration |
|  | 1 -> UmpoRpcReadFromSystemPowerKey |
|  | 2 -> UmpoRpcReadFromUserPowerKey |
|  | 3 -> UmpoRpcReadACValue |
|  | 4 -> UmpoRpcReadDCValue |
|  | 5 -> UmpoRpcWriteToSystemPowerKey |
|  | 6 -> UmpoRpcWriteToUserPowerKey |
|  | 7 -> UmpoRpcApplyPowerRequestOverride |
|  | 8 -> UmpoRpcApplyPowerSetting |
|  | 9 -> UmpoRpcSetActiveScheme |
|  | 10 -> UmpoRpcGetActiveScheme |
|  | 11 -> UmpoRpcSetActiveOverlayScheme |
|  | 12 -> UmpoRpcGetActualOverlayScheme |
|  | 13 -> UmpoRpcGetEffectiveOverlayScheme |
|  | 14 -> UmpoRpcGetOverlaySchemes |
|  | 15 -> UmpoRpcRestoreDefaultScheme |
|  | 16 -> UmpoRpcRestoreDefaultSchemesAll |
|  | 17 -> UmpoRpcDuplicateScheme |
|  | 18 -> UmpoRpcDeleteScheme |
|  | 19 -> UmpoRpcImportScheme |
|  | 20 -> UmpoRpcReplaceDefaultPowerSchemes |
|  | 21 -> UmpoRpcLegacyEventRegisterNotification |
|  | 22 -> UmpoRpcEnumerate |
|  | 23 -> UmpoRpcReadSecurityDescriptor |
|  | 24 -> UmpoRpcWriteSecurityDescriptor |
|  | 25 -> UmpoRpcSettingAccessCheck |
|  | 26 -> UmpoRpcCreateSetting |
|  | 27 -> UmpoRpcCreatePossibleSetting |
|  | 28 -> UmpoRpcRemoveSetting |
|  | 29 -> UmpoSetExpectedUserAwayIntervals |
|  | 30 -> UmpoClearExpectedUserAwayIntervals |
|  | 31 -> UmpoGetMinUserAwayPredictionInterval |
|  | 32 -> UmpoRpcGetAdaptiveStandbyDiagnostics |
|  | RPC 9b8699ae-0e44-47b1-8e7f-86a461d7ecdc (0.0) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> \_LaunchActivatorServer |
|  | 1 -> \_LaunchRunAsServer |
|  | 2 -> \_LaunchService |
|  | 3 -> LaunchWinRTActivatorServer |
|  | 4 -> \_LaunchWinRTRunAsServer |
|  | 5 -> \_LaunchWinRTService |
|  | 6 -> \_CertifyServerIdentity |
|  | 7 -> \_QueryNTService |
|  | 8 -> \_QueryNTServiceType |
|  | 9 -> ControlNTService |
|  | 10 -> PrivRunAsSetWinstaDesktop |
|  | 11 -> PrivRunAsRelease |
|  | 12 -> PrivRunAsInvalidateAndRelease |
|  | 13 -> PrivTranslateShareName |
|  | 14 -> GenericMarshalingStreamWithContextAttributesViaCallback<<lambda\_9644d90489056d7e1fb2e547ff4245ea> >::Clone |
|  | 15 -> IsPortOpen |
|  | 16 -> TickleActivationSettings |
|  | 17 -> QueryProcessArchitecture |
|  | 18 -> PrivilegedNotifyWinRTActivationStoreChanged |
|  | 19 -> \_QueryUserSidForSession |
|  | 20 -> PrivActivatePsmServer |
|  | 21 -> \_PrivGetUserTokenForSession |
|  | 22 -> PrivGetBrokerToken |
|  | 23 -> PrivGetDesktopWinRTBrokerToken |
|  | 24 -> PrivGetPsmToken |
|  | 25 -> GetSessionUserTokenCacheDetails |
|  | 26 -> PrivilegedNotifyComClassChangesFromDeployment |
|  | 27 -> PrivGetPsmTokenWithDynamicId |
|  | 28 -> PrivGetInteractiveUserToken |
|  | 29 -> PrivReportUnhealthyProcess |
|  | RPC 4bec6bb8-b5c2-4b6f-b2c1-5da5cf92d0d9 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvActivateApplication |
|  | 1 -> PsmSrvCloseActivationChannel |
|  | 2 -> PsmSrvOpenActivationChannel |
|  | 3 -> PsmSrvRegisterProcess |
|  | RPC 085b0334-e454-4d91-9b8c-4134f9e793f3 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvInitializeExtension |
|  | 1 -> PsmSrvOpenManagementChannel |
|  | 2 -> PsmSrvSetApplicationState |
|  | 3 -> PsmSrvSetApplicationPriority |
|  | 4 -> PsmSrvReleaseCacheEntry |
|  | 5 -> PsmSrvAcquireCachedEntries |
|  | 6 -> PsmSrvQueryApplicationSwapState |
|  | 7 -> PsmSrvCloseActivationChannel |
|  | 8 -> PsmSrvSetApplicationProperties |
|  | 9 -> PsmSrvQueryApplicationProperties |
|  | 10 -> PsmSrvQueryApplicationResourceUsage |
|  | 11 -> PsmSrvQueryMemoryUsage |
|  | 12 -> PsmSrvResetMaxMemoryUsage |
|  | 13 -> PsmSrvQuerySharedCommit |
|  | RPC 8782d3b9-ebbd-4644-a3d8-e8725381919b (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvRegisterQuiesceResumeApp |
|  | 1 -> PsmSrvQuiesceCallbacksComplete |
|  | 2 -> PsmSrvCloseActivationChannel |
|  | RPC 3b338d89-6cfa-44b8-847e-531531bc9992 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvQueryApplicationPerformanceInformation |
|  | 1 -> PsmSrvQueryQuotaInformation |
|  | RPC bdaa0970-413b-4a3e-9e5d-f6dc9d7e0760 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvOpenTcChannel |
|  | 1 -> PsmSrvApplyTaskCompletion |
|  | 2 -> PsmSrvRegisterDynamicProcess |
|  | 3 -> PsmSrvCloseActivationChannel |
|  | 4 -> PsmSrvGetSessionInfo |
|  | RPC 5824833b-3c1a-4ad2-bdfd-c31d19e23ed2 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvRegisterAppPriorityNotification |
|  | 1 -> PsmSrvQueryApplicationResourceUsageForTimer |
|  | 2 -> PsmSrvTimerStart |
|  | 3 -> PsmSrvTimerCleanup |
|  | 4 -> PsmSrvTimerRemainingResourceTimeGet |
|  | 5 -> PsmSrvTimerElapsedResourceTimeGet |
|  | RPC 0361ae94-0316-4c6c-8ad8-c594375800e2 (1.0) -- c:\\windows\\system32\\psmsrv.dll |
|  | 0 -> PsmSrvQueryCurrentApplications |
|  | 1 -> PsmSrvQueryApplicationHosts |
|  | 2 -> PsmSrvQueryApplicationHostExecutionState |
|  | 3 -> PsmSrvQueryApplicationHostJob |
|  | 4 -> PsmSrvConnect |
|  | 5 -> PsmSrvDisconnect |
|  | 6 -> PsmSrvSubscribeToNotifications |
|  | 7 -> PsmSrvUnsubscribeFromNotifications |
|  | RPC 2d98a740-581d-41b9-aa0d-a88b9d5ce938 (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> RBiSrvActivateDeferredWorkItem |
|  | 1 -> RBiSrvActivateInBackground |
|  | 2 -> RBiSrvActivateWorkItem |
|  | 3 -> RBiSrvAssociateActivationProxy |
|  | 4 -> RBiSrvAssociateApplicationExtensionClass |
|  | 5 -> RBiSrvCancelWorkItem |
|  | 6 -> RBiSrvCreateEvent |
|  | 7 -> RBiSrvCreateEventForPackageName |
|  | 8 -> RBiSrvDeleteEvent |
|  | 9 -> RBiSrvDisassociateWorkItem |
|  | 10 -> RBiSrvDiscardPendingActivations |
|  | 11 -> RBiSrvEnumerateBrokeredEvents |
|  | 12 -> RBiSrvEnumerateUserContexts |
|  | 13 -> RBiSrvEnumerateUserSessions |
|  | 14 -> RBiSrvEnumerateWorkItemsForPackageName |
|  | 15 -> RBiSrvQueryBrokeredEvent |
|  | 16 -> RBiSrvQuerySystemStateBroadcastChannels |
|  | 17 -> RBiSrvQueryUserContext |
|  | 18 -> RBiSrvQueryUserSession |
|  | 19 -> RBiSrvQueryWorkItem |
|  | 20 -> RBiPtSrvQueryWorkItemStatusStateName |
|  | 21 -> RBiSrvSignalEvent |
|  | 22 -> RBiSrvSignalMultipleEvents |
|  | 23 -> RBiSrvSignalTriggerEvent |
|  | 24 -> RBiSrvUpdateEventParameters |
|  | 25 -> RBiSrvUpdateEventFlags |
|  | 26 -> RBiSrvUpdateEventInformation |
|  | RPC 8bfc3be1-6def-4e2d-af74-7c47cd0ade4a (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> RBiSrvActivateWorkItemForUser |
|  | 1 -> RBiSrvChangeApplicationStateForPackageNameForUser |
|  | 2 -> RBiSrvChangeApplicationStateForPsmKeyForUser |
|  | 3 -> RBiSrvChangeUserState |
|  | 4 -> RBiSrvEnumerateWorkItemsForPackageNameAndUser |
|  | 5 -> RBiSrvGetActiveBackgroundTasksEventForUser |
|  | 6 -> RBiSrvGetCancellationTimeoutInMs |
|  | 7 -> RBiSrvIsApplicationTerminateSensitiveForUser |
|  | 8 -> RBiSrvNotifyEndSession |
|  | 9 -> RBiSrvNotifyNewSession |
|  | 10 -> RBiSrvNotifyNewSessionComplete |
|  | 11 -> RBiSrvNotifyNewUser |
|  | 12 -> RBiSrvQueryWorkItemForUser |
|  | 13 -> RBiSrvResetActiveUserForPackage |
|  | 14 -> RBiSrvSetActiveUserForPackage |
|  | 15 -> RBiSrvTerminateApplicationHostForUser |
|  | 16 -> RBiSrvUpdateBackgroundAccessApplicationsForUser |
|  | RPC 1b37ca91-76b1-4f5e-a3c7-2abfc61f2bb0 (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> RBiRtSrvAddWaitableEvent |
|  | 1 -> RBiRtSrvAssociateWorkItem |
|  | 2 -> RBiRtSrvCreateEvent |
|  | 3 -> RBiRtSrvCreateEventForApp |
|  | 4 -> RBiRtSrvCreateStatusStateName |
|  | 5 -> RBiRtSrvDeleteEvent |
|  | 6 -> RBiRtSrvDisassociateWorkItem |
|  | 7 -> RBiRtSrvEnumerateBrokeredEvents |
|  | 8 -> RBiRtSrvEnumerateWorkItems |
|  | 9 -> RBiRtSrvGetWorkItemProperties |
|  | 10 -> RBiRtSrvInitiatePause |
|  | 11 -> RBiRtSrvQueryBrokerEventId |
|  | 12 -> RBiRtSrvQueryBrokerEventIdFromWorkItem |
|  | 13 -> RBiRtSrvRegisterWorkItem |
|  | 14 -> RBiRtSrvSignalEvent |
|  | 15 -> RBiRtSrvUpdateEventParameters |
|  | RPC c605f9fb-f0a3-4e2a-a073-73560f8d9e3e (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> RBiSrvSignalEvent |
|  | RPC 0d3e2735-cea0-4ecc-a9e2-41a2d81aed4e (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> RBiPtSrvActivateDeferredWorkItem |
|  | 1 -> RBiPtSrvActivateInBackground |
|  | 2 -> RBiPtSrvActivateWorkItem |
|  | 3 -> RBiPtSrvAssociateActivationProxy |
|  | 4 -> RBiPtSrvAssociateApplicationEntryPoint |
|  | 5 -> RBiPtSrvCancelWorkItem |
|  | 6 -> RBiPtSrvCreateEvent |
|  | 7 -> RBiPtSrvCreateEventForApp |
|  | 8 -> RBiPtSrvCreateEventForPackageName |
|  | 9 -> RBiPtSrvDeleteEvent |
|  | 10 -> RBiPtSrvDisableWorkItem |
|  | 11 -> RBiPtSrvDisassociateWorkItem |
|  | 12 -> RBiPtSrvEnableWorkItem |
|  | 13 -> RBiPtSrvEnumerateBrokeredEvents |
|  | 14 -> RBiPtSrvEnumerateWorkItemsForPackageName |
|  | 15 -> RBiPtSrvQueryBrokeredEvent |
|  | 16 -> RBiPtSrvQueryBrokerEventId |
|  | 17 -> RBiPtSrvQuerySystemStateBroadcastChannels |
|  | 18 -> RBiPtSrvQueryWorkItem |
|  | 19 -> RBiPtSrvQueryWorkItemStatusStateName |
|  | 20 -> RBiPtSrvSignalEvent |
|  | 21 -> RBiPtSrvSignalMultipleEvents |
|  | 22 -> RBiPtSrvSignalTriggerEvent |
|  | RPC 55e6b932-1979-45d6-90c5-7f6270724112 (1.0) -- C:\\WINDOWS\\SYSTEM32\\resourcepolicyserver.dll |
|  | 0 -> Srv\_GetResourcePolicyKey |
|  | 1 -> Srv\_GetResourcePolicyInformation |
|  | 2 -> Srv\_CreateResourcePolicy |
|  | 3 -> Srv\_GetResourcePolicyName |
|  | 4 -> Srv\_CreatePolicyEngineClientContext |
|  | 5 -> Srv\_ClosePolicyEngineClientContext |
|  | 6 -> Srv\_AcquireResources |
|  | 7 -> Srv\_ResSet\_Apply |
|  | 8 -> Srv\_ResSet\_ReleaseResources |
|  | 9 -> Srv\_ResSet\_SetProperty |
|  | 10 -> Srv\_ResSet\_GetProperty |
|  | 11 -> Srv\_ResSet\_SetExternalPriorities |
|  | 12 -> Srv\_ResSet\_NotifyPendingTransition |
|  | 13 -> Srv\_ResSet\_CreateTerminalResourceSet |
|  | 14 -> Srv\_ResSet\_UpdateImportanceAndResourceLimits |
|  | 15 -> Srv\_RegisterForPackageEnergyStateChangeNotifications |
|  | 16 -> Srv\_IsPackageInGoodEnergyState |
|  | 17 -> Srv\_ResourcePolicy\_SetProcessAffinityMask |
|  | 18 -> Srv\_ResourcePolicy\_RevertProcessAffinityMask |
|  | 19 -> Srv\_ResourcePolicy\_GetProcessGroupCount |
|  | 20 -> Srv\_ResourcePolicy\_GetProcessAffinityMask |
|  | 21 -> Srv\_ResourcePolicy\_SetGlobalProcessAffinityMask |
|  | 22 -> Srv\_ResourcePolicy\_GetGlobalGroupCount |
|  | 23 -> Srv\_ResourcePolicy\_GetGlobalProcessAffinityMask |
|  | 24 -> Srv\_QueryPackageInterruptiveUIState |
|  | 25 -> Srv\_QueryApplicationInterruptiveUIState |
|  | 26 -> Srv\_QueryApplicationInterruptiveUIStateByPsmKey |
|  | 27 -> Srv\_InterruptiveUIStateChanged\_Subscribe |
|  | 28 -> Srv\_InterruptiveUIStateChanged\_Unsubscribe |
|  | RPC 76c217bc-c8b4-4201-a745-373ad9032b1a (1.0) -- C:\\WINDOWS\\SYSTEM32\\resourcepolicyserver.dll |
|  | 0 -> Srv\_QueryApplicationEnergyUsage |
|  | 1 -> Srv\_GetDeviceSpecificConversionFactor |
|  | 2 -> Srv\_ResetTotalEnergyUsage |
|  | RPC 88abcbc3-34ea-76ae-8215-767520655a23 (0.0) -- C:\\WINDOWS\\SYSTEM32\\resourcepolicyserver.dll |
|  | 0 -> GcsSrv\_GetGameConfigSize |
|  | 1 -> GcsSrv\_GetGameConfig |
|  | 2 -> GcsSrv\_GetGameConfigSizeForClientProcess |
|  | 3 -> GcsSrv\_GetGameConfigForClientProcess |
|  | 4 -> GcsSrv\_ModifyGameConfig |
|  | 5 -> GcsSrv\_AddGameConfig |
|  | 6 -> GcsSrv\_RemoveGameConfig |
|  | 7 -> GcsSrv\_GetGameIdByAUMID |
|  | 8 -> GcsSrv\_GetGameIdByPID |
|  | 9 -> GcsSrv\_GetGameIdCount |
|  | 10 -> GcsSrv\_GetAllGameIds |
|  | 11 -> GcsSrv\_GetGameIdsByExeNameCount |
|  | 12 -> GcsSrv\_GetGameIdsByExeName |
|  | 13 -> GcsSrv\_GetGameProperty |
|  | 14 -> GcsSrv\_GetGamePropertySize |
|  | 15 -> GcsSrv\_SetGameProperty |
|  | 16 -> GcsSrv\_GetGlobalProperty |
|  | 17 -> GcsSrv\_GetGlobalPropertySize |
|  | 18 -> GcsSrv\_SetGlobalProperty |
|  | 19 -> GcsSrv\_SetGamePropertyUserOverride |
|  | 20 -> GcsSrv\_GetGamePropertyIsUserOverride |
|  | RPC 2c7fd9ce-e706-4b40-b412-953107ef9bb0 (0.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> RmgrSrv\_RegisterWithServer |
|  | 1 -> RmgrSrv\_RmSetMemoryUsageLimit |
|  | 2 -> RmgrSrv\_RmRegisterResource |
|  | 3 -> RmgrSrv\_RmAccessCheck |
|  | 4 -> RmgrSrv\_RmAccessCheckOnCaller |
|  | 5 -> RmgrSrv\_RmAvailabilityCheck |
|  | 6 -> RmgrSrv\_RmAcquireResources |
|  | 7 -> RmgrSrv\_RmGetNotification |
|  | 8 -> RmgrSrv\_RmReleaseResources |
|  | RPC c521facf-09a9-42c5-b155-72388595cbf0 (0.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> RmtSrv\_RM\_ConnectToServer |
|  | 1 -> RmtSrv\_RM\_DisconnectFromServer |
|  | 2 -> RmtSrv\_RM\_AcquireResourceSet |
|  | 3 -> RmtSrv\_RS\_Apply |
|  | 4 -> RmtSrv\_RS\_ReleaseResources |
|  | 5 -> RmtSrv\_RS\_CreateTerminalResourceSet |
|  | 6 -> RmtSrv\_RS\_SetExternalResourcePriorities |
|  | 7 -> RmtSrv\_RS\_SetAutoRelease |
|  | RPC 1832bcf6-cab8-41d4-85d2-c9410764f75a (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> RmCoreRpcSrvConnectToRmServer |
|  | 1 -> RmCoreRpcSrvDisconnectFromRmServer |
|  | 2 -> RmCoreRpcSrvRegisterActivityHostCallbacks |
|  | 3 -> RmCoreRpcSrvUnregisterActivityHostCallbacks |
|  | 4 -> RmCoreRpcSrvAcquireResourceSet |
|  | 5 -> RmCoreRpcSrvApplyResourceSet |
|  | 6 -> RmCoreRpcSrvReleaseResourceSet |
|  | 7 -> RmCoreRpcSrvSetHostLimits |
|  | 8 -> RmCoreRpcSrvQueryHostMemoryLimitValues |
|  | RPC 4dace966-a243-4450-ae3f-9b7bcb5315b8 (2.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> RmGameModeSrvRegisterProcess |
|  | 1 -> RmGameModeSrvUnregisterProcess |
|  | 2 -> RmGameModeSrvDisableForRegisteredProcess |
|  | 3 -> RmGameModeSrvReenableForRegisteredProcess |
|  | 4 -> RmGameModeSrvGetLargestValidResourceRequest |
|  | 5 -> RmGameModeSrvRegisterPairedAuxiliaryProcess |
|  | RPC e53d94ca-7464-4839-b044-09a2fb8b3ae5 (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnect |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvCreateActivity |
|  | 3 -> HamRpcSrvCreateActivityForProcess |
|  | 4 -> HamRpcSrvStartActivityAsync |
|  | 5 -> HamRpcSrvStopActivity |
|  | 6 -> HamRpcSrvUpdateActivityProperties |
|  | 7 -> HamRpcSrvTerminateActivityHost |
|  | 8 -> HamRpcSrvSetExternalResourcePriority |
|  | 9 -> HamRpcSrvResetExternalResourcePriority |
|  | 10 -> HamRpcSrvCloseActivity |
|  | 11 -> HamRpcSrvIsHostBeingDebugged |
|  | 12 -> HamRpcSrvTerminateHostOnProcessExit |
|  | 13 -> HamRpcSrvGetApplicationInterruptiveUIState |
|  | 14 -> HamRpcSrvGetPackageInterruptiveUIState |
|  | 15 -> HamRpcSrvGetInterruptiveUIStateForAumid |
|  | RPC 082a3471-31b6-422a-b931-a54401960c62 (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnectExtendedExecution |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvIsHostHamManaged |
|  | 3 -> HamRpcSrvQueryTaskCompletionsForTerminateGraph |
|  | 4 -> HamRpcSrvCreateExtendedExecution |
|  | 5 -> HamRpcSrvStartExtendedExecutionAsync |
|  | 6 -> HamRpcSrvCloseActivity |
|  | 7 -> HamRpcSrvAddDependency |
|  | 8 -> HamRpcSrvRemoveDependency |
|  | 9 -> HamRpcSrvAddHostDependency |
|  | 10 -> HamRpcSrvRemoveHostDependency |
|  | 11 -> HamRpcSrvTerminateSelf |
|  | 12 -> HamRpcSrvTryEstimateRemainingQuiesceTime |
|  | RPC 4ed8abcc-f1e2-438b-981f-bb0e8abc010c (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnectStateChangeNotifications |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvGetApplicationStateForPsmKey |
|  | 3 -> HamRpcSrvTerminateIfSuspendedByProcess |
|  | RPC 95406f0b-b239-4318-91bb-cea3a46ff0dc (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnectServicing |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvDebugOpenPackageHandle |
|  | 3 -> HamRpcSrvDebugClosePackageHandle |
|  | 4 -> HamRpcSrvServicingQueryActiveAppsInPackage |
|  | 5 -> HamRpcSrvServicingEnableServicing |
|  | 6 -> HamRpcSrvDebugTerminatePackage |
|  | RPC fae436b0-b864-4a87-9eda-298547cd82f2 (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnectDebugging |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvDebugOpenPackageHandle |
|  | 3 -> HamRpcSrvDebugClosePackageHandle |
|  | 4 -> HamRpcSrvDebugModeEnable |
|  | 5 -> HamRpcSrvDebugTerminatePackage |
|  | 6 -> HamRpcSrvDebugQueryPackageState |
|  | 7 -> HamRpcSrvDebugSuspendPackage |
|  | RPC 178d84be-9291-4994-82c6-3f909aca5a03 (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> RmGameModeRSrvRegisterProcess |
|  | 1 -> RmGameModeRSrvUnregisterProcess |
|  | 2 -> RmGameModeRSrvDisableForRegisteredProcess |
|  | 3 -> RmGameModeRSrvReenableForRegisteredProcess |
|  | 4 -> RmGameModeRSrvRegisterPairedAuxiliaryProcess |
|  | RPC 0d47017b-b33b-46ad-9e18-fe96456c5078 (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> HamRpcSrvConnectSessionState |
|  | 1 -> HamRpcSrvDisconnect |
|  | 2 -> HamRpcSrvSessionStateLogoffUser |
|  | 3 -> HamRpcSrvSessionStateLogoffSession |
|  | RPC dd59071b-3215-4c59-8481-972edadc0f6a (1.0) -- C:\\WINDOWS\\SYSTEM32\\psmserviceexthost.dll |
|  | 0 -> CrmRpcSrvSubscribe |
|  | 1 -> CrmRpcSrvUnsubscribe |
|  | 2 -> CrmRpcSrvWorkStart |
|  | 3 -> CrmRpcSrvWorkStop |
|  | RPC 2513bcbe-6cd4-4348-855e-7efb3c336dd3 (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> SrvOdbCreateSession |
|  | 1 -> SrvOdbCompleteSession |
|  | 2 -> SrvOdbLaunchBackgroundTask |
|  | 3 -> SrvOdbCancelBackgroundTask |
|  | 4 -> SrvOdbCancelBackgroundTasksForPackage |
|  | RPC 20c40295-8dba-48e6-aebf-3e78ef3bb144 (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> SrvOdbPtCreateSession |
|  | 1 -> SrvOdbPtCompleteSession |
|  | 2 -> SrvOdbPtLaunchBackgroundTask |
|  | 3 -> SrvOdbPtCancelBackgroundTask |
|  | 4 -> SrvOdbPtCancelBackgroundTasksForPackage |
|  | RPC b8cadbaf-e84b-46b9-84f2-6f71c03f9e55 (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> SrvOdbLbPublishLegacyExitCode |
|  | RPC 857fb1be-084f-4fb5-b59c-4b2c4be5f0cf (1.0) -- c:\\windows\\system32\\bisrv.dll |
|  | 0 -> SrvOdbPrivGetLaunchInfo |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | RPC d09bdeb5-6171-4a34-bfe2-06fa82652568 (1.0) -- c:\\windows\\system32\\BrokerLib.dll |
|  | 0 -> \_BriCreateEvent |
|  | 1 -> \_BriDeleteEvent |
|  | 2 -> BriDisableEvent |
|  | 3 -> BriEnableEvent |
|  | 4 -> BriSignalEvent |
|  | RPC 9b008953-f195-4bf9-bde0-4471971e58ed (1.0) -- c:\\windows\\system32\\systemeventsbrokerserver.dll |
|  | 0 -> SebiEnumerateEvents |
|  | 1 -> \_SebiEnumerateEventsByType |
|  | 2 -> SebiQueryEventData |
|  | 3 -> SebiQueryEventPackage |
|  | 4 -> SebiSignalSyncEventEx |
|  | 5 -> SebiGetUserPresenceHistory |
|  | RPC 697dcda9-3ba9-4eb2-9247-e11f1901b0d2 (1.0) -- c:\\windows\\system32\\systemeventsbrokerserver.dll |
|  | 0 -> CSebiCreateWellKnownEvent |
|  | 1 -> \_CSebiCreatePrivateEvent |
|  | 2 -> \_CSebiDeleteEvent |
|  | 3 -> CSebiEnumerateEvents |
|  | 4 -> CSebiQueryEventData |
|  | 5 -> CSebiCreateCustomEvent |
|  | RPC 1377d115-98fd-4034-b574-111156ca239c (1.0) -- c:\\windows\\system32\\systemeventsbrokerserver.dll |
|  | 0 -> \_CSebiRegisterPublisher |
|  | 1 -> CSebiPublisherUpdateLevelEvent |
|  | 2 -> CSebiUnregisterPublisher |
|  | RPC 7419cf08-91a7-4afd-8f5e-1dd76de094fd (1.0) -- c:\\windows\\system32\\DAB.dll |
|  | 0 -> s\_DabRpcRegisterTriggerConsumer |
|  | 1 -> s\_DabRpcUnregisterTriggerConsumer |
|  | 2 -> s\_DabRpcGetLastScheduledRunTime |
|  | RPC fc48cd89-98d6-4628-9839-86f7a3e4161a (1.0) -- C:\\Windows\\System32\\ACPBackgroundManagerPolicy.dll |
|  | 0 -> MVoipSrvNotifyVoipActiveCall |
|  | 1 -> MVoipSrvNotifyVoipActivityCompleted |
|  | 2 -> MVoipSrvHoldActiveCall |
|  | 3 -> MVoipSrvUnholdActiveCall |
|  | 4 -> MVoipSrvNotifyIncomingCallDialogDisplayed |
|  | 5 -> MVoipSrvNotifyIncomingCallDialogDismissed |
|  | 6 -> MVoipSrvLaunchVoipRtcTask |
|  | 7 -> MVoipSrvCancelVoipRtcTask |
|  | OLE 7656cfa4-b63a-4542-a8de-ef402bac895d (0.0) -- IUserApplicationStateChangeHandler |
|  | OLE 43c6b434-c1be-4ad2-af03-c0deaccebd1f (0.0) -- IBackgroundAccessStateChangeHandler |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 0166231b-fd21-4e33-a713-75eb3207a138 (0.0) -- IBackgroundWorkItemInstanceRemote |
|  | OLE 839d7762-5121-4009-9234-4f0d19394f04 (0.0) -- ITaskHandler |
|  | Endpoints : |
|  | ncalrpc : umpo |
|  | ncalrpc : actkernel |
|  | ncalrpc : LRPC-a0c225312c664cbe52 |
|  | ncalrpc : LRPC-9117321b1f3e68b3ea |
|  | ncalrpc : LRPC-c415227320dbc2b224 |
|  | ncalrpc : OLE725BEDE187C9611C6F16D2B71ED3 |
|  | ncalrpc : LRPC-ad9f8eadd07cbdf162 |
|  | ncalrpc : LRPC-77924dd5092f1575c4 |
|  | ncalrpc : LRPC-c3073d1124937de4cc |
|  | ncalrpc : csebpub |
|  | ncalrpc : dabrpc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "WUDFHost.exe" pid 744 at 0x5e18828L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1120 at 0x5e18438L> |
|  | 64 |
|  | \['RpcEptMapper', 'RpcSs'\] |
|  |  |
|  | Interfaces : |
|  | RPC e1af8308-5d1f-11c9-91a4-08002b14a0fa (3.0) -- c:\\windows\\system32\\rpcepmap.dll |
|  | 0 -> ept\_delete |
|  | 1 -> ept\_delete |
|  | 2 -> ept\_lookup |
|  | 3 -> ept\_map |
|  | 4 -> ept\_lookup\_handle\_free |
|  | 5 -> ept\_delete |
|  | 6 -> ept\_delete |
|  | 7 -> ept\_map\_auth |
|  | 8 -> ept\_map\_auth\_async |
|  | RPC 0b0a6584-9e0f-11cf-a3cf-00805f68cb1b (1.1) -- c:\\windows\\system32\\rpcepmap.dll |
|  | 0 -> OpenEndpointMapper |
|  | 1 -> AllocateReservedIPPort |
|  | 2 -> ept\_insert\_ex |
|  | 3 -> ept\_delete\_ex |
|  | 4 -> SetRestrictRemoteClients |
|  | 5 -> ResetWithNoAuthException |
|  | RPC 1d55b526-c137-46c5-ab79-638f2a68e869 (1.0) -- c:\\windows\\system32\\rpcepmap.dll |
|  | 0 -> RemoteGetCellByDebugCellID |
|  | 1 -> RemoteOpenRPCDebugCallInfoEnumeration |
|  | 2 -> RemoteGetNextRPCDebugCallInfo |
|  | 3 -> RemoteFinishRPCDebugCallInfoEnumeration |
|  | 4 -> RemoteOpenRPCDebugEndpointInfoEnumeration |
|  | 5 -> RemoteGetNextRPCDebugEndpointInfo |
|  | 6 -> RemoteFinishRPCDebugEndpointInfoEnumeration |
|  | 7 -> RemoteOpenRPCDebugThreadInfoEnumeration |
|  | 8 -> RemoteGetNextRPCDebugThreadInfo |
|  | 9 -> RemoteFinishRPCDebugThreadInfoEnumeration |
|  | 10 -> RemoteOpenRPCDebugClientCallInfoEnumeration |
|  | 11 -> RemoteGetNextRPCDebugClientCallInfo |
|  | 12 -> RemoteFinishRPCDebugClientCallInfoEnumeration |
|  | RPC 64fe0b7f-9ef5-4553-a7db-9a1975777554 (1.0) -- c:\\windows\\system32\\RpcRtRemote.dll |
|  | 0 -> FwConnectToManager |
|  | 1 -> FwSubscribeForNewRulesNotification |
|  | 2 -> FwInterfaceRegistered |
|  | RPC e60c73e6-88f9-11cf-9af1-0020af6e72f4 (2.0) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> \_Connect |
|  | 1 -> \_SetAppID |
|  | 2 -> GetDefaultSecurityPermissions |
|  | 3 -> \_AllocateReservedIds |
|  | 4 -> BulkUpdateOIDs |
|  | 5 -> \_ClientResolveOXID |
|  | 6 -> \_ServerAllocateOXIDAndOIDs |
|  | 7 -> \_ServerAllocateOIDs |
|  | 8 -> ServerFreeOXIDAndOIDs |
|  | 9 -> \_SetServerOIDFlags |
|  | 10 -> \_Disconnect |
|  | RPC 99fcfec4-5260-101b-bbcb-00aa0021347a (0.0) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> ResolveOxid |
|  | 1 -> SimplePing |
|  | 2 -> ComplexPing |
|  | 3 -> ServerAlive |
|  | 4 -> ResolveOxid2 |
|  | 5 -> ServerAlive2 |
|  | RPC b9e79e60-3d52-11ce-aaa1-00006901293f (0.2) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> IrotRegister |
|  | 1 -> IrotRevoke |
|  | 2 -> IrotIsRunning |
|  | 3 -> IrotGetObject |
|  | 4 -> IrotNoteChangeTime |
|  | 5 -> IrotGetTimeOfLastChange |
|  | 6 -> IrotEnumRunning |
|  | 7 -> IMgotRegister |
|  | 8 -> IMgotRevoke |
|  | 9 -> IMgotGetObject |
|  | 10 -> IMgotEnumRunning |
|  | RPC 412f241e-c12a-11ce-abff-0020af6e7a17 (0.2) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> ServerRegisterClsid |
|  | 1 -> ServerRevokeClsid |
|  | 2 -> ServerRegisterActivatableClasses |
|  | 3 -> ServerRevokeActivatableClasses |
|  | 4 -> GetThreadID |
|  | 5 -> UpdateActivationSettings |
|  | 6 -> RegisterWindowPropInterface |
|  | 7 -> GetWindowPropInterface |
|  | 8 -> EnableDisableDynamicIPTracking |
|  | 9 -> GetCurrentAddrExclusionList |
|  | 10 -> SetAddrExclusionList |
|  | 11 -> FlushSCMBindings |
|  | 12 -> RetireServer |
|  | 13 -> NotifyDDStartOrStop |
|  | 14 -> QueryDragDropActive |
|  | 15 -> SetOrRevokeForcedDropTarget |
|  | 16 -> IsObjectCreationAllowed |
|  | 17 -> ControlTracingForProcess |
|  | 18 -> QueryPIDForActivation |
|  | 19 -> NotifyWinRTActivationStoreChanged |
|  | 20 -> DecodeProxy |
|  | 21 -> NotifyPsmResume |
|  | 22 -> QueryServerProcessHandleHeld |
|  | 23 -> RegisterRacActivationToken |
|  | 24 -> RevokeRacActivationToken |
|  | 25 -> RegisterConsoleHandles |
|  | 26 -> RevokeConsoleHandles |
|  | 27 -> NotifyComClassChangesFromDeployment |
|  | DCOM 00000136-0000-0000-c000-000000000046 (0.0) -- ISCMLocalActivator |
|  | RPC c6f3ee72-ce7e-11d1-b71e-00c04fc3111a (1.0) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> ProcessActivatorStarted |
|  | 1 -> ProcessActivatorInitializing |
|  | 2 -> ProcessActivatorReady |
|  | 3 -> ProcessActivatorStopped |
|  | 4 -> ProcessActivatorPaused |
|  | 5 -> ProcessActivatorResumed |
|  | 6 -> ProcessActivatorUserInitializing |
|  | RPC 4d9f4ab8-7d1c-11cf-861e-0020af6e7c57 (0.0) -- c:\\windows\\system32\\rpcss.dll |
|  | 0 -> RemoteActivation |
|  | DCOM 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | Endpoints : |
|  | ncalrpc : epmapper |
|  | ncacn\_ip\_tcp : 135 |
|  | ncacn\_np : \\pipe\\epmapper |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1164 at 0x5e18748L> |
|  | 64 |
|  | \['LSM'\] |
|  |  |
|  | Interfaces : |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- c:\\windows\\system32\\SYSNTFY.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | RPC 11f25515-c879-400a-989e-b074d5f092fe (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcGetUserToken |
|  | 1 -> RpcConnectTerminal |
|  | 2 -> RpcSystemShutdownStarted |
|  | 3 -> RpcGetRequestForWinlogon |
|  | 4 -> RpcReportWinlogonReply |
|  | 5 -> RpcGetReconnectId |
|  | 6 -> RpcCreateWorkerSession |
|  | 7 -> RpcGetWorkerSessionGpuLuid |
|  | RPC 1e665584-40fe-4450-8f6e-802362399694 (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcBroadcastSystemMessage |
|  | 1 -> RpcSendWindowMessage |
|  | 2 -> RpcCreateSession |
|  | 3 -> RpcTerminateSession |
|  | RPC 484809d6-4239-471b-b5bc-61df8c23ac48 (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcOpenSession |
|  | 1 -> RpcCloseSession |
|  | 2 -> RpcConnect |
|  | 3 -> RpcDisconnect |
|  | 4 -> RpcLogoff |
|  | 5 -> RpcGetUserName |
|  | 6 -> RpcGetTerminalName |
|  | 7 -> RpcGetState |
|  | 8 -> RpcIsSessionDesktopLocked |
|  | 9 -> RpcShowMessageBox |
|  | 10 -> RpcGetTimes |
|  | 11 -> RpcGetSessionCounters |
|  | 12 -> RpcGetSessionInformation |
|  | 13 -> RpcSwitchToServicesSession |
|  | 14 -> RpcRevertFromServicesSession |
|  | 15 -> RpcGetLoggedOnCount |
|  | 16 -> RpcGetSessionType |
|  | 17 -> RpcGetSessionInformationEx |
|  | 18 -> RpcIsTerminalRemote |
|  | 19 -> RpcConnectAndLockTargetDesktop |
|  | RPC e3907f22-c899-44e7-9d11-9d8b3d924832 (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcEnableChildSessions |
|  | 1 -> RpcIsChildSessionsEnabled |
|  | 2 -> RpcGetChildSessionId |
|  | 3 -> RpcGetParentSessionId |
|  | 4 -> RpcGetAllUserSessions |
|  | RPC 53825514-1183-4934-a0f4-cfdc51c3389b (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcIsCurrentSessionTerminalRemote |
|  | 1 -> RpcGetCurrentSessionTerminalName |
|  | 2 -> RpcGetCurrentSessionInformation |
|  | 3 -> RpcGetCurrentSessionCapabilities |
|  | 4 -> RpcGetCurrentSessionType |
|  | RPC 11899a43-2b68-4a76-92e3-a3d6ad8c26ce (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcWaitForSessionState |
|  | 1 -> RpcRegisterAsyncNotification |
|  | 2 -> RpcWaitAsyncNotification |
|  | 3 -> RpcUnRegisterAsyncNotification |
|  | RPC c2d15ccf-a416-46dc-ba58-4624ac7a9123 (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcRegisterCurrentSessionAsyncNotification |
|  | 1 -> RpcWaitAsyncNotificationEx |
|  | 2 -> RpcUnRegisterAsyncNotificationEx |
|  | RPC 88143fd0-c28d-4b2b-8fef-8d882f6a9390 (1.0) -- c:\\windows\\system32\\lsm.dll |
|  | 0 -> RpcOpenEnum |
|  | 1 -> RpcCloseEnum |
|  | 2 -> RpcFilterByState |
|  | 3 -> RpcFilterByCallersName |
|  | 4 -> RpcEnumAddFilter |
|  | 5 -> RpcGetEnumResult |
|  | 6 -> RpcFilterBySessionType |
|  | 7 -> RpcFilterByLicenseType |
|  | 8 -> RpcGetSessionIds |
|  | 9 -> RpcGetEnumResultEx |
|  | 10 -> RpcGetAllSessions |
|  | 11 -> RpcGetAllSessionsEx |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 517f87fe-597a-4672-8555-6daf1c8c788d (0.0) -- ISessionManager |
|  | OLE 75a446c5-40b7-41d3-8d53-292652c04121 (0.0) -- ITSEventDispatcher |
|  | OLE 959c5a99-177c-478e-8c3b-77e07e9bf3aa (0.0) -- ISessionList |
|  | OLE a8105b4f-7d5a-402b-aac0-fd85daecf94c (0.0) -- ISessionEnum |
|  | OLE a1b7de7a-4e77-43db-ae78-96fc182fed4a (0.0) -- ITSSession |
|  | OLE 1a8a5d71-d95b-4dcd-915e-f9f6d31879ad (0.0) -- ITerminal |
|  | OLE 6344a5b7-ef1c-47ba-98b7-28c664427793 (0.0) -- IGlassTerminal |
|  | OLE c2d3e131-c587-49b4-8bae-f0ee269eeb31 (0.0) -- ITSSessionAttribute |
|  | OLE 35481b58-f46c-4254-b52c-fdc3001484c3 (0.0) -- IRestrictedCalls |
|  | OLE 4d10b48b-c531-4731-9bde-b03c28e9c61c (0.0) -- IUserName |
|  | Endpoints : |
|  | ncalrpc : LRPC-56fe77ce659d43da99 |
|  | ncalrpc : LSMApi |
|  | ncacn\_np : \\pipe\\LSM\_API\_service |
|  | ncalrpc : OLE72598D8A0D6838E6A3EBF8662F4B |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1396 at 0x5e18908L> |
|  | 64 |
|  | \['TermService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE be5a9fee-1c29-4aae-a6b7-feb0e4c96d5e (0.0) -- IConnectionManager |
|  | OLE 6e796d86-376c-46fe-8381-43982edd00fe (0.0) -- ITSNotifySink |
|  | RPC 2f59a331-bf7d-48cb-9e5c-7c090d76e8b8 (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcLicensingOpenServer |
|  | 1 -> RpcLicensingCloseServer |
|  | 2 -> RpcLicensingLoadPolicy |
|  | 3 -> RpcLicensingLoadPolicy |
|  | 4 -> RpcLicensingSetPolicy |
|  | 5 -> RpcLicensingGetAvailablePolicyIds |
|  | 6 -> RpcLicensingGetPolicy |
|  | 7 -> RpcLicensingGetPolicyInformation |
|  | 8 -> RpcLicensingDeactivateCurrentPolicy |
|  | 9 -> RpcLicensingServerPing |
|  | 10 -> RpcGetSessionUnderArbitration |
|  | RPC 1f260487-ba29-4f13-928a-bbd29761b083 (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcIsSessionPermitted |
|  | 1 -> RpcGetUserCredentials |
|  | 2 -> RpcGetUserProfile |
|  | 3 -> RpcWinStationRedirectErrorMessage |
|  | 4 -> RpcRedirectLogonBeginPainting |
|  | 5 -> RpcRedirectLogonStatus |
|  | 6 -> RpcRedirectLogonMessage |
|  | 7 -> RpcRedirectLogonError |
|  | 8 -> RpcGetRedirectAuthInfo |
|  | 9 -> RpcGetRestrictedLogonInfo |
|  | RPC ecd85155-cc3a-4f10-aad5-9a9a2bf2ef0c (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcSetAutologonPassword |
|  | RPC bde95fdf-eee0-45de-9e12-e5a61cd0d4fe (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcGetClientData |
|  | 1 -> RpcGetConfigData |
|  | 2 -> RpcGetProtocolStatus |
|  | 3 -> RpcGetLastInputTime |
|  | 4 -> RpcGetRemoteAddress |
|  | 5 -> RpcShadow |
|  | 6 -> RpcShadowTarget |
|  | 7 -> RpcShadowStop |
|  | 8 -> RpcGetAllListeners |
|  | 9 -> RpcGetSessionProtocolLastInputTime |
|  | 10 -> RpcGetUserCertificates |
|  | 11 -> RpcQuerySessionData |
|  | RPC 497d95a6-2d27-4bf5-9bbd-a6046957133c (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcOpenListener |
|  | 1 -> RpcCloseListener |
|  | 2 -> RpcStopListener |
|  | 3 -> RpcStartListener |
|  | 4 -> RpcIsListening |
|  | RPC 5267aaba-4f49-4653-8e26-d1e11f3f2ad9 (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcCreateVirtualChannel |
|  | 1 -> CConnectionEx::Connect |
|  | 2 -> RpcPopSecurityDialog |
|  | 3 -> RpcGetInitialApplication |
|  | 4 -> RpcGetConnectionProperty |
|  | 5 -> CConnectionEx::Connect |
|  | 6 -> RpcVerify |
|  | 7 -> RpcCreateChildSessionTransport |
|  | 8 -> RpcRcmShadow2 |
|  | 9 -> RpcShadowAccessCheck |
|  | 10 -> RpcShadowStop2 |
|  | RPC 28098650-fe3c-4af4-8a41-8bcd284941c5 (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcGetCurrentSessionConnectionProperty |
|  | 1 -> RpcGetCurrentSessionClientData |
|  | 2 -> RpcGetCurrentSessionConfigData |
|  | 3 -> RpcGetCurrentSessionProtocolLastInputTime |
|  | RPC 5ca4a760-ebb1-11cf-8611-00a0245420ed (1.0) -- c:\\windows\\system32\\termsrv.dll |
|  | 0 -> RpcWinStationOpenServer |
|  | 1 -> RpcWinStationCloseServer |
|  | 2 -> RpcIcaServerPing |
|  | 3 -> RpcWinStationEnumerate |
|  | 4 -> RpcWinStationRename |
|  | 5 -> RpcWinStationQueryInformation |
|  | 6 -> RpcWinStationSetInformation |
|  | 7 -> RpcWinStationSendMessage |
|  | 8 -> RpcLogonIdFromWinStationName |
|  | 9 -> RpcWinStationNameFromLogonId |
|  | 10 -> RpcWinStationConnect |
|  | 11 -> RpcWinStationVirtualOpen |
|  | 12 -> RpcWinStationBeepOpen |
|  | 13 -> RpcWinStationDisconnect |
|  | 14 -> RpcWinStationReset |
|  | 15 -> RpcWinStationShutdownSystem |
|  | 16 -> RpcWinStationWaitSystemEvent |
|  | 17 -> RpcWinStationShadow |
|  | 18 -> RpcWinStationShadowTargetSetup |
|  | 19 -> RpcWinStationShadowTarget |
|  | 20 -> RpcWinStationGenerateLicense |
|  | 21 -> RpcWinStationInstallLicense |
|  | 22 -> RpcWinStationEnumerateLicenses |
|  | 23 -> RpcWinStationActivateLicense |
|  | 24 -> RpcWinStationRemoveLicense |
|  | 25 -> RpcWinStationQueryLicense |
|  | 26 -> RpcWinStationSetPoolCount |
|  | 27 -> RpcWinStationQueryUpdateRequired |
|  | 28 -> RpcWinStationCallback |
|  | 29 -> RpcWinStationBreakPoint |
|  | 30 -> RpcWinStationReadRegistry |
|  | 31 -> RpcWinStationWaitForConnect |
|  | 32 -> RpcWinStationNotifyLogon |
|  | 33 -> RpcWinStationNotifyLogoff |
|  | 34 -> OldRpcWinStationEnumerateProcesses |
|  | 35 -> RpcWinStationAnnoyancePopup |
|  | 36 -> RpcWinStationEnumerateProcesses |
|  | 37 -> RpcWinStationTerminateProcess |
|  | 38 -> RpcServerNWLogonSetAdmin |
|  | 39 -> RpcServerNWLogonQueryAdmin |
|  | 40 -> RpcWinStationCheckForApplicationName |
|  | 41 -> RpcWinStationGetApplicationInfo |
|  | 42 -> RpcWinStationNtsdDebug |
|  | 43 -> RpcWinStationGetAllProcesses |
|  | 44 -> RpcWinStationGetProcessSid |
|  | 45 -> RpcWinStationGetTermSrvCountersValue |
|  | 46 -> RpcWinStationReInitializeSecurity |
|  | 47 -> RpcWinStationBroadcastSystemMessage |
|  | 48 -> RpcWinStationSendWindowMessage |
|  | 49 -> RpcWinStationNotifyNewSession |
|  | 50 -> RpcServerGetInternetConnectorStatus |
|  | 51 -> RpcServerSetInternetConnectorStatus |
|  | 52 -> RpcServerQueryInetConnectorInformation |
|  | 53 -> RpcWinStationGetLanAdapterName |
|  | 54 -> RpcWinStationUpdateUserConfig |
|  | 55 -> RpcWinStationQueryLogonCredentials |
|  | 56 -> RpcWinStationRegisterConsoleNotification |
|  | 57 -> RpcWinStationUnRegisterConsoleNotification |
|  | 58 -> RpcWinStationUpdateSettings |
|  | 59 -> RpcWinStationShadowStop |
|  | 60 -> RpcWinStationCloseServerEx |
|  | 61 -> RpcWinStationIsHelpAssistantSession |
|  | 62 -> RpcWinStationGetMachinePolicy |
|  | 63 -> RpcWinStationUpdateClientCachedCredentials |
|  | 64 -> RpcWinStationFUSCanRemoteUserDisconnect |
|  | 65 -> RpcWinStationCheckLoopBack |
|  | 66 -> RpcConnectCallback |
|  | 67 -> RpcWinStationNotifyDisconnectPipe |
|  | 68 -> RpcWinStationSessionInitialized |
|  | 69 -> RpcRemoteAssistancePrepareSystemRestore |
|  | 70 -> RpcWinStationGetAllProcesses\_NT6 |
|  | 71 -> RpcWinStationRegisterNotificationEvent |
|  | 72 -> RpcWinStationUnRegisterNotificationEvent |
|  | 73 -> RpcWinStationAutoReconnect |
|  | 74 -> RpcWinStationCheckAccess |
|  | 75 -> RpcWinStationOpenSessionDirectory |
|  | OLE 4d10b48b-c531-4731-9bde-b03c28e9c61c (0.0) -- IUserName |
|  | OLE a9052eea-734f-41d8-978b-e32cad12381a (0.0) -- ISessionArbitration |
|  | OLE 02e6ec4c-96e4-42e8-b533-336916a0087d (0.0) -- ISessionEnumFilter |
|  | Endpoints : |
|  | ncalrpc : OLEEABDDF036C5315E862E0343FC263 |
|  | ncalrpc : LcRpc |
|  | ncalrpc : TermSrvApi |
|  | ncacn\_np : \\pipe\\TermSrv\_API\_service |
|  | ncacn\_np : \\pipe\\Ctx\_WinStation\_API\_service |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1404 at 0x5e18a58L> |
|  | 64 |
|  | \['BDESVC'\] |
|  |  |
|  | Interfaces : |
|  | RPC ae55c4c0-64ce-11dd-ad8b-0800200c9a66 (1.0) -- c:\\windows\\system32\\bdesvc.dll |
|  | 0 -> BdeSvcApipAddRecoveryPassword |
|  | 1 -> BdeSvcApipConversionEncrypt |
|  | 2 -> BdeSvcApipEventTrigger |
|  | 3 -> BdeSvcApipChangeProtector |
|  | 4 -> BdeSvcApipConversionEncryptEx |
|  | 5 -> BdeSvcApipCheckADSchema |
|  | 6 -> BdeSvcApipQueryCachedEASProtectionStatus |
|  | 7 -> BdeSvcApipDoTurnOnDeviceEncryption |
|  | 8 -> BdeSvcApipEnableSilentDeviceEncryption |
|  | 9 -> BdeSvcApipEnableSilentBitLocker |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-33b5f6eebf56b84252 |
|  | ncalrpc : OLEE2E87CED3CCC1206BBA6ED3A58AB |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1508 at 0x5e181d0L> |
|  | 64 |
|  | \['NcbService'\] |
|  |  |
|  | Interfaces : |
|  | RPC d09bdeb5-6171-4a34-bfe2-06fa82652568 (1.0) -- c:\\windows\\system32\\BrokerLib.dll |
|  | 0 -> \_BriCreateEvent |
|  | 1 -> \_BriDeleteEvent |
|  | 2 -> BriDisableEvent |
|  | 3 -> BriEnableEvent |
|  | 4 -> BriSignalEvent |
|  | RPC 5222821f-d5e2-4885-84f1-5f6185a0ec41 (1.0) -- c:\\windows\\system32\\ncbservice.dll |
|  | 0 -> RpcSrvRegisterControlChannelReset |
|  | 1 -> RpcSrvUnregisterControlChannelReset |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | RPC 880fd55e-43b9-11e0-b1a8-cf4edfd72085 (1.0) -- c:\\windows\\system32\\ncbservice.dll |
|  | 0 -> KapiRegisterProvider |
|  | 1 -> KapiDeregisterProvider |
|  | 2 -> KapiUpdateKaSample |
|  | 3 -> KapiReceiveKaUpdateRequest |
|  | RPC e40f7b57-7a25-4cd3-a135-7f7d3df9d16b (1.0) -- c:\\windows\\system32\\ncbservice.dll |
|  | 0 -> RpcSrvCreateSession |
|  | 1 -> RpcSrvDestroySession |
|  | 2 -> RpcSrvStartBrokeredActivation |
|  | 3 -> RpcSrvSetServerKeepAliveInterval |
|  | 4 -> RpcSrvGetCurrentKeepAliveInterval |
|  | 5 -> RpcSrvDecreaseKeepAliveInterval |
|  | 6 -> RpcSrvUsingTransport |
|  | 7 -> RpcSrvIndicateSlotAllocation |
|  | 8 -> RpcSrvSBCreatePushEnabledContext |
|  | 9 -> RpcSrvSBTransferOwnership |
|  | 10 -> RpcSrvSBRetrieveSocket |
|  | 11 -> RpcSrvSBCompleteRetrieveSocket |
|  | 12 -> RpcSrvSBRetrieveContext |
|  | 13 -> RpcSrvSBEnumSockets |
|  | 14 -> RpcSrvCreateRadioDevice |
|  | 15 -> RpcSrvDeleteRadioDevice |
|  | 16 -> RpcSrvHotspotRegisterHotspotApp |
|  | 17 -> RpcSrvHotspotFindEventForPackage |
|  | 18 -> RpcSrvHotspotTriggerBackgroundEvent |
|  | 19 -> RpcSrvHotspotIsAppInstalled |
|  | 20 -> RpcSrvFirewallWcmSetFirewallRule |
|  | 21 -> RpcSrvFirewallWcmSetFirewallRuleFlags |
|  | 22 -> RpcSrvFirewallWcmDeleteFirewallRule |
|  | Endpoints : |
|  | ncalrpc : LRPC-313331d19214b6495c |
|  | ncalrpc : LRPC-fb5f696445160b36fd |
|  | ncalrpc : OLE9764AD9A03F54AA6A31D01B9E095 |
|  | ncalrpc : LRPC-613198ad3a2d3b1d80 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1516 at 0x5e188d0L> |
|  | 64 |
|  | \['TimeBrokerSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC d09bdeb5-6171-4a34-bfe2-06fa82652568 (1.0) -- c:\\windows\\system32\\BrokerLib.dll |
|  | 0 -> \_BriCreateEvent |
|  | 1 -> \_BriDeleteEvent |
|  | 2 -> BriDisableEvent |
|  | 3 -> BriEnableEvent |
|  | 4 -> BriSignalEvent |
|  | RPC a500d4c6-0dd1-4543-bc0c-d5f93486eaf8 (1.0) -- c:\\windows\\system32\\timebrokerserver.dll |
|  | 0 -> TbiEnumerateEvents |
|  | 1 -> TbiQueryEventData |
|  | 2 -> \_TbiUpdateEvent |
|  | 3 -> TbiQueryCEventData |
|  | 4 -> \_TbiQueryCEventTriggerTime |
|  | 5 -> \_TbiUpdateCEvent |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-79f50bbbaf08bfdf31 |
|  | ncalrpc : LRPC-3f91aa657c2b5629c4 |
|  | ncalrpc : OLE4BB861028DFA5B85A3C54E9A040F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1628 at 0x5e18668L> |
|  | 64 |
|  | \['hidserv'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1636 at 0x5e18cc0L> |
|  | 64 |
|  | \['HvHost'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1716 at 0x5e18e10L> |
|  | 64 |
|  | \['EventLog'\] |
|  |  |
|  | Interfaces : |
|  | RPC 82273fdc-e32a-18c3-3f78-827929dc23ea (0.0) -- c:\\windows\\system32\\wevtsvc.dll |
|  | 0 -> ElfrClearELFW |
|  | 1 -> ElfrBackupELFW |
|  | 2 -> ElfrCloseEL |
|  | 3 -> ElfrDeregisterEventSource |
|  | 4 -> ElfrNumberOfRecords |
|  | 5 -> ElfrOldestRecord |
|  | 6 -> ElfrChangeNotify |
|  | 7 -> ElfrOpenELW |
|  | 8 -> ElfrRegisterEventSourceW |
|  | 9 -> ElfrOpenBELW |
|  | 10 -> ElfrReadELW |
|  | 11 -> ElfrReportEventW |
|  | 12 -> ElfrClearELFA |
|  | 13 -> ElfrBackupELFA |
|  | 14 -> ElfrOpenELA |
|  | 15 -> ElfrRegisterEventSourceA |
|  | 16 -> ElfrOpenBELA |
|  | 17 -> ElfrReadELA |
|  | 18 -> ElfrReportEventA |
|  | 19 -> ElfrRegisterClusterSvc |
|  | 20 -> ElfrDeregisterClusterSvc |
|  | 21 -> ElfrWriteClusterEvents |
|  | 22 -> ElfrGetLogInformation |
|  | 23 -> ElfrFlushEL |
|  | 24 -> ElfrReportEventAndSourceW |
|  | 25 -> ElfrReportEventExW |
|  | 26 -> ElfrReportEventExA |
|  | RPC f6beaff7-1e19-4fbb-9f8f-b89e2018337c (1.0) -- c:\\windows\\system32\\wevtsvc.dll |
|  | 0 -> \_EvtRpcRegisterRemoteSubscription |
|  | 1 -> \_EvtRpcRemoteSubscriptionNextAsync |
|  | 2 -> \_EvtRpcRemoteSubscriptionNext |
|  | 3 -> EvtRpcRemoteSubscriptionWaitAsync |
|  | 4 -> EvtRpcRegisterControllableOperation |
|  | 5 -> \_EvtRpcRegisterLogQuery |
|  | 6 -> EvtRpcClearLog |
|  | 7 -> EvtRpcExportLog |
|  | 8 -> EvtRpcLocalizeExportLog |
|  | 9 -> \_EvtRpcMessageRender |
|  | 10 -> EvtRpcMessageRenderDefault |
|  | 11 -> \_EvtRpcQueryNext |
|  | 12 -> \_EvtRpcQuerySeek |
|  | 13 -> EvtRpcClose |
|  | 14 -> EvtRpcCancel |
|  | 15 -> \_EvtRpcAssertConfig |
|  | 16 -> \_EvtRpcRetractConfig |
|  | 17 -> \_EvtRpcOpenLogHandle |
|  | 18 -> \_EvtRpcGetLogFileInfo |
|  | 19 -> \_EvtRpcGetChannelList |
|  | 20 -> \_EvtRpcGetChannelConfig |
|  | 21 -> EvtRpcPutChannelConfig |
|  | 22 -> \_EvtRpcGetPublisherList |
|  | 23 -> EvtRpcGetPublisherListForChannel |
|  | 24 -> \_EvtRpcGetPublisherMetadata |
|  | 25 -> \_EvtRpcGetPublisherResourceMetadata |
|  | 26 -> EvtRpcGetEventMetadataEnum |
|  | 27 -> EvtRpcGetNextEventMetadata |
|  | 28 -> \_EvtRpcGetClassicLogDisplayName |
|  | Endpoints : |
|  | ncalrpc : eventlog |
|  | ncacn\_np : \\pipe\\eventlog |
|  | ncacn\_ip\_tcp : 1537 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1944 at 0x5e184e0L> |
|  | 64 |
|  | \['nsi'\] |
|  |  |
|  | Interfaces : |
|  | RPC 7ea70bcf-48af-4f6a-8968-6a440754d5fa (1.0) -- c:\\windows\\system32\\nsisvc.dll |
|  | 0 -> RpcNsiGetParameter |
|  | 1 -> RpcNsiGetAllParameters |
|  | 2 -> RpcNsiEnumerateObjectsAllParameters |
|  | 3 -> RpcNsiSetParameter |
|  | 4 -> RpcNsiSetAllParameters |
|  | 5 -> RpcNsiRegisterChangeNotification |
|  | 6 -> RpcNsiDeregisterChangeNotification |
|  | 7 -> RpcNsiRequestChangeNotification |
|  | 8 -> RpcNsiParameterChange |
|  | Endpoints : |
|  | ncalrpc : LRPC-a9e30291416fef1f94 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "NVDisplay.Container.exe" pid 1964 at 0x5e184a8L> |
|  | 64 |
|  | \['NVDisplay.ContainerLocalSystem'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE dc09760e-9fda-454a-b9d2-7e663e58c39d (0.0) -- ISyncProxy |
|  | OLE 4473e3a7-c2ad-4075-a1f8-935a584740a9 (0.0) -- IStateEvents |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE e6ab4158-38b8-4fdf-85cf-adc2e9870970 (0.0) -- IStateData |
|  | Endpoints : |
|  | ncalrpc : OLE746562F804CA9A0BF02362173C98 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2044 at 0x5275da0L> |
|  | 64 |
|  | \['Dhcp'\] |
|  |  |
|  | Interfaces : |
|  | RPC 3c4728c5-f0ab-448b-bda1-6ce01eb0a6d6 (1.0) -- c:\\windows\\system32\\dhcpcore6.dll |
|  | 0 -> RpcSrvRequestPrefixEx |
|  | 1 -> RpcSrvRenewPrefixEx |
|  | 2 -> RpcSrvReleasePrefixEx |
|  | 3 -> RpcSrvCancelOperation |
|  | 4 -> RpcSrvEnablev6Tracing |
|  | 5 -> RpcSrvRequestParams |
|  | 6 -> RpcSrvAcquireParametersv6 |
|  | 7 -> RpcSrvReleaseParametersv6 |
|  | 8 -> RpcSrvQueryLeaseInfov6 |
|  | 9 -> RpcSrvGetTraceArray |
|  | 10 -> RpcSrvSetUserClass |
|  | 11 -> RpcSrvQueryLeaseInfov6Array |
|  | 12 -> RpcSrvEnableDhcpv6 |
|  | RPC 3c4728c5-f0ab-448b-bda1-6ce01eb0a6d5 (1.0) -- c:\\windows\\system32\\dhcpcore.dll |
|  | 0 -> RpcSrvEnableDhcp |
|  | 1 -> RpcSrvRenewLease |
|  | 2 -> RpcSrvDeleteStaticAddressAndDefaultGateways |
|  | 3 -> RpcSrvCheckServerAvailability |
|  | 4 -> RpcSrvRenewLeaseByBroadcast |
|  | 5 -> RpcSrvReleaseLease |
|  | 6 -> RpcSrvSetFallbackParams |
|  | 7 -> RpcSrvGetFallbackParams |
|  | 8 -> RpcSrvFallbackRefreshParams |
|  | 9 -> RpcSrvStaticRefreshParams |
|  | 10 -> RpcSrvRemoveDnsRegistrations |
|  | 11 -> RpcSrvRequestParams |
|  | 12 -> RpcSrvPersistentRequestParams |
|  | 13 -> RpcSrvRegisterParams |
|  | 14 -> RpcSrvDeRegisterParams |
|  | 15 -> RpcSrvEnumInterfaces |
|  | 16 -> RpcSrvQueryLeaseInfo |
|  | 17 -> RpcSrvQueryLeaseInfoArray |
|  | 18 -> RpcSrvSetClassId |
|  | 19 -> RpcSrvGetClassId |
|  | 20 -> RpcSrvSetClientId |
|  | 21 -> RpcSrvGetClientId |
|  | 22 -> RpcSrvNotifyMediaReconnected |
|  | 23 -> RpcSrvGetOriginalSubnetMask |
|  | 24 -> RpcSrvSetMSFTVendorSpecificOptions |
|  | 25 -> RpcSrvRequestCachedParams |
|  | 26 -> RpcSrvRegisterConnectionStateNotification |
|  | 27 -> RpcSrvDeRegisterConnectionStateNotification |
|  | 28 -> RpcSrvGetNotificationStatus |
|  | 29 -> RpcSrvGetDhcpServicedConnections |
|  | 30 -> RpcSrvGetTraceArray |
|  | 31 -> RpcSrvEnableTracing |
|  | 32 -> RpcSrvLeaseIpAddressEx |
|  | 33 -> RpcSrvRenewIpAddressLeaseEx |
|  | 34 -> RpcSrvReleaseIpAddressLeaseEx |
|  | 35 -> RpcSrvMadcapApiStartup |
|  | 36 -> RpcSrvMadcapApiCleanup |
|  | 37 -> RpcSrvMadcapEnumerateScopes |
|  | 38 -> RpcSrvMadcapGenUID |
|  | 39 -> RpcSrvMadcapRequestAddress |
|  | 40 -> RpcSrvMadcapRenewAddress |
|  | 41 -> RpcSrvMadcapReleaseAddress |
|  | Endpoints : |
|  | ncalrpc : dhcpcsvc6 |
|  | ncalrpc : dhcpcsvc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 768 at 0x5e18048L> |
|  | 64 |
|  | \['UmRdpService'\] |
|  |  |
|  | Interfaces : |
|  | RPC 7212a04b-b463-402e-9649-2ba477394676 (1.0) -- c:\\windows\\system32\\umrdp.dll |
|  | 0 -> CTSEventFilterBlockAllEvents::AllowTSEvent |
|  | 1 -> RpcOpenDevice |
|  | 2 -> RpcCloseDevice |
|  | 3 -> RpcGetSessionId |
|  | 4 -> RpcGetInterfaceGuids |
|  | 5 -> RpcGetClientDeviceId |
|  | 6 -> RpcGetDeviceCaps |
|  | RPC c80066a8-7579-44fc-b9b2-8466930791b0 (1.0) -- c:\\windows\\system32\\umrdp.dll |
|  | 0 -> RpcPrintDrvGetInfo |
|  | Endpoints : |
|  | ncalrpc : RemoteDevicesLPC\_API |
|  | ncalrpc : TSUMRPD\_PRINT\_DRV\_LPC\_API |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1828 at 0x5e185c0L> |
|  | 64 |
|  | \['ProfSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 326731e3-c1c0-4a69-ae20-7d9044a4ea5c (1.0) -- c:\\windows\\system32\\profsvc.dll |
|  | 0 -> DropClientContext |
|  | 1 -> ReleaseClientContext |
|  | 2 -> LoadUserProfileServer |
|  | 3 -> UnloadUserProfileServer |
|  | 4 -> DeleteProfileServer |
|  | 5 -> RemapProfileServer |
|  | 6 -> CreateProfileServer |
|  | 7 -> ProcessWmiSettingsServer |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- c:\\windows\\system32\\SYSNTFY.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | Endpoints : |
|  | ncalrpc : IUserProfile2 |
|  | ncalrpc : OLE6F8BDD12948DEBD71B04215252FE |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1840 at 0x5e18898L> |
|  | 64 |
|  | \['SysMain'\] |
|  |  |
|  | Interfaces : |
|  | RPC b58aa02e-2884-4e97-8176-4ee06d794184 (1.0) -- c:\\windows\\system32\\sysmain.dll |
|  | 0 -> PfRpcServerExecuteCommand |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-0e6f1aa3c02f3f32a5 |
|  | ncalrpc : OLE723934C840209383EF7E4D981BAC |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2064 at 0x5e18b00L> |
|  | 64 |
|  | \['Themes'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2076 at 0x5e18c88L> |
|  | 64 |
|  | \['EventSystem'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 64b8f404-a4ae-11d1-b7b6-00c04fb926af (0.0) -- IEventSystemTier2Factory |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE 609b954b-4fb6-11d1-9971-00c04fbbb345 (0.0) -- IEventSystemTier2 |
|  | OLE 609b9557-4fb6-11d1-9971-00c04fbbb345 (0.0) -- IEventSubscriptionTier2 |
|  | OLE 609b9555-4fb6-11d1-9971-00c04fbbb345 (0.0) -- IEventClassTier2 |
|  | OLE 00000100-0000-0000-c000-000000000046 (0.0) -- IEnumUnknown |
|  | Endpoints : |
|  | ncalrpc : OLEF464024137C004FA9D20CD0863BC |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2188 at 0x5e18da0L> |
|  | 64 |
|  | \['camsvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE ef1a89c8-29b1-4ab0-94a7-851b33527a2e (0.0) -- Windows.Internal.CapabilityAccess.Management.ICapabilityConsentManagerStatics |
|  | OLE 5455de8d-1f18-4201-96c9-4410b8ac430c (0.0) -- Windows.Internal.CapabilityAccess.Management.ICapabilityConsentManager |
|  | OLE b4b78257-ea0d-4842-8d24-ab5ec49d42ca (0.0) -- Windows.Internal.CapabilityAccess.Management.ICapabilityConsent |
|  | OLE 12f28d6b-46e5-559d-9d5f-7a77c3540f9b (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CCapabilityAccess\_\_CManagement\_\_CCapabilityConsent |
|  | OLE 518f3880-4e5c-4524-ab03-cd01336b2178 (0.0) -- Windows.Internal.CapabilityAccess.ICapabilityAccessStatics |
|  | OLE 0f8e44dd-ee48-4b95-a524-f4ceb214ab7e (0.0) -- Windows.Internal.CapabilityAccess.ICapabilityAccess |
|  | OLE b10178d8-440d-4575-a8af-4345685701b7 (0.0) -- Windows.Internal.CapabilityAccess.Management.ICapabilityProvisioningStatics |
|  | OLE b35dcc0f-f8ab-4ddb-857f-c1458340174d (0.0) -- Windows.Internal.CapabilityAccess.Management.ICapabilityProvisioning |
|  | OLE 2f13c006-a03a-5f69-b090-75a43e33423e (0.0) -- IVectorView<HSTRING> |
|  | Endpoints : |
|  | ncalrpc : OLEDFAB9FF408B07D7CBC6D115A163E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2208 at 0x5e18fd0L> |
|  | 64 |
|  | \['NlaSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC aa411582-9bdf-48fb-b42b-faa1eee33949 (1.0) -- c:\\windows\\system32\\nlasvc.dll |
|  | 0 -> PMuxRpcPluginRegister |
|  | 1 -> PMuxRpcPluginUnregister |
|  | 2 -> PMuxRpcPluginDataIndicate |
|  | RPC c33b9f46-2088-4dbc-97e3-6125f127661c (1.0) -- c:\\windows\\system32\\nlasvc.dll |
|  | 0 -> AppSrv\_NlaOpenQuery |
|  | 1 -> AppSrv\_NlaAsyncIndicate |
|  | 2 -> AppSrv\_NlaRefreshQuery |
|  | 3 -> AppSrv\_NlaCloseQuery |
|  | 4 -> RpcNlaIndicateReprobe |
|  | RPC 4c8d0bef-d7f1-49f0-9102-caa05f58d114 (1.0) -- c:\\windows\\system32\\nlasvc.dll |
|  | 0 -> RPCQueryLANIds |
|  | Endpoints : |
|  | ncalrpc : nlaplg |
|  | ncalrpc : nlaapi |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2248 at 0x5e18e80L> |
|  | 64 |
|  | \['CertPropSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 30b044a5-a225-43f0-b3a4-e060df91f9c1 (1.0) -- c:\\windows\\system32\\certprop.dll |
|  | 0 -> s\_RPC\_SmartCardRootCertsNotifyService |
|  | 1 -> s\_RPC\_SmartCardCertsNotifyService |
|  | Endpoints : |
|  | ncalrpc : LRPC-efec9fc562caac861f |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2320 at 0x5e187f0L> |
|  | 64 |
|  | \['Schedule'\] |
|  |  |
|  | Interfaces : |
|  | RPC 0a74ef1c-41a4-4e06-83ae-dc74fb1cdd53 (1.0) -- c:\\windows\\system32\\schedsvc.dll |
|  | 0 -> ItSrvRegisterIdleTask |
|  | 1 -> ItSrvUnregisterIdleTask |
|  | 2 -> ItSrvProcessIdleTasks |
|  | 3 -> ItSrvSetDetectionParameters |
|  | 4 -> ItSrvSetRuntimeOverrides |
|  | RPC 1ff70682-0a51-30e8-076d-740be8cee98b (1.0) -- C:\\WINDOWS\\system32\\taskcomp.dll |
|  | 0 -> NetrJobAdd |
|  | 1 -> NetrJobDel |
|  | 2 -> NetrJobEnum |
|  | 3 -> NetrJobGetInfo |
|  | RPC 378e52b0-c0a9-11cf-822d-00aa0051e40f (1.0) -- C:\\WINDOWS\\system32\\taskcomp.dll |
|  | 0 -> SASetAccountInformation |
|  | 1 -> SASetNSAccountInformation |
|  | 2 -> SAGetNSAccountInformation |
|  | 3 -> SAGetAccountInformation |
|  | RPC 2a82bb21-e44f-4791-9aa1-dfae788e2f43 (1.0) -- c:\\windows\\system32\\UBPM.dll |
|  | 0 -> s\_UbpmRpcOpenTaskHostChannel |
|  | 1 -> s\_UbpmRpcCloseTaskHostChannel |
|  | 2 -> s\_UbpmRpcTaskHostSendResponseReceiveCommand |
|  | 3 -> s\_UbpmRpcTaskHostReportTaskStatus |
|  | RPC 33d84484-3626-47ee-8c6f-e7e98b113be1 (2.0) -- C:\\WINDOWS\\SYSTEM32\\WPTaskScheduler.dll |
|  | 0 -> s\_TaskSchedulerCreateSchedule |
|  | 1 -> s\_TaskSchedulerDeleteSchedule |
|  | 2 -> s\_TaskSchedulerFindFirstSchedule |
|  | 3 -> s\_TaskSchedulerFindNextSchedule |
|  | 4 -> s\_TaskSchedulerFindScheduleClose |
|  | 5 -> s\_TaskSchedulerGetSchedule |
|  | 6 -> s\_TaskSchedulerEnableSchedule |
|  | 7 -> s\_TaskSchedulerExecuteSchedule |
|  | 8 -> s\_TaskSchedulerAdvanceSchedule |
|  | 9 -> s\_TaskSchedulerAdvanceScheduleIntervals |
|  | 10 -> s\_TaskSchedulerSnoozeSchedule |
|  | 11 -> s\_TaskSchedulerGetPublishStateName |
|  | 12 -> s\_TaskSchedulerServiceControl |
|  | RPC 86d35949-83c9-4044-b424-db363231fd0c (1.0) -- c:\\windows\\system32\\schedsvc.dll |
|  | 0 -> SchRpcHighestVersion |
|  | 1 -> SchRpcRegisterTask |
|  | 2 -> SchRpcRetrieveTask |
|  | 3 -> SchRpcCreateFolder |
|  | 4 -> SchRpcSetSecurity |
|  | 5 -> SchRpcGetSecurity |
|  | 6 -> SchRpcEnumFolders |
|  | 7 -> SchRpcEnumTasks |
|  | 8 -> SchRpcEnumInstances |
|  | 9 -> SchRpcGetInstanceInfo |
|  | 10 -> SchRpcStopInstance |
|  | 11 -> SchRpcStop |
|  | 12 -> SchRpcRun |
|  | 13 -> SchRpcDelete |
|  | 14 -> SchRpcRename |
|  | 15 -> SchRpcScheduledRuntimes |
|  | 16 -> SchRpcGetLastRunInfo |
|  | 17 -> SchRpcGetTaskInfo |
|  | 18 -> SchRpcGetNumberOfMissedRuns |
|  | 19 -> SchRpcEnableTask |
|  | RPC 3a9ef155-691d-4449-8d05-09ad57031823 (1.0) -- c:\\windows\\system32\\schedsvc.dll |
|  | 0 -> I\_pSchRpcRegisterTask |
|  | 1 -> I\_pSchRpcEnumTasks |
|  | 2 -> I\_pSchRpcGetTaskInfo |
|  | 3 -> I\_pSchRpcAquireTaskStateNotificationsName |
|  | 4 -> I\_pAcquireBackgroundExecutionMode |
|  | 5 -> I\_pReleaseBackgroundExecutionMode |
|  | 6 -> I\_pSetTaskDisabledForCurrentUser |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-51c51864fe6e0c48ac |
|  | ncacn\_np : \\PIPE\\atsvc |
|  | ncalrpc : ubpmtaskhostchannel |
|  | ncalrpc : LRPC-c2989cc83b76aaef0e |
|  | ncacn\_ip\_tcp : 1538 |
|  | ncalrpc : OLEFCCE0CD6FC139AAA2578089FB67F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2464 at 0x5e18550L> |
|  | 64 |
|  | \['SENS'\] |
|  |  |
|  | Interfaces : |
|  | RPC 63fbe424-2029-11d1-8db8-00aa004abd5e (1.0) -- c:\\windows\\system32\\sens.dll |
|  | 0 -> RPC\_IsNetworkAlive |
|  | 1 -> RPC\_IsDestinationReachableA |
|  | 2 -> RPC\_IsDestinationReachableA |
|  | RPC a0bc4698-b8d7-4330-a28f-7709e18b6108 (4.0) -- c:\\windows\\system32\\sens.dll |
|  | 0 -> RPC\_SensNotifyWinlogonEvent |
|  | 1 -> RPC\_SensNotifyRasEvent |
|  | 2 -> RPC\_SensNotifyNetconEvent |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- c:\\windows\\system32\\SYSNTFY.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 97312c82-d4c2-11d1-b682-00805fc79216 (0.0) -- ICollectionNotify |
|  | Endpoints : |
|  | ncalrpc : senssvc |
|  | ncalrpc : LRPC-acd8265eed74c34dcd |
|  | ncalrpc : OLEC47EA283FE69A099E22AC7CA613A |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "Memory Compression" pid 2480 at 0x5e18a20L> |
|  | 64 |
|  | \[!!\] Invalid rpcrt4 base: 0x0 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "igfxCUIService.exe" pid 2600 at 0x5e189e8L> |
|  | 64 |
|  | \['igfxCUIService2.0.0.0'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE d597bab3-5b9f-11d1-8dd2-00aa004abd5e (0.0) -- ISensLogon |
|  | OLE d597bab4-5b9f-11d1-8dd2-00aa004abd5e (0.0) -- ISensLogon2 |
|  | Endpoints : |
|  | ncalrpc : OLED1CCDC2B65C305FC8DCE034C9D1B |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2628 at 0x5e18cf8L> |
|  | 64 |
|  | \['netprofm'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE d0074ffd-570f-4a9b-8d69-199fdba5723b (0.0) -- INetworkListManager |
|  | OLE 26656eaa-54eb-4e6f-8f85-4f0ef901a406 (0.0) -- IEnumNetwork |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE bcd1de7e-2db1-418b-b047-4a74e101f8c1 (0.0) -- IEnumNetworkInterface |
|  | OLE 2a1c9eb2-df62-4154-b800-63278fcb8037 (0.0) -- INetworkInterface |
|  | OLE 8a40a45d-055c-4b62-abd7-6d613e2ceaec (0.0) -- INetwork |
|  | OLE 55272a00-42cb-11ce-8135-00aa004bb851 (0.0) -- IPropertyBag |
|  | Endpoints : |
|  | ncalrpc : OLE71388FD622ABF6931111693CB5E5 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2668 at 0x5e18518L> |
|  | 64 |
|  | \['LanmanWorkstation'\] |
|  |  |
|  | Interfaces : |
|  | RPC f2c9b409-c1c9-4100-8639-d8ab1486694a (1.0) -- c:\\windows\\system32\\wkssvc.dll |
|  | 0 -> ClusterConnectUpcall |
|  | 1 -> ClusterDisConnectUpcall |
|  | RPC eb081a0d-10ee-478a-a1dd-50995283e7a8 (3.0) -- c:\\windows\\system32\\wkssvc.dll |
|  | 0 -> GetWitnessNodes |
|  | RPC 6bffd098-a112-3610-9833-46c3f87e345a (1.0) -- c:\\windows\\system32\\wkssvc.dll |
|  | 0 -> NetrWkstaGetInfo |
|  | 1 -> NetrWkstaSetInfo |
|  | 2 -> NetrWkstaUserEnum |
|  | 3 -> NetrWkstaUserGetInfo |
|  | 4 -> NetrWkstaUserSetInfo |
|  | 5 -> NetrWkstaTransportEnum |
|  | 6 -> NetrWkstaTransportAdd |
|  | 7 -> NetrWkstaTransportDel |
|  | 8 -> NetrUseAdd |
|  | 9 -> NetrUseGetInfo |
|  | 10 -> NetrUseDel |
|  | 11 -> NetrUseEnum |
|  | 12 -> I\_NetrLogonDomainNameAdd |
|  | 13 -> NetrWorkstationStatisticsGet |
|  | 14 -> I\_NetrLogonDomainNameAdd |
|  | 15 -> I\_NetrLogonDomainNameAdd |
|  | 16 -> I\_NetrLogonDomainNameAdd |
|  | 17 -> I\_NetrLogonDomainNameAdd |
|  | 18 -> I\_NetrLogonDomainNameAdd |
|  | 19 -> I\_NetrLogonDomainNameAdd |
|  | 20 -> NetrGetJoinInformation |
|  | 21 -> I\_NetrLogonDomainNameAdd |
|  | 22 -> NetrJoinDomain2 |
|  | 23 -> NetrUnjoinDomain2 |
|  | 24 -> NetrRenameMachineInDomain2 |
|  | 25 -> NetrValidateName2 |
|  | 26 -> NetrGetJoinableOUs2 |
|  | 27 -> NetrAddAlternateComputerName |
|  | 28 -> NetrRemoveAlternateComputerName |
|  | 29 -> NetrSetPrimaryComputerName |
|  | 30 -> NetrEnumerateComputerNames |
|  | RPC 7f1343fe-50a9-4927-a778-0c5859517bac (1.0) -- c:\\windows\\system32\\wkssvc.dll |
|  | 0 -> DfsDsGetDcName |
|  | 1 -> DfsDsIsDomainController |
|  | 2 -> DfsCredWrite |
|  | 3 -> DfsCredDelete |
|  | Endpoints : |
|  | ncalrpc : LRPC-ae939f8a0790b55959 |
|  | ncacn\_np : \\PIPE\\wkssvc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2708 at 0x5e18278L> |
|  | 64 |
|  | \['UserManager'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 155eb23b-242a-45e0-a2e9-3171fc6a7fdd (0.0) -- Windows.System.IUserStatics |
|  | OLE 252e7f79-acfa-4ea2-9a7e-fa27a8a4d3d9 (0.0) -- Windows.System.Internal.IUserManagerStatics |
|  | RPC b18fbab6-56f8-4702-84e0-41053293a869 (1.0) -- c:\\windows\\system32\\usermgr.dll |
|  | 0 -> svcQueryUserToken |
|  | 1 -> svcGetConstrainedUserToken |
|  | 2 -> svcIsAllowedToActivateAsUser |
|  | 3 -> svcQueryDefaultAccountToken |
|  | 4 -> svcQuerySessionVirtualAccountToken |
|  | 5 -> svcLaunchShell |
|  | 6 -> svcLaunchShellInfrastructureHost |
|  | 7 -> svcSetShellInformation |
|  | 8 -> svcInformUserLogon |
|  | 9 -> svcInformUserLogoff |
|  | 10 -> svcQueryUserContext |
|  | 11 -> svcUMLogonUser |
|  | 12 -> svcQuerySessionUserToken |
|  | 13 -> svcGetConstrainedUserTokenFromAppcontainer |
|  | 14 -> svcEnumerateSessionUsers |
|  | 15 -> svcQueryUserTokenFromName |
|  | 16 -> svcQueryUserContextFromName |
|  | 17 -> svcQueryUserTokenFromSid |
|  | 18 -> svcQueryUserContextFromSid |
|  | 19 -> svcOpenProcessHandleForAccess |
|  | 20 -> svcOpenProcessTokenForQuery |
|  | 21 -> svcUMSetCachedCredentials |
|  | 22 -> svcUMGetCachedCredentials |
|  | 23 -> svcInformFlags |
|  | 24 -> svcChangeSessionUserToken |
|  | 25 -> svcConnectLocalUser |
|  | 26 -> svcDisconnectLocalUser |
|  | 27 -> svcGetImpersonationTokenForContext |
|  | 28 -> svcGetDefaultSignInAccount |
|  | 29 -> svcClearDefaultSignInAccount |
|  | 30 -> svcGetSessionActiveShellUserToken |
|  | 31 -> svcChangeSessionActiveShellUser |
|  | RPC 0d3c7f20-1c8d-4654-a1b3-51563b298bda (1.0) -- c:\\windows\\system32\\usermgr.dll |
|  | 0 -> svcGetUserMarshalData |
|  | OLE 100eb64b-b24c-4c38-8964-720d926d05a4 (0.0) -- Windows.System.Internal.ISignInStateManager |
|  | OLE 039a83e3-d5bd-491a-9e47-3feba3427a92 (0.0) -- Windows.System.Internal.IUserManagerStatics2 |
|  | OLE 155eb23b-242a-45e0-a2e9-3171fc6a7fbb (0.0) -- Windows.System.IUserWatcher |
|  | OLE df9a26c6-e746-4bcd-b5d4-120103c4209b (0.0) -- Windows.System.IUser |
|  | OLE 086459dc-18c6-48db-bc99-724fb9203ccc (0.0) -- Windows.System.IUserChangedEventArgs |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE e44ea1df-bb85-5a8c-bddc-c8e960c355c9 (0.0) -- Windows.Foundation.IAsyncOperation\[Windows.Foundation.Collections.IVectorView\[Windows.System.User\]\] |
|  | OLE 8cbd762a-1222-5ee5-b745-489e7a42c6ec (0.0) -- Windows.Foundation.Collections.IVectorView\[Windows.System.User\] |
|  | Endpoints : |
|  | ncalrpc : OLE724BAE7054C6781B2327735CF9CC |
|  | ncalrpc : LRPC-6626d6b746680acbda |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2904 at 0x5e18630L> |
|  | 64 |
|  | \['AudioEndpointBuilder'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2912 at 0x5e182b0L> |
|  | 64 |
|  | \['FontCache'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 97ea99c7-0186-4ad4-8df9-c5b4e0ed6b22 (0.0) -- IBackgroundCopyCallback |
|  | Endpoints : |
|  | ncalrpc : OLE545C922C4385EEF282FED11687B7 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2920 at 0x5e18710L> |
|  | 64 |
|  | \['SessionEnv'\] |
|  |  |
|  | Interfaces : |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- c:\\windows\\system32\\SYSNTFY.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | RPC b12fd546-c875-4b41-97d8-950487662202 (1.0) -- c:\\windows\\system32\\sessenv.dll |
|  | 0 -> RpcCreateUserVhdTemplate |
|  | 1 -> RpcGetCreateUserProfileVhd |
|  | 2 -> RpcDestroyUserProfileVhd |
|  | 3 -> RpcRepairUserProfileVhd |
|  | 4 -> RpcReEncryptUserCredential |
|  | 5 -> RpcDeleteFileFromVHD |
|  | 6 -> RpcSetupVhdForRdv |
|  | 7 -> RpcCopyRdvFolderFromVhdToHost |
|  | 8 -> RpcQueryVhdOfflineInformation |
|  | RPC 1257b580-ce2f-4109-82d6-a9459d0bf6bc (1.0) -- c:\\windows\\system32\\sessenv.dll |
|  | 0 -> RpcShadow2 |
|  | RPC 29770a8f-829b-4158-90a2-78cd488501f7 (1.0) -- c:\\windows\\system32\\sessenv.dll |
|  | 0 -> TSSDFarmRpcGrantUserTSAccessRight |
|  | Endpoints : |
|  | ncalrpc : LRPC-744dd95aed38325a70 |
|  | ncalrpc : SessEnvPrivateRpc |
|  | ncacn\_np : \\pipe\\SessEnvPublicRpc |
|  | ncacn\_ip\_tcp : 1540 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2988 at 0x5e18c18L> |
|  | 64 |
|  | \['Dnscache'\] |
|  |  |
|  | Interfaces : |
|  | RPC 45776b01-5956-4485-9f80-f428f7d60129 (2.0) -- c:\\windows\\system32\\dnsrslvr.dll |
|  | 0 -> CRrReadCache |
|  | 1 -> R\_ResolverGetConfig |
|  | 2 -> R\_ResolverFlushCache |
|  | 3 -> R\_ResolverFlushCacheEntry |
|  | 4 -> R\_ResolverQuery |
|  | 5 -> R\_DnsRegisterLocal |
|  | 6 -> R\_DnsDeRegisterLocal |
|  | 7 -> R\_DnsStartMulticastQuery |
|  | 8 -> R\_DnsGetMulticastData |
|  | 9 -> R\_DnsStopMulticastQuery |
|  | 10 -> R\_ResolverSimpleOp |
|  | 11 -> R\_DnsGetProxyInformation |
|  | 12 -> R\_DnsGetPolicyTableInfo |
|  | 13 -> R\_DnsSetConnectionPolicyInfo |
|  | 14 -> R\_DnsDeleteConnectionPolicyInfo |
|  | Endpoints : |
|  | ncalrpc : DNSResolver |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3096 at 0x5e180b8L> |
|  | 64 |
|  | \['Audiosrv'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | RPC 47ac638a-718f-49a0-97c5-574ac77acf4d (2.7) -- c:\\windows\\system32\\audiosrv.dll |
|  | 0 -> AudioServerGetMixFormat |
|  | 1 -> AudioServerIsFormatSupported |
|  | 2 -> AudioServerGetDevicePeriod |
|  | 3 -> AudioServerIsOffloadCapable |
|  | 4 -> AudioServerInitialize |
|  | 5 -> AudioServerDisconnect |
|  | 6 -> AudioServerGetAudioSession |
|  | 7 -> AudioServerCreateStream |
|  | 8 -> AudioServerStartStream |
|  | 9 -> AudioServerStopStream |
|  | 10 -> AudioServerPreStartStream |
|  | 11 -> AudioServerStartStreamAborted |
|  | 12 -> AudioServerResetEndpoint |
|  | 13 -> AudioServerDestroyStream |
|  | 14 -> AudioServerGetEndpointBufferSize |
|  | 15 -> AudioServerGetPositionForOffload |
|  | 16 -> AudioServerGetFrequencyForOffload |
|  | 17 -> AudioServerGetStreamLatency |
|  | 18 -> AudioServerSetStreamSampleRate |
|  | 19 -> AudioServerGetChannelCount |
|  | 20 -> AudioServerSetChannelVolume |
|  | 21 -> AudioServerGetChannelVolume |
|  | 22 -> AudioServerSetAllVolumes |
|  | 23 -> AudioServerGetAllVolumes |
|  | 24 -> AudioServerSetAllInitialVolumesWithRamp |
|  | 25 -> AudioServerNotifyStreamSuspensionState |
|  | 26 -> AudioSessionGetId |
|  | 27 -> AudioSessionGetInstanceId |
|  | 28 -> AudioSessionGetStreamSwitchId |
|  | 29 -> AudioSessionGetProcessId |
|  | 30 -> AudioSessionGetState |
|  | 31 -> AudioSessionGetLastActivation |
|  | 32 -> AudioSessionGetLastInactivation |
|  | 33 -> AudioSessionIsSystemSoundsSession |
|  | 34 -> AudioSessionGetDisplayOptions |
|  | 35 -> AudioSessionGetDisplayName |
|  | 36 -> AudioSessionSetDisplayName |
|  | 37 -> AudioSessionGetIconPath |
|  | 38 -> AudioSessionSetIconPath |
|  | 39 -> AudioSessionGetGroupingParam |
|  | 40 -> AudioSessionSetGroupingParam |
|  | 41 -> AudioSessionGetVolume |
|  | 42 -> AudioSessionSetVolume |
|  | 43 -> AudioSessionGetMute |
|  | 44 -> AudioSessionSetMute |
|  | 45 -> AudioSessionGetChannelCount |
|  | 46 -> AudioSessionSetChannelVolume |
|  | 47 -> AudioSessionGetChannelVolume |
|  | 48 -> AudioSessionSetAllVolumes |
|  | 49 -> AudioSessionGetAllVolumes |
|  | 50 -> AudioSessionPropertyStoreCommit |
|  | 51 -> AudioSessionPropertyStoreGetAt |
|  | 52 -> AudioSessionPropertyStoreGetCount |
|  | 53 -> AudioSessionPropertyStoreGetValue |
|  | 54 -> AudioSessionPropertyStoreSetValue |
|  | 55 -> AudioSessionSetDuckingPreference |
|  | 56 -> AudioSessionGetDuckingState |
|  | 57 -> AudioSessionGetIsComms |
|  | 58 -> AudioSessionDestroy |
|  | 59 -> AudioSessionMeterGetPeakValue |
|  | 60 -> AudioSessionMeterGetMeteringChannelCount |
|  | 61 -> AudioSessionMeterGetChannelsPeakValues |
|  | 62 -> AudioSessionSetViewId |
|  | 63 -> PolicyConfigGetMixFormat |
|  | 64 -> PolicyConfigGetDeviceFormat |
|  | 65 -> PolicyConfigSetDeviceFormat |
|  | 66 -> PolicyConfigResetDeviceFormat |
|  | 67 -> PolicyConfigGetProcessingPeriod |
|  | 68 -> PolicyConfigSetProcessingPeriod |
|  | 69 -> PolicyConfigGetShareMode |
|  | 70 -> PolicyConfigSetShareMode |
|  | 71 -> PolicyConfigGetPropertyValue |
|  | 72 -> PolicyConfigSetPropertyValue |
|  | 73 -> PolicyConfigSetDefaultEndpoint |
|  | 74 -> PolicyConfigSetEndpointVisibility |
|  | 75 -> PolicyConfigSetEndpointAbilityToBeDefault |
|  | 76 -> PolicyConfigSetApplicationDefaultEndpoint |
|  | 77 -> PolicyConfigClearApplicationDefaultEndpoint |
|  | 78 -> PolicyConfigSetAccessibilityAudioMonoMixState |
|  | 79 -> PolicyConfigGetAccessibilityAudioMonoMixState |
|  | 80 -> PolicyConfigValidateSpatialAudioSettings |
|  | 81 -> PolicyConfigAddDynamicRoutingRule |
|  | 82 -> PolicyConfigRemoveDynamicRoutingRule |
|  | 83 -> GetAudioSessionManager |
|  | 84 -> AudioSessionManagerDestroy |
|  | 85 -> AudioSessionManagerGetAudioSessions |
|  | 86 -> AudioSessionManagerGetCurrentSession |
|  | 87 -> AudioSessionManagerGetExistingSession |
|  | 88 -> AudioSessionManagerGetSessionForStreamSwitch |
|  | 89 -> AudioSessionManagerAddAudioSessionClientNotification |
|  | 90 -> AudioSessionManagerDeleteAudioSessionClientNotification |
|  | 91 -> AudioSessionManagerAddVolumeDuckNotification |
|  | 92 -> AudioSessionManagerDeleteVolumeDuckNotification |
|  | 93 -> AudioVolumeConnect |
|  | 94 -> AudioVolumeDisconnect |
|  | 95 -> AudioVolumeQueryHardwareSupport |
|  | 96 -> AudioVolumeGetVolumeRange |
|  | 97 -> AudioVolumeGetChannelCount |
|  | 98 -> AudioVolumeSetMasterVolumeLevel |
|  | 99 -> AudioVolumeSetMasterVolumeLevelScalar |
|  | 100 -> AudioVolumeGetMasterVolumeLevel |
|  | 101 -> AudioVolumeGetMasterVolumeLevelScalar |
|  | 102 -> AudioVolumeSetChannelVolumeLevel |
|  | 103 -> AudioVolumeSetChannelVolumeLevelScalar |
|  | 104 -> AudioVolumeGetChannelVolumeLevel |
|  | 105 -> AudioVolumeGetChannelVolumeLevelScalar |
|  | 106 -> AudioVolumeSetMute |
|  | 107 -> AudioVolumeGetMute |
|  | 108 -> AudioVolumeAddMasterVolumeNotification |
|  | 109 -> AudioVolumeDeleteMasterVolumeNotification |
|  | 110 -> AudioMeterGetPeakValue |
|  | 111 -> AudioMeterGetMeteringChannelCount |
|  | 112 -> AudioMeterGetChannelsPeakValues |
|  | 113 -> AudioVolumeGetStepInfo |
|  | 114 -> AudioVolumeStepUp |
|  | 115 -> AudioVolumeStepDown |
|  | 116 -> AudioServerGetBufferSizeLimits |
|  | 117 -> AudioServerSetLastBufferInProgress |
|  | 118 -> AudioServerIsRawStreamSupported |
|  | 119 -> AudioServerDeriveStreamCategory |
|  | 120 -> AudioServerGetStreamVpoContext |
|  | 121 -> AudioServerGetEndpointVpoContext |
|  | 122 -> AudioServerCloseVpoContext |
|  | 123 -> AudioServerGetCurrentSharedModeEnginePeriod |
|  | 124 -> AudioServerGetSharedModeEnginePeriod |
|  | 125 -> AudioServerRequestSpatialDynamicObjects |
|  | 126 -> AudioServerSetAmbMetadata |
|  | 127 -> AudioServerSetAmbHeadTracking |
|  | 128 -> AudioServerGetAmbHeadTracking |
|  | 129 -> AudioServerSetAmbRotation |
|  | 130 -> asm\_GetApplicationSubmixContext |
|  | 131 -> asm\_GetApplicationSubmixContextFromPID |
|  | 132 -> asm\_GetApplicationSubmixContextForProcessTree |
|  | 133 -> asm\_ApplicationSubmixContextDestroy |
|  | 134 -> asm\_GetApplicationSubmixes |
|  | 135 -> asm\_ApplicationSubmixDestroy |
|  | 136 -> asm\_AudioServerGetApplicationSubmixFormat |
|  | 137 -> asm\_AudioServerGetApplicationSubmixPeriod |
|  | 138 -> asm\_AudioServerGetApplicationSubmixId |
|  | 139 -> asm\_GetApplicationSubmixFromId |
|  | 140 -> asm\_AudioServerInitializeStream |
|  | 141 -> AudioServerTelephonyControlStartSession |
|  | 142 -> AudioServerTelephonyControlIsSessionStarted |
|  | 143 -> AudioServerTelephonyControlEndSession |
|  | 144 -> AudioServerTelephonyControlSetRoutingPolicy |
|  | 145 -> AudioServerTelephonyControlGetRoutingPolicy |
|  | 146 -> AudioServerTelephonyControlSetCallState |
|  | 147 -> AudioServerTelephonyControlGetCallState |
|  | 148 -> AudioServerTelephonyControlProviderChange |
|  | 149 -> AudioServerTelephonyControlSetMute |
|  | 150 -> AudioServerTelephonyControlGetMute |
|  | 151 -> AudioServerTelephonyControlSetVOIPMute |
|  | 152 -> AudioServerTelephonyControlGetVOIPMute |
|  | 153 -> AudioServerTelephonyControlSetVolume |
|  | 154 -> AudioServerTelephonyControlGetMaxCallInstanceCount |
|  | 155 -> AudioServerTelephonyControlGetValidTelephonyInstance |
|  | OLE a8a900c6-da0b-5bcc-a71a-be0b9265d87a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageInstallingEventArgs |
|  | OLE bd636cf1-541f-53ea-8efc-e1604a395b1a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageUninstallingEventArgs |
|  | RPC 7c69ac10-fa12-4dbf-90d9-c7f1e40f5dc5 (1.6) -- c:\\windows\\system32\\audiosrv.dll |
|  | 0 -> s\_winmmGetPnpInfo |
|  | 1 -> s\_mmeNotifyDeviceStateChanged |
|  | 2 -> s\_mmeNotifyDeviceAdded |
|  | 3 -> s\_mmeNotifyDeviceRemoved |
|  | 4 -> s\_mmeNotifyDefaultDeviceChanged |
|  | 5 -> s\_tsSessionGetAudioProtocol |
|  | 6 -> s\_tsRegisterAudioProtocolNotification |
|  | 7 -> s\_tsUnregisterAudioProtocolNotification |
|  | 8 -> s\_sndevtResolveSoundAlias |
|  | 9 -> s\_pbmRegisterPlaybackManagerNotifications |
|  | 10 -> s\_pbmUnregisterPlaybackManagerNotifications |
|  | 11 -> s\_pbmSetSmtcSubscriptionState |
|  | 12 -> s\_pbmGetSoundLevel |
|  | 13 -> s\_ccCreateHandsfreeHidFileFromAudioId |
|  | 14 -> s\_pbmRegisterAppClosureNotification |
|  | 15 -> s\_pbmUnregisterAppClosureNotification |
|  | 16 -> s\_pbmPlayToStreamStateChanged |
|  | 17 -> s\_pbmIsPlaying |
|  | 18 -> s\_pbmCastingAppStateChanged |
|  | 19 -> s\_pbmVoipCallStateChanged |
|  | 20 -> s\_pbmLaunchBackgroundTask |
|  | 21 -> s\_pbmRegisterAsBackgroundTask |
|  | 22 -> s\_afxOpenAudioEffectsWatcher |
|  | 23 -> s\_afxCloseAudioEffectsWatcher |
|  | 24 -> s\_midiOpenPort |
|  | 25 -> s\_rtgGetDefaultAudioEndpoint |
|  | 26 -> s\_apmRegisterProxyAudioProcess |
|  | 27 -> s\_apmSetDuckingGainForId |
|  | 28 -> s\_apmSetLayoutGainForId |
|  | 29 -> s\_apmSetVolumeGroupGainForId |
|  | 30 -> s\_apmSetVolumeGroupGainScalarForId |
|  | 31 -> s\_apmSetVolumeGroupMuteForId |
|  | 32 -> s\_setRingerVibrateState |
|  | 33 -> s\_getRingerVibrateState |
|  | 34 -> s\_getEmergencyCallbackMode |
|  | 35 -> s\_setEmergencyCallbackMode |
|  | 36 -> s\_apmSetPersistedDefaultAudioEndpoint |
|  | 37 -> s\_apmGetPersistedDefaultAudioEndpoint |
|  | 38 -> s\_apmClearAllPersistedApplicationDefaultEndpoints |
|  | 39 -> s\_apmRegisterAudioStateMonitor |
|  | 40 -> s\_apmUnregisterAudioStateMonitor |
|  | 41 -> AudioServerTelephonyControlGetCallStateSync |
|  | 42 -> AudioServerTelephonyControlGetMuteSync |
|  | 43 -> s\_apmSetBalanceGroupBalanceForId |
|  | 44 -> s\_apmSetPreferredChatApplication |
|  | 45 -> s\_apmResetPreferredChatApplication |
|  | 46 -> s\_CreateHolographicDisplay |
|  | 47 -> s\_DestroyHolographicDisplay |
|  | 48 -> s\_GetHeadRotation |
|  | RPC 5fc2481b-f8d7-466b-a741-cc7806c784a3 (1.0) -- c:\\windows\\system32\\audiosrv.dll |
|  | 0 -> s\_pbmReportAppInteractivityChange |
|  | 1 -> CHybridPropertyStore::Commit |
|  | 2 -> s\_pbmAllowMediaPlaybackForApp |
|  | 3 -> s\_CapabilityAccessManagerNotification |
|  | 4 -> s\_pbmRegisterAppManagerNotification |
|  | 5 -> s\_pbmUnregisterAppManagerNotification |
|  | 6 -> s\_pbmReportAppClosing |
|  | 7 -> s\_pbmReportHostedAppStateChange |
|  | 8 -> s\_SetScreenReaderState |
|  | 9 -> s\_pbmSwitchSoftNonInteractiveAppsToHardNonInteractive |
|  | 10 -> s\_pbmReportApplicationState |
|  | RPC cba4c918-e55a-46ee-aa62-cade158e9165 (1.0) -- c:\\windows\\system32\\audiosrv.dll |
|  | 0 -> s\_adGetDeviceGraphWnfStateName |
|  | RPC c7ce3826-891f-4376-b161-c63d2403142c (1.0) -- c:\\windows\\system32\\audiosrv.dll |
|  | 0 -> s\_RequestHrtfData |
|  | OLE 2f732065-eff0-4c7c-8fc1-363851b1f1d7 (0.0) -- iaudiographcallback |
|  | Endpoints : |
|  | ncalrpc : OLE70F1DC39F57A4CC77FDC882BF09D |
|  | ncalrpc : AudioClientRpc |
|  | ncalrpc : Audiosrv |
|  | ncalrpc : PlaybackManagerRpc |
|  | ncalrpc : AudioSrvDiagnosticsRpc |
|  | ncalrpc : SpatialSoundDataManagerRpc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3156 at 0x5e18320L> |
|  | 64 |
|  | \['StateRepository'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 78662bbb-1464-4279-b5ff-ffccb2bc6529 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIApplicationExtensionStatics |
|  | OLE 7bf24de6-6ffa-585b-92fc-ef9d24fb1023 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CApplicationExtension |
|  | OLE b07904dd-31f6-452c-a738-fa5a2fda337b (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIUserStatics |
|  | OLE bb7966ba-e363-4f5d-b1bf-901fabfb603b (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageStatics |
|  | OLE 5232f8ea-49c7-4840-bfbb-66e785689e88 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIUser |
|  | OLE 35215f68-9b34-5676-b602-3814bf0e57f6 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackage |
|  | OLE ab19c2c5-9694-5644-a825-7976f20063b1 (0.0) -- \_\_FIIterable\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackage |
|  | OLE 7d4d0de5-3dc0-58c1-a31e-572e2eba5228 (0.0) -- \_\_FIIterator\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackage |
|  | OLE 8e69aa27-aa66-456a-8ca9-6ce89f1bf043 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackage |
|  | OLE d239aef3-1f67-43ec-be5e-8fbc2cb72000 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CITileViewStatics |
|  | OLE 76b8f79f-34a1-4d59-bfaa-1472aba872e5 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPrimaryTileUserStatics |
|  | OLE 3f593a63-8c13-4aaf-b4c6-840d3dda9e89 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CISecondaryTileUserStatics |
|  | OLE b17fc34b-d906-4cd1-ad70-c16d125d1686 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPrimaryTileUserNotificationChannelStatics |
|  | OLE 366a9874-5ea2-436a-828f-0145bd6cf463 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPrimaryTileUserNotificationChannel |
|  | OLE fe39030f-8455-4bf4-af4a-a34c336e4c13 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CISecondaryTileUserNotificationChannelStatics |
|  | OLE 100e0fe5-f8e6-4211-b7ad-21085e53a12e (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CISecondaryTileUserNotificationChannel |
|  | OLE 8645456f-d9a2-4b82-afec-58f0e8df0acf (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIFileTypeAssociationStatics |
|  | OLE 89bc3f49-f8d9-5103-ba13-de497e609167 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CFileTypeAssociation |
|  | OLE d81e96f1-a89c-417e-9335-59531026309d (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIApplicationStatics |
|  | OLE 4b7906ca-2e76-43c5-8532-306ad2ffbcfa (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CManagement\_CIRepositoryManager |
|  | OLE 04602114-d4b3-488d-b06e-2ff82fd0732b (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CITileViewQueryFilter |
|  | OLE 482e676d-b913-5ec1-afa8-5f96922e94ae (0.0) -- IVector<GUID> |
|  | OLE 74ab0f33-cc46-5c44-8e0f-7bca52cbfc94 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CTileView |
|  | OLE 53afb3c8-d1c7-51a2-9f66-b13f31c5a359 (0.0) -- \_\_FIIterable\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CTileView |
|  | OLE 7d88b5c6-cf84-5e7e-a847-3996fe4b5b1a (0.0) -- \_\_FIIterator\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CTileView |
|  | OLE a1196ae9-cfc4-40f3-9f82-547fd281ea09 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CITileView |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 8a43ed9f-f4e6-4421-acf9-1dab2986820c (0.0) -- IPropertySet |
|  | OLE 5b086f31-e193-4811-a185-6db2816d1691 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIApplication |
|  | OLE 1b0d3570-0877-5ec2-8a2c-3b9539506aca (0.0) -- IMap<HSTRING,IInspectable> |
|  | OLE 4cc8fe6a-5976-4ece-ac32-62e2a5497f46 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIFileTypeAssociation |
|  | OLE d5d7f1a9-68ca-4212-847b-ee4be420279f (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIApplicationExtension |
|  | OLE 0f2f217e-7957-4262-a74c-df03d9e9e9c1 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIProtocolStatics |
|  | OLE 63624def-cd42-5bcf-96e6-e27614e5d807 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CProtocol |
|  | OLE fdd7e51e-d1cc-41d9-ae36-a5fac6fe5216 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIProtocol |
|  | OLE 4594fad2-aa09-4ed9-b9eb-bd38949814e4 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageUserStatics |
|  | OLE 6dd00567-b07e-59ee-ad82-d9d8ec4c2914 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserDataChange |
|  | OLE da069297-d440-588a-8550-8302e7e879b8 (0.0) -- \_\_FIIterable\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserDataChange |
|  | OLE 15b2bc91-0a52-5ba5-8f3a-9302adfa28a6 (0.0) -- \_\_FIIterator\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserDataChange |
|  | OLE 16462b61-3298-441c-af1b-1c0995748cf7 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPrimaryTileUserDataChange |
|  | OLE 6a94ad8a-dd00-5816-a025-016d0ba262b6 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserDataChange |
|  | OLE d54e91cc-2033-5964-b69d-bd0f2459c396 (0.0) -- \_\_FIIterable\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserDataChange |
|  | OLE 3c310f81-daa9-5425-baa9-7e7958c75b5f (0.0) -- \_\_FIIterator\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserDataChange |
|  | OLE 32227928-3a92-4d68-86c5-9c0c727c205e (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageUser |
|  | OLE 4fe0a6ff-aa6b-4cb3-9241-dd477a7abb84 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageFamily |
|  | OLE dd692782-932c-53a0-90ca-70249ebfa3d9 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CApplication |
|  | OLE dd4cd077-46ac-4e8f-9afb-f0055ae35b32 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageLocationStatics |
|  | OLE a39a796c-2c0e-4530-bf70-d633ee369785 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageLocation |
|  | OLE 86f5b0ee-9560-4d76-a06a-ca4c8bfe4426 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageFamilyStatics |
|  | OLE f7e80409-27e5-4514-805f-a431c4ce3b96 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIMrtApplicationStatics |
|  | OLE 8afe010a-b611-484e-944d-5ea6e4a23569 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIMrtApplication |
|  | OLE ede4711a-0c90-4d5b-acf3-58af696d9425 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIMrtPackageStatics |
|  | OLE e15958e5-d7fd-435b-a075-0b959b6788d5 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIMrtPackage |
|  | OLE cb3a2a28-41c0-4687-9ea6-c248191321de (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CITargetDeviceFamilyStatics |
|  | OLE e5dbfeae-3a40-4926-920c-a1ad8882663e (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CITargetDeviceFamily |
|  | OLE 87d78196-5c2c-5b8a-b40c-b99083eb509b (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackageUser |
|  | OLE 01e6e15a-7659-4e66-8f82-223e1831afc8 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackageFamilyPolicyStatics |
|  | OLE 96362321-f8c2-591f-b3ef-32979d06a8bb (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackageFamilyPolicy |
|  | OLE 98c49948-0028-4aa0-b2e1-40980bc744bb (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIAppUriHandlerStatics |
|  | OLE c338a4da-6bcb-54c1-aa44-9ee9087ca23b (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CAppUriHandlerLauncherInfo |
|  | OLE 15f99879-aa48-571f-845d-144893440cfd (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CFileTypeAssociationLauncherInfo |
|  | OLE d44270bd-68f9-5da1-a9f1-7c08a8112463 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CAppUriHandler |
|  | OLE 6c49acc8-ff43-497f-afd8-42c00346b6ac (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIAppUriHandler |
|  | OLE 04222ebf-3c08-5a6f-b227-d886a2b52873 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CProtocolLauncherInfo |
|  | OLE 219c82b0-40f6-4f7e-a532-4373bb075ed7 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIProtocolLauncherInfo |
|  | OLE 8f8bf3e3-b9be-4969-9eb5-e49b5a12d2ec (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIFileTypeAssociationLauncherInfo |
|  | OLE f7a88ec3-6f33-46bf-83b8-78aaf94ac396 (0.0) -- \_\_x\_Windows\_CInternal\_CStateRepository\_CIPackagePolicyStatics |
|  | OLE 500f5564-558d-5886-ba4a-b41ffeb39322 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CStateRepository\_\_CPackagePolicy |
|  | Endpoints : |
|  | ncalrpc : OLE80E3A89A4F0098F26B690C8D6DD9 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3216 at 0x5e18860L> |
|  | 64 |
|  | \['DusmSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC c27f3c08-92ba-478c-b446-b419c4cef0e2 (1.0) -- c:\\windows\\system32\\dusmsvc.dll |
|  | 0 -> DusmRpcEnumConnectionList |
|  | 1 -> DusmRpcEnumProfileList |
|  | 2 -> DusmRpcQueryConnectionProperties |
|  | 3 -> DusmRpcQueryCost |
|  | 4 -> DusmRpcQueryUserCost |
|  | 5 -> DusmRpcQueryOperatorCost |
|  | 6 -> DusmRpcSetUserCost |
|  | 7 -> DusmRpcSetOperatorCost |
|  | 8 -> DusmRpcQueryDataPlan |
|  | 9 -> DusmRpcQueryUserDataPlan |
|  | 10 -> DusmRpcQueryOperatorDataPlan |
|  | 11 -> DusmRpcSetUserDataPlan |
|  | 12 -> DusmRpcSetOperatorDataPlan |
|  | 13 -> DusmRpcQuerySource |
|  | 14 -> DusmRpcSetSource |
|  | 15 -> DusmRpcQueryBackgroundRestriction |
|  | 16 -> DusmRpcSetBackgroundRestriction |
|  | 17 -> DusmRpcQueryGlobalDpuState |
|  | 18 -> DusmRpcGetAttributedNetworkUsage |
|  | 19 -> DusmRpcGetConnectionListNetworkUsage |
|  | 20 -> DusmRpcGetNetworkUsage |
|  | 21 -> DusmRpcGetProviderNetworkUsage |
|  | 22 -> DusmRpcSetAttributionMapping |
|  | 23 -> DusmRpcResetNetworkUsage |
|  | 24 -> DusmRpcFlushCostCache |
|  | Endpoints : |
|  | ncalrpc : LRPC-321ce10e1e312e06be |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3240 at 0x5e18ba8L> |
|  | 64 |
|  | \['Wcmsvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | RPC abfb6ca3-0c5e-4734-9285-0aee72fe8d1c (1.0) -- c:\\windows\\system32\\wcmsvc.dll |
|  | 0 -> RpcOpenHandle |
|  | 1 -> RpcCloseHandle |
|  | 2 -> RpcEnumInterfaces |
|  | 3 -> RpcQueryParameter |
|  | 4 -> RpcSetParameter |
|  | 5 -> RpcQueryPublicParameter |
|  | 6 -> RpcSetPublicParameter |
|  | 7 -> RpcSetProfileList |
|  | 8 -> RpcGetProfileList |
|  | 9 -> RpcGetProfileListByPurpose |
|  | 10 -> RpcGetTokens |
|  | 11 -> RpcOrderConnection |
|  | 12 -> RpcBeginIgnoreProfileList |
|  | 13 -> RpcResetIgnoreProfileList |
|  | 14 -> RpcEndIgnoreProfileList |
|  | 15 -> RpcOpenOnDemandRequestHandle |
|  | 16 -> RpcOpenOnDemandRequestHandleByWwanProfileName |
|  | 17 -> RpcStartOnDemandRequest |
|  | 18 -> RpcCancelOnDemandRequest |
|  | 19 -> RpcCloseOnDemandRequestHandle |
|  | 20 -> RpcQueryOnDemandRequestStateInfo |
|  | RPC b37f900a-eae4-4304-a2ab-12bb668c0188 (1.0) -- c:\\windows\\system32\\wcmsvc.dll |
|  | 0 -> RpcRegisterForNotifications |
|  | 1 -> RpcGetPendingNotification |
|  | 2 -> RpcCloseNotificationsHandle |
|  | 3 -> RpcAcquireSelectableConnectionAsync |
|  | 4 -> RpcReleaseSelectableConnection |
|  | 5 -> RpcGetSelectableConnectionList |
|  | 6 -> RpcGetInterfaceContextTable |
|  | 7 -> RpcAddRoutePolicy |
|  | 8 -> RpcRemoveRoutePolicy |
|  | 9 -> RpcRemoveMatchingRoutePolicy |
|  | 10 -> RpcGetRoutingHint |
|  | 11 -> RpcCheckCapabilityStatus |
|  | RPC e7f76134-9ef5-4949-a2d6-3368cc0988f3 (1.0) -- c:\\windows\\system32\\wcmsvc.dll |
|  | 0 -> RpcEnterConnectedStandby |
|  | 1 -> RpcExitConnectedStandby |
|  | 2 -> RpcEnterNetQuiet |
|  | 3 -> RpcExitNetQuiet |
|  | RPC 7aeb6705-3ae6-471a-882d-f39c109edc12 (1.0) -- c:\\windows\\system32\\wcmsvc.dll |
|  | 0 -> RpcSetOperatorDataplanStatus |
|  | 1 -> RpcSetOperatorConnectionCost |
|  | 2 -> RpcSetOperatorCycleData |
|  | RPC f44e62af-dab1-44c2-8013-049a9de417d6 (1.0) -- c:\\windows\\system32\\wcmsvc.dll |
|  | 0 -> RpcUpdateCapabilityAccess |
|  | 1 -> RpcDeprovisionCapability |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | RPC af7fead8-c34a-461f-8894-6d6f0e5eddcd (1.0) -- C:\\WINDOWS\\SYSTEM32\\wifinetworkmanager.dll |
|  | 0 -> WiFiUserGetInterface |
|  | 1 -> WiFiUserSetAlwaysSendUIRequests |
|  | 2 -> WiFiUserSetPowerState |
|  | 3 -> WiFiUserSetPowerStateAsync |
|  | 4 -> WiFiUserGetPowerBackOnOption |
|  | 5 -> WiFiUserSetPowerBackOnOption |
|  | 6 -> WiFiUserSetScanMode |
|  | 7 -> WiFiUserStartScan |
|  | 8 -> WiFiUserScanForHidden |
|  | 9 -> WiFiUserConfigureNetwork |
|  | 10 -> WiFiUserStartConnectingToNetwork |
|  | 11 -> WiFiUserStartConnectingToNetworkDiscovery |
|  | 12 -> WiFiUserStopHijackedConnection |
|  | 13 -> WiFiUserSkipHijackedState |
|  | 14 -> WiFiUserDeleteNetwork |
|  | 15 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 16 -> WiFiUserGetPowerState |
|  | 17 -> WiFiUserGetConnectionState |
|  | 18 -> WiFiUserGetScanMode |
|  | 19 -> WiFiUserGetAvailableNetworkList |
|  | 20 -> WiFiUserGetNetworkBssList |
|  | 21 -> WiFiUserGetPreferredNetworkList |
|  | 22 -> WiFiUserGetSocialNetworkList |
|  | 23 -> WiFiUserSetSocialNetworkStatus |
|  | 24 -> WiFiUserGetExchangeOptInState |
|  | 25 -> WiFiUserSetExchangeOptInState |
|  | 26 -> WiFiUserGetNetworkExchangeState |
|  | 27 -> WiFiUserSetNetworkExchangeState |
|  | 28 -> WiFiUserSetCurrentNetworkExchangeState |
|  | 29 -> WiFiUserGetNetworkBssidList |
|  | 30 -> WiFiUserSendSharedNetworks |
|  | 31 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 32 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 33 -> WiFiUserGetCurrentBssEntry |
|  | 34 -> WiFiUserGetSupportedEapTypes |
|  | 35 -> WiFiUserGetRequestDetails |
|  | 36 -> WiFiUserSendRequestedCredentials |
|  | 37 -> WiFiUserGetHotspotStatus |
|  | 38 -> WiFiUserSetHotspotStatus |
|  | 39 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 40 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 41 -> WiFiUserGetAdapterInfo |
|  | 42 -> WiFiUserSetStaticAdapterProperties |
|  | 43 -> WiFiUserGetStaticAdapterProperties |
|  | 44 -> WiFiAddAdapterIpAddressEntry |
|  | 45 -> WiFiRemoveAdapterIpAddressEntry |
|  | 46 -> WiFiGetAdapterIpAddressEntries |
|  | 47 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 48 -> WiFiTestSetActionRequired |
|  | 49 -> HotspotNetworkProvider::OnCredentialsRequested |
|  | 50 -> WiFiUserForceLowPowerState |
|  | 51 -> WiFiUserGetAutoConnectStatus |
|  | 52 -> WiFiUserSetAutoConnectStatus |
|  | 53 -> WiFiUserGetPaidAutoConnectStatus |
|  | 54 -> WiFiUserSetPaidAutoConnectStatus |
|  | 55 -> WiFiUserFreeTileManagerMemory |
|  | 56 -> WiFiUserProvisionHotspotApp |
|  | 57 -> WifiUserStartHotspot2Registration |
|  | 58 -> WifiUserEnableHotspot2OsuRegistration |
|  | 59 -> WifiUserGetHotspot2OsuRegistrationStatus |
|  | 60 -> WiFiUserGetAutomaticState |
|  | 61 -> WiFiUserSetAutomaticState |
|  | 62 -> WiFiUserGetRandomizationStatus |
|  | 63 -> WiFiUserSetRandomizationStatus |
|  | 64 -> WiFiUserGetProfileRandomizationMode |
|  | 65 -> WiFiUserSetProfileRandomizationMode |
|  | 66 -> WiFiUserRequestLocalAccess |
|  | 67 -> WiFiUserGetProvideCaptivePortalDetailsStatus |
|  | 68 -> WiFiUserSetProvideCaptivePortalDetailsStatus |
|  | 69 -> WiFiUserGetCaptivePortalSetting |
|  | 70 -> WiFiUserSetCaptivePortalSetting |
|  | 71 -> WiFiUserDisconnect |
|  | 72 -> WiFiUserGetNetworkFavoriteState |
|  | 73 -> WiFiUserSetNetworkFavoriteState |
|  | 74 -> WiFiUserSendTurnOnHint |
|  | 75 -> WiFiUserSendEncourageHint |
|  | 76 -> WiFiUserGetMediaStreamingState |
|  | 77 -> WiFiUserGetProfileMetadata |
|  | 78 -> WiFiUserSetProfileMetadata |
|  | 79 -> WiFiUserGetProfileEapMethod |
|  | 80 -> WiFiUserActivateNotification |
|  | 81 -> WiFiUserGetNotificationTargetProfile |
|  | Endpoints : |
|  | ncalrpc : OLE8914EEF16B487F2D5C47E85D3F48 |
|  | ncalrpc : LRPC-a7499718ef7b1c5e0a |
|  | ncalrpc : LRPC-6cf419c2d1797b567b |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3372 at 0x5e18f28L> |
|  | 64 |
|  | \['WlanSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 25952c5d-7976-4aa1-a3cb-c35f7ae79d1b (1.1) -- c:\\windows\\system32\\wlansvc.dll |
|  | 0 -> Srv\_WDiagRpcInitSession |
|  | 1 -> Srv\_WDiagRpcEndSession |
|  | 2 -> Srv\_WDiagRpcQueryStatistics |
|  | 3 -> Srv\_WDiagRpcQueryConnectionContextInfo |
|  | 4 -> Srv\_WDiagRpcAutoConfigGetInterfaceInfo |
|  | 5 -> Srv\_WDiagRpcGetExtensibilityInfo |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- c:\\windows\\system32\\SYSNTFY.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | RPC 266f33b4-c7c1-4bd1-8f52-ddb8f2214ea9 (1.0) -- c:\\windows\\system32\\wlansvc.dll |
|  | 0 -> RpcOpenHandle |
|  | 1 -> RpcCloseHandle |
|  | 2 -> RpcEnumInterfaces |
|  | 3 -> RpcSetAutoConfigParameter |
|  | 4 -> RpcQueryAutoConfigParameter |
|  | 5 -> RpcGetInterfaceCapability |
|  | 6 -> RpcSetInterface |
|  | 7 -> RpcQueryInterface |
|  | 8 -> RpcIhvControl |
|  | 9 -> RpcScan |
|  | 10 -> RpcGetAvailableNetworkList |
|  | 11 -> RpcPrivateGetAvailableNetworkList |
|  | 12 -> RpcPrivateClearAnqpCache |
|  | 13 -> RpcPrivateRefreshAnqpCache |
|  | 14 -> RpcPrivateGetAnqpCacheResponse |
|  | 15 -> RpcPrivateParseAnqpRawData |
|  | 16 -> RpcPrivateGetAnqpOSUProviderList |
|  | 17 -> RpcPrivateEnableAnqpOsuRegistration |
|  | 18 -> RpcPrivateGetAnqpOsuRegistrationStatus |
|  | 19 -> RpcGetNetworkBssList |
|  | 20 -> RpcConnect |
|  | 21 -> RpcConnectEx |
|  | 22 -> RpcDisconnect |
|  | 23 -> RpcRegisterNotification |
|  | 24 -> RpcAsyncGetNotification |
|  | 25 -> RpcSetProfileEapUserData |
|  | 26 -> RpcSetProfile |
|  | 27 -> RpcGetProfile |
|  | 28 -> RpcDeleteProfile |
|  | 29 -> RpcRenameProfile |
|  | 30 -> RpcSetProfileList |
|  | 31 -> RpcSetProfileListForOffload |
|  | 32 -> RpcGetProfileList |
|  | 33 -> RpcSetProfilePosition |
|  | 34 -> RpcSetProfileCustomUserData |
|  | 35 -> RpcGetProfileCustomUserData |
|  | 36 -> RpcSetFilterList |
|  | 37 -> RpcGetFilterList |
|  | 38 -> RpcSetPsdIEDataList |
|  | 39 -> RpcSaveTemporaryProfile |
|  | 40 -> RpcIsUIRequestPending |
|  | 41 -> RpcSetUIForwardingNetworkList |
|  | 42 -> RpcIsNetworkSuppressed |
|  | 43 -> RpcRemoveUIForwardingNetworkList |
|  | 44 -> RpcQueryExtUIRequest |
|  | 45 -> RpcUIResponse |
|  | 46 -> RpcGetProfileKeyInfo |
|  | 47 -> RpcAsyncDoPlap |
|  | 48 -> RpcQueryPlapCredentials |
|  | 49 -> RpcCancelPlap |
|  | 50 -> RpcSetSecuritySettings |
|  | 51 -> RpcGetSecuritySettings |
|  | 52 -> RpcHostedNetworkPerformOperation |
|  | 53 -> RpcHostedNetworkHlpQueryEverUsed |
|  | 54 -> RpcHostedNetworkSetProperty |
|  | 55 -> RpcHostedNetworkQueryProperty |
|  | 56 -> RpcHostedNetworkQueryStatus |
|  | 57 -> RpcHostedNetworkQueryWCNSettings |
|  | 58 -> RpcHostedNetworkSetWCNSettings |
|  | 59 -> RpcGetProfileEapUserDataInfo |
|  | 60 -> RpcQueryPreConnectInput |
|  | 61 -> RpcConnectWithInput |
|  | 62 -> RpcRefreshConnections |
|  | 63 -> RpcInternalScan |
|  | 64 -> RpcHostedNetworkSetSecondaryKey |
|  | 65 -> RpcHostedNetworkQuerySecondaryKey |
|  | 66 -> RpcRegisterVirtualStationNotification |
|  | 67 -> RpcEnumAllInterfaces |
|  | 68 -> RpcQueryInterfacePortType |
|  | 69 -> RpcWFDDiscoverDevices |
|  | 70 -> RpcWFDGetVisibleDevices |
|  | 71 -> RpcWFDStopDiscoverDevices |
|  | 72 -> RpcWFDStartBackgroundDiscovery |
|  | 73 -> RpcWFDStopBackgroundDiscovery |
|  | 74 -> RpcWFDDiscoverDeviceServiceInformation |
|  | 75 -> RpcWFDOpenHandle |
|  | 76 -> RpcWFDRegisterVMgrCaller |
|  | 77 -> RpcWFDUnregisterVMgrCaller |
|  | 78 -> RpcWFDQueryProperty |
|  | 79 -> RpcWFDSetProperty |
|  | 80 -> RpcWFDSetSecondaryDeviceTypeList |
|  | 81 -> RpcWFDPairEnumerateCeremonies |
|  | 82 -> RpcWFDPairSelectCeremony |
|  | 83 -> RpcWFDPairWithDevice |
|  | 84 -> RpcWFDPairCancel |
|  | 85 -> RpcWFDPairCancelByDeviceAddress |
|  | 86 -> RpcWFDOpenSession |
|  | 87 -> RpcWFDGetSessionEndpointPairs |
|  | 88 -> RpcWFDConfigureFirewallForSession |
|  | 89 -> RpcWFDCancelOpenSession |
|  | 90 -> RpcWFDCloseSession |
|  | 91 -> RpcWFDAbortSession |
|  | 92 -> RpcWFDForceDisconnect |
|  | 93 -> RpcWFDForceDisconnectLegacyPeer |
|  | 94 -> RpcWFDAcceptGroupRequestAndOpenSession |
|  | 95 -> RpcWFDDeclineGroupRequest |
|  | 96 -> RpcWFDSetWCNSettings |
|  | 97 -> RpcWFDAcceptConnectRequestAndOpenSession |
|  | 98 -> RpcWFDDeclineConnectRequest |
|  | 99 -> RpcWFDGetPeerInfo |
|  | 100 -> RpcWFDGetDefaultGroupProfile |
|  | 101 -> RpcWFDGetProfileKeyInfo |
|  | 102 -> RpcWFDStartUsingGroup |
|  | 103 -> RpcWFDStopUsingGroup |
|  | 104 -> RpcWFDOpenLegacySessionWithProfile |
|  | 105 -> RpcWFDCloseLegacySession |
|  | 106 -> RpcWFDIsInterfaceWiFiDirect |
|  | 107 -> RpcIsWiFiDirectRunningOnWiFiAdapter |
|  | 108 -> RpcWFDUpdateDeviceVisibility |
|  | 109 -> RpcWFDOpenLegacySession |
|  | 110 -> RpcWFDFlushVisibleDeviceList |
|  | 111 -> RpcWlanNotifyVsIeProvider |
|  | 112 -> RpcWlanNotifyVsIeProviderEx |
|  | 113 -> RpcWFDGetDeviceDescriptorForPendingRequest |
|  | 114 -> RpcWFDStartOffloadedDiscovery |
|  | 115 -> RpcWFDStopOffloadedDiscovery |
|  | 116 -> RpcWFDGetPrimaryAdapterState |
|  | 117 -> RpcWFDDiscoverDevicesEx |
|  | 118 -> RpcWFDGetVisibleDevicesEx |
|  | 119 -> RpcWFDStopDiscoverDevicesEx |
|  | 120 -> RpcWFDSetSelectedWfdMgr |
|  | 121 -> RpcWFDSetSelectedWfdMgrWithoutClientContext |
|  | 122 -> RpcWFDResetSelectedWfdMgr |
|  | 123 -> RpcWiFiDisplaySetSinkClientHandle |
|  | 124 -> RpcWiFiDisplaySetSinkState |
|  | 125 -> RpcWiFiDisplayResetSinkState |
|  | 126 -> RpcSetProfileMetadata |
|  | 127 -> RpcGetProfileMetadata |
|  | 128 -> RpcWCMGetProfileList |
|  | 129 -> RpcWcmSetProfile |
|  | 130 -> RpcWcmSetInterface |
|  | 131 -> RpcWcmGetInterface |
|  | 132 -> RpcWcmDisconnect |
|  | 133 -> RpcStoreRadioState |
|  | 134 -> RpcGetStoredRadioState |
|  | 135 -> RpcGetRadioInformation |
|  | 136 -> RpcGetProfileIndex |
|  | 137 -> RpcGetMFPNegotiated |
|  | 138 -> RpcPrivateQueryInterface |
|  | 139 -> RpcPrivateSetInterface |
|  | 140 -> RpcUpdateBasicProfileSecurity |
|  | 141 -> RpcPrivateQuery11adPairedConfig |
|  | 142 -> RpcGetSupportedDeviceServices |
|  | 143 -> RpcDeviceServiceCommand |
|  | RPC 266f33b4-c7c1-4bd1-8f52-ddb8f2214eb0 (1.0) -- c:\\windows\\system32\\wlansvc.dll |
|  | 0 -> RpcLowPrivOpenHandle |
|  | 1 -> RpcLowPrivCloseHandle |
|  | 2 -> RpcLowPrivRegisterNotification |
|  | 3 -> RpcLowPrivAsyncGetNotification |
|  | 4 -> RpcLowPrivSetInterface |
|  | 5 -> RpcLowPrivQueryInterface |
|  | 6 -> RpcLowPrivEnumInterfaces |
|  | 7 -> RpcWfdLowPrivIsWfdSupported |
|  | 8 -> RpcWfdLowPrivOpenHandle |
|  | 9 -> RpcWfdLowPrivCancelOpenSession |
|  | 10 -> RpcWfdLowPrivCloseSession |
|  | 11 -> RpcWfdLowPrivGetSessionEndpointPairs |
|  | 12 -> RpcWfdLowPrivConfigureFirewallForSession |
|  | 13 -> RpcWfdLowPrivOpenLegacySessionWithProfile |
|  | 14 -> RpcWfdLowPrivCloseLegacySession |
|  | 15 -> RpcWfdLowPrivQueryProperty |
|  | 16 -> RpcWfdLowPrivSetProperty |
|  | 17 -> RpcWfdLowPrivStartUsingGroup |
|  | 18 -> RpcWfdLowPrivStopUsingGroup |
|  | 19 -> RpcWlanLowPrivNotifyVsIeProvider |
|  | 20 -> RpcWfdLowPrivOpenSessionByDafObjectId |
|  | 21 -> RpcWfdLowPrivDeclineDeviceApiConnectionRequest |
|  | 22 -> RpcWfdLowPrivStartDeviceApiConnectionRequestListener |
|  | 23 -> RpcWfdLowPrivStopDeviceApiConnectionRequestListener |
|  | 24 -> RpcWFDSvcLowPrivPublishService |
|  | 25 -> RpcWFDSvcLowPrivUnpublishService |
|  | 26 -> RpcWfdSvcLowPrivOpenSeekerSession |
|  | 27 -> RpcWfdSvcLowPrivOpenAdvertiserSession |
|  | 28 -> RpcWfdSvcLowPrivGetProvisioningInfo |
|  | 29 -> RpcWfdSvcLowPrivConnectSession |
|  | 30 -> RpcWfdSvcLowPrivCancelSession |
|  | 31 -> RpcWfdSvcLowPrivAcceptSession |
|  | 32 -> RpcWfdSvcLowPrivConfigureSession |
|  | 33 -> RpcWfdSvcLowPrivCloseSession |
|  | 34 -> RpcWfdSvcLowPrivGetSessionEndpointPairs |
|  | 35 -> RpcWfdLowPrivRegisterVMgrCaller |
|  | 36 -> RpcWfdLowPrivUnregisterVMgrCaller |
|  | 37 -> RpcWlanVMgrQueryCurrentScenarios |
|  | 38 -> RpcWfdLowPrivGetPendingGroupRequestDetails |
|  | RPC c3f42c6e-d4cc-4e5a-938b-9c5e8a5d8c2e (1.0) -- c:\\windows\\system32\\WLANMSM.DLL |
|  | 0 -> RpcDot11ExtRegisterIhvProcess |
|  | 1 -> RpcDot11ExtPreAssociateCompletion |
|  | 2 -> RpcDot11ExtPostAssociateCompletion |
|  | 3 -> RpcDot11ExtSendUIRequest |
|  | 4 -> RpcDot11ExtSendNotification |
|  | 5 -> RpcDot11ExtGetProfileCustomUserData |
|  | 6 -> RpcDot11ExtSetProfileCustomUserData |
|  | 7 -> RpcDot11ExtNotifyChangeState |
|  | 8 -> RpcDot11ExtSetCurrentProfile |
|  | 9 -> RpcDot11ExtStartOneX |
|  | 10 -> RpcDot11ExtStopOneX |
|  | 11 -> RpcDot11ExtProcessSecurityPacket |
|  | 12 -> RpcDot11ExtRequestVirtualStation |
|  | 13 -> RpcDot11ExtReleaseVirtualStation |
|  | 14 -> RpcDot11ExtSetVirtualStationAPProperties |
|  | RPC a111f1c6-5923-47c0-9a68-d0bafb577901 (1.0) -- C:\\Windows\\System32\\NetSetupShim.dll |
|  | 0 -> RpcNetSetup\_NotifyHost\_Connect |
|  | 1 -> RpcNetSetup\_NotifyHost\_Disconnect |
|  | 2 -> RpcNetSetup\_Isolation\_ExecuteInfSection |
|  | 3 -> RpcNetSetup\_NotifyObject\_Load |
|  | 4 -> RpcNetSetup\_NotifyObject\_Unload |
|  | 5 -> RpcNetSetup\_ComponentControl\_Initialize |
|  | 6 -> RpcNetSetup\_ComponentControl\_ApplyChanges |
|  | 7 -> RpcNetSetup\_ComponentControl\_ApplyPnpChanges |
|  | 8 -> RpcNetSetup\_ComponentControl\_CancelChanges |
|  | 9 -> RpcNetSetup\_ComponentSetup\_Install |
|  | 10 -> RpcNetSetup\_ComponentSetup\_Upgrade |
|  | 11 -> RpcNetSetup\_ComponentSetup\_Removing |
|  | 12 -> RpcNetSetup\_NotifyBinding\_QueryBindingPath |
|  | 13 -> RpcNetSetup\_NotifyBinding\_NotifyBindingPath |
|  | 14 -> RpcNetSetup\_NotifyGlobal\_GetSupportedNotifications |
|  | 15 -> RpcNetSetup\_NotifyGlobal\_SysQueryBindingPath |
|  | 16 -> RpcNetSetup\_NotifyGlobal\_SysNotifyBindingPath |
|  | 17 -> RpcNetSetup\_NotifyGlobal\_SysNotifyComponent |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-980e251dff6123d053 |
|  | ncalrpc : LRPC-1584350eef00c3a38a |
|  | ncalrpc : OLE70A9045440095781F084FEE0B79C |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3452 at 0x5e18b70L> |
|  | 64 |
|  | \['BFE', 'CoreMessagingRegistrar', 'mpssvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC df4df73a-c52d-4e3a-8003-8437fdf8302a (0.0) -- c:\\windows\\system32\\coremessaging.dll |
|  | 0 -> ServerValidateWindowId |
|  | 1 -> ServerValidateWindowIdAndOwner |
|  | RPC dd490425-5325-4565-b774-7e27d6c09c24 (1.0) -- c:\\windows\\system32\\bfe.dll |
|  | 0 -> BfeRpcGetNextNotificationBatch |
|  | 1 -> BfeRpcNotifyComplete |
|  | 2 -> BfeRpcEngineOpen |
|  | 3 -> BfeRpcEngineClose |
|  | 4 -> BfeRpcEngineGetOption |
|  | 5 -> BfeRpcEngineSetOption |
|  | 6 -> BfeRpcEngineGetSecurityInfo |
|  | 7 -> BfeRpcEngineSetSecurityInfo |
|  | 8 -> BfeRpcSessionCreateEnumHandle |
|  | 9 -> BfeRpcAleEndpointEnum |
|  | 10 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 11 -> BfeRpcTransactionBegin |
|  | 12 -> BfeRpcTransactionCommit |
|  | 13 -> BfeRpcTransactionAbort |
|  | 14 -> BfeRpcProviderAdd |
|  | 15 -> BfeRpcProviderDeleteByKey |
|  | 16 -> BfeRpcProviderGetByKey |
|  | 17 -> BfeRpcProviderCreateEnumHandle |
|  | 18 -> BfeRpcAleEndpointEnum |
|  | 19 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 20 -> BfeRpcProviderGetSecurityInfoByKey |
|  | 21 -> BfeRpcProviderSetSecurityInfoByKey |
|  | 22 -> BfeRpcProviderSubscribeChanges |
|  | 23 -> BfeRpcProviderUnsubscribeChanges |
|  | 24 -> BfeRpcProviderSubscriptionsGet |
|  | 25 -> BfeRpcProviderContextAdd |
|  | 26 -> BfeRpcProviderContextDeleteById |
|  | 27 -> BfeRpcProviderContextDeleteByKey |
|  | 28 -> BfeRpcProviderContextGetById |
|  | 29 -> BfeRpcProviderContextGetByKey |
|  | 30 -> BfeRpcProviderContextCreateEnumHandle |
|  | 31 -> BfeRpcAleEndpointEnum |
|  | 32 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 33 -> BfeRpcProviderContextGetSecurityInfoByKey |
|  | 34 -> BfeRpcProviderContextSetSecurityInfoByKey |
|  | 35 -> BfeRpcProviderContextSubscribeChanges |
|  | 36 -> BfeRpcProviderContextUnsubscribeChanges |
|  | 37 -> BfeRpcProviderContextSubscriptionsGet |
|  | 38 -> BfeRpcSubLayerAdd |
|  | 39 -> BfeRpcSubLayerDeleteByKey |
|  | 40 -> BfeRpcSubLayerGetByKey |
|  | 41 -> BfeRpcSubLayerCreateEnumHandle |
|  | 42 -> BfeRpcAleEndpointEnum |
|  | 43 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 44 -> BfeRpcSubLayerGetSecurityInfoByKey |
|  | 45 -> BfeRpcSubLayerSetSecurityInfoByKey |
|  | 46 -> BfeRpcSubLayerSubscribeChanges |
|  | 47 -> BfeRpcSubLayerUnsubscribeChanges |
|  | 48 -> BfeRpcSubLayerSubscriptionsGet |
|  | 49 -> BfeRpcLayerGetById |
|  | 50 -> BfeRpcLayerGetByKey |
|  | 51 -> BfeRpcLayerCreateEnumHandle |
|  | 52 -> BfeRpcAleEndpointEnum |
|  | 53 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 54 -> BfeRpcLayerGetSecurityInfoByKey |
|  | 55 -> BfeRpcLayerSetSecurityInfoByKey |
|  | 56 -> BfeRpcCalloutAdd |
|  | 57 -> BfeRpcCalloutDeleteById |
|  | 58 -> BfeRpcCalloutDeleteByKey |
|  | 59 -> BfeRpcCalloutGetById |
|  | 60 -> BfeRpcCalloutGetByKey |
|  | 61 -> BfeRpcCalloutCreateEnumHandle |
|  | 62 -> BfeRpcAleEndpointEnum |
|  | 63 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 64 -> BfeRpcCalloutGetSecurityInfoByKey |
|  | 65 -> BfeRpcCalloutSetSecurityInfoByKey |
|  | 66 -> BfeRpcCalloutSubscribeChanges |
|  | 67 -> BfeRpcCalloutUnsubscribeChanges |
|  | 68 -> BfeRpcCalloutSubscriptionsGet |
|  | 69 -> BfeRpcFilterAdd |
|  | 70 -> BfeRpcFilterDeleteById |
|  | 71 -> BfeRpcFilterDeleteByKey |
|  | 72 -> BfeRpcFilterGetById |
|  | 73 -> BfeRpcFilterGetByKey |
|  | 74 -> BfeRpcFilterCreateEnumHandle |
|  | 75 -> BfeRpcAleEndpointEnum |
|  | 76 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 77 -> BfeRpcFilterGetSecurityInfoByKey |
|  | 78 -> BfeRpcFilterSetSecurityInfoByKey |
|  | 79 -> BfeRpcFilterSubscribeChanges |
|  | 80 -> BfeRpcFilterUnsubscribeChanges |
|  | 81 -> BfeRpcFilterSubscriptionsGet |
|  | 82 -> BfeRpcBfeIPsecOffloadDone |
|  | 83 -> BfeRpcBfeIPsecDosFWUsed |
|  | 84 -> BfeRpcBfeIPsecGetStatistics |
|  | 85 -> BfeRpcBfeIPsecSaContextCreate |
|  | 86 -> BfeRpcBfeIPsecSaContextDeleteById |
|  | 87 -> BfeRpcBfeIPsecSaContextGetById |
|  | 88 -> BfeRpcBfeIPsecSaContextGetOrSetSpi |
|  | 89 -> BfeRpcBfeIPsecSaContextAddInbound |
|  | 90 -> BfeRpcBfeIPsecSaContextAddOutbound |
|  | 91 -> BfeRpcBfeIPsecSaContextUpdate |
|  | 92 -> BfeRpcBfeIPsecSaContextExpire |
|  | 93 -> BfeRpcBfeIPsecSaContextCreateEnumHandle |
|  | 94 -> BfeRpcAleEndpointEnum |
|  | 95 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 96 -> BfeRpcBfeIPsecSaContextSubscribe |
|  | 97 -> BfeRpcBfeIPsecSaContextUnsubscribe |
|  | 98 -> BfeRpcBfeIPsecSaContextSubscriptionsGet |
|  | 99 -> BfeRpcBfeIPsecSaCreateEnumHandle |
|  | 100 -> BfeRpcAleEndpointEnum |
|  | 101 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 102 -> BfeRpcBfeIPsecSaDbGetSecurityInfo |
|  | 103 -> BfeRpcBfeIPsecSaDbSetSecurityInfo |
|  | 104 -> BfeRpcBfeIPsecDospGetStatistics |
|  | 105 -> BfeRpcBfeIPsecDospStateCreateEnumHandle |
|  | 106 -> BfeRpcAleEndpointEnum |
|  | 107 -> BfeRpcBfeIPsecDospStateDestroyEnumHandle |
|  | 108 -> BfeRpcBfeIPsecDospGetSecurityInfo |
|  | 109 -> BfeRpcBfeIPsecDospSetSecurityInfo |
|  | 110 -> BfeRpcNetEventCreateEnumHandle |
|  | 111 -> BfeRpcAleEndpointEnum |
|  | 112 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 113 -> BfeRpcNetEventsGetSecurityInfo |
|  | 114 -> BfeRpcNetEventsSetSecurityInfo |
|  | 115 -> BfeRpcNetEventSubscribe |
|  | 116 -> BfeRpcNetEventUnsubscribe |
|  | 117 -> BfeRpcNetEventSubscriptionsGet |
|  | 118 -> BfeRpcNetEventsLost |
|  | 119 -> BfeRpcConnectionGetById |
|  | 120 -> BfeRpcConnectionGetByIPsecInfo |
|  | 121 -> BfeRpcConnectionGetByS2STunnelId |
|  | 122 -> BfeRpcConnectionCreateEnumHandle |
|  | 123 -> BfeRpcAleEndpointEnum |
|  | 124 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 125 -> BfeRpcConnectionGetSecurityInfo |
|  | 126 -> BfeRpcConnectionSetSecurityInfo |
|  | 127 -> BfeRpcConnectionGetS2STunnelId |
|  | 128 -> BfeRpcConnectionSubscribe |
|  | 129 -> BfeRpcConnectionUnsubscribe |
|  | 130 -> BfeRpcConnectionSubscriptionsGet |
|  | 131 -> BfeRpcConnectionsLost |
|  | 132 -> BfeRpcClassify |
|  | 133 -> BfeRpcAddLayerReplica |
|  | 134 -> BfeRpcDeleteLayerReplica |
|  | 135 -> BfeRpcSecureSocketAdd |
|  | 136 -> BfeRpcBfeIPsecTunnelDeleteByKey |
|  | 137 -> BfeRpcBfeIPsecTunnelAdd |
|  | 138 -> BfeRpcBfeIPsecTunnelAddConditions |
|  | 139 -> BfeRpcBfeIPsecS2STunnelAddConditions |
|  | 140 -> BfeRpcBfeIPsecS2STunnelRemoveConditions |
|  | 141 -> BfeRpcBfeIPsecTunnelDeleteByKey |
|  | 142 -> BfeRpcBfeIPsecS2STunnelAddInterfaceToCompartment |
|  | 143 -> BfeRpcBfeIPsecS2STunnelGetInterfaceForCompartment |
|  | 144 -> BfeRpcBfeIPsecS2STunnelRemoveInterfaceFromCompartment |
|  | 145 -> BfeRpcBfeIPsecSaInitiateAsync |
|  | 146 -> BfeRpcOpenToken |
|  | 147 -> BfeRpcCloseToken |
|  | 148 -> BfeRpcAleExplicitCredentialsQuery |
|  | 149 -> BfeRpcAleEndpointGetById |
|  | 150 -> BfeRpcAleEndpointCreateEnumHandle |
|  | 151 -> BfeRpcAleEndpointEnum |
|  | 152 -> BfeRpcAleEndpointDestroyEnumHandle |
|  | 153 -> BfeRpcAleEndpointGetSecurityInfo |
|  | 154 -> BfeRpcAleEndpointSetSecurityInfo |
|  | 155 -> BfeRpcAleGetPortStatus |
|  | 156 -> BfeRpcIsUserAuthConfigured |
|  | 157 -> BfeRpcKeyModuleAdd |
|  | 158 -> BfeRpcKeyModuleDeleteByKey |
|  | 159 -> BfeRpcKeyModuleUpdateAcquire |
|  | 160 -> BfeRpcKeyDictatorCheck |
|  | 161 -> BfeRpcGetKeyFromDictator |
|  | 162 -> BfeRpcNotifyKey |
|  | 163 -> BfeRpcKeyManagerAdd |
|  | 164 -> BfeRpcKeyManagerDeleteByKey |
|  | 165 -> BfeRpcKeyManagersGet |
|  | 166 -> BfeRpcKeyManagerGetSecurityInfoByKey |
|  | 167 -> BfeRpcKeyManagerSetSecurityInfoByKey |
|  | 168 -> BfeRpcvSwitchEventFire |
|  | 169 -> BfeRpcvSwitchEventsGetSecurityInfo |
|  | 170 -> BfeRpcvSwitchEventsSetSecurityInfo |
|  | 171 -> BfeRpcvSwitchEventSubscribe |
|  | 172 -> BfeRpcvSwitchEventUnsubscribe |
|  | 173 -> BfeRpcvSwitchEventSubscriptionsGet |
|  | 174 -> BfeRpcBfeIPsecDriverInitiateAcquire |
|  | 175 -> BfeRpcBfeIPsecDriverExpire |
|  | 176 -> BfeRpcBfeIPsecDriverSaOffloaded |
|  | 177 -> BfeRpcBfeIPsecDriverProcessClearTextResponse |
|  | 178 -> BfeRpcBfeProcessNameResolutionEvent |
|  | 179 -> BfeRpcVpnTriggerEventFire |
|  | 180 -> BfeRpcVpnTriggerEventSubscribe |
|  | 181 -> BfeRpcVpnTriggerEventUnsubscribe |
|  | 182 -> BfeRpcVpnTriggerAddAppSids |
|  | 183 -> BfeRpcVpnTriggerRemoveAppSids |
|  | 184 -> BfeRpcVpnTriggerAddFilePaths |
|  | 185 -> BfeRpcVpnTriggerRemoveFilePaths |
|  | 186 -> BfeRpcVpnTriggerAddSecurityDescriptor |
|  | 187 -> BfeRpcVpnTriggerRemoveSecurityDescriptor |
|  | 188 -> BfeRpcVpnTriggerSetStateDisconnected |
|  | 189 -> BfeRpcVpnTriggerInitializeNrptTriggering |
|  | 190 -> BfeRpcVpnTriggerUninitializeNrptTriggering |
|  | 191 -> BfeRpcVpnTriggerResetNrptTriggering |
|  | 192 -> BfeRpcVpnTriggerConfigureParameters |
|  | 193 -> BfeRpcBitmapIndexGet |
|  | 194 -> BfeRpcBitmapIndexFree |
|  | RPC 7f9d11bf-7fb9-436b-a812-b2d50c5d4c03 (1.0) -- c:\\windows\\system32\\mpssvc.dll |
|  | 0 -> RPC\_FWIndicatePortInUse |
|  | 1 -> RPC\_FWGetIndicatedPortInUse |
|  | 2 -> RPC\_FWIndicateTupleInUse |
|  | 3 -> RPC\_FWResetIndicatedTupleInUse |
|  | 4 -> RPC\_FWIndicateProxyForUrl |
|  | 5 -> CNetProfileEventSink::NetworkAdded |
|  | 6 -> RPC\_FWIsTargetAProxy |
|  | 7 -> RPC\_NetworkIsolationSetupAppContainerBinaries |
|  | 8 -> RPC\_NetworkIsolationRegisterForAppContainerChanges |
|  | 9 -> Rpc\_NetworkIsolationRegistrationGetLastEvent |
|  | 10 -> RPC\_NetworkIsolationUnregisterForAppContainerChanges |
|  | 11 -> RPC\_NetworkIsolationGetAppContainer |
|  | 12 -> RPC\_NetworkIsolationEnumAppContainers |
|  | 13 -> RPC\_NetworkIsolationAddAllowEnterpriseIdRule |
|  | 14 -> RPC\_NetworkIsolationCreateAllInterfacesContainer |
|  | 15 -> RPC\_NetworkIsolationCreateInterfaceContainer |
|  | 16 -> RPC\_NetworkIsolationDeleteAllInterfacesContainer |
|  | 17 -> RPC\_NetworkIsolationDeleteInterfaceContainer |
|  | RPC f47433c3-3e9d-4157-aad4-83aa1f5c2d4c (1.0) -- c:\\windows\\system32\\mpssvc.dll |
|  | 0 -> RPC\_NetworkIsolationDiagnoseConnectFailure |
|  | 1 -> RPC\_NetworkIsolationGetEnterpriseIdAsync |
|  | 2 -> RPC\_NetworkIsolationCreateContainer |
|  | 3 -> RPC\_NetworkIsolationDeleteContainer |
|  | 4 -> RPC\_NetworkIsolationGetAppContainerConfig |
|  | 5 -> RPC\_NetworkIsolationSetAppContainerConfig |
|  | 6 -> RPC\_NetworkIsolationCreateAppContainer |
|  | 7 -> RPC\_NetworkIsolationDeleteAppContainer |
|  | 8 -> RPC\_NetworkIsolationCreateAppContainerLoopbackRules |
|  | 9 -> RPC\_NetworkIsolationDeleteAppContainerLoopbackRules |
|  | RPC 2fb92682-6599-42dc-ae13-bd2ca89bd11c (1.0) -- c:\\windows\\system32\\mpssvc.dll |
|  | 0 -> RPC\_FWOpenPolicyStore |
|  | 1 -> RPC\_FWClosePolicyStore |
|  | 2 -> RPC\_FWRestoreDefaults |
|  | 3 -> RPC\_FWGetGlobalConfig |
|  | 4 -> RPC\_FWSetGlobalConfig |
|  | 5 -> RPC\_FWAddFirewallRule |
|  | 6 -> RPC\_FWSetFirewallRule |
|  | 7 -> RPC\_FWDeleteFirewallRule |
|  | 8 -> RPC\_FWDeleteAllFirewallRules |
|  | 9 -> RPC\_FWEnumFirewallRules |
|  | 10 -> RPC\_FWGetConfig |
|  | 11 -> RPC\_FWSetConfig |
|  | 12 -> RPC\_FWNotifyUnsupportedAttempt |
|  | 13 -> RPC\_FWAddConnectionSecurityRule |
|  | 14 -> RPC\_FWSetConnectionSecurityRule |
|  | 15 -> RPC\_FWDeleteConnectionSecurityRule |
|  | 16 -> RPC\_FWDeleteAllConnectionSecurityRules |
|  | 17 -> RPC\_FWEnumConnectionSecurityRules |
|  | 18 -> RPC\_FWAddAuthenticationSet |
|  | 19 -> RPC\_FWSetAuthenticationSet |
|  | 20 -> RPC\_FWDeleteAuthenticationSet |
|  | 21 -> RPC\_FWDeleteAllAuthenticationSets |
|  | 22 -> RPC\_FWEnumAuthenticationSets |
|  | 23 -> RPC\_FWAddCryptoSet |
|  | 24 -> RPC\_FWSetCryptoSet |
|  | 25 -> RPC\_FWDeleteCryptoSet |
|  | 26 -> RPC\_FWDeleteAllCryptoSets |
|  | 27 -> RPC\_FWEnumCryptoSets |
|  | 28 -> RPC\_FWEnumPhase1SAs |
|  | 29 -> RPC\_FWEnumPhase2SAs |
|  | 30 -> RPC\_FWDeletePhase1SAs |
|  | 31 -> RPC\_FWDeletePhase2SAs |
|  | 32 -> RPC\_FWRegisterProduct |
|  | 33 -> RPC\_FWUnregisterProduct |
|  | 34 -> RPC\_FWEnumProducts |
|  | 35 -> RPC\_FWAddMainModeRule |
|  | 36 -> RPC\_FWSetMainModeRule |
|  | 37 -> RPC\_FWDeleteMainModeRule |
|  | 38 -> RPC\_FWDeleteAllMainModeRules |
|  | 39 -> RPC\_FWEnumMainModeRules |
|  | 40 -> RPC\_FWQueryFirewallRules |
|  | 41 -> RPC\_FWQueryConnectionSecurityRules2\_10 |
|  | 42 -> RPC\_FWQueryMainModeRules |
|  | 43 -> RPC\_FWQueryAuthenticationSets |
|  | 44 -> RPC\_FWQueryCryptoSets |
|  | 45 -> RPC\_FWEnumNetworks |
|  | 46 -> RPC\_FWEnumAdapters |
|  | 47 -> RPC\_FWGetGlobalConfig2\_10 |
|  | 48 -> RPC\_FWGetConfig2\_10 |
|  | 49 -> RPC\_FWAddFirewallRule2\_10 |
|  | 50 -> RPC\_FWSetFirewallRule2\_10 |
|  | 51 -> RPC\_FWEnumFirewallRules2\_10 |
|  | 52 -> RPC\_FWAddConnectionSecurityRule2\_10 |
|  | 53 -> RPC\_FWSetConnectionSecurityRule2\_10 |
|  | 54 -> RPC\_FWEnumConnectionSecurityRules2\_10 |
|  | 55 -> RPC\_FWAddAuthenticationSet2\_10 |
|  | 56 -> RPC\_FWSetAuthenticationSet2\_10 |
|  | 57 -> RPC\_FWEnumAuthenticationSets2\_10 |
|  | 58 -> RPC\_FWAddCryptoSet2\_10 |
|  | 59 -> RPC\_FWSetCryptoSet2\_10 |
|  | 60 -> RPC\_FWEnumCryptoSets2\_10 |
|  | 61 -> RPC\_FWDiagGetAppList |
|  | 62 -> RPC\_FWAddConnectionSecurityRule2\_20 |
|  | 63 -> RPC\_FWSetConnectionSecurityRule2\_20 |
|  | 64 -> RPC\_FWEnumConnectionSecurityRules2\_20 |
|  | 65 -> RPC\_FWQueryConnectionSecurityRules2\_20 |
|  | 66 -> RPC\_FWAddAuthenticationSet2\_20 |
|  | 67 -> RPC\_FWSetAuthenticationSet2\_20 |
|  | 68 -> RPC\_FWEnumAuthenticationSets2\_20 |
|  | 69 -> RPC\_FWQueryAuthenticationSets2\_20 |
|  | 70 -> RPC\_FWAddFirewallRule2\_20 |
|  | 71 -> RPC\_FWSetFirewallRule2\_20 |
|  | 72 -> RPC\_FWEnumFirewallRules2\_20 |
|  | 73 -> RPC\_FWQueryFirewallRules2\_20 |
|  | 74 -> RPC\_FWQueryIsolationType |
|  | 75 -> RPC\_FWSelectConSecRule |
|  | 76 -> RPC\_FWAddFirewallRule2\_24 |
|  | 77 -> RPC\_FWSetFirewallRule2\_24 |
|  | 78 -> RPC\_FWEnumFirewallRules2\_24 |
|  | 79 -> RPC\_FWQueryFirewallRules2\_24 |
|  | 80 -> RPC\_FWAddFirewallRule2\_25 |
|  | 81 -> RPC\_FWSetFirewallRule2\_25 |
|  | 82 -> RPC\_FWEnumFirewallRules2\_25 |
|  | 83 -> RPC\_FWQueryFirewallRules2\_25 |
|  | 84 -> RPC\_FWAddFirewallRule2\_26 |
|  | 85 -> RPC\_FWSetFirewallRule2\_26 |
|  | 86 -> RPC\_FWEnumFirewallRules2\_26 |
|  | 87 -> RPC\_FWQueryFirewallRules2\_26 |
|  | 88 -> RPC\_FWAddFirewallRule2\_27 |
|  | 89 -> RPC\_FWSetFirewallRule2\_27 |
|  | 90 -> RPC\_FWEnumFirewallRules2\_27 |
|  | 91 -> RPC\_FWQueryFirewallRules2\_27 |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | Endpoints : |
|  | ncalrpc : LRPC-d9f8936950b36b0b95 |
|  | ncalrpc : LRPC-85eb860f11f29b9b01 |
|  | ncalrpc : LRPC-4ef3a62e074c9cae5b |
|  | ncalrpc : LRPC-514e2a0c21b20b4d9a |
|  | ncalrpc : LRPC-135f73867046c3d66f |
|  | ncalrpc : OLE7306F1ABD36F90ECF223B73622E2 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3524 at 0x5e18470L> |
|  | 64 |
|  | \['ShellHWDetection'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE bf0d821f-486c-49c4-8a3d-86e990047d65 (0.0) -- ISetShellForeground |
|  | OLE 3b0f86b5-8113-439d-b2a3-2766c839d073 (0.0) -- IHardwareDevices |
|  | OLE 1c0eb79b-2cde-44ec-bb35-fc471024c13c (0.0) -- IHardwareDevicesVolumesEnum |
|  | OLE ee93d145-9b4e-480c-8385-1e8119a6f7b2 (0.0) -- IHardwareDevicesMountPointsEnum |
|  | Endpoints : |
|  | ncalrpc : OLE248E9160E50B226360C8D3532556 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "spoolsv.exe" pid 3632 at 0x5e183c8L> |
|  | 64 |
|  | \['Spooler'\] |
|  |  |
|  | Interfaces : |
|  | RPC 12345678-1234-abcd-ef00-0123456789ab (1.0) -- C:\\WINDOWS\\System32\\spoolsv.exe |
|  | 0 -> RpcEnumPrinters |
|  | 1 -> RpcOpenPrinter |
|  | 2 -> RpcSetJob |
|  | 3 -> RpcGetJob |
|  | 4 -> RpcEnumJobs |
|  | 5 -> RpcAddPrinter |
|  | 6 -> RpcDeletePrinter |
|  | 7 -> RpcSetPrinter |
|  | 8 -> RpcGetPrinter |
|  | 9 -> RpcAddPrinterDriver |
|  | 10 -> RpcEnumPrinterDrivers |
|  | 11 -> RpcGetPrinterDriver |
|  | 12 -> RpcGetPrinterDriverDirectory |
|  | 13 -> RpcDeletePrinterDriver |
|  | 14 -> RpcAddPrintProcessor |
|  | 15 -> RpcEnumPrintProcessors |
|  | 16 -> RpcGetPrintProcessorDirectory |
|  | 17 -> RpcStartDocPrinter |
|  | 18 -> RpcStartPagePrinter |
|  | 19 -> RpcWritePrinter |
|  | 20 -> RpcEndPagePrinter |
|  | 21 -> RpcAbortPrinter |
|  | 22 -> RpcReadPrinter |
|  | 23 -> RpcEndDocPrinter |
|  | 24 -> RpcAddJob |
|  | 25 -> RpcScheduleJob |
|  | 26 -> RpcGetPrinterData |
|  | 27 -> RpcSetPrinterData |
|  | 28 -> RpcWaitForPrinterChange |
|  | 29 -> RpcClosePrinter |
|  | 30 -> RpcAddForm |
|  | 31 -> RpcDeleteForm |
|  | 32 -> RpcGetForm |
|  | 33 -> RpcSetForm |
|  | 34 -> RpcEnumForms |
|  | 35 -> RpcEnumPorts |
|  | 36 -> RpcEnumMonitors |
|  | 37 -> RpcAddPort |
|  | 38 -> RpcConfigurePort |
|  | 39 -> RpcDeletePort |
|  | 40 -> RpcCreatePrinterIC |
|  | 41 -> RpcPlayGdiScriptOnPrinterIC |
|  | 42 -> RpcDeletePrinterIC |
|  | 43 -> RpcAddPrinterConnection |
|  | 44 -> RpcDeletePrinterConnection |
|  | 45 -> RpcPrinterMessageBox |
|  | 46 -> RpcAddMonitor |
|  | 47 -> RpcDeleteMonitor |
|  | 48 -> RpcDeletePrintProcessor |
|  | 49 -> RpcAddPrintProvidor |
|  | 50 -> RpcDeletePrintProvidor |
|  | 51 -> RpcEnumPrintProcessorDatatypes |
|  | 52 -> RpcResetPrinter |
|  | 53 -> RpcGetPrinterDriver2 |
|  | 54 -> RpcClientFindFirstPrinterChangeNotification |
|  | 55 -> RpcFindNextPrinterChangeNotification |
|  | 56 -> RpcFindClosePrinterChangeNotification |
|  | 57 -> NThreadingLibrary::TWorkItem::NotifyCancel |
|  | 58 -> RpcReplyOpenPrinter |
|  | 59 -> RpcRouterReplyPrinter |
|  | 60 -> RpcReplyClosePrinter |
|  | 61 -> RpcAddPortEx |
|  | 62 -> RpcRemoteFindFirstPrinterChangeNotification |
|  | 63 -> RpcSetAllocFailCount |
|  | 64 -> RpcResetPrinterEx |
|  | 65 -> RpcRemoteFindFirstPrinterChangeNotificationEx |
|  | 66 -> RpcRouterReplyPrinterEx |
|  | 67 -> RpcRouterRefreshPrinterChangeNotification |
|  | 68 -> RpcSetAllocFailCount |
|  | 69 -> RpcOpenPrinterEx |
|  | 70 -> RpcAddPrinterEx |
|  | 71 -> RpcSetPort |
|  | 72 -> RpcEnumPrinterData |
|  | 73 -> RpcDeletePrinterData |
|  | 74 -> NThreadingLibrary::TWorkItem::NotifyCancel |
|  | 75 -> NThreadingLibrary::TWorkItem::NotifyCancel |
|  | 76 -> NThreadingLibrary::TWorkItem::NotifyCancel |
|  | 77 -> RpcSetPrinterDataEx |
|  | 78 -> RpcGetPrinterDataEx |
|  | 79 -> RpcEnumPrinterDataEx |
|  | 80 -> RpcEnumPrinterKey |
|  | 81 -> RpcDeletePrinterDataEx |
|  | 82 -> RpcDeletePrinterKey |
|  | 83 -> RpcSeekPrinter |
|  | 84 -> RpcDeletePrinterDriverEx |
|  | 85 -> RpcAddPerMachineConnection |
|  | 86 -> RpcDeletePerMachineConnection |
|  | 87 -> RpcEnumPerMachineConnections |
|  | 88 -> RpcXcvData |
|  | 89 -> RpcAddPrinterDriverEx |
|  | 90 -> RpcSplOpenPrinter |
|  | 91 -> RpcGetSpoolFileInfo |
|  | 92 -> RpcCommitSpoolData |
|  | 93 -> RpcGetSpoolFileInfo2 |
|  | 94 -> RpcCommitSpoolData2 |
|  | 95 -> RpcCloseSpoolFileHandle |
|  | 96 -> RpcFlushPrinter |
|  | 97 -> RpcSendRecvBidiData |
|  | 98 -> RpcAddDriverCatalog |
|  | 99 -> RpcAddPrinterConnection2 |
|  | 100 -> RpcInstallPrinterDriverFromPackage |
|  | 101 -> RpcUploadPrinterDriverPackage |
|  | 102 -> RpcGetCorePrinterDrivers |
|  | 103 -> RpcCorePrinterDriverInstalled |
|  | 104 -> RpcGetPrinterDriverPackagePath |
|  | 105 -> RpcDeletePrinterDriverPackage |
|  | 106 -> RpcFindCompatibleDriver |
|  | 107 -> RpcReportJobProcessingProgress |
|  | 108 -> RpcSetSpoolerPolicy |
|  | 109 -> RpcInternalGetPrinterDriver |
|  | 110 -> RpcGetJobNamedPropertyValue |
|  | 111 -> RpcSetJobNamedProperty |
|  | 112 -> RpcDeleteJobNamedProperty |
|  | 113 -> RpcEnumJobNamedProperties |
|  | 114 -> RpcCreateAppSandbox |
|  | 115 -> RpcGetUserPropertyBag |
|  | 116 -> RpcLogJobInfoForBranchOffice |
|  | RPC 0b6edbfa-4a24-4fc6-8a23-942b1eca65d1 (1.0) -- C:\\WINDOWS\\System32\\spoolsv.exe |
|  | 0 -> IRPCAsyncNotify\_RegisterClient |
|  | 1 -> IRPCAsyncNotify\_UnregisterClient |
|  | 2 -> IRPCAsyncNotify\_GetServerRefferal |
|  | 3 -> IRPCAsyncNotify\_GetNewChannel |
|  | 4 -> IRPCAsyncNotify\_GetNotificationSendResponse |
|  | 5 -> IRPCAsyncNotify\_GetNotification |
|  | 6 -> IRPCAsyncNotify\_CloseChannel |
|  | RPC ae33069b-a2a8-46ee-a235-ddfd339be281 (1.0) -- C:\\WINDOWS\\System32\\spoolsv.exe |
|  | 0 -> IRPCRemoteObject\_Create |
|  | 1 -> IRPCRemoteObject\_Delete |
|  | RPC 4a452661-8290-4b36-8fbe-7f4093a94978 (1.0) -- C:\\WINDOWS\\System32\\spoolsv.exe |
|  | 0 -> IRPCAsyncNotifyChannel\_CreateChannel |
|  | 1 -> IRPCAsyncNotifyChannel\_SendNotification |
|  | 2 -> IRPCAsyncNotifyChannel\_SendNotificationGetResponse |
|  | 3 -> IRPCAsyncNotifyChannel\_CloseChannel |
|  | RPC 76f03f96-cdfd-44fc-a22c-64950a001209 (1.0) -- C:\\WINDOWS\\System32\\spoolsv.exe |
|  | 0 -> RpcAsyncOpenPrinter |
|  | 1 -> RpcAsyncAddPrinter |
|  | 2 -> RpcAsyncSetJob |
|  | 3 -> RpcAsyncGetJob |
|  | 4 -> RpcAsyncEnumJobs |
|  | 5 -> RpcAsyncAddJob |
|  | 6 -> RpcAsyncScheduleJob |
|  | 7 -> RpcAsyncDeletePrinter |
|  | 8 -> RpcAsyncSetPrinter |
|  | 9 -> RpcAsyncGetPrinter |
|  | 10 -> RpcAsyncStartDocPrinter |
|  | 11 -> RpcAsyncStartPagePrinter |
|  | 12 -> RpcAsyncWritePrinter |
|  | 13 -> RpcAsyncEndPagePrinter |
|  | 14 -> RpcAsyncEndDocPrinter |
|  | 15 -> RpcAsyncAbortPrinter |
|  | 16 -> RpcAsyncGetPrinterData |
|  | 17 -> RpcAsyncGetPrinterDataEx |
|  | 18 -> RpcAsyncSetPrinterData |
|  | 19 -> RpcAsyncSetPrinterDataEx |
|  | 20 -> RpcAsyncClosePrinter |
|  | 21 -> RpcAsyncAddForm |
|  | 22 -> RpcAsyncDeleteForm |
|  | 23 -> RpcAsyncGetForm |
|  | 24 -> RpcAsyncSetForm |
|  | 25 -> RpcAsyncEnumForms |
|  | 26 -> RpcAsyncGetPrinterDriver |
|  | 27 -> RpcAsyncEnumPrinterData |
|  | 28 -> RpcAsyncEnumPrinterDataEx |
|  | 29 -> RpcAsyncEnumPrinterKey |
|  | 30 -> RpcAsyncDeletePrinterData |
|  | 31 -> RpcAsyncDeletePrinterDataEx |
|  | 32 -> RpcAsyncDeletePrinterKey |
|  | 33 -> RpcAsyncXcvData |
|  | 34 -> RpcAsyncSendRecvBidiData |
|  | 35 -> RpcAsyncCreatePrinterIC |
|  | 36 -> RpcAsyncPlayGdiScriptOnPrinterIC |
|  | 37 -> RpcAsyncDeletePrinterIC |
|  | 38 -> RpcAsyncEnumPrinters |
|  | 39 -> RpcAsyncAddPrinterDriver |
|  | 40 -> RpcAsyncEnumPrinterDrivers |
|  | 41 -> RpcAsyncGetPrinterDriverDirectory |
|  | 42 -> RpcAsyncDeletePrinterDriver |
|  | 43 -> RpcAsyncDeletePrinterDriverEx |
|  | 44 -> RpcAsyncAddPrintProcessor |
|  | 45 -> RpcAsyncEnumPrintProcessors |
|  | 46 -> RpcAsyncGetPrintProcessorDirectory |
|  | 47 -> RpcAsyncEnumPorts |
|  | 48 -> RpcAsyncEnumMonitors |
|  | 49 -> RpcAsyncAddPort |
|  | 50 -> RpcAsyncSetPort |
|  | 51 -> RpcAsyncAddMonitor |
|  | 52 -> RpcAsyncDeleteMonitor |
|  | 53 -> RpcAsyncDeletePrintProcessor |
|  | 54 -> RpcAsyncEnumPrintProcessorDatatypes |
|  | 55 -> RpcAsyncAddPerMachineConnection |
|  | 56 -> RpcAsyncDeletePerMachineConnection |
|  | 57 -> RpcAsyncEnumPerMachineConnections |
|  | 58 -> RpcSyncRegisterForRemoteNotifications |
|  | 59 -> RpcSyncUnRegisterForRemoteNotifications |
|  | 60 -> RpcSyncRefreshRemoteNotifications |
|  | 61 -> RpcAsyncGetRemoteNotifications |
|  | 62 -> RpcAsyncInstallPrinterDriverFromPackage |
|  | 63 -> RpcAsyncUploadPrinterDriverPackage |
|  | 64 -> RpcAsyncGetCorePrinterDrivers |
|  | 65 -> RpcAsyncCorePrinterDriverInstalled |
|  | 66 -> RpcAsyncGetPrinterDriverPackagePath |
|  | 67 -> RpcAsyncDeletePrinterDriverPackage |
|  | 68 -> RpcAsyncReadPrinter |
|  | 69 -> RpcAsyncResetPrinter |
|  | 70 -> RpcAsyncGetJobNamedPropertyValue |
|  | 71 -> RpcAsyncSetJobNamedProperty |
|  | 72 -> RpcAsyncDeleteJobNamedProperty |
|  | 73 -> RpcAsyncEnumJobNamedProperties |
|  | 74 -> RpcAsyncLogJobInfoForBranchOffice |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | Endpoints : |
|  | ncalrpc : LRPC-86933dfe29009d4e26 |
|  | ncacn\_np : \\pipe\\spoolss |
|  | ncacn\_ip\_tcp : 1541 |
|  | ncalrpc : OLEA8008E976AAC9D631AC104F46EEF |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3968 at 0x5e18208L> |
|  | 64 |
|  | \['DiagTrack'\] |
|  |  |
|  | Interfaces : |
|  | RPC 4c9dbf19-d39e-4bb9-90ee-8f7179b20283 (1.0) -- c:\\windows\\system32\\diagtrack.dll |
|  | 0 -> UtcApi\_IsScenarioActive |
|  | 1 -> UtcApi\_EscalateScenario |
|  | 2 -> UtcApi\_EscalateScenarioAsync |
|  | 3 -> UtcApi\_IsEscalationRunning |
|  | 4 -> UtcApi\_DownloadLatestSettingsForNamespace |
|  | 5 -> UtcApi\_DownloadLatestSettingsForNamespaceAsync |
|  | 6 -> UtcApi\_GetActiveScenarioList |
|  | 7 -> UtcApi\_ForceUpload |
|  | 8 -> UtcApi\_ResetUsageMetrics |
|  | 9 -> UtcApi\_IsTraceRunning |
|  | 10 -> UtcApi\_GetActiveTraceRuntime |
|  | 11 -> UtcApi\_GetKnownTraceList |
|  | 12 -> UtcApi\_DownloadLatestSettings |
|  | 13 -> UtcApi\_ReloadSettings |
|  | 14 -> UtcApi\_UpdateTimerConfiguration |
|  | 15 -> UtcApi\_ClearTimerConfiguration |
|  | 16 -> UtcApi\_GetNextScheduledFireTime |
|  | 17 -> UtcApi\_GetTimerConfiguration |
|  | 18 -> UtcApi\_GetCustomTraceList |
|  | 19 -> UtcApi\_StartCustomTrace |
|  | 20 -> UtcApi\_SnapCustomTrace |
|  | 21 -> UtcApi\_StopCustomTrace |
|  | 22 -> UtcApi\_EscalateScenario2 |
|  | 23 -> UtcApi\_EscalateScenarioAsync2 |
|  | 24 -> UtcApi\_GetActiveTraceInfo |
|  | 25 -> UtcApi\_EnableWERLocalReports |
|  | 26 -> UtcApi\_RestoreWERLocalReportsSettings |
|  | 27 -> UtcApi\_QueryWERLocalReportsEnabled |
|  | 28 -> UtcApi\_IsEscalationRunningEx |
|  | RPC fd8be72b-a9cd-4b2c-a9ca-4ded242fbe4d (1.0) -- c:\\windows\\system32\\diagtrack.dll |
|  | 0 -> UtcApi\_SendSyntheticTrigger |
|  | 1 -> UtcApi\_ChangeEtmPauseState |
|  | RPC 95095ec8-32ea-4eb0-a3e2-041f97b36168 (1.0) -- c:\\windows\\system32\\diagtrack.dll |
|  | 0 -> UtcTelemetryOptInApi\_SetTelemetryOptIn |
|  | RPC e38f5360-8572-473e-b696-1b46873beeab (1.0) -- c:\\windows\\system32\\diagtrack.dll |
|  | 0 -> UtcTenantApi\_RegisterTelemetryTenant |
|  | 1 -> UtcTenantApi\_UnregisterTelemetryTenant |
|  | 2 -> UtcTenantApi\_UpdateDailyUploadQuota |
|  | 3 -> UtcTenantApi\_ForceUpload |
|  | RPC d22895ef-aff4-42c5-a5b2-b14466d34ab4 (1.0) -- c:\\windows\\system32\\diagtrack.dll |
|  | 0 -> UtcEventTranscriptApi\_FetchTranscriptStats |
|  | 1 -> UtcEventTranscriptApi\_FetchTranscriptRecordsPage |
|  | 2 -> UtcEventTranscriptApi\_FetchTranscriptRecordPayload |
|  | 3 -> UtcEventTranscriptApi\_FetchKnownTags |
|  | 4 -> UtcEventTranscriptApi\_FetchEventTags |
|  | 5 -> UtcEventTranscriptApi\_IsSampledIn |
|  | 6 -> UtcEventTranscriptApi\_FetchTranscriptRecordsPage2 |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE ac7f26f2-feb7-5b2a-8ac4-345bc62caede (0.0) -- IMapView<HSTRING,HSTRING> |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | OLE 199e065c-8195-55da-9c10-8aeaf9ac1062 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenResponse |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | Endpoints : |
|  | ncalrpc : LRPC-cb86006467d51636ea |
|  | ncalrpc : OLE2D17161BF24248D2919A6BE91941 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "Sysmon.exe" pid 3980 at 0x5e18160L> |
|  | 64 |
|  | \['Sysmon'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLEBAF99B38F76E596FC5253FFF71AD |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "armsvc.exe" pid 3988 at 0x5e18978L> |
|  | 32 |
|  | \['AdobeARMservice'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RegSrvc.exe" pid 3996 at 0x5e180f0L> |
|  | 64 |
|  | \['RegSrvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE a9f62bbe-82f7-4e45-894d-f9497738d744 (0.0) -- IRegistry |
|  | Endpoints : |
|  | ncalrpc : OLEE12D1A851B1B8BE823B7A8B27ADC |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "MSIService.exe" pid 4004 at 0x5e18ac8L> |
|  | 32 |
|  | \['Micro Star SCM'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "KillerService.exe" pid 4012 at 0x5e18780L> |
|  | 64 |
|  | \['Killer Service V2'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "EvtEng.exe" pid 4020 at 0x5e18588L> |
|  | 64 |
|  | \['EvtEng'\] |
|  | \[!!\] Invalid rpcrt4 base: 0x1c4427e0000 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4036 at 0x5e186a0L> |
|  | 64 |
|  | \['TrkWks'\] |
|  |  |
|  | Interfaces : |
|  | RPC 300f3532-38cc-11d0-a3f0-0020af6b0add (1.2) -- c:\\windows\\system32\\trkwks.dll |
|  | 0 -> Stubold\_LnkMendLink |
|  | 1 -> StubGetFileTrackingInformation |
|  | 2 -> StubGetFileTrackingInformation |
|  | 3 -> StubLnkSetVolumeId |
|  | 4 -> StubGetFileTrackingInformation |
|  | 5 -> StubGetFileTrackingInformation |
|  | 6 -> StubGetFileTrackingInformation |
|  | 7 -> StubGetFileTrackingInformation |
|  | 8 -> StubLnkOnRestore |
|  | 9 -> StubLnkMendLink |
|  | 10 -> StubGetFileTrackingInformation |
|  | 11 -> StubGetFileTrackingInformation |
|  | 12 -> StubLnkSearchMachine |
|  | Endpoints : |
|  | ncacn\_np : \\pipe\\trkwks |
|  | ncalrpc : trkwks |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4028 at 0x5e18080L> |
|  | 64 |
|  | \['CryptSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 0d72a7d4-6148-11d1-b4aa-00c04fb66ea0 (1.0) -- c:\\windows\\system32\\cryptsvc.dll |
|  | 0 -> s\_SSCertProtectFunction |
|  | RPC 2579ff35-0ab0-4e5a-88fa-1d88c4e0cb92 (2.0) -- C:\\Windows\\System32\\crypttpmeksvc.dll |
|  | 0 -> s\_SSTpmEndorsementKeyGetInfo |
|  | 1 -> s\_SSTpmEndorsementKeyDecryptChallenge |
|  | 2 -> s\_SSTpmAttestationCapable |
|  | 3 -> s\_SSTpmGetAttestationForAik |
|  | 4 -> s\_SSTpmGetManufacturerInfo |
|  | RPC f50aac00-c7f3-428e-a022-a6b71bfb9d43 (2.0) -- C:\\Windows\\System32\\cryptcatsvc.dll |
|  | 0 -> s\_SSCatDBAddCatalog |
|  | 1 -> s\_SSCatDBDeleteCatalog |
|  | 2 -> s\_SSCatDBEnumCatalogs |
|  | 3 -> s\_SSCatDBPauseResumeService |
|  | 4 -> s\_SSCatDBRebuildDatabase |
|  | 5 -> s\_SSCatDBPrepareForCall |
|  | 6 -> s\_SSCatDBAddCatalog2 |
|  | 7 -> s\_SSCatDBSmartlockerDefenderCheck |
|  | RPC 1495a2be-b7a8-4299-9d3b-8825e5bcbfb9 (1.0) -- C:\\Windows\\System32\\webauthn.dll |
|  | 0 -> s\_SSCtapCommand |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : keysvc |
|  | ncalrpc : OLE114FFE22F3EBA1BDE1F447BE0387 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4044 at 0x5e18b38L> |
|  | 64 |
|  | \['DPS'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | RPC 714dc5c4-c5f6-466a-b037-a573c958031e (1.0) -- C:\\WINDOWS\\System32\\eeprov.dll |
|  | 0 -> PtRpcSetProcessTag |
|  | 1 -> PtRpcWriteTelemetry |
|  | OLE 71a5ec7f-f325-4376-9d94-622c372e256f (0.0) -- ISrumServer |
|  | Endpoints : |
|  | ncalrpc : OLE86DD29122D64C7B9ED08A237FEC1 |
|  | ncalrpc : LRPC-450da0932f82856e9c |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4052 at 0x5e18390L> |
|  | 64 |
|  | \['Winmgmt'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE f309ad18-d86a-11d0-a075-00c04fb68820 (0.0) -- IWbemLevel1Login |
|  | OLE d4781cd6-e5d3-44df-ad94-930efe48a887 (0.0) -- IWbemLoginClientID |
|  | OLE 9f6c78ef-fce5-42fa-abea-3e7df91921dc (0.0) -- IWbemLoginClientIDEx |
|  | OLE 9556dc99-828c-11cf-a37e-00aa003240c7 (0.0) -- IWbemServices |
|  | OLE 027947e1-d731-11ce-a357-000000000001 (0.0) -- IEnumWbemClassObject |
|  | OLE 1c1c45ee-4395-11d2-b60b-00104b703efd (0.0) -- IWbemFetchSmartEnum |
|  | OLE 423ec01e-2e35-11d2-b604-00104b703efd (0.0) -- IWbemWCOSmartEnum |
|  | OLE 21cd80a2-b305-4f37-9d4c-4534a8d9b568 (0.0) -- \_IWmiProviderFactory |
|  | OLE eb658b8a-7a64-4ddc-9b8d-a92610db0206 (0.0) -- \_IWmiProviderQuota |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE 41aa40e6-2fba-4e80-ade9-34306567206d (0.0) -- \_IWmiProviderSubsystemRegistrar |
|  | OLE 1be41571-91dd-11d1-aeb2-00c04fb68820 (0.0) -- IWbemProviderInitSink |
|  | OLE a359dec5-e813-4834-8a2a-ba7f1d777d76 (0.0) -- IWbemBackupRestoreEx |
|  | OLE 44aca675-e8fc-11d0-a07c-00c04fb68820 (0.0) -- IWbemCallResult |
|  | OLE 6c19be34-7500-11d1-ad94-00c04fd8fdff (0.0) -- IWbemFilterStub |
|  | OLE 6c19be32-7500-11d1-ad94-00c04fd8fdff (0.0) -- IWbemMetaData |
|  | OLE 755f9da6-7508-11d1-ad94-00c04fd8fdff (0.0) -- IWbemMultiTarget |
|  | OLE 37196b39-cccf-11d2-b35c-00105a1f8177 (0.0) -- IWbemFetchSmartMultiTarget |
|  | OLE 37196b38-cccf-11d2-b35c-00105a1f8177 (0.0) -- IWbemSmartMultiTarget |
|  | OLE 2c9273e0-1dc3-11d3-b364-00105a1f8177 (0.0) -- IWbemRefreshingServices |
|  | OLE e8107bdf-baaf-4c7c-bb5f-9d732e8d8f07 (0.0) -- \_IWmiProvSS |
|  | OLE b7b31df9-d515-11d3-a11c-00105a1f515a (0.0) -- IWbemShutdown |
|  | Endpoints : |
|  | ncalrpc : OLEE3815E632ABE47DA859BC28718EE |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4056 at 0x5e18940L> |
|  | 64 |
|  | \['SstpSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 78e5d322-59a2-4324-ae3f-8bc8de32bdfc (1.0) -- c:\\windows\\system32\\sstpsvc.dll |
|  | 0 -> SstpSvcSetConfig |
|  | 1 -> SstpSvcGetConfig |
|  | 2 -> SstpSvcCreateUpdateTenantGatewayMapping |
|  | 3 -> SstpSvcRemoveTenantGatewayMapping |
|  | 4 -> SstpSvcGetTenantGatewayMapping |
|  | Endpoints : |
|  | ncalrpc : SstpSvcRpc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4068 at 0x5e185f8L> |
|  | 64 |
|  | \['stisvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 8c7a6de0-788d-11d0-9edf-444553540000 (2.0) -- c:\\windows\\system32\\wiaservc.dll |
|  | 0 -> R\_StiApiGetVersion |
|  | 1 -> R\_StiApiEnableHwNotifications |
|  | 2 -> R\_StiApiGetHwNotificationState |
|  | 3 -> R\_StiApiLaunchApplication |
|  | 4 -> R\_StiApiOpenDevice |
|  | 5 -> R\_StiApiSubscribe |
|  | 6 -> R\_StiApiGetLastNotificationData |
|  | 7 -> R\_StiApiUnSubscribe |
|  | 8 -> R\_StiApiCloseDevice |
|  | 9 -> R\_StiApiLockDevice |
|  | 10 -> R\_StiApiUnlockDevice |
|  | 11 -> R\_WiaGetEventDataAsync |
|  | 12 -> OpenClientConnection |
|  | 13 -> CloseClientConnection |
|  | 14 -> RegisterUnregisterForEventNotification |
|  | 15 -> WiaGetRuntimetEventDataAsync |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | Endpoints : |
|  | ncalrpc : STI\_LRPC |
|  | ncalrpc : OLE1E06AB5CC832699E14B490289211 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4080 at 0x5e18198L> |
|  | 64 |
|  | \['WpnService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE df8e9480-ca73-448e-b8f0-da000f581428 (0.0) -- IWpnPlatform |
|  | OLE a6311d38-813c-46c8-9929-89d3b6e14515 (0.0) -- IConnectionManagerFactory |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 549bd355-eb18-42d4-866b-c8ed31b46e50 (0.0) -- IWpnInternalConnectionManager |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 78f5febc-30ff-450e-a2bf-911ff25df1df (0.0) -- IConnectionProvider |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE ae363a51-a0de-5827-80f4-961b407b40c2 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CWebAuthentication\_\_CUserHostIdentity |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE f655b052-348b-4ab0-947b-a7dafa44d404 (0.0) -- IWpnRegistrationEndpoint |
|  | OLE 7d85494e-d99e-493a-bf51-80d2c9feab49 (0.0) -- IWpnSystemRegistrationEndpoint |
|  | OLE 43c6b434-c1be-4ad2-af03-c0deaccebd1f (0.0) -- IBackgroundAccessStateChangeHandler |
|  | OLE 2a45cbbe-93a2-4f76-8c01-b6c2a1720f20 (0.0) -- IConnectionManagerCallbacks2 |
|  | OLE b755e6e0-b048-49cc-8911-11a041216f5f (0.0) -- IApplicationStateChangeHandler |
|  | OLE dcaee35a-508d-4419-9e56-50d658c2c812 (0.0) -- IWpnAppEndpoint |
|  | OLE dcb00007-570f-4a9b-8d69-199fdba5723b (0.0) -- INetworkConnectionEvents |
|  | OLE 71ba143f-598e-49d0-84eb-8febaedcc195 (0.0) -- INetworkStatusChangedEventHandler |
|  | Endpoints : |
|  | ncalrpc : OLE8B450DBE6E499F2775CE23B3DCD8 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4088 at 0x5e186d8L> |
|  | 64 |
|  | \['DeviceAssociationService'\] |
|  |  |
|  | Interfaces : |
|  | RPC 850cee52-3038-4277-b9b4-e05db8b2c35c (1.0) -- c:\\windows\\system32\\das.dll |
|  | 0 -> DasCreateAssociationContextForApp |
|  | 1 -> DasCreateAssociationContextFromOobBlob |
|  | 2 -> DasStartEnumCeremonies |
|  | 3 -> DasSelectCeremony |
|  | 4 -> DasStartReadCeremonyData |
|  | 5 -> DasStartWriteCeremonyData |
|  | 6 -> DasStartFinalize |
|  | 7 -> DasStartDeviceStatusNotification |
|  | 8 -> DasCloseAssociationContext |
|  | 9 -> DasStartRemoveAssociation |
|  | 10 -> DasCreateImportExportContext |
|  | 11 -> DasStartAepImport |
|  | 12 -> DasStartAepExport |
|  | 13 -> DasCloseImportExportContext |
|  | RPC a1d4eae7-39f8-4bca-8e72-832767f5082a (1.0) -- c:\\windows\\system32\\das.dll |
|  | 0 -> DasCreateInboundContext |
|  | 1 -> DasStartListenForInboundAssociations |
|  | 2 -> DasGetInboundAssociationResult |
|  | 3 -> DasCloseInboundContext |
|  | 4 -> DasRegisterForInboundAssociationsAppActivation |
|  | 5 -> DasGetInboundAssociationResultForAppActivation |
|  | RPC 2e7d4935-59d2-4312-a2c8-41900aa5495f (1.0) -- c:\\windows\\system32\\das.dll |
|  | 0 -> DasCreateChallengeContext |
|  | 1 -> DasStartChallengeDevicePresence |
|  | 2 -> DasCloseChallengeContext |
|  | RPC bd84cd86-9825-4376-813d-334c543f89b1 (1.0) -- c:\\windows\\system32\\das.dll |
|  | 0 -> RpcDevQueryCreate |
|  | 1 -> RpcDevQueryClose |
|  | 2 -> RpcDevQueryGetResult |
|  | 3 -> RpcDevPropertySet |
|  | RPC 5b665b9a-a086-4e26-ae24-96ab050b0ec3 (1.0) -- c:\\windows\\system32\\das.dll |
|  | 0 -> DasCreateAepStoreAep |
|  | 1 -> DasDeleteAepStoreAep |
|  | 2 -> DasSetAepStoreAepProperties |
|  | Endpoints : |
|  | ncalrpc : LRPC-84704d3fc3ab9c25d8 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "MsiTrueColorService.exe" pid 3116 at 0x5e18e48L> |
|  | 64 |
|  | \['MsiTrueColorService'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ZeroConfigService.exe" pid 4132 at 0x5e189b0L> |
|  | 64 |
|  | \['ZeroConfigService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE bd77db67-45a8-42dc-8d00-6dcf15f8377a (0.0) -- ISensorManager |
|  | Endpoints : |
|  | ncalrpc : OLEEC5AA2291C0108EE58764702415E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ibtsiva.exe" pid 4172 at 0x5e18be0L> |
|  | 64 |
|  | \['ibtsiva'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "IntelCpHDCPSvc.exe" pid 4180 at 0x5dd8550L> |
|  | 64 |
|  | \['cplspcon'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | Endpoints : |
|  | ncalrpc : OLE0B6250729CEE218F8C5E353295C5 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SecurityHealthService.exe" pid 4188 at 0x5dd8b00L> |
|  | 64 |
|  | \['SecurityHealthService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 06f64788-2882-425b-b5da-0f8d773ff9d8 (0.0) -- IDefenderShield |
|  | OLE 92cbb2de-4b91-4e74-8020-49d6e52f5860 (0.0) -- IThreatProtectionShield |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 722a338c-6e8e-4e72-ac27-1417fb0c81c2 (0.0) -- IWSCProductList |
|  | OLE 8c38232e-3a45-4a27-92b0-1a16a975f669 (0.0) -- IWscProduct |
|  | OLE f896ca54-fe09-4403-86d4-23cb488d81d8 (0.0) -- IWscProduct2 |
|  | OLE 536fca99-3e74-4d9e-9251-714917e6dac1 (0.0) -- INetworkProtectionShield |
|  | OLE f6e33e03-133b-490b-b93a-2130c6b5091d (0.0) -- IHardwareShield |
|  | OLE 02e11ab8-8308-4c55-9fbf-b0749cc5073e (0.0) -- IAppAndBrowserShield |
|  | OLE bb2c77c9-136b-424a-b75b-aa8b62088741 (0.0) -- IAccountProtectionShield |
|  | OLE 6fc78c64-0aa1-4c1f-bca8-b6cbe0b531eb (0.0) -- IOSProtectionShield |
|  | OLE 2a23ae77-9bfc-4b7b-8520-2d7b3e4a40b6 (0.0) -- \_\_x\_Windows\_CSecurityCenter\_CIWscBrokerManagerSink |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 6ee9fd33-75be-4cf0-bf70-3bb7b70cec6b (0.0) -- IDataProtectionShield |
|  | OLE d71bece8-17b8-4636-832c-d010d4f847f7 (0.0) -- IDashboard |
|  | OLE 18e4f715-debb-4a21-abc9-ff7b6f434703 (0.0) -- IHealthAdvisorShield |
|  | Endpoints : |
|  | ncalrpc : OLE0EF9B32CC4DD275914028903A53B |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4288 at 0x5dd8128L> |
|  | 64 |
|  | \['TapiSrv'\] |
|  |  |
|  | Interfaces : |
|  | RPC 2f5f6520-ca46-1067-b319-00dd010662da (1.0) -- c:\\windows\\system32\\tapisrv.dll |
|  | 0 -> ClientAttach |
|  | 1 -> ClientRequest |
|  | 2 -> ClientDetach |
|  | RPC 2f5f6521-cb55-1059-b446-00df0bce31db (1.0) -- c:\\windows\\system32\\unimdm.tsp |
|  | 0 -> notifSendFrame |
|  | Endpoints : |
|  | ncacn\_np : \\pipe\\tapsrv |
|  | ncalrpc : tapsrvlpc |
|  | ncalrpc : unimdmsvc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmnetdhcp.exe" pid 4560 at 0x5dd8cc0L> |
|  | 32 |
|  | \['VMnetDHCP'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmnat.exe" pid 4604 at 0x5dd8cf8L> |
|  | 32 |
|  | \['VMware NAT Service'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmware-authd.exe" pid 4716 at 0x5dd8ac8L> |
|  | 32 |
|  | \['VMAuthdService'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4728 at 0x5dd8b70L> |
|  | 64 |
|  | \['WdiServiceHost'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Unknown 00000000-0000-0000-0000-000000000000 (0.0) -- |
|  | Endpoints : |
|  | ncalrpc : OLE228909161DE369A89955A04C97E3 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4760 at 0x5dd83c8L> |
|  | 64 |
|  | \['LanmanServer'\] |
|  |  |
|  | Interfaces : |
|  | RPC 98716d03-89ac-44c7-bb8c-285824e51c4a (1.0) -- c:\\windows\\system32\\srvsvc.dll |
|  | 0 -> XsOpenPrinter |
|  | 1 -> XsClosePrinter |
|  | 2 -> XsAddJob |
|  | 3 -> XsScheduleJob |
|  | 4 -> XsProcessPnp |
|  | 5 -> XsProcDownLevelAPI |
|  | RPC 1a0d010f-1c33-432c-b0f5-8cf4e8053099 (1.0) -- c:\\windows\\system32\\srvsvc.dll |
|  | 0 -> IdSegRequestNextSequence |
|  | 1 -> IdSegRequestNodeInvalidation |
|  | RPC 4b324fc8-1670-01d3-1278-5a47bf6ee188 (3.0) -- c:\\windows\\system32\\srvsvc.dll |
|  | 0 -> NetrCharDevControl |
|  | 1 -> NetrCharDevControl |
|  | 2 -> NetrCharDevControl |
|  | 3 -> NetrCharDevControl |
|  | 4 -> NetrCharDevControl |
|  | 5 -> NetrCharDevControl |
|  | 6 -> NetrCharDevControl |
|  | 7 -> NetrCharDevControl |
|  | 8 -> NetrConnectionEnum |
|  | 9 -> NetrFileEnum |
|  | 10 -> NetrFileGetInfo |
|  | 11 -> NetrFileClose |
|  | 12 -> NetrSessionEnum |
|  | 13 -> NetrSessionDel |
|  | 14 -> NetrShareAdd |
|  | 15 -> NetrShareEnum |
|  | 16 -> NetrShareGetInfo |
|  | 17 -> NetrShareSetInfo |
|  | 18 -> NetrShareDel |
|  | 19 -> NetrShareDelSticky |
|  | 20 -> NetrShareCheck |
|  | 21 -> NetrServerGetInfo |
|  | 22 -> NetrServerSetInfo |
|  | 23 -> NetrServerDiskEnum |
|  | 24 -> NetrServerStatisticsGet |
|  | 25 -> NetrServerTransportAdd |
|  | 26 -> NetrServerTransportEnum |
|  | 27 -> NetrServerTransportDel |
|  | 28 -> NetrRemoteTOD |
|  | 29 -> I\_NetrServerSetServiceBits |
|  | 30 -> NetprPathType |
|  | 31 -> NetprPathCanonicalize |
|  | 32 -> NetprPathCompare |
|  | 33 -> NetprNameValidate |
|  | 34 -> NetprNameCanonicalize |
|  | 35 -> NetprNameCompare |
|  | 36 -> NetrShareEnumSticky |
|  | 37 -> NetrShareDelStart |
|  | 38 -> NetrShareDelCommit |
|  | 39 -> NetrpGetFileSecurity |
|  | 40 -> NetrpSetFileSecurity |
|  | 41 -> NetrServerTransportAddEx |
|  | 42 -> I\_NetrServerSetServiceBitsEx |
|  | 43 -> NetrDfsGetVersion |
|  | 44 -> NetrCharDevControl |
|  | 45 -> NetrCharDevControl |
|  | 46 -> NetrCharDevControl |
|  | 47 -> NetrCharDevControl |
|  | 48 -> NetrCharDevControl |
|  | 49 -> NetrCharDevControl |
|  | 50 -> NetrCharDevControl |
|  | 51 -> NetrCharDevControl |
|  | 52 -> NetrCharDevControl |
|  | 53 -> NetrServerTransportDelEx |
|  | 54 -> NetrServerAliasAdd |
|  | 55 -> NetrServerAliasEnum |
|  | 56 -> NetrServerAliasDel |
|  | 57 -> NetrShareDelEx |
|  | 58 -> LocalrSessionEnum |
|  | 59 -> LocalrSessionGetInfo |
|  | 60 -> LocalrSessionDel |
|  | 61 -> LocalrFileEnum |
|  | 62 -> LocalrFileGetInfo |
|  | 63 -> LocalrFileClose |
|  | 64 -> LocalrShareEnum |
|  | 65 -> LocalrShareGetInfo |
|  | 66 -> LocalrShareSetInfo |
|  | 67 -> LocalrShareAdd |
|  | 68 -> LocalrShareDelEx |
|  | 69 -> LocalrAliasGet |
|  | 70 -> NetrServerTransportAddForInstance |
|  | 71 -> NetrServerTransportDelForInstance |
|  | Endpoints : |
|  | ncalrpc : LRPC-f4d5bafb48cb6d0b45 |
|  | ncacn\_np : \\PIPE\\srvsvc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmms.exe" pid 4780 at 0x5dd88d0L> |
|  | 64 |
|  | \['vmms'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 9556dc99-828c-11cf-a37e-00aa003240c7 (0.0) -- IWbemServices |
|  | OLE f50a28cf-5c9c-4f7e-9d80-e25e16e18c59 (0.0) -- Internal\_IWbemServices |
|  | OLE 1be41572-91dd-11d1-aeb2-00c04fb68820 (0.0) -- IWbemProviderInit |
|  | OLE 6919dd07-1637-4611-a8a7-c16fac5b2d53 (0.0) -- Internal\_IWbemProviderInit |
|  | OLE fec1b0ac-5808-4033-a915-c0185934581e (0.0) -- \_IWmiProviderSite |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE e245105b-b06e-11d0-ad61-00c04fd8fdff (0.0) -- IWbemEventProvider |
|  | OLE fd450835-cf1b-4c87-9fd2-5e0d42fde081 (0.0) -- Internal\_IWbemEventProvider |
|  | OLE 580acaf8-fa1c-11d0-ad72-00c04fd8fdff (0.0) -- IWbemEventProviderQuerySink |
|  | OLE 8a0dc377-a9d3-41cb-bd69-ae1fdaf2dc68 (0.0) -- Internal\_IWbemEventProviderQuerySink |
|  | OLE 631f7d96-d993-11d2-b339-00105a1f4aaf (0.0) -- IWbemEventProviderSecurity |
|  | OLE df2373f5-efb2-475c-ad58-3102d61967d4 (0.0) -- Internal\_IWbemEventProviderSecurity |
|  | Endpoints : |
|  | ncalrpc : OLE6EE3BF241503FC06C6B76236FBA0 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4796 at 0x5dd8a90L> |
|  | 64 |
|  | \['iphlpsvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 552d076a-cb29-4e44-8b6a-d15e59e2c0af (1.0) -- c:\\windows\\system32\\iphlpsvc.dll |
|  | 0 -> IpTransitionProtocolApplyConfigChanges |
|  | 1 -> IpTransitionProtocolApplyConfigChangesEx |
|  | RPC ecbdb051-f208-46b9-8c8b-648d9d3f3944 (1.0) -- c:\\windows\\system32\\iphlpsvc.dll |
|  | 0 -> RefreshTeredoState |
|  | 1 -> ResetDisabledComponentsForTeredo |
|  | RPC 1fff8faa-ec23-4e3f-a8ce-4b2f8707e636 (1.0) -- c:\\windows\\system32\\iphlpsvc.dll |
|  | 0 -> TeredoCreateConsumerHandle |
|  | 1 -> TeredoCloseConsumerHandle |
|  | RPC 2e6035b2-e8f1-41a7-a044-656b439c4c34 (1.0) -- C:\\WINDOWS\\system32\\httpprxm.dll |
|  | 0 -> ProxyMgrProviderRegisterForEventNotification |
|  | 1 -> ProxyMgrProviderUnregisterEventNotification |
|  | 2 -> ProxyMgrProviderGetNotification |
|  | 3 -> ProxyMgrGetProxyEventInformation |
|  | 4 -> ProxyMgrSetProxyConfiguration |
|  | 5 -> ProxyMgrSetProxyCredentials |
|  | RPC c36be077-e14b-4fe9-8abc-e856ef4f048b (1.0) -- C:\\WINDOWS\\system32\\httpprxm.dll |
|  | 0 -> RpcSrvProxyMgrClientRegisterForEventNotification |
|  | 1 -> RpcSrvProxyMgrClientGetNotification |
|  | 2 -> RpcSrvProxyMgrClientUnregisterEventNotification |
|  | 3 -> RpcSrvProxyMgrClientGetProxyForUrl |
|  | 4 -> RpcSrvProxyMgrClientGetProxyCredentials |
|  | 5 -> RpcSrvProxyMgrClientGetAllProxiesForUrl |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | RPC c49a5a70-8a7f-4e70-ba16-1e8f1f193ef1 (1.0) -- C:\\WINDOWS\\system32\\adhsvc.dll |
|  | 0 -> Rpc\_AdhEngineOpen |
|  | 1 -> Rpc\_AdhEngineClose |
|  | 2 -> Rpc\_AdhStatusEventSubscribe |
|  | 3 -> Rpc\_AdhStatusEventSubscriptionGetLastEvent |
|  | 4 -> Rpc\_AdhStatusEventUnsubscribe |
|  | 5 -> Rpc\_AdhGetConfig |
|  | 6 -> Rpc\_AdhGetEvidenceCollectorResult |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | Endpoints : |
|  | ncalrpc : LRPC-468ba3aa8e54f640a8 |
|  | ncalrpc : TeredoDiagnostics |
|  | ncalrpc : TeredoControl |
|  | ncalrpc : OLE8D3C864969A59979DAAEDA313AF1 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmware-usbarbitrator64.exe" pid 4808 at 0x5dd8f28L> |
|  | 64 |
|  | \['VMUSBArbService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLE82060BD201B177BF72B77E7B995C |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "IntelCpHeciSvc.exe" pid 4840 at 0x5dd8438L> |
|  | 64 |
|  | \['cphs'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE a91e0bdd-79b0-42c5-a3a0-5be434329577 (0.0) -- ICphsSession |
|  | Endpoints : |
|  | ncalrpc : OLEA622594D2CCC1AEF80FFD40CB4F1 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 4948 at 0x5dd8518L> |
|  | 64 |
|  | \['RasMan'\] |
|  |  |
|  | Interfaces : |
|  | RPC 20610036-fa22-11cf-9823-00a0c911e5df (1.0) -- c:\\windows\\system32\\rasmans.dll |
|  | 0 -> RasRpcPortEnum |
|  | 1 -> RasRpcDeviceEnum |
|  | 2 -> RasRpcGetDevConfig |
|  | 3 -> RasRpcPortGetInfo |
|  | 4 -> RasRpcEnumConnections |
|  | 5 -> RasRpcDeleteEntry |
|  | 6 -> RasRpcGetErrorString |
|  | 7 -> RasRpcGetCountryInfo |
|  | 8 -> RasRpcGetInstalledProtocols |
|  | 9 -> RasRpcGetUserPreferences |
|  | 10 -> RasRpcSetUserPreferences |
|  | 11 -> RasRpcGetSystemDirectory |
|  | 12 -> RasRpcSubmitRequest |
|  | 13 -> RasRpcSubmitRequestLocal |
|  | 14 -> RasRpcGetInstalledProtocolsEx |
|  | 15 -> RasRpcGetVersion |
|  | RPC 81ee95a8-882e-4615-888a-53344ca149e4 (1.0) -- C:\\WINDOWS\\system32\\vpnike.dll |
|  | 0 -> VpnikeCreateTunnel |
|  | 1 -> VpnikeUpdateTunnel |
|  | 2 -> VpnikeCloseTunnel |
|  | 3 -> VpnikeGetCfgPayloadRequest |
|  | 4 -> VpnikeProcessCfgPayloadReply |
|  | 5 -> VpnikeProcessCfgPayloadRequest |
|  | 6 -> VpnikeNewRasIncomingCall |
|  | 7 -> VpnikeGetTsRequest |
|  | 8 -> VpnikeProcessTsReply |
|  | 9 -> VpnikeProcessTsRequest |
|  | 10 -> VpnikeRemoveTs |
|  | 11 -> VpnikeGetServerEapAuthRequestPacket |
|  | 12 -> VpnikeProcessEapAuthPacket |
|  | 13 -> VpnikeQueryEapAuthAttributes |
|  | 14 -> VpnIkeProcessAdditionalAddressNotification |
|  | 15 -> VpnikeCreateIDPayload |
|  | 16 -> VpnikeTunnelAuthDone |
|  | 17 -> VpnikeCreateOptionalIDrPayload |
|  | RPC 650a7e26-eab8-5533-ce43-9c1dfce11511 (1.0) -- C:\\WINDOWS\\system32\\rascustom.dll |
|  | 0 -> Rpc\_VpnProtEngOpen |
|  | 1 -> Rpc\_VpnProtEngClose |
|  | 2 -> Rpc\_VpnProtEngEventSubscribe |
|  | 3 -> Rpc\_VpnProtEngEventSubscriptionGetLastEvent |
|  | 4 -> Rpc\_VpnProtEngEventUnsubscribe |
|  | 5 -> Rpc\_VpnProtEngSendGetCredentialsRequest |
|  | 6 -> Rpc\_VpnProtEngSendNegotiatingNetworkRequest |
|  | 7 -> Rpc\_VpnProtEngSendInterfaceCreateRequest |
|  | 8 -> Rpc\_VpnProtEngSendInterfaceDestroyRequest |
|  | 9 -> Rpc\_VpnProtEngSendConnectError |
|  | 10 -> Rpc\_VpnProtEngGetConfiguration |
|  | 11 -> Rpc\_VpnProtEngGetBestCostInterface |
|  | 12 -> Rpc\_VpnProtEngGetStatementOfHealth |
|  | 13 -> Rpc\_VpnProtEngSetKeepAliveFrequencyOverrideRequest |
|  | 14 -> Rpc\_VpnProtEngSendGetCustomPromptRequest |
|  | 15 -> Rpc\_VpnProtEngSendGetCertificateConsentBlankUiRequest |
|  | 16 -> Rpc\_VpnProtEngSendCloseCertificateConsentBlankUiRequest |
|  | 17 -> Rpc\_VpnProtEngPluginInstall |
|  | 18 -> Rpc\_VpnProtEngPluginUninstall |
|  | 19 -> Rpc\_VpnProtEngSetCostNetworkSettings |
|  | 20 -> Rpc\_VpnProtEngGetCostNetworkSettings |
|  | 21 -> Rpc\_VpnProtEngExecuteAndCaptureLogs |
|  | 22 -> Rpc\_VpnProtEngGetInterface |
|  | 23 -> Rpc\_VpnProtEngPluginEnumerate |
|  | 24 -> Rpc\_VpnProtEngAddProfileFromXml |
|  | 25 -> Rpc\_VpnProtEngWinRtConnect |
|  | 26 -> Rpc\_VpnProtEngWinRtDisconnect |
|  | 27 -> Rpc\_VpnProtEngWinRtEnumerate |
|  | 28 -> Rpc\_VpnProtEngWinRtGetEapBlob |
|  | 29 -> Rpc\_VpnProtEngWinRtGetEapXml |
|  | 30 -> Rpc\_VpnProtEngWinRtGetMoniker |
|  | 31 -> Rpc\_VpnProtEngWinRtGetConnectionStatus |
|  | 32 -> Rpc\_VpnProtEngWinRtUpdateRegistryProfileList |
|  | 33 -> Rpc\_VpnProtEngGetProxyForUrlAndSingleSessionDeviceUser |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | Endpoints : |
|  | ncacn\_np : \\PIPE\\ROUTER |
|  | ncalrpc : RasmanLrpc |
|  | ncalrpc : VpnikeRpc |
|  | ncalrpc : LRPC-ac14c3be97f6e49e09 |
|  | ncalrpc : OLEE9C19143A346A740C8B1E9E8B3E7 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "dasHost.exe" pid 5088 at 0x5dd8978L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC eeee008d-5c99-4e4b-861b-547a26e8abd0 (1.0) -- C:\\WINDOWS\\system32\\dashost.exe |
|  | 0 -> DasHostLoadProvider |
|  | 1 -> DasHostSetDasProcessHandle |
|  | 2 -> DasHostUnloadProvider |
|  | 3 -> DasHostShutdown |
|  | 4 -> DasHostCreateProviderQuery |
|  | 5 -> DasHostCloseQuery |
|  | 6 -> DasHostProviderQueryGetResult |
|  | 7 -> DasHostCreateAssociationContext |
|  | 8 -> DasHostCreateAssociationContextFromOobBlob |
|  | 9 -> DasHostStartEnumCeremonies |
|  | 10 -> DasHostSelectCeremony |
|  | 11 -> DasHostStartReadCeremonyData |
|  | 12 -> DasHostStartWriteCeremonyData |
|  | 13 -> DasHostStartFinalize |
|  | 14 -> DasHostDeviceStatusNotification |
|  | 15 -> DasHostStartRemoveAssociation |
|  | 16 -> DasHostCloseAssociationContext |
|  | 17 -> DasHostCreateDevnodeManagementContext |
|  | 18 -> DasHostStartDevnodeManagement |
|  | 19 -> DasHostEndDevnodeManagement |
|  | 20 -> DasHostPickupDevnodeManagementOperation |
|  | 21 -> DasHostGetDevnodeFactoryOperationInfo |
|  | 22 -> DasHostCompleteDevnodeFactoryOperation |
|  | 23 -> DasHostGetDevnodeOperationInfo |
|  | 24 -> DasHostCompleteDevnodeOperation |
|  | 25 -> DasHostCloseDevnodeManagementContext |
|  | 26 -> DasHostCreateChallengeContext |
|  | 27 -> DasHostStartChallengeDevicePresence |
|  | 28 -> DasHostCloseChallengeContext |
|  | 29 -> DasHostCreateImportExportContext |
|  | 30 -> DasHostStartImport |
|  | 31 -> DasHostStartExport |
|  | 32 -> DasHostCloseImportExportContext |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : DasHostCC{8d6a4f7a-48c7-4547-be8ba9c99a2bab25} |
|  | ncalrpc : OLED67D46C9255848EC676551EAFAA7 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 5932 at 0x5dd8080L> |
|  | 64 |
|  | \['PolicyAgent'\] |
|  |  |
|  | Interfaces : |
|  | RPC 12345678-1234-abcd-ef00-0123456789ab (1.0) -- c:\\windows\\system32\\ipsecsvc.dll |
|  | 0 -> RpcAddTransportFilter |
|  | 1 -> RpcDeleteTransportFilter |
|  | 2 -> RpcEnumTransportFilters |
|  | 3 -> RpcSetTransportFilter |
|  | 4 -> RpcGetTransportFilter |
|  | 5 -> RpcAddQMPolicy |
|  | 6 -> RpcDeleteQMPolicy |
|  | 7 -> RpcEnumQMPolicies |
|  | 8 -> RpcSetQMPolicy |
|  | 9 -> RpcGetQMPolicy |
|  | 10 -> RpcAddMMPolicy |
|  | 11 -> RpcDeleteMMPolicy |
|  | 12 -> RpcEnumMMPolicies |
|  | 13 -> RpcSetMMPolicy |
|  | 14 -> RpcGetMMPolicy |
|  | 15 -> RpcAddMMFilter |
|  | 16 -> RpcDeleteMMFilter |
|  | 17 -> RpcEnumMMFilters |
|  | 18 -> RpcSetMMFilter |
|  | 19 -> RpcGetMMFilter |
|  | 20 -> RpcMatchMMFilter |
|  | 21 -> RpcMatchTransportFilter |
|  | 22 -> RpcGetQMPolicyByID |
|  | 23 -> RpcGetMMPolicyByID |
|  | 24 -> RpcAddMMAuthMethods |
|  | 25 -> RpcDeleteMMAuthMethods |
|  | 26 -> RpcEnumMMAuthMethods |
|  | 27 -> RpcSetMMAuthMethods |
|  | 28 -> RpcGetMMAuthMethods |
|  | 29 -> RpcAddSAs |
|  | 30 -> RpcAddSAs |
|  | 31 -> RpcAddSAs |
|  | 32 -> RpcEnumMMSAs |
|  | 33 -> RpcDeleteMMSAs |
|  | 34 -> RpcDeleteQMSAs |
|  | 35 -> RpcQueryIKEStatistics |
|  | 36 -> RpcAddSAs |
|  | 37 -> RpcAddSAs |
|  | 38 -> RpcAddSAs |
|  | 39 -> RpcQueryIPSecStatistics |
|  | 40 -> RpcEnumQMSAs |
|  | 41 -> RpcAddTunnelFilter |
|  | 42 -> RpcDeleteTunnelFilter |
|  | 43 -> RpcEnumTunnelFilters |
|  | 44 -> RpcSetTunnelFilter |
|  | 45 -> RpcGetTunnelFilter |
|  | 46 -> RpcMatchTunnelFilter |
|  | 47 -> RpcOpenMMFilterHandle |
|  | 48 -> RpcCloseMMFilterHandle |
|  | 49 -> RpcOpenTransportFilterHandle |
|  | 50 -> RpcCloseTransportFilterHandle |
|  | 51 -> RpcOpenTunnelFilterHandle |
|  | 52 -> RpcCloseTunnelFilterHandle |
|  | 53 -> RpcEnumIpsecInterfaces |
|  | 54 -> RpcAddSAs |
|  | 55 -> RpcSetConfigurationVariables |
|  | 56 -> RpcGetConfigurationVariables |
|  | 57 -> RpcQuerySpdPolicyState |
|  | 58 -> RpcAddMMFilterEx |
|  | 59 -> RpcEnumMMFiltersEx |
|  | 60 -> RpcSetMMFilterEx |
|  | 61 -> RpcGetMMFilterEx |
|  | 62 -> RpcMatchMMFilterEx |
|  | 63 -> RpcOpenMMFilterHandleEx |
|  | 64 -> RpcAddTransportFilterEx |
|  | 65 -> RpcEnumTransportFiltersEx |
|  | 66 -> RpcSetTransportFilterEx |
|  | 67 -> RpcGetTransportFilterEx |
|  | 68 -> RpcMatchTransportFilterEx |
|  | 69 -> RpcOpenTransportFilterHandleEx |
|  | 70 -> RpcQueryRemoteFWRunning |
|  | Endpoints : |
|  | ncalrpc : ipsec |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 5940 at 0x5dd8c50L> |
|  | 64 |
|  | \['SSDPSRV'\] |
|  |  |
|  | Interfaces : |
|  | RPC 4b112204-0e19-11d3-b42b-0000f81feb9f (1.0) -- c:\\windows\\system32\\ssdpsrv.dll |
|  | 0 -> \_SSDPOpenRpc |
|  | 1 -> \_SSDPCloseRpc |
|  | 2 -> RegisterServiceExRpc |
|  | 3 -> \_DeregisterServiceRpc |
|  | 4 -> CleanupCacheRpc |
|  | 5 -> BeginSearchRpc |
|  | 6 -> GetSearchNotificationRpc |
|  | 7 -> CancelSearchRpc |
|  | 8 -> CloseSearchRpc |
|  | 9 -> EnableNotificationRpc |
|  | 10 -> \_InitializeSyncHandle |
|  | 11 -> \_RemoveSyncHandle |
|  | 12 -> RegisterNotificationRpc |
|  | 13 -> RegisterNotificationAsyncRpc |
|  | 14 -> \_GetNotificationRpc |
|  | 15 -> \_WakeupGetNotificationRpc |
|  | 16 -> DeregisterNotificationRpc |
|  | 17 -> SetICSInterfaces |
|  | 18 -> SetICSOff |
|  | 19 -> EnableFirewallRuleRpc |
|  | 20 -> DisableFirewallRuleRpc |
|  | Endpoints : |
|  | ncalrpc : LRPC-5e723fcc225d082187 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "WmiPrvSE.exe" pid 5452 at 0x5dd8588L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE b7b31df9-d515-11d3-a11c-00105a1f515a (0.0) -- IWbemShutdown |
|  | OLE 07435309-d440-41b7-83f3-eb82db6c622f (0.0) -- \_IWmiProviderHost |
|  | OLE 21cd80a2-b305-4f37-9d4c-4534a8d9b568 (0.0) -- \_IWmiProviderFactory |
|  | OLE 06413d98-405c-4a5a-8d6f-19b8b7c6acf7 (0.0) -- \_IWmiProviderFactoryInitialize |
|  | OLE e245105b-b06e-11d0-ad61-00c04fd8fdff (0.0) -- IWbemEventProvider |
|  | OLE fd450835-cf1b-4c87-9fd2-5e0d42fde081 (0.0) -- Internal\_IWbemEventProvider |
|  | OLE 6b3fc272-bf37-4968-933a-6df9222a2607 (0.0) -- \_IWmiProviderConfiguration |
|  | OLE 0fc8c622-1728-4149-a57f-ad19d0970710 (0.0) -- Internal\_IWmiProviderConfiguration |
|  | OLE fec1b0ac-5808-4033-a915-c0185934581e (0.0) -- \_IWmiProviderSite |
|  | OLE 60e512d4-c47b-11d2-b338-00105a1f4aaf (0.0) -- IWbemFilterProxy |
|  | OLE 9556dc99-828c-11cf-a37e-00aa003240c7 (0.0) -- IWbemServices |
|  | OLE f50a28cf-5c9c-4f7e-9d80-e25e16e18c59 (0.0) -- Internal\_IWbemServices |
|  | OLE 580acaf8-fa1c-11d0-ad72-00c04fd8fdff (0.0) -- IWbemEventProviderQuerySink |
|  | OLE 8a0dc377-a9d3-41cb-bd69-ae1fdaf2dc68 (0.0) -- Internal\_IWbemEventProviderQuerySink |
|  | OLE 631f7d96-d993-11d2-b339-00105a1f4aaf (0.0) -- IWbemEventProviderSecurity |
|  | OLE df2373f5-efb2-475c-ad58-3102d61967d4 (0.0) -- Internal\_IWbemEventProviderSecurity |
|  | Endpoints : |
|  | ncalrpc : OLE8F3A7725171108B9DC2243028771 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmware-hostd.exe" pid 6200 at 0x5dd8a20L> |
|  | 32 |
|  | \['VMwareHostd'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "vmcompute.exe" pid 6604 at 0x5dd84e0L> |
|  | 64 |
|  | \['vmcompute'\] |
|  |  |
|  | Interfaces : |
|  | RPC e7a216af-1ec1-447f-8d3f-a87278db564d (1.0) -- C:\\WINDOWS\\system32\\vmcompute.exe |
|  | 0 -> HcsRpc\_EnumerateSystems |
|  | 1 -> HcsRpc\_CreateSystem |
|  | 2 -> HcsRpc\_OpenSystem |
|  | 3 -> HcsRpc\_StartSystem |
|  | 4 -> HcsRpc\_ShutdownSystem |
|  | 5 -> HcsRpc\_TerminateSystem |
|  | 6 -> HcsRpc\_PauseSystem |
|  | 7 -> HcsRpc\_ResumeSystem |
|  | 8 -> HcsRpc\_SaveSystem |
|  | 9 -> HcsRpc\_GetSystemProperties |
|  | 10 -> HcsRpc\_ModifySystem |
|  | 11 -> HcsRpc\_AddSystemResource |
|  | 12 -> HcsRpc\_ModifySystemResource |
|  | 13 -> HcsRpc\_RemoveSystemResource |
|  | 14 -> HcsRpc\_RegisterSystemNotifications |
|  | 15 -> HcsRpc\_UnregisterSystemNotifications |
|  | 16 -> HcsRpc\_QuerySystemNotification |
|  | 17 -> HcsRpc\_CloseSystem |
|  | 18 -> HcsRpc\_CreateProcess |
|  | 19 -> HcsRpc\_OpenProcess |
|  | 20 -> HcsRpc\_SignalProcess |
|  | 21 -> HcsRpc\_GetProcessInfo |
|  | 22 -> HcsRpc\_GetProcessProperties |
|  | 23 -> HcsRpc\_ModifyProcess |
|  | 24 -> HcsRpc\_RegisterProcessNotifications |
|  | 25 -> HcsRpc\_UnregisterProcessNotifications |
|  | 26 -> HcsRpc\_QueryProcessNotification |
|  | 27 -> HcsRpc\_CloseProcess |
|  | 28 -> HcsRpc\_GetServiceProperties |
|  | 29 -> HcsRpc\_ModifyServiceSettings |
|  | Endpoints : |
|  | ncalrpc : LRPC-4068c498fbc5b167b0 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 6888 at 0x5dd8b38L> |
|  | 64 |
|  | \['hns'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 0b43d888-341a-4d8c-8c3a-f9ef5045df01 (0.0) -- IHnsApi |
|  | OLE 2f81081e-c2ab-40ca-8e3c-af6022e8aff4 (0.0) -- IVmsManagementEvents |
|  | Endpoints : |
|  | ncalrpc : OLE7F16549350AD37A0B0FAA997C469 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 7048 at 0x5dd8940L> |
|  | 64 |
|  | \['PcaSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 0767a036-0d22-48aa-ba69-b619480f38cb (1.0) -- c:\\windows\\system32\\pcasvc.dll |
|  | 0 -> RAiMonitorProcess |
|  | 1 -> RAiSendToService |
|  | 2 -> RAiNotifyMsiInstall |
|  | 3 -> RAiLinkChildToParent |
|  | 4 -> RAiGetFileInfoFromPath |
|  | Endpoints : |
|  | ncalrpc : LRPC-3dbea9ac2075148991 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 7148 at 0x5dd8dd8L> |
|  | 64 |
|  | \['SharedAccess'\] |
|  |  |
|  | Interfaces : |
|  | RPC e64b9aee-f372-4312-9a14-8f1502b5c8e3 (1.0) -- c:\\windows\\system32\\ipnathlp.dll |
|  | 0 -> IpNatHlpRpcServerGetConnectedDevices |
|  | 1 -> IpNatHlpRpcServerStartSharing |
|  | 2 -> IpNatHlpRpcServerStopSharing |
|  | 3 -> IpNatHlpRpcServerStartDhcpServer |
|  | 4 -> IpNatHlpRpcServerStopDhcpServer |
|  | 5 -> IpNatHlpRpcServerUpdateSharingSettingsFromStorage |
|  | 6 -> V2IpNatHlpRpcServerStartSharingByInternalPrefix |
|  | 7 -> V2IpNatHlpRpcServerStopSharingByInternalPrefix |
|  | 8 -> V2IpNatHlpRpcServerStartDhcpServer |
|  | 9 -> V2IpNatHlpRpcServerStopDhcpServer |
|  | 10 -> V2IpNatHlpRpcServerStartDnsServer |
|  | 11 -> V2IpNatHlpRpcServerStopDnsServer |
|  | 12 -> V2IpNatHlpRpcServerEnumDhcpState |
|  | 13 -> V2IpNatHlpRpcServerEnumDnsState |
|  | 14 -> V2IpNatHlpRpcServerCreateStaticMapping |
|  | 15 -> V2IpNatHlpRpcServerDeleteStaticMapping |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-50c214ea8705fbab3a |
|  | ncalrpc : OLE2DC3BB3BCF471E67CEF1904EADCD |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3436 at 0x5dd8f60L> |
|  | 64 |
|  | \['nvagent'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE 2f81081e-c2ab-40ca-8e3c-af6022e8aff4 (0.0) -- IVmsManagementEvents |
|  | Endpoints : |
|  | ncalrpc : OLEECAF479F3B278CDDE15C4AEE09C2 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "unsecapp.exe" pid 6480 at 0x5dd8d68L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 1cfaba8c-1523-11d1-ad79-00c04fd8fdff (0.0) -- IUnsecuredApartment |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE 04963311-c399-408e-ad51-05d01506eed0 (0.0) -- \_IWmiObjectSinkSecurity |
|  | Endpoints : |
|  | ncalrpc : OLED96340CDD9CF4DC31A6998552CC3 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "PresentationFontCache.exe" pid 7240 at 0x5dd8c88L> |
|  | 64 |
|  | \['FontCache3.0.0.0'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 6992 at 0x5dd86d8L> |
|  | 64 |
|  | \['TabletInputService'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLE9AA19BF67BE29A42A2636603A5A6 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 8312 at 0x5dd8d30L> |
|  | 64 |
|  | \['Appinfo'\] |
|  |  |
|  | Interfaces : |
|  | RPC 0497b57d-2e66-424f-a0c6-157cd5d41700 (1.0) -- c:\\windows\\system32\\appinfo.dll |
|  | 0 -> RAiLaunchProcessWithIdentity |
|  | 1 -> RAiGetPackageActivationToken |
|  | 2 -> RAiFinishPackageActivation |
|  | 3 -> RAiEnsurePackageShutdown |
|  | RPC 201ef99a-7fa0-444c-9399-19ba84f12a1a (1.0) -- c:\\windows\\system32\\appinfo.dll |
|  | 0 -> RAiLaunchAdminProcess |
|  | 1 -> RAiProcessRunOnce |
|  | 2 -> RAiLogonWithSmartCardCreds |
|  | 3 -> RAiOverrideDesktopPromptPolicy |
|  | 4 -> RAiDisableElevationForSession |
|  | 5 -> RAiEnableElevationForSession |
|  | 6 -> RAiForceElevationPromptForCOM |
|  | RPC 5f54ce7d-5b79-4175-8584-cb65313a0e98 (1.0) -- c:\\windows\\system32\\appinfo.dll |
|  | 0 -> RAiGetTokenForCOM |
|  | RPC fd7a0523-dc70-43dd-9b2e-9c5ed48225b1 (1.0) -- c:\\windows\\system32\\appinfo.dll |
|  | 0 -> RAiGetTokenForMSI |
|  | RPC 58e604e8-9adb-4d2e-a464-3b0683fb1480 (1.0) -- c:\\windows\\system32\\appinfo.dll |
|  | 0 -> RAiGetTokenForAxIS |
|  | Endpoints : |
|  | ncalrpc : LRPC-2c336e65039e36772a |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 8844 at 0x5dd8f98L> |
|  | 64 |
|  | \['TokenBroker'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 07650a66-66ea-489d-aa90-0dabc75f3567 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CITokenBrokerInternalStatics |
|  | OLE a8a900c6-da0b-5bcc-a71a-be0b9265d87a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageInstallingEventArgs |
|  | OLE bd636cf1-541f-53ea-8efc-e1604a395b1a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageUninstallingEventArgs |
|  | OLE c23e15f6-c618-522a-82ab-4fab36665ce5 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageUpdatingEventArgs |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE b5a6f1bc-1641-5f4c-b946-79084e41ee35 (0.0) -- \_\_FIAsyncOperation\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CGetDefaultSignInAccountResult |
|  | OLE 9e8e4bd8-bfc5-4785-94c2-b210db698776 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CIGetDefaultSignInAccountResult |
|  | OLE b53a11bd-746a-45ee-80e6-aa5b7faa597c (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CITokenBrokerInternalStatics4 |
|  | OLE 66b59040-7c93-5f96-b52f-2c098d1557d0 (0.0) -- \_\_FIAsyncOperation\_1\_\_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccount |
|  | OLE 4631f6e7-ffcd-4b75-8fc6-160350fa89ab (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CIWamObjectStoreManagerStatics |
|  | OLE e0798d3d-2b4a-589a-ab12-02dccc158afc (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccount |
|  | OLE cc51f0fc-48d9-4e33-a38c-85546b542fe7 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CITokenBrokerListenerInternal |
|  | OLE e60e20a2-87a0-4b34-8502-ee3b8fb4ec16 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CIWamProviderRegistrationStatics |
|  | OLE 63a0a1e5-f8fe-4ba6-8508-caef1277dd35 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CIWamProviderRegistrationInformation |
|  | OLE 4f81bfe6-fdb4-4dc4-86b9-4af32d514b78 (0.0) -- IWebAccountProviderInternalFactory |
|  | OLE 7f565cd8-5dff-4b5e-abdf-1bb1f8b913f3 (0.0) -- IWebAccountProviderInternalFactory2 |
|  | OLE 067cd3b2-1f07-4710-8ae5-5cd2e71efc11 (0.0) -- IWebAccountInternalFactory |
|  | OLE 414f1885-ae5f-4340-a5de-2e39df0c8605 (0.0) -- IWebAccountInternalFactory2 |
|  | OLE 57d369ee-7364-4ab0-a307-bdd25bce408c (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CITokenBrokerInternalStatics5 |
|  | OLE 74e86d0b-0564-4391-bbd6-98cbdc0770df (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CAuthentication\_CWeb\_CITokenBrokerAccountManagerStatics |
|  | Endpoints : |
|  | ncalrpc : OLE28BA40446C430773D01DEC47135E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 9916 at 0x5dd80b8L> |
|  | 64 |
|  | \['CDPSvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE d5440bb1-a7de-46b8-95eb-834a495ff209 (0.0) -- ICDPComAccountProviderCallback |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 228f00f6-5db9-45f7-83e4-888d69441ea6 (0.0) -- ICDPComUserServiceNotificationHost |
|  | OLE 683d7fc9-8697-4309-994e-e8a2c5628884 (0.0) -- ICDPComAFSUserSettings |
|  | OLE 023f18e5-585f-433e-9fc5-c19087315129 (0.0) -- ICDPComDeviceQuery |
|  | OLE 058a5209-8d74-4989-938b-942e6c178b7d (0.0) -- ICDPComDevice |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000026-0000-0000-c000-000000000046 (0.0) -- IUrlMon |
|  | OLE 0000000e-0000-0000-c000-000000000046 (0.0) -- IBindCtx |
|  | Endpoints : |
|  | ncalrpc : OLE4B42099629F015CDE55BFFE92C1F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SearchIndexer.exe" pid 1856 at 0x5dd8e10L> |
|  | 64 |
|  | \['WSearch'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\Windows\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 993eceb0-6f1b-49fe-8ba2-21b6a5317de1 (0.0) -- IWsPlatform |
|  | OLE 2bab5a77-7751-4955-ad37-4a27a3c3046d (0.0) -- IGatherStoreAppCleanup |
|  | OLE 6eedf548-1c00-4415-bd0a-b122a3cbdb2a (0.0) -- IWsStoreAppData |
|  | OLE b80dfda4-1915-4a94-ad31-c08fc2c1eb91 (0.0) -- IWsStoreAppEndpoint |
|  | OLE ab310581-ac80-11d1-8df3-00c04fb6ef69 (0.0) -- ISearchManager |
|  | OLE ab310581-ac80-11d1-8df3-00c04fb6ef50 (0.0) -- ISearchCatalogManager |
|  | OLE ab310581-ac80-11d1-8df3-00c04fb6ef55 (0.0) -- ISearchCrawlScopeManager |
|  | OLE ab310581-ac80-11d1-8df3-00c04fb6ef52 (0.0) -- IEnumSearchRoots |
|  | OLE 04c18ccf-1f57-4cbd-88cc-3900f5195ce3 (0.0) -- ISearchRoot |
|  | OLE b05651f9-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherNotify |
|  | OLE b05651e6-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherManagerAdmin |
|  | OLE b05651e4-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherApplications |
|  | OLE b05651e2-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherApplication |
|  | OLE b05651c1-9b10-425e-b616-1fcd828db3b1 (0.0) -- IApplicationPlugins |
|  | OLE b05651c2-9b10-425e-b616-1fcd828db3b1 (0.0) -- IApplicationPlugin |
|  | OLE b05651e9-9b10-425e-b616-1fcd828db3b1 (0.0) -- IProjects |
|  | OLE b05651df-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherProjectAdmin |
|  | OLE b05651c3-9b10-425e-b616-1fcd828db3b1 (0.0) -- IPlugins |
|  | OLE 1bb12744-3e9b-4959-9226-54751dedba5a (0.0) -- IWsStoreRegistrationEndpoint |
|  | OLE 6a4eb77f-114c-4ff0-9aa8-9e159df6c137 (0.0) -- IWsStoreAppServicingEndpoint |
|  | OLE 7e5e602d-98c3-4dc3-a624-610e430b3c5f (0.0) -- IGatherManagerAdmin4 |
|  | OLE b05651e8-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherManagerAdmin3 |
|  | OLE c886b1d4-dc18-48d6-8a8f-e66046fcd0cd (0.0) -- IGatherApplication2 |
|  | OLE b05651ea-9b10-425e-b616-1fcd828db3b1 (0.0) -- IProjects2 |
|  | OLE b05651e0-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherProjectAdmin2 |
|  | OLE b05651f6-9b10-425e-b616-1fcd828db3b1 (0.0) -- IGatherAdmin |
|  | OLE fce7ec00-38e9-4837-9f8c-a0313215b86f (0.0) -- IGatherAdmin3 |
|  | OLE 9d0876ca-02dc-453a-95d9-f2194a656442 (0.0) -- IExtensions |
|  | OLE ab310581-ac80-11d1-8df3-00c04fb6ef63 (0.0) -- ISearchQueryHelper |
|  | OLE b05651c4-9b10-425e-b616-1fcd828db3b1 (0.0) -- IPlugin |
|  | OLE 00020400-0000-0000-c000-000000000046 (0.0) -- IDispatch |
|  | OLE b0565244-9b10-425e-b616-1fcd828db3b1 (0.0) -- IIndexerPlugIn |
|  | OLE 6246699e-57cb-41b8-894c-12b180346274 (0.0) -- IWsStoreStatisticsEndpoint |
|  | OLE a5eba07a-dae8-4d15-b12f-728efd8a9866 (0.0) -- IGatherNotify2 |
|  | OLE b05651ce-9b10-425e-b616-1fcd828db3b1 (0.0) -- IStartAddresses |
|  | OLE 00020404-0000-0000-c000-000000000046 (0.0) -- IEnumVARIANT |
|  | OLE b05651d0-9b10-425e-b616-1fcd828db3b1 (0.0) -- IStartAddress |
|  | OLE b05651c6-9b10-425e-b616-1fcd828db3b1 (0.0) -- ISiteRestrictions |
|  | OLE b05651c7-9b10-425e-b616-1fcd828db3b1 (0.0) -- ISiteRestriction |
|  | OLE b05651c9-9b10-425e-b616-1fcd828db3b1 (0.0) -- ISitePaths |
|  | OLE b05651ca-9b10-425e-b616-1fcd828db3b1 (0.0) -- ISitePath |
|  | OLE 6292f7ad-4e19-4717-a534-8fc22bcd5ccd (0.0) -- ISearchCrawlScopeManager2 |
|  | Endpoints : |
|  | ncalrpc : OLEC386E2D6DF81BF65D17D47BF6A52 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 10804 at 0x5dd8748L> |
|  | 64 |
|  | \['RmSvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE db3afbfb-08e6-46c6-aa70-bf9a34c30ab7 (0.0) -- IUIRadioManager |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE dad2e05e-d00c-49f5-a904-2f83b01520d2 (0.0) -- IUIRadioInstance |
|  | Endpoints : |
|  | ncalrpc : OLEE12B1215A834E1C218F6772CDAA4 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 11976 at 0x5dd8668L> |
|  | 64 |
|  | \['UsoSvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 9fc14b6b-ec4b-427c-8aaf-a128d33ee310 (0.0) -- |
|  | OLE 4e46ebe0-dcd6-40da-9fab-abb7b2c613b5 (0.0) -- IDeploymentInformationFactory |
|  | OLE 07f3afac-7c8a-4ce7-a5e0-3d24ee8a77e0 (0.0) -- IUpdateSessionOrchestrator |
|  | OLE b357f841-2130-454e-802c-5c398b549f8e (0.0) -- IUsoSession |
|  | OLE a1e78367-46b7-4ac8-affa-d9f55645223b (0.0) -- IUsoUpdateCollection |
|  | OLE d960b85b-11b6-4442-a45c-771283ed293a (0.0) -- IUsoUpdate |
|  | OLE ae363a51-a0de-5827-80f4-961b407b40c2 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CWebAuthentication\_\_CUserHostIdentity |
|  | OLE ac7f26f2-feb7-5b2a-8ac4-345bc62caede (0.0) -- IMapView<HSTRING,HSTRING> |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | OLE 199e065c-8195-55da-9c10-8aeaf9ac1062 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenResponse |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 1726f52d-2b8c-524a-98c6-f2cf0893c0f2 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageStagingEventArgs |
|  | OLE a575c2d8-ad34-456f-810b-f6c67795014d (0.0) -- IAppxStreamingDataSourceFactory |
|  | OLE 3cc7f52c-5d10-4686-8944-713e716ea8da (0.0) -- IAppxStreamingDataSource |
|  | OLE 33311ed3-9e5c-49ad-8227-7943c59820b4 (0.0) -- IAppxRangeRequestJob |
|  | OLE 97ea99c7-0186-4ad4-8df9-c5b4e0ed6b22 (0.0) -- IBackgroundCopyCallback |
|  | OLE eb64a8e8-e728-406e-8877-3c9a01be791f (0.0) -- IAppxStreamingDataSource2 |
|  | OLE f0907064-bc14-4834-bbaf-61001e30e98d (0.0) -- IUsoTaskSchedulerUtil |
|  | OLE 5b311480-e5ce-4325-90cd-586c1a123fd3 (0.0) -- ISusInternalUpgrade |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | Endpoints : |
|  | ncalrpc : OLEEFF43BCE4EB8E49676CC096B55E1 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 1472 at 0x5dd8e80L> |
|  | 64 |
|  | \['QWAVE'\] |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "IAStorDataMgrSvc.exe" pid 9152 at 0x5dd82e8L> |
|  | 32 |
|  | \['IAStorDataMgrSvc'\] |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SgrmBroker.exe" pid 11100 at 0x5dd8390L> |
|  | 64 |
|  | \['SgrmBroker'\] |
|  |  |
|  | Interfaces : |
|  | RPC 7a20fcec-dec4-4c59-be57-212e8f65d3de (1.0) -- C:\\WINDOWS\\system32\\SgrmBroker.exe |
|  | 0 -> s\_SgrmGetReport |
|  | 1 -> s\_SgrmRegisterSense |
|  | 2 -> s\_SgrmUnregisterSense |
|  | Endpoints : |
|  | ncalrpc : SgrmRpc |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 6612 at 0x5dd87f0L> |
|  | 64 |
|  | \['wscsvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | RPC 06bba54a-be05-49f9-b0a0-30f790261023 (1.0) -- c:\\windows\\system32\\wscsvc.dll |
|  | 0 -> CWindowsFirewallDetectoid::OnResetWaitHandle |
|  | 1 -> s\_wscRegisterChangeNotification |
|  | 2 -> s\_wscUnRegisterChangeNotification |
|  | 3 -> s\_wscGetAlertStatus |
|  | 4 -> s\_wscAntiVirusExpiredBeyondThreshold |
|  | 5 -> s\_wscAntiVirusExpiredBeyondThreshold |
|  | 6 -> s\_wscAntiVirusExpiredBeyondThreshold |
|  | 7 -> s\_wscFirewallGetStatus |
|  | 8 -> s\_wscIcfEnable |
|  | 9 -> s\_wscAntiVirusGetStatus |
|  | 10 -> s\_wscAntiSpywareGetStatus |
|  | 11 -> s\_wscGeneralSecurityGetStatus |
|  | 12 -> s\_wscLuaSettingsFix |
|  | 13 -> s\_wscRegisterSecurityProduct |
|  | 14 -> s\_wscUnregisterSecurityProduct |
|  | 15 -> s\_wscUpdateProductStatus |
|  | 16 -> s\_wscAntiVirusExpiredBeyondThreshold |
|  | 17 -> s\_wscIsDefenderAntivirusSupported |
|  | 18 -> s\_wscUserNotificationRequired |
|  | 19 -> s\_wscInitiateOfflineCleaning |
|  | 20 -> s\_wscAbortOfflineCleaning |
|  | 21 -> s\_wscNotifyUserForNearExpiration |
|  | 22 -> s\_wscAntiVirusGetUpgradableProducts |
|  | 23 -> s\_wscAntiVirusRemoveUpgradableProduct |
|  | 24 -> s\_wscAntiVirusGetRemovedButNotUpgradableProducts |
|  | 25 -> s\_wscMakeDefaultProductRequest |
|  | 26 -> s\_wscSetDefaultProduct |
|  | 27 -> s\_wscUpdateProductSubStatus |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE b529b7f5-76aa-431f-ad7f-1272feedff07 (0.0) -- \_\_x\_Windows\_CSecurityCenter\_CIWscBrokerManager |
|  | Endpoints : |
|  | ncalrpc : OLE993F3F6E79F1AFA166353FF779E9 |
|  | ncalrpc : LRPC-e0e0a3aa36dfcaed1a |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 10808 at 0x5dd8a58L> |
|  | 64 |
|  | \['StorSvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC be7f785e-0e3a-4ab7-91de-7e46e443be29 (0.0) -- c:\\windows\\system32\\storsvc.dll |
|  | 0 -> SvcMountVolume |
|  | 1 -> SvcDismountVolume |
|  | 2 -> SvcFormatVolume |
|  | 3 -> SvcGetStorageInstanceCount |
|  | 4 -> SvcGetStorageDeviceInfo |
|  | 5 -> CCleanupPolicy::CleanupItem |
|  | 6 -> SvcResetPhone |
|  | 7 -> SvcRebootToFlashingMode |
|  | 8 -> SvcRebootToUosFlashing |
|  | 9 -> SvcFinalizeVolume |
|  | 10 -> SvcGetStorageSettings |
|  | 11 -> SvcResetStoragePolicySettings |
|  | 12 -> SvcSetStorageSettings |
|  | 13 -> SvcTriggerStorageCleanup |
|  | 14 -> SvcTriggerLowStorageNotification |
|  | 15 -> SvcMoveFileInheritSecurity |
|  | 16 -> SvcScanVolume |
|  | 17 -> SvcProcessStorageCardChange |
|  | 18 -> SvcProvisionForAppInstall |
|  | 19 -> SvcGetStorageInstanceCountForMaps |
|  | 20 -> SvcGetStoragePolicySettings |
|  | 21 -> SvcSetStoragePolicySettings |
|  | 22 -> SvcTriggerStoragePolicies |
|  | 23 -> SvcPredictStorageHealth |
|  | RPC 54b4c689-969a-476f-8dc2-990885e9f562 (0.0) -- c:\\windows\\system32\\storsvc.dll |
|  | 0 -> SvcOpenStorageType |
|  | 1 -> SvcSelectStorageVolumeEx |
|  | 2 -> SvcSelectStorageVolume |
|  | 3 -> SvcFindNextStorageType |
|  | 4 -> SvcFindNextStorageTypeEx |
|  | 5 -> SvcCloseFindStorage |
|  | 6 -> SvcGetStorageDebugInfo |
|  | 7 -> SvcGetStorageExecutionInfo |
|  | 8 -> SvcGetTopFolders |
|  | 9 -> SvcFindNextStorageTypeExAsync |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-916a7dc50d8ab310bd |
|  | ncalrpc : OLE2CDE8F840013580E84B91408DB75 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 13288 at 0x5dd82b0L> |
|  | 64 |
|  | \['LicenseManager'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | RPC a4b8d482-80ce-40d6-934d-b22a01a44fe7 (1.0) -- c:\\windows\\system32\\licensemanagersvc.dll |
|  | 0 -> BeginAcquireLicense |
|  | 1 -> PrecacheLicenseForPackageResume |
|  | 2 -> EnsureLicenseForPackageActivation |
|  | 3 -> EnsureLicenseForOptionalPackageUsage |
|  | 4 -> PackageSuspendedNotification |
|  | 5 -> PackageRundownNotification |
|  | 6 -> OptionalPackageRundownNotification |
|  | 7 -> Reset |
|  | OLE 90e2000c-b946-42fa-892f-94506f30ca4f (0.0) -- IApplicationLicenseManager |
|  | OLE 71ba143f-598e-49d0-84eb-8febaedcc195 (0.0) -- INetworkStatusChangedEventHandler |
|  | OLE afce43e5-977b-4b8a-b7b6-e26ecec26ddf (0.0) -- ISusNotify |
|  | OLE beef4698-9382-44ce-99a0-ece4e9c0916e (0.0) -- |
|  | OLE ac7f26f2-feb7-5b2a-8ac4-345bc62caede (0.0) -- IMapView<HSTRING,HSTRING> |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | OLE 199e065c-8195-55da-9c10-8aeaf9ac1062 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenResponse |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | Endpoints : |
|  | ncalrpc : OLEC4EEB3122562CB67C7247A27AA37 |
|  | ncalrpc : LicenseServiceEndpoint |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 7716 at 0x5dd8ef0L> |
|  | 64 |
|  | \['DsSvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | RPC bf4dc912-e52f-4904-8ebe-9317c1bdd497 (1.0) -- c:\\windows\\system32\\dssvc.dll |
|  | 0 -> RpcDSSCreateSharedFileToken |
|  | 1 -> RpcDSSGetSharedFileName |
|  | 2 -> RpcDSSGetSharingTokenOwner |
|  | 3 -> RpcDSSGetSharingTokenInformation |
|  | 4 -> RpcDSSDelegateSharingToken |
|  | 5 -> RpcDSSRemoveSharingToken |
|  | 6 -> RpcDSSOpenSharedFile |
|  | 7 -> RpcDSSMoveToSharedFile |
|  | 8 -> RpcDSSMoveFromSharedFile |
|  | 9 -> RpcDSSCopyFromSharedFile |
|  | 10 -> RpcDSSRemoveExpiredTokens |
|  | Endpoints : |
|  | ncalrpc : OLE18028803A64A631CDD3D751A2AB0 |
|  | ncalrpc : LRPC-3deab3cf967a579232 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "LMIGuardianSvc.exe" pid 12048 at 0x5dd8860L> |
|  | 64 |
|  | \['LMIGuardianSvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 4615b7a3-8ef2-40c0-83f0-63bcd479c791 (0.0) -- IGuardianSvc |
|  | Endpoints : |
|  | ncalrpc : OLE3DD2D73FB7A223F52DFC7D9FA81E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3936 at 0x5dd8898L> |
|  | 64 |
|  | \['Netman'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE faedcf69-31fe-11d1-aad2-00805fc1270e (0.0) -- INetConnectionManager2 |
|  | RPC a111f1c6-5923-47c0-9a68-d0bafb577901 (1.0) -- C:\\Windows\\System32\\NetSetupShim.dll |
|  | 0 -> RpcNetSetup\_NotifyHost\_Connect |
|  | 1 -> RpcNetSetup\_NotifyHost\_Disconnect |
|  | 2 -> RpcNetSetup\_Isolation\_ExecuteInfSection |
|  | 3 -> RpcNetSetup\_NotifyObject\_Load |
|  | 4 -> RpcNetSetup\_NotifyObject\_Unload |
|  | 5 -> RpcNetSetup\_ComponentControl\_Initialize |
|  | 6 -> RpcNetSetup\_ComponentControl\_ApplyChanges |
|  | 7 -> RpcNetSetup\_ComponentControl\_ApplyPnpChanges |
|  | 8 -> RpcNetSetup\_ComponentControl\_CancelChanges |
|  | 9 -> RpcNetSetup\_ComponentSetup\_Install |
|  | 10 -> RpcNetSetup\_ComponentSetup\_Upgrade |
|  | 11 -> RpcNetSetup\_ComponentSetup\_Removing |
|  | 12 -> RpcNetSetup\_NotifyBinding\_QueryBindingPath |
|  | 13 -> RpcNetSetup\_NotifyBinding\_NotifyBindingPath |
|  | 14 -> RpcNetSetup\_NotifyGlobal\_GetSupportedNotifications |
|  | 15 -> RpcNetSetup\_NotifyGlobal\_SysQueryBindingPath |
|  | 16 -> RpcNetSetup\_NotifyGlobal\_SysNotifyBindingPath |
|  | 17 -> RpcNetSetup\_NotifyGlobal\_SysNotifyComponent |
|  | OLE c08956a2-1cd3-11d1-b1c5-00805fc1270e (0.0) -- INetConnectionManager |
|  | OLE faedcf71-31fe-11d1-aad2-00805fc1270e (0.0) -- INetConnectionManager3 |
|  | OLE c08956a1-1cd3-11d1-b1c5-00805fc1270e (0.0) -- INetConnection |
|  | OLE faedcf59-31fe-11d1-aad2-00805fc1270e (0.0) -- IPersistNetConnection |
|  | OLE 0000010c-0000-0000-c000-000000000046 (0.0) -- IPersist |
|  | OLE faedcf5f-31fe-11d1-aad2-00805fc1270e (0.0) -- INetConnectionRefresh |
|  | OLE c08956a0-1cd3-11d1-b1c5-00805fc1270e (0.0) -- IEnumNetConnection |
|  | OLE d44289db-a594-491a-8326-190b5085e381 (0.0) -- IRasEventNotify |
|  | Endpoints : |
|  | ncalrpc : OLE1B83BE5FEA80C4DAA6F39E121A97 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "hamachi-2.exe" pid 6436 at 0x5dd8c18L> |
|  | 64 |
|  | \['Hamachi2Svc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Unknown 00000000-0000-0000-0000-000000000000 (0.0) -- |
|  | Endpoints : |
|  | ncalrpc : OLE305615A4AD92302C163F0820644F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "dllhost.exe" pid 11328 at 0x5dd8400L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE a168aadc-1674-49da-ad4f-4f27df8760d0 (0.0) -- IUrlCacheManager |
|  | RPC cad784cb-4c1b-4d96-b8f7-4716b568b13c (1.0) -- C:\\WINDOWS\\system32\\wininet.dll |
|  | 0 -> s\_UrlCacheGetManagerInterface |
|  | 1 -> StaticProxyResolver::CancelAll |
|  | 2 -> s\_UrlCacheOpenContainer |
|  | 3 -> s\_UrlCacheCloseContainer |
|  | 4 -> s\_UrlCacheSetContainerEntryMaximumAge |
|  | 5 -> s\_UrlCacheAddUrl |
|  | 6 -> s\_UrlCacheLookupUrl |
|  | 7 -> s\_UrlCacheCheckUrlsExist |
|  | 8 -> s\_UrlCacheGetUrlBinaryBlob |
|  | 9 -> s\_UrlCacheAddUrlBinaryBlob |
|  | 10 -> s\_UrlCacheDeleteUrl |
|  | 11 -> s\_UrlCacheUnlockUrl |
|  | 12 -> s\_UrlCacheUpdateUrl |
|  | 13 -> s\_UrlCacheEntryEnum |
|  | 14 -> s\_UrlCacheEntryEnumClose |
|  | 15 -> s\_UrlCacheEntryEnumNext |
|  | 16 -> s\_UrlCacheCleanupUrls |
|  | 17 -> s\_UrlCacheCleanupHttpsUrls |
|  | 18 -> s\_UrlCacheGetSize |
|  | 19 -> s\_UrlCacheGetLimit |
|  | 20 -> s\_UrlCacheSetLimit |
|  | 21 -> s\_UrlCacheGetCrossContainerContentTotalSizeAndLimit |
|  | 22 -> s\_UrlCacheCleanupCrossContainers |
|  | 23 -> s\_UrlCacheGetBloomFilter |
|  | 24 -> s\_UrlCacheReleaseBloomFilter |
|  | 25 -> s\_UrlCacheGetNextDirectory |
|  | 26 -> s\_UrlCacheAddLeakFile |
|  | 27 -> s\_UrlCacheCreateGroup |
|  | 28 -> s\_UrlCacheDeleteGroup |
|  | 29 -> s\_UrlCacheGetGroupIds |
|  | 30 -> s\_UrlCacheGetGroup |
|  | 31 -> s\_UrlCacheUpdateGroup |
|  | 32 -> s\_UrlCacheSetUrlGroup |
|  | 33 -> s\_UrlCacheGetContentContainerDirectories |
|  | 34 -> s\_UrlCacheCreateExtensibleContainer |
|  | 35 -> s\_UrlCacheDeleteExtensibleContainer |
|  | 36 -> s\_UrlCacheGetExtensibleContainersList |
|  | 37 -> s\_UrlCacheRpcSetGlobalLimit |
|  | 38 -> s\_UrlCacheRpcGetGlobalLimit |
|  | 39 -> s\_UrlCacheRpcReloadSettings |
|  | 40 -> s\_UrlCacheGetGlobalCounters |
|  | 41 -> s\_AppCacheOpenContainer |
|  | 42 -> s\_AppCacheCloseContainer |
|  | 43 -> s\_AppCacheRpcCheckManifest |
|  | 44 -> s\_AppCacheRpcLookup |
|  | 45 -> s\_AppCacheRpcDeleteGroup |
|  | 46 -> s\_AppCacheRpcDeleteIeGroup |
|  | 47 -> s\_AppCacheRpcGetFallbackUrl |
|  | 48 -> s\_AppCacheRpcGetDownloadList |
|  | 49 -> s\_AppCacheRpcCloseHandle |
|  | 50 -> s\_AppCacheRpcInvalidate |
|  | 51 -> s\_AppCacheRpcGetInfo |
|  | 52 -> s\_AppCacheRpcGetGroupsList |
|  | 53 -> s\_AppCacheRpcFreeSpace |
|  | 54 -> s\_AppCacheRpcGetIeGroupList |
|  | 55 -> s\_AppCacheRpcFreeIeSpace |
|  | 56 -> s\_AppCacheRpcRetrieveUrl |
|  | 57 -> s\_AppCacheRpcCommitUrl |
|  | 58 -> s\_AppCacheRpcUpdateExtraData |
|  | 59 -> s\_AppCacheRpcFinalize |
|  | 60 -> s\_DependencyStoreOpenContainer |
|  | 61 -> s\_DependencyStoreCloseContainer |
|  | 62 -> s\_DependencyStoreUpdateUrl |
|  | 63 -> s\_DependencyStoreRetrieveUrl |
|  | 64 -> s\_DependencyStoreDeleteContainer |
|  | 65 -> s\_HstsOpenContainer |
|  | 66 -> s\_HstsCloseContainer |
|  | 67 -> s\_HstsGetHstsEntries |
|  | 68 -> s\_HstsSetHstsEntries |
|  | 69 -> s\_HstsPurgeContainer |
|  | 70 -> s\_CookieOpenContainer |
|  | 71 -> s\_CookieCloseContainer |
|  | 72 -> s\_CookieGetCookies |
|  | 73 -> s\_CookieGetAllCookies |
|  | 74 -> s\_CookieUpdateCookies |
|  | 75 -> s\_CookiePurgeContainer |
|  | 76 -> s\_BlobOpenContainer |
|  | 77 -> s\_BlobCloseContainer |
|  | 78 -> s\_BlobGetEntries |
|  | 79 -> s\_BlobGetEntry |
|  | 80 -> s\_BlobSetEntry |
|  | 81 -> s\_BlobDeleteEntry |
|  | 82 -> s\_BlobPurgeContainer |
|  | Endpoints : |
|  | ncalrpc : OLE123B7F93FED52141368C164E1BE2 |
|  | ncalrpc : webcache\_{7329ea82-0845-4e4c-bd18-02b67ac065cc}\_S-1-5-18 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "wlanext.exe" pid 13024 at 0x5dd8da0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC 98e96949-bc59-47f1-92d1-8c25b46f85c7 (1.0) -- C:\\WINDOWS\\system32\\WLANExt.exe |
|  | 0 -> RpcDot11ExtIhvInitService |
|  | 1 -> RpcDot11ExtIhvDeinitService |
|  | 2 -> RpcDot11ExtIhvInitAdapter |
|  | 3 -> RpcDot11ExtIhvDeinitAdapter |
|  | 4 -> RpcDot11ExtIhvProcessSessionChange |
|  | 5 -> RpcDot11ExtIhvIsUIRequestPending |
|  | 6 -> RpcDot11ExtIhvPerformCapabilityMatch |
|  | 7 -> RpcDot11ExtIhvValidateProfile |
|  | 8 -> RpcDot11ExtIhvPerformPreAssociate |
|  | 9 -> RpcDot11ExtIhvAdapterReset |
|  | 10 -> RpcDot11ExtIhvCreateDiscoveryProfiles |
|  | 11 -> RpcDot11ExtIhvProcessUIResponse |
|  | 12 -> RpcDot11ExtIhvQueryUIRequest |
|  | 13 -> RpcDot11ExtIhvOnexIndicateResult |
|  | 14 -> RpcDot11ExtIhvControl |
|  | RPC a111f1c6-5923-47c0-9a68-d0bafb577901 (1.0) -- C:\\Windows\\System32\\NetSetupShim.dll |
|  | 0 -> RpcNetSetup\_NotifyHost\_Connect |
|  | 1 -> RpcNetSetup\_NotifyHost\_Disconnect |
|  | 2 -> RpcNetSetup\_Isolation\_ExecuteInfSection |
|  | 3 -> RpcNetSetup\_NotifyObject\_Load |
|  | 4 -> RpcNetSetup\_NotifyObject\_Unload |
|  | 5 -> RpcNetSetup\_ComponentControl\_Initialize |
|  | 6 -> RpcNetSetup\_ComponentControl\_ApplyChanges |
|  | 7 -> RpcNetSetup\_ComponentControl\_ApplyPnpChanges |
|  | 8 -> RpcNetSetup\_ComponentControl\_CancelChanges |
|  | 9 -> RpcNetSetup\_ComponentSetup\_Install |
|  | 10 -> RpcNetSetup\_ComponentSetup\_Upgrade |
|  | 11 -> RpcNetSetup\_ComponentSetup\_Removing |
|  | 12 -> RpcNetSetup\_NotifyBinding\_QueryBindingPath |
|  | 13 -> RpcNetSetup\_NotifyBinding\_NotifyBindingPath |
|  | 14 -> RpcNetSetup\_NotifyGlobal\_GetSupportedNotifications |
|  | 15 -> RpcNetSetup\_NotifyGlobal\_SysQueryBindingPath |
|  | 16 -> RpcNetSetup\_NotifyGlobal\_SysNotifyBindingPath |
|  | 17 -> RpcNetSetup\_NotifyGlobal\_SysNotifyComponent |
|  | Endpoints : |
|  | ncalrpc : LRPC-88cce70afd054e6103 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "conhost.exe" pid 5808 at 0x5dd89e8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 9728 at 0x5dd8eb8L> |
|  | 64 |
|  | \['wlidsvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC cc105610-da03-467e-bc73-5b9e2937458d (1.0) -- c:\\windows\\system32\\wlidsvc.dll |
|  | 0 -> WLIDPublishService |
|  | 1 -> WLIDUnpublishService |
|  | 2 -> WLIDResolveDevice |
|  | 3 -> WLIDResolveUser |
|  | 4 -> WLIDConnectIdentity |
|  | 5 -> WLIDUpdateConnectedIdentity |
|  | 6 -> WLIDCompleteConnect |
|  | 7 -> WLIDDisconnectIdentity |
|  | 8 -> WLIDCreateIdentity |
|  | 9 -> WLIDDeleteIdentity |
|  | 10 -> WLIDImportIdentity |
|  | 11 -> WLIDGetLocalDeviceName |
|  | 12 -> WLIDCreateContext |
|  | 13 -> WLIDCreateContextWithLogonId |
|  | 14 -> WLIDSetAuthData |
|  | 15 -> WLIDDeleteContext |
|  | 16 -> WLIDGetServiceConfig |
|  | 17 -> WLIDAcquireTokens |
|  | 18 -> WLIDUpdateToken |
|  | 19 -> WLIDAddOrDeleteColorSetCookie |
|  | 20 -> WLIDWatsonReport |
|  | 21 -> WLIDGetCachedTokens |
|  | 22 -> WLIDGetExtendedError |
|  | 23 -> WLIDGetUserExtendedProperty |
|  | 24 -> WLIDSetUserExtendedProperty |
|  | 25 -> WLIDGetIdentityProperty |
|  | 26 -> WLIDSetOptions |
|  | 27 -> WLIDEnumIdentities |
|  | 28 -> WLIDHasPersistedCredential |
|  | 29 -> WLIDPersistCredential |
|  | 30 -> WLIDPersistCredentialForConnectedUser |
|  | 31 -> WLIDRemovePersistedCredential |
|  | 32 -> WLIDVerifyAssertion |
|  | 33 -> WLIDGetDeviceId |
|  | 34 -> WLIDProvisionDeviceId |
|  | 35 -> WLIDGetDeviceIdEx |
|  | 36 -> WLIDRenewDeviceId |
|  | 37 -> WLIDDeProvisionDeviceId |
|  | 38 -> WLIDEnumDevices |
|  | 39 -> WLIDAssociateDeviceToUser |
|  | 40 -> WLIDDisassociateDeviceFromUser |
|  | 41 -> WLIDEnumerateUserAssociatedDevices |
|  | 42 -> WLIDUpdateUserAssociatedDeviceProperties |
|  | 43 -> WLIDCreateContextForLinkedIdentity |
|  | 44 -> WLIDAddUserToSsoGroup |
|  | 45 -> WLIDGetUsersFromSsoGroup |
|  | 46 -> WLIDRemoveUserFromSsoGroup |
|  | 47 -> WLIDGetAuthError |
|  | 48 -> WLIDGetDeviceShortLivedToken |
|  | 49 -> WLIDGetHIPChallenge |
|  | 50 -> WLIDSetHIPSolution |
|  | 51 -> WLIDSetDefaultUserForTarget |
|  | 52 -> WLIDGetDefaultUserForTarget |
|  | 53 -> WLIDIsKioskMode |
|  | 54 -> WLIDGetConfigString |
|  | 55 -> WLIDGetSvcEnvironment |
|  | 56 -> WLIDGetIdName |
|  | 57 -> WLIDGetConfigDWORDValue |
|  | 58 -> WLIDGetUserPropertiesFromSystemStore |
|  | 59 -> WLIDSetUserPropertiesToSystemStore |
|  | 60 -> WLIDInitializeEx |
|  | 61 -> WLIDEnableTrace |
|  | 62 -> WLIDDisableTrace |
|  | 63 -> WLIDGetOneTimeCredential |
|  | 64 -> WLIDGetIssuerCertificate |
|  | 65 -> WLIDCreateContextWithChallenge |
|  | 66 -> WLIDGetDefaultUserForTargetEx |
|  | 67 -> WLIDSendOneTimeCode |
|  | 68 -> WLIDGetUserPropertiesFromHandle |
|  | 69 -> WLIDGetKeyLatest |
|  | 70 -> WLIDGetKeyWithVersion |
|  | 71 -> WLIDGetOpenHandlesData |
|  | 72 -> WLIDGetSignedTokens |
|  | 73 -> WLIDGetDeviceDAToken |
|  | 74 -> WLIDGetProofOfPossessionTokens |
|  | 75 -> WLIDRegisterUserIdkey |
|  | 76 -> WLIDUpdateDeviceLicenseInfo |
|  | 77 -> WLIDManageApprover |
|  | 78 -> WLIDListSessions |
|  | 79 -> WLIDApproveSession |
|  | 80 -> WLIDGetScenarioInlineUrlWithContextData |
|  | 81 -> WLIDGetInlineUrlContextData |
|  | 82 -> WLIDAcquireTokensWithNGC |
|  | 83 -> WLIDGetTotpCode |
|  | 84 -> WLIDCleanupIdentity |
|  | 85 -> WLIDGetAppData |
|  | RPC faf2447b-b348-4feb-8dbe-beee5b7f7778 (1.0) -- c:\\windows\\system32\\wlidsvc.dll |
|  | 0 -> RenewCertificate |
|  | RPC 572e35b4-1344-4565-96a1-f5df3bfa89bb (1.0) -- c:\\windows\\system32\\wlidsvc.dll |
|  | 0 -> WLIDNCreateContext |
|  | 1 -> WLIDNDeleteContext |
|  | 2 -> WLIDNGetNextNotification |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : LRPC-a88769e55cac7e04eb |
|  | ncalrpc : liveidsvcnotify |
|  | ncalrpc : OLE843CCE9586FB30A70A5793E2BFE5 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "csrss.exe" pid 11728 at 0x5dd8828L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "winlogon.exe" pid 1324 at 0x5dd8278L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC 76f226c3-ec14-4325-8a99-6a46348418ae (1.0) -- C:\\WINDOWS\\System32\\WinLogon.exe |
|  | 0 -> I\_WMsgkSendMessage |
|  | 1 -> I\_WMsgSendPSPMessage |
|  | RPC 76f226c3-ec14-4325-8a99-6a46348418af (1.0) -- C:\\WINDOWS\\System32\\WinLogon.exe |
|  | 0 -> I\_WMsgSendMessage |
|  | 1 -> I\_WMsgSendPSPMessage |
|  | 2 -> I\_WMsgSendNotifyMessage |
|  | 3 -> I\_WMsgSendReconnectionUpdateMessage |
|  | RPC 12e65dd8-887f-41ef-91bf-8d816c42c2e7 (1.0) -- C:\\WINDOWS\\System32\\WinLogon.exe |
|  | 0 -> WlSecureDesktoprPromptingRequest |
|  | 1 -> WlSecureDesktoprConfirmationRequest |
|  | 2 -> WlSecureDesktoprCredmanBackupRequest |
|  | 3 -> WlSecureDesktoprCredmanRestoreRequest |
|  | 4 -> WlSecureDesktoprSimulateSAS |
|  | Endpoints : |
|  | ncalrpc : WMsgKRpc01841F46E2 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "fontdrvhost.exe" pid 5920 at 0x5dd8198L> |
|  | 64 |
|  | \[!!\] Invalid rpcrt4 base: 0x0 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "dwm.exe" pid 3952 at 0x5dd81d0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00621c22-42e8-529f-9270-836b32931d72 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CGaming\_\_CInput\_\_CRawGameController |
|  | Endpoints : |
|  | ncalrpc : OLEFD8A708A175E429C025F79C15FFC |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "NVDisplay.Container.exe" pid 12100 at 0x5dd86a0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE e6ab4158-38b8-4fdf-85cf-adc2e9870970 (0.0) -- IStateData |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE 4473e3a7-c2ad-4075-a1f8-935a584740a9 (0.0) -- IStateEvents |
|  | OLE a3116d99-0a9b-400d-851e-84b3e387dbcc (0.0) -- IStateDataReadOnly |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 501f9389-11f2-43be-ba11-73d55f9d1963 (0.0) -- IPipelineElement |
|  | OLE ea8e8d90-f1bb-499f-93b2-ae1eb8dcd9a6 (0.0) -- ITransactionController |
|  | Endpoints : |
|  | ncalrpc : OLE0BD7BCC41CC05E312A90CADE2021 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "sihost.exe" pid 8184 at 0x5dd8908L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE cb728b20-f786-11ce-92ad-00aa00a74cd0 (0.0) -- IProfferService |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE e7fb793d-3581-4b54-a798-ab8e9d69c963 (0.0) -- IBackgroundActivationSessionManagerEvents |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE 6d5140c1-7436-11ce-8034-00aa006009fa (0.0) -- IServiceProvider |
|  | OLE e12fe107-2d78-46a1-bca8-d93e4c2ab2bc (0.0) -- IPlmStateChangeNotifications |
|  | OLE fc99c60d-d59b-4b2b-b73d-3a1cc9f2aafa (0.0) -- ILifetimeManagerRemote |
|  | OLE d7a5d1cc-fcbc-4e54-9deb-45ef67293cf8 (0.0) -- ISuspensionDependencyBroker |
|  | OLE 428d4ddd-3462-43df-9395-1eff13ae7a4b (0.0) -- IBackgroundAccessManagerService |
|  | OLE 69c083b1-7f6f-490d-9d77-c0219a95b25d (0.0) -- IProcessLifetimeManagerControl |
|  | OLE 7656cfa4-b63a-4542-a8de-ef402bac895d (0.0) -- IUserApplicationStateChangeHandler |
|  | RPC 8ec21e98-b5ce-4916-a3d6-449fa428a007 (0.0) -- C:\\Windows\\System32\\modernexecserver.dll |
|  | 0 -> FmMuxSrvRegisterCoreUIEndpoints |
|  | 1 -> FmMuxSrvGenerateTaskInstanceId |
|  | 2 -> FmMuxSrvLaunchTask |
|  | 3 -> FmMuxSrvResumeTask |
|  | 4 -> FmMuxSrvPauseTask |
|  | 5 -> FmMuxSrvCancelTask |
|  | 6 -> FmMuxSrvAbortTask |
|  | 7 -> FmMuxSrvGetTaskPid |
|  | 8 -> FmMuxSrvSetTaskDehydrationEligibility |
|  | 9 -> FmMuxSrvSetTaskProperty |
|  | 10 -> FmMuxSrvResolveApplicationUri |
|  | 11 -> FmMuxSrvGetActivationPolicy |
|  | 12 -> FmMuxSrvLogoffUser |
|  | 13 -> FmMuxSrvShutdown |
|  | 14 -> FmMuxSrvSetForegroundTaskInstanceId |
|  | 15 -> FmMuxSrvGenerateActivationInstanceId |
|  | 16 -> FmMuxSrvActivationPrerequisitePhase |
|  | 17 -> FmMuxSrvIsCBETask |
|  | 18 -> FmMuxSrvIsValidTaskPid |
|  | 19 -> FmMuxSrvResumePrerequisitePhase |
|  | 20 -> FmMuxSrvGetForegroundTaskInstanceId |
|  | 21 -> FmMuxSrvActivationBypass |
|  | 22 -> FmMuxSrvIsActivationDehydrated |
|  | 23 -> FmMuxSrvRequestResourceSet |
|  | RPC 0fc77b1a-95d8-4a2e-a0c0-cff54237462b (0.0) -- C:\\Windows\\System32\\modernexecserver.dll |
|  | 0 -> FmMuxSrvRegisterFGNotificationCoreUIEndpoint |
|  | 1 -> FmMuxSrvUnRegisterFGNotificationCoreUIEndpoint |
|  | 2 -> FmMuxSrvGetForegroundProductId |
|  | 3 -> FmMuxSrvIsForegroundProductId |
|  | 4 -> FmMuxSrvGetProductIdFromProcessId |
|  | 5 -> FmMuxSrvGenerateWatsonReport |
|  | 6 -> FmMuxSrvGetProcessProductId |
|  | 7 -> FmMuxSrvDehydrateHost |
|  | 8 -> FmMuxSrvIsCallingProcessForeground |
|  | RPC b1ef227e-dfa5-421e-82bb-67a6a129c496 (0.0) -- C:\\Windows\\System32\\modernexecserver.dll |
|  | 0 -> FmMuxSrvIsActivationBeingDebugged |
|  | 1 -> FmMuxSrvIsForegroundActivation |
|  | 2 -> FmMuxSrvGetForegroundActivationInstanceId |
|  | 3 -> FmMuxSrvGetApplicationId |
|  | 4 -> FmMuxSrvGetPackageFamilyName |
|  | 5 -> FmMuxSrvGetPackageFullName |
|  | 6 -> FmMuxSrvGetPSMKey |
|  | 7 -> FmMuxSrvDehydrateApplication |
|  | 8 -> FmMuxSrvSetAutoDehydrateFlag |
|  | 9 -> FmMuxSrvGetAutoDehydrateFlag |
|  | 10 -> FmMuxSrvReloadSettings |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE a478f456-5d69-41d4-8fd5-a414c516c781 (0.0) -- IUserPackageStateChangeHandler |
|  | OLE 998d66a2-4a54-496c-9e18-268890860004 (0.0) -- IApplicationActivationManagerPriv |
|  | OLE e7a5f14e-0650-44f2-9168-35cd1d04fe20 (0.0) -- IApplicationActivationPhonePriv |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE ca4d975c-d4d6-43f0-97c0-0833c6391c24 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CISplashScreen |
|  | OLE cd292360-2763-4085-8a9f-74b224a29175 (0.0) -- \_\_x\_Windows\_CUI\_CCore\_CICoreWindowFactory |
|  | OLE 83140d1c-7e82-4cfb-96e4-f997cede7e10 (0.0) -- IUiaManagerWindowRegistration |
|  | OLE 6dc8c1be-86e5-4eef-8335-72cab53f06c8 (0.0) -- IUiaWindowRegistrationToken |
|  | OLE 087ca5a4-8cfc-4264-b39d-da2bb2583a11 (0.0) -- ICoreWindowFactoryPriv |
|  | OLE 0e8c8da1-11b5-4fad-975a-14f51015e07a (0.0) -- ISplashScreenPriv |
|  | OLE 445289d9-2bba-4b3d-9f41-09683cc27200 (0.0) -- IBackgroundTaskCapabilityInternal |
|  | OLE 2f3eca0f-a0a7-445b-8f88-f6260a7dac04 (0.0) -- IPlmDataQuery |
|  | OLE 0f4accb1-d8f9-4011-ba37-2557925a78cf (0.0) -- IServiceHostBrokerProvider |
|  | OLE 267265c8-eb6e-409d-b104-e6451ee39433 (0.0) -- \_\_x\_Windows\_CSystem\_CInternal\_CLaunch\_CIQueryAssociationBrokerStatics |
|  | OLE 49244656-5ea6-5680-bf99-87ef7636f6c8 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSystem\_\_CInternal\_\_CLaunch\_\_CExtensionInfo |
|  | OLE 683906e1-1771-40a1-bbd6-409cc4c8e268 (0.0) -- IImmersiveApplicationDebugControlInternal |
|  | OLE 36c8be08-bca4-4431-b5c0-b07bc0baf3c8 (0.0) -- IPlmPackageServicing |
|  | Endpoints : |
|  | ncalrpc : OLE9FD67C4538B9899C2F1EF1126F80 |
|  | ncalrpc : LRPC-163a6a24109db2222a |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 11196 at 0x5dd8780L> |
|  | 64 |
|  | \['CDPUserSvc\_184a7aba'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 8255a6da-c295-48c3-a4da-dae510b5c193 (0.0) -- ICDPComUserActivitySettings |
|  | OLE 6f4670bb-cdf1-4fb7-8d5c-46c9200dfbf3 (0.0) -- ICDPComActivityStoreInfoWatcher |
|  | OLE 36943385-8b4c-432c-9bbd-075efda748be (0.0) -- ICDPComResourceManager |
|  | OLE a0798ff7-2d46-47f2-815c-f316eb1c35f5 (0.0) -- ICDPComResourceHandler |
|  | OLE c092cc2f-5eca-5a5d-9c9c-f050e892dd97 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountAddedEventArgs |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE df3657fc-19c8-5e99-b48f-4a59b98d4e8a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountDeletedEventArgs |
|  | OLE 7b21266a-2f7e-453c-ae9b-e515620b04cc (0.0) -- ICDPComAccountProvider |
|  | OLE 50ce6ccb-94b2-5a0b-8841-3639c33d1467 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountProviderChangedEventArgs |
|  | OLE 9477622b-1340-5574-81fc-5013581f57c9 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccountProvider |
|  | OLE dc8b9f35-216c-54ff-99db-cd7e04c6a074 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountChangedEventArgs |
|  | OLE c2090d8c-37d8-5c47-9581-0f17b91a0cd3 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_\_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccount |
|  | OLE d5440bb1-a7de-46b8-95eb-834a495ff209 (0.0) -- ICDPComAccountProviderCallback |
|  | OLE 4bd6f1e5-ca89-5240-8f3d-7f1b54ae90a7 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccount |
|  | OLE 8cb134c6-72c3-4c94-859f-c1f2d40ddd13 (0.0) -- ICDPComUserSettingsProvider |
|  | OLE 51aa6c40-b054-5c68-801e-03b75f43e2a1 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CGetDefaultSignInAccountResult |
|  | OLE bc0d0f9f-ecd0-4545-b41e-6df5f379bde0 (0.0) -- IWpnChannelRequest |
|  | OLE ba0acdb0-707c-45b3-a844-640bafe062c0 (0.0) -- ICDPComActivityStore |
|  | OLE ede5d338-21dc-4359-85d5-cd8d9c5a2e4e (0.0) -- ICDPComActivityStoreReader |
|  | OLE 8dd85454-2ca5-4099-9412-f471edac4253 (0.0) -- ICDPComActivityStoreManagementControl |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE deb54b22-70f2-55ab-97c0-6cbdc5ddb6f0 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenRequestResult |
|  | OLE 199e065c-8195-55da-9c10-8aeaf9ac1062 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenResponse |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE ac7f26f2-feb7-5b2a-8ac4-345bc62caede (0.0) -- IMapView<HSTRING,HSTRING> |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | Endpoints : |
|  | ncalrpc : OLE85B0D102E1BBCD401B8E91366987 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 3796 at 0x5dd8fd0L> |
|  | 64 |
|  | \['WpnUserService\_184a7aba'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE df8e9480-ca73-448e-b8f0-da000f581428 (0.0) -- IWpnPlatform |
|  | OLE 43c6b434-c1be-4ad2-af03-c0deaccebd1f (0.0) -- IBackgroundAccessStateChangeHandler |
|  | OLE 2a45cbbe-93a2-4f76-8c01-b6c2a1720f20 (0.0) -- IConnectionManagerCallbacks2 |
|  | OLE b755e6e0-b048-49cc-8911-11a041216f5f (0.0) -- IApplicationStateChangeHandler |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE a5322dff-9ebc-5df1-953d-0237cea8614b (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserChangedEventArgs |
|  | OLE ccb96d97-791c-5741-8f33-fb7266d6ea33 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserChangedEventArgs |
|  | OLE f655b052-348b-4ab0-947b-a7dafa44d404 (0.0) -- IWpnRegistrationEndpoint |
|  | OLE 7d85494e-d99e-493a-bf51-80d2c9feab49 (0.0) -- IWpnSystemRegistrationEndpoint |
|  | OLE 2537d644-8c2f-4449-b8b6-10928822630c (0.0) -- INotificationController |
|  | OLE 443b1739-3779-4aba-953b-9e4ff84dd4b6 (0.0) -- INotificationSettings |
|  | OLE 6bff4732-81ec-4ffb-ae67-b6c1bc29631f (0.0) -- IQuietHoursSettings |
|  | OLE 0e467ac1-65f2-48d6-8bf2-375430548a87 (0.0) -- IWpnPresentationEndpoint |
|  | OLE ff94ea7e-7d6c-406e-826e-0ad128677b50 (0.0) -- IWpnSettingsEndpoint |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE dcaee35a-508d-4419-9e56-50d658c2c812 (0.0) -- IWpnAppEndpoint |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 926516e8-d891-45bc-9de5-6959fb8ecac5 (0.0) -- IWpnAppEndpoint3 |
|  | OLE 4f38fd3e-2c10-4c00-9ec1-62bd536a1feb (0.0) -- IWpnToastFeedback |
|  | OLE 71ba143f-598e-49d0-84eb-8febaedcc195 (0.0) -- INetworkStatusChangedEventHandler |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | Endpoints : |
|  | ncalrpc : OLE44E7AB9380587C43A78CDB450540 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "taskhostw.exe" pid 2352 at 0x5dd85c0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC 9d420415-b8fb-4f4a-8c53-4502ead30ca9 (1.0) -- C:\\WINDOWS\\System32\\PlaySndSrv.dll |
|  | 0 -> I\_PlaySoundkPostMessage |
|  | RPC cad784cb-4c1b-4d96-b8f7-4716b568b13c (1.0) -- C:\\WINDOWS\\system32\\wininet.dll |
|  | 0 -> s\_UrlCacheGetManagerInterface |
|  | 1 -> StaticProxyResolver::CancelAll |
|  | 2 -> s\_UrlCacheOpenContainer |
|  | 3 -> s\_UrlCacheCloseContainer |
|  | 4 -> s\_UrlCacheSetContainerEntryMaximumAge |
|  | 5 -> s\_UrlCacheAddUrl |
|  | 6 -> s\_UrlCacheLookupUrl |
|  | 7 -> s\_UrlCacheCheckUrlsExist |
|  | 8 -> s\_UrlCacheGetUrlBinaryBlob |
|  | 9 -> s\_UrlCacheAddUrlBinaryBlob |
|  | 10 -> s\_UrlCacheDeleteUrl |
|  | 11 -> s\_UrlCacheUnlockUrl |
|  | 12 -> s\_UrlCacheUpdateUrl |
|  | 13 -> s\_UrlCacheEntryEnum |
|  | 14 -> s\_UrlCacheEntryEnumClose |
|  | 15 -> s\_UrlCacheEntryEnumNext |
|  | 16 -> s\_UrlCacheCleanupUrls |
|  | 17 -> s\_UrlCacheCleanupHttpsUrls |
|  | 18 -> s\_UrlCacheGetSize |
|  | 19 -> s\_UrlCacheGetLimit |
|  | 20 -> s\_UrlCacheSetLimit |
|  | 21 -> s\_UrlCacheGetCrossContainerContentTotalSizeAndLimit |
|  | 22 -> s\_UrlCacheCleanupCrossContainers |
|  | 23 -> s\_UrlCacheGetBloomFilter |
|  | 24 -> s\_UrlCacheReleaseBloomFilter |
|  | 25 -> s\_UrlCacheGetNextDirectory |
|  | 26 -> s\_UrlCacheAddLeakFile |
|  | 27 -> s\_UrlCacheCreateGroup |
|  | 28 -> s\_UrlCacheDeleteGroup |
|  | 29 -> s\_UrlCacheGetGroupIds |
|  | 30 -> s\_UrlCacheGetGroup |
|  | 31 -> s\_UrlCacheUpdateGroup |
|  | 32 -> s\_UrlCacheSetUrlGroup |
|  | 33 -> s\_UrlCacheGetContentContainerDirectories |
|  | 34 -> s\_UrlCacheCreateExtensibleContainer |
|  | 35 -> s\_UrlCacheDeleteExtensibleContainer |
|  | 36 -> s\_UrlCacheGetExtensibleContainersList |
|  | 37 -> s\_UrlCacheRpcSetGlobalLimit |
|  | 38 -> s\_UrlCacheRpcGetGlobalLimit |
|  | 39 -> s\_UrlCacheRpcReloadSettings |
|  | 40 -> s\_UrlCacheGetGlobalCounters |
|  | 41 -> s\_AppCacheOpenContainer |
|  | 42 -> s\_AppCacheCloseContainer |
|  | 43 -> s\_AppCacheRpcCheckManifest |
|  | 44 -> s\_AppCacheRpcLookup |
|  | 45 -> s\_AppCacheRpcDeleteGroup |
|  | 46 -> s\_AppCacheRpcDeleteIeGroup |
|  | 47 -> s\_AppCacheRpcGetFallbackUrl |
|  | 48 -> s\_AppCacheRpcGetDownloadList |
|  | 49 -> s\_AppCacheRpcCloseHandle |
|  | 50 -> s\_AppCacheRpcInvalidate |
|  | 51 -> s\_AppCacheRpcGetInfo |
|  | 52 -> s\_AppCacheRpcGetGroupsList |
|  | 53 -> s\_AppCacheRpcFreeSpace |
|  | 54 -> s\_AppCacheRpcGetIeGroupList |
|  | 55 -> s\_AppCacheRpcFreeIeSpace |
|  | 56 -> s\_AppCacheRpcRetrieveUrl |
|  | 57 -> s\_AppCacheRpcCommitUrl |
|  | 58 -> s\_AppCacheRpcUpdateExtraData |
|  | 59 -> s\_AppCacheRpcFinalize |
|  | 60 -> s\_DependencyStoreOpenContainer |
|  | 61 -> s\_DependencyStoreCloseContainer |
|  | 62 -> s\_DependencyStoreUpdateUrl |
|  | 63 -> s\_DependencyStoreRetrieveUrl |
|  | 64 -> s\_DependencyStoreDeleteContainer |
|  | 65 -> s\_HstsOpenContainer |
|  | 66 -> s\_HstsCloseContainer |
|  | 67 -> s\_HstsGetHstsEntries |
|  | 68 -> s\_HstsSetHstsEntries |
|  | 69 -> s\_HstsPurgeContainer |
|  | 70 -> s\_CookieOpenContainer |
|  | 71 -> s\_CookieCloseContainer |
|  | 72 -> s\_CookieGetCookies |
|  | 73 -> s\_CookieGetAllCookies |
|  | 74 -> s\_CookieUpdateCookies |
|  | 75 -> s\_CookiePurgeContainer |
|  | 76 -> s\_BlobOpenContainer |
|  | 77 -> s\_BlobCloseContainer |
|  | 78 -> s\_BlobGetEntries |
|  | 79 -> s\_BlobGetEntry |
|  | 80 -> s\_BlobSetEntry |
|  | 81 -> s\_BlobDeleteEntry |
|  | 82 -> s\_BlobPurgeContainer |
|  | Endpoints : |
|  | ncalrpc : PlaySoundKRpc2 |
|  | ncalrpc : webcache\_{031b98cf-4a69-4c31-ab42-fd9b3c199407}\_S-1-5-21-4215984009-642367717-812980365-1001 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SynTPEnh.exe" pid 6452 at 0x5dd8160L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "igfxEM.exe" pid 11140 at 0x5dd8be0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | Endpoints : |
|  | ncalrpc : OLE14D78EDFC7080A30BC7850BC37F3 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "explorer.exe" pid 11004 at 0x5dd8470L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE de8ed432-fd92-47a6-9c73-738c7b466c69 (0.0) -- IAppReadinessTaskCallback |
|  | OLE 76c0dbbb-15e0-4e7b-b61b-20eeea2001e0 (0.0) -- IAccPropServer |
|  | OLE 00000160-0000-0000-c000-000000000046 (0.0) -- IPrivDragDrop |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 8b14e88b-5663-4caf-b196-c31479262831 (0.0) -- IImmersiveApplication |
|  | OLE cb728b20-f786-11ce-92ad-00aa00a74cd0 (0.0) -- IProfferService |
|  | OLE 6d5140c1-7436-11ce-8034-00aa006009fa (0.0) -- IServiceProvider |
|  | OLE 7702e77c-66f6-479b-af2b-e316cff5f814 (0.0) -- IAsyncCallbackDispatcher |
|  | OLE 000214e3-0000-0000-c000-000000000046 (0.0) -- IShellView |
|  | OLE 00000114-0000-0000-c000-000000000046 (0.0) -- IOleWindow |
|  | OLE cd17328b-e4ef-4215-a92d-62a914658f82 (0.0) -- IObjectWithCachedState |
|  | OLE d1b9407f-a351-5319-bce5-178ee5585391 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CShell\_\_CViewManagerInterop\_\_CIViewWrapper\_Windows\_\_CInternal\_\_CShell\_\_CViewManagerInterop\_\_CIViewEventArgs |
|  | OLE b755e6e0-b048-49cc-8911-11a041216f5f (0.0) -- IApplicationStateChangeHandler |
|  | OLE 940c223d-5bdc-49db-968c-e4f3ef9b9270 (0.0) -- IImmersiveMonitorNotification |
|  | OLE 727f9e97-76ee-497b-a942-b6371328485c (0.0) -- IApplicationViewChangeListener |
|  | OLE ea8a389b-437d-4791-aa14-5dca004bc92a (0.0) -- IAsyncCallback |
|  | OLE 6592b66a-4a51-5ccc-82c5-9042acf93a44 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CShellExperienceDispatcher\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CIShellExperienceViewStateChangedEventArgs |
|  | OLE 1b7781cd-1b97-4728-8b6e-67a7e55cc53c (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIPeopleBarFlyoutExperienceManager |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE ab65b025-ff88-470a-9513-b62bcd7ce879 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIPeopleBarJumpViewExperienceManager |
|  | OLE 8667db0d-6960-465f-b9a4-c461863efa91 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIShoulderTapExperienceManager |
|  | OLE df65db57-d504-456e-8bd7-004ce308d8d9 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIActionCenterExperienceManager |
|  | OLE 87324ffd-bd0a-4de8-840a-b60e345a336f (0.0) -- ISettingsFlowController |
|  | OLE 90adbab9-cdb8-43dd-8daa-ba1180be5215 (0.0) -- IMultitaskingViewServiceProvider |
|  | OLE 103231ae-04cb-4e5e-b63d-e3ce47cd0f0a (0.0) -- IImmersiveAppCrusher |
|  | OLE 373e56cf-0a1b-4b4a-a1a4-a46b25ffd7e3 (0.0) -- ITabletModeViewManager |
|  | OLE fff59320-db70-4865-8fed-8b502d692f12 (0.0) -- ISnapServiceProvider |
|  | OLE 6a5e657d-223a-4875-838b-c311ed73523b (0.0) -- IImmersiveLayoutChanges |
|  | OLE 6584ce6b-7d82-49c2-89c9-c6bc02ba8c38 (0.0) -- IAppVisibilityEvents |
|  | OLE 00000001-0000-0000-c000-000000000046 (0.0) -- IClassFactory |
|  | OLE e87e2bc9-ec45-4ddb-95e1-b275d66cbeaa (0.0) -- IApplicationPreLaunch |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 537b455d-1240-433b-82af-10929138b8be (0.0) -- IMultitaskingViewManager |
|  | OLE a5322dff-9ebc-5df1-953d-0237cea8614b (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserChangedEventArgs |
|  | OLE ccb96d97-791c-5741-8f33-fb7266d6ea33 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserChangedEventArgs |
|  | OLE 6e6c3c52-5a5e-4b4b-a0f8-7fe12621a93e (0.0) -- IEdgeUiManager |
|  | OLE bcf1f74f-2413-46b3-8707-ec2fca11965d (0.0) -- IImmersiveLauncherTrayNotify |
|  | OLE 5090de35-ed23-43be-9714-586c5041026a (0.0) -- IHolographicViewTransitionNotificationService |
|  | OLE d8d60399-a0f1-f987-5551-321fd1b49864 (0.0) -- IImmersiveLauncher |
|  | OLE c50898f6-c536-5f47-8583-8b2c2438a13b (0.0) -- Windows.Foundation.IEventHandler<IInspectable> |
|  | OLE 99fc44e3-ce9a-4284-bf04-76331d1b1788 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CIInitializeActivatedEventArgs |
|  | OLE cf651713-cd08-4fd8-b697-a281b6544e2e (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CIActivatedEventArgs |
|  | OLE 7ca84d06-f54c-4ba8-bd6f-9abaf9380d51 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CIMultiviewActivationProperties |
|  | OLE 0c44717b-19f7-48d6-b046-cf22826eaa74 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CIPrelaunchActivatedEventArgs |
|  | OLE fbc93e26-a14a-4b4f-82b0-33bed920af52 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CActivation\_CILaunchActivatedEventArgs |
|  | OLE 9767060c-9476-42e2-8f7b-2f10fd13765c (0.0) -- IImmersiveShellBroker |
|  | OLE fec0a504-8e6c-40ff-8a92-f7d693afdcf0 (0.0) -- IShellExperienceBroker |
|  | OLE 99e01be7-d840-6dfb-694f-8814c2ec727e (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIStartExperienceBroker |
|  | OLE a16f3786-6cb0-4258-a21e-d949edaa7a18 (0.0) -- IApplicationGlomBroker |
|  | OLE 796be4b3-0fb1-415d-9984-0bc8b72e5fa2 (0.0) -- IFullScreenBroker |
|  | OLE 988881d6-4fa0-4554-86b0-25911104973a (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIStartUserInfoBroker |
|  | OLE 905a0fe1-bc53-11df-8c49-001e4fc686da (0.0) -- \_\_x\_Windows\_CFoundation\_CIByteSeeker |
|  | OLE bb94daad-7836-4d62-9557-2a7b83839b7b (0.0) -- ISafeSaveHandleManager |
|  | OLE f4ee3175-aba2-4df7-b53c-93c4e4e2b0a3 (0.0) -- IRefCountedClosable |
|  | OLE 5e0ebc87-bece-4f2a-8d36-3673758f6c55 (0.0) -- IFileHandle |
|  | OLE fa9812c4-0b34-47d0-9b0b-157fb5b5fdf2 (0.0) -- IDuplicateHandleProvider |
|  | OLE 04c2542d-3c28-4510-a0c0-8db0e0a3a526 (0.0) -- IDuplicateHandleProvider2 |
|  | OLE 68766f36-3808-42f9-a18f-0abde6391172 (0.0) -- IAdviseOplockCallback |
|  | OLE 2e8fcb18-a0ee-41ad-8ef8-77fb3a370ca5 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIShellExperienceManagerFactory |
|  | OLE 599db028-e1d3-433d-9f90-32468634d59e (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIInputDialExperienceManager |
|  | OLE 13c6456c-c8eb-4f83-91b8-9d425f546210 (0.0) -- INotificationControllerDataSink |
|  | OLE 85cb6900-4d95-11cf-960c-0080c7f4ee85 (0.0) -- IShellWindows |
|  | OLE 00020400-0000-0000-c000-000000000046 (0.0) -- IDispatch |
|  | OLE 71538e01-5877-4d2d-ac1a-ff42b6da910d (0.0) -- IWpnSettingCallback |
|  | OLE 1ec5d3ef-a8bf-4311-9eeb-33ba50f461fe (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIBaseExperienceManager |
|  | OLE 3c4367fa-99ac-52c0-964d-0dcd1a9ba729 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CIBaseExperienceManager\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CIVisibilityChangedEventArgs |
|  | OLE 7ab93c52-0e48-4750-ba9d-1a4113981847 (0.0) -- IToastNotificationManagerStatics2 |
|  | OLE 5caddc63-01d3-4c97-986f-0533483fee14 (0.0) -- IToastNotificationHistory |
|  | OLE d133ce13-3537-48ba-93a7-afcd5d2053b4 (0.0) -- ITrayNotify |
|  | OLE 71ba143f-598e-49d0-84eb-8febaedcc195 (0.0) -- INetworkStatusChangedEventHandler |
|  | OLE af581601-f71a-4a31-8f8d-91f7df79371f (0.0) -- \_\_x\_SharedStartModel\_CIStartLayoutInitializationStatics |
|  | OLE 1bf3dc4c-07a0-4f3f-87f8-5a625cd2e7ad (0.0) -- IImmersiveAppCrusherNotification |
|  | OLE 76bb2cfb-c246-41ec-b9c3-671e5347cf51 (0.0) -- IHolographicViewTransitionNotification |
|  | OLE c092cc2f-5eca-5a5d-9c9c-f050e892dd97 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountAddedEventArgs |
|  | OLE dc8b9f35-216c-54ff-99db-cd7e04c6a074 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountChangedEventArgs |
|  | OLE 104e5d12-179f-597c-80ce-18627ceeb8b6 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountDeletePendingEventArgs |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 27354133-7f64-5b0f-8f00-5d77afbe261e (0.0) -- IDiscRecorder2 |
|  | OLE 27354132-7f64-5b0f-8f00-5d77afbe261e (0.0) -- IDiscRecorder2Ex |
|  | OLE 27354153-9f64-5b0f-8f00-5d77afbe261e (0.0) -- IDiscFormat2Data |
|  | OLE e716b283-6be7-4e6f-a88f-1cde47d5e355 (0.0) -- IWpnPresentationTileSink |
|  | OLE 78c8b458-dd5a-4f32-9d8b-d45a19ae9e1f (0.0) -- IActiveZBandNotificationForMonitor |
|  | OLE 0000000c-0000-0000-c000-000000000046 (0.0) -- IStream |
|  | OLE bfb02fed-4c71-40e1-b4f3-ce99c2ff0542 (0.0) -- IObjectWithFileHandle |
|  | OLE c179334c-4295-40d3-bea1-c654d965605a (0.0) -- IVirtualDesktopNotification |
|  | OLE 2c1448e1-7540-41b2-9b0d-188c012da2f1 (0.0) -- IShellTargetingChangeNotification |
|  | OLE 000214e6-0000-0000-c000-000000000046 (0.0) -- IShellFolder |
|  | OLE 000214ea-0000-0000-c000-000000000046 (0.0) -- IPersistFolder |
|  | OLE 0000010c-0000-0000-c000-000000000046 (0.0) -- IPersist |
|  | OLE 321a6a6a-d61f-4bf3-97ae-14be2986bb36 (0.0) -- IObjectWithBackReferences |
|  | OLE 1ac3d9f0-175c-11d1-95be-00609797ea4f (0.0) -- IPersistFolder2 |
|  | OLE e014d578-d95e-4757-bffb-3bda010fe68a (0.0) -- IAutomaticDestinationList2 |
|  | OLE 5632b1a4-e38a-400a-928a-d4cd63230295 (0.0) -- IObjectCollection |
|  | OLE 49a07732-e7b8-5c5b-9de7-22e33cb97004 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CApplicationModel\_\_CActivation\_\_CBackgroundActivatedEventArgs |
|  | OLE 4f9c5cec-0197-49fe-b800-0d5a72a6c505 (0.0) -- IUiaWindowNotifierCallback |
|  | OLE 2dbdba9d-20da-519d-9078-09f835bc5bc7 (0.0) -- ITypedEventHandler<UISettings,IInspectable> |
|  | OLE d4351e8c-208e-4c24-88ac-6e2add5f4bb1 (0.0) -- IApplicationViewBroker |
|  | OLE 2166ee67-71df-4476-8394-0ced2ed05274 (0.0) -- IInputHostManagerBroker |
|  | OLE 50ac103f-d235-4598-bbef-98fe4d1a3ad4 (0.0) -- IToastNotificationManagerStatics |
|  | OLE 75927b93-03f3-41ec-91d3-6e5bac1b38e7 (0.0) -- IToastNotificationManager |
|  | OLE 04124b20-82c6-4229-b109-fd9ed4662b53 (0.0) -- IToastNotificationFactory |
|  | OLE a3fa4101-4713-4f91-a8f1-93a4573ec5a7 (0.0) -- IWpnNotification |
|  | OLE bebf1b6f-4d08-4e3e-9902-a256a285c970 (0.0) -- ITransientNotificationDetails |
|  | OLE 4f38fd3e-2c10-4c00-9ec1-62bd536a1feb (0.0) -- IWpnToastFeedback |
|  | OLE 35176862-cfd4-44f8-ad64-f500fd896c3b (0.0) -- IToastFailedEventArgs |
|  | OLE 95e3e803-c969-5e3a-9753-ea2ad22a9a33 (0.0) -- ITypedEventHandler\_2\_Windows\_\_CUI\_\_CNotifications\_\_CToastNotification\_Windows\_\_CUI\_\_CNotifications\_\_CToastFailedEventArgs |
|  | OLE a7052211-8b56-43c4-8f26-12852f7303a3 (0.0) -- INowPlayingSessionManager |
|  | OLE 22ba7cc0-8e75-484f-844e-0b6d74105413 (0.0) -- IGlobalRudeWindowNotifications |
|  | OLE b722bccb-4e68-101b-a2bc-00aa00404770 (0.0) -- IOleCommandTarget |
|  | OLE 7154c95d-c519-49bd-a97e-645bbfabe111 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CITrayMtcUvcFlyoutExperienceManager |
|  | OLE 8cecdf70-ced8-5bc7-84a7-d80615fedcdd (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CShell\_\_CViewManagerInterop\_\_CIClientWindowState\_Windows\_\_CInternal\_\_CShell\_\_CViewManagerInterop\_\_CIClientWindowReadyForPresentationChangedEventArgs |
|  | OLE 0c40987c-7026-499e-adad-c164c0ffee84 (0.0) -- IActiveZBandNotification |
|  | OLE 8d4d1ec2-4740-4fc5-b4b1-6dc3722a2eeb (0.0) -- ILightDismissNotification |
|  | OLE a5cd92ff-29be-454c-8d04-d82879fb3f1b (0.0) -- IVirtualDesktopManager |
|  | OLE b196b284-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPointContainer |
|  | OLE b196b286-bab4-101a-b69c-00aa00341d07 (0.0) -- IConnectionPoint |
|  | OLE 50a87baa-5f79-4c31-b6b3-28f6f2d097e6 (0.0) -- IExplorerHost |
|  | OLE 9c4960d4-7626-4e13-beec-1adad82ff5a0 (0.0) -- IThreadUndoManager |
|  | OLE d001f200-ef97-11ce-9bc9-00aa00608e01 (0.0) -- IOleUndoManager |
|  | OLE f2153260-232e-4474-9d0a-9f2ab153441d (0.0) -- IVerbStateTaskCallBack |
|  | OLE 35bd3360-1b35-4927-bae4-b10e70d99eff (0.0) -- IFrameTaskManager |
|  | OLE cde725b0-ccc9-4519-917e-325d72fab4ce (0.0) -- IFolderView |
|  | OLE 76542021-fff8-43f3-acbd-bb46a60a94ca (0.0) -- IExplorerFrame |
|  | OLE f66724ea-ae8f-41a2-b3f3-3d6581ea891c (0.0) -- IRibbonTabsetCallBack |
|  | OLE b3a4b685-b685-4805-99d9-5dead2873236 (0.0) -- IParentAndItem |
|  | OLE ef01eb89-5a19-42cb-bc8c-f10ed6c6791b (0.0) -- ISyncIntegrationManager |
|  | OLE 0002df05-0000-0000-c000-000000000046 (0.0) -- IWebBrowserApp |
|  | OLE 00000122-0000-0000-c000-000000000046 (0.0) -- IDropTarget |
|  | OLE fc992f1f-debb-4596-b355-50c7a6dd1222 (0.0) -- IWaitCursorManager |
|  | OLE 0000010e-0000-0000-c000-000000000046 (0.0) -- IDataObject |
|  | OLE 00000103-0000-0000-c000-000000000046 (0.0) -- IEnumFORMATETC |
|  | OLE 1aba2312-77b6-44d7-b975-cce3f3d3fb2f (0.0) -- ISyncStatusProvider |
|  | OLE ad6db2cf-0c8d-438b-b25d-9a9a82903b2b (0.0) -- IWindow |
|  | OLE 1b988c32-1bc7-52fa-83ba-0b97e79c878b (0.0) -- IAsyncOperationCompletedHandler<AppReputationResult> |
|  | OLE 7724f749-b79e-42a0-aa9e-878b498f26ec (0.0) -- IWsDocumentUpdate |
|  | OLE a4ed5c81-76c9-40bd-8be6-b1d90fb20ae7 (0.0) -- IAsyncActionCompletedHandler |
|  | OLE 58a98b87-ed3c-4e12-b5df-c72bf4470aee (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIJumpViewExperienceManager |
|  | OLE 28536166-c75b-5df1-99ca-96967f7d999a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CJumpViewExperienceManager\_Windows\_\_CInternal\_\_CShell\_\_CExperience\_\_CJumpViewExperienceEventArgs |
|  | OLE 6d5174ec-f425-4cd9-8643-cf36042987f1 (0.0) -- IOperationStatusService |
|  | OLE 4ae7498c-e1c0-475f-8573-41c26127c5d8 (0.0) -- IOperationStatusTile |
|  | OLE 000214e2-0000-0000-c000-000000000046 (0.0) -- IShellBrowser |
|  | OLE 831d1dff-7f57-4720-87e4-cb57d6214428 (0.0) -- IInvocationLocation |
|  | OLE 9536ca39-1acb-4ae6-ad27-2403d04ca28f (0.0) -- IShellItemBrowser |
|  | OLE 8f45ef43-0585-4881-a90d-f55d35ce7797 (0.0) -- IOperationInterrupt |
|  | OLE 6faf1156-8855-47b5-bdc8-4555d13c095f (0.0) -- IConflictInterrupt |
|  | OLE c7c67cb1-44ae-4e71-9e69-2c92f8d732fc (0.0) -- IConflictItemDataCallback |
|  | OLE b1604325-6b59-427b-bf1b-80a2db02d3d8 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CITrayClockFlyoutExperienceManager |
|  | OLE d597bab3-5b9f-11d1-8dd2-00aa004abd5e (0.0) -- ISensLogon |
|  | OLE c853771a-f336-4cf8-9a27-1570293ab52d (0.0) -- ILockScreenDirectorServiceProvider |
|  | OLE 6119bcc6-cac2-4d37-9bbf-76a34697e7fb (0.0) -- ILockScreenDirector |
|  | OLE a2aa05aa-47af-4b4a-8e77-6cd6efe35cda (0.0) -- ILockScreenDirectorPrivate |
|  | OLE c59766f7-d190-4f69-a822-05ca45b201e7 (0.0) -- ILockAppHost |
|  | OLE a40cce11-67ee-4e74-8c46-91edb265261c (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CILockScreenExperienceManager |
|  | OLE 0689ac07-5db1-488b-bc6d-9dfbc2cf7911 (0.0) -- ILockAppHostSafeguard |
|  | OLE a340ae45-86bf-4c9c-b6c8-6109ca1e2f29 (0.0) -- IImmersiveSessionIdleDetector |
|  | OLE 985c98a3-21f6-4585-9e13-f708cb0de4f2 (0.0) -- IImmersiveSessionIdleNotification |
|  | OLE 72163aa1-8a18-436a-9067-3a86aa7460dc (0.0) -- ILockAppHostShellInterop |
|  | OLE 053bf212-5a22-4a75-87eb-dfca4ea90e02 (0.0) -- ILockScreenViewManager |
|  | OLE 989e63bd-43c5-4815-b192-2251e9a6e452 (0.0) -- ILockScreenViewManagerNotificationCallback |
|  | OLE 7c7a3e75-4362-4d12-860d-68ee72909f83 (0.0) -- IImmersiveMonitorNotificationService |
|  | OLE ce2ad461-c28a-4db3-b9d7-b7d8f6865657 (0.0) -- ILockAppHostEndpoint |
|  | OLE 3721d4ef-bca1-418a-98e2-ec3def272b2f (0.0) -- IAboveLockActivationManager |
|  | OLE dcb00007-570f-4a9b-8d69-199fdba5723b (0.0) -- INetworkConnectionEvents |
|  | OLE dcb00004-570f-4a9b-8d69-199fdba5723b (0.0) -- INetworkEvents |
|  | OLE dcb00009-570f-4a9b-8d69-199fdba5723b (0.0) -- INetworkCostManagerEvents |
|  | OLE 880b26f8-9197-43d0-8045-8702d0d72000 (0.0) -- IImmersiveMonitor |
|  | OLE fc413902-2a24-4522-ad1f-2d27c0ffee84 (0.0) -- IDesktopVisibilityChangesNotification |
|  | OLE 5ef7890f-319b-4259-8d0f-36e5ff0916ce (0.0) -- IImmersiveLauncherCortana |
|  | OLE 016f611a-b360-4768-8b28-6779ddfde2e0 (0.0) -- |
|  | OLE 6ee8a11f-f5f0-4feb-8b78-a69aaa8a2a6a (0.0) -- IUpFrontConfirmation |
|  | OLE 47e7bb4d-2d83-4604-905c-0ee8eab077a4 (0.0) -- IConfirmationInterrupt |
|  | OLE 55272a00-42cb-11ce-8135-00aa004bb851 (0.0) -- IPropertyBag |
|  | OLE 9d923edc-b7a9-4f77-9933-284e7e2b2536 (0.0) -- IObjectWithOpenWithFlags |
|  | OLE fc4801a3-2ba9-11cf-a229-00aa003d7352 (0.0) -- IObjectWithSite |
|  | OLE 1af3a467-214f-4298-908e-06b03e0b39f9 (0.0) -- IFolderView2 |
|  | OLE 667708d1-a931-4a85-9999-609eaa7dd85a (0.0) -- ILocalCopyDownloadSettings |
|  | OLE 4d4c1e64-e410-4faa-bafa-59ca069bfec2 (0.0) -- IImmersiveMonitorManager |
|  | OLE d770b2ad-8f5e-4b8e-b3df-f05a2ab5287c (0.0) -- IImmersiveLayout |
|  | OLE b849acb5-8ac5-4fb8-88b6-55c749d25a44 (0.0) -- ILightDismissProvider |
|  | OLE bf63999f-7411-40da-861c-df72c0ffee84 (0.0) -- IImmersiveApplicationManager |
|  | OLE 405444d2-baa5-48ed-abfe-a673f70be863 (0.0) -- IAltTabViewHost |
|  | OLE c59a7a3c-0676-4526-8192-5d0bf9b89b95 (0.0) -- IMultitaskingViewVisibilityNotification |
|  | OLE ff62716a-0bd0-4105-a6ec-83b09d864267 (0.0) -- IShellPositionerManager |
|  | OLE 95e1216b-c9d8-4d0c-aa1b-19a86de9aa5b (0.0) -- IShellPositionerProxy |
|  | OLE 2ad63a67-f12f-4bd7-b1bf-6213290a552a (0.0) -- IUIAutomationCrossThreadRelease |
|  | OLE f7041e23-1a6c-41bb-89b2-b3425c51ccd5 (0.0) -- IExplorerWindowManager |
|  | OLE 00000135-0000-0000-c000-000000000046 (0.0) -- IInterfaceFromWindowProp |
|  | OLE 3d8b0590-f691-11d2-8ea9-006097df5bd4 (0.0) -- IDataObjectAsyncCapability |
|  | OLE 93f2f68c-1d1b-11d3-a30e-00c04f79abd1 (0.0) -- IShellFolder2 |
|  | OLE cef04fdf-fe72-11d2-87a5-00c04f6837cf (0.0) -- IPersistFolder3 |
|  | OLE 0000000e-0000-0000-c000-000000000046 (0.0) -- IBindCtx |
|  | OLE 8a4427de-b11b-4a61-8977-844a3a7bc63b (0.0) -- IJumpViewExecuteHelper |
|  | OLE b3e7c340-ef97-11ce-9bc9-00aa00608e01 (0.0) -- IEnumOleUndoUnits |
|  | OLE 31e4fa78-02b4-419f-9430-7b7585237c77 (0.0) -- IFrameManager |
|  | OLE b92b56a9-8b55-4e14-9a89-0199bbb6f93b (0.0) -- IDesktopWallpaper |
|  | OLE 4473e3a7-c2ad-4075-a1f8-935a584740a9 (0.0) -- IStateEvents |
|  | OLE dcb07fdc-3bb5-451c-90be-966644fed7b0 (0.0) -- INewMenuClient |
|  | OLE 538317c5-5bad-4847-962d-42da294f5e0a (0.0) -- IHolographicViewManager |
|  | OLE 4fda780a-acd2-41f7-b4f2-ebe674c9bf2a (0.0) -- ITabletModeController |
|  | OLE dcf1427b-9f2f-4bb5-8aa2-ec625e2b2082 (0.0) -- IJumpViewContextMenuWrapper |
|  | Endpoints : |
|  | ncalrpc : OLE6540C7DFAE33DDD8108A8FDE0EE7 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SynTPHelper.exe" pid 1892 at 0x5dd85f8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ClassicStartMenu.exe" pid 1900 at 0x5dd89b0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ShellExperienceHost.exe" pid 2852 at 0x5dd8ba8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\Windows\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 92696c00-7578-48e1-ac1a-2ca909e2c8cf (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CIActivatableApplication |
|  | OLE 638bb2db-451d-4661-b099-414f34ffb9f1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationView |
|  | OLE 49a07732-e7b8-5c5b-9de7-22e33cb97004 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CApplicationModel\_\_CActivation\_\_CBackgroundActivatedEventArgs |
|  | OLE 2e5500b6-66ad-467f-abb5-022a64283d88 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationViewInternal |
|  | OLE 4f9c5cec-0197-49fe-b800-0d5a72a6c505 (0.0) -- IUiaWindowNotifierCallback |
|  | OLE abadfe7f-04c1-4a9f-9b3c-a323f1c80178 (0.0) -- IScaleChangeSink |
|  | OLE c50898f6-c536-5f47-8583-8b2c2438a13b (0.0) -- Windows.Foundation.IEventHandler<IInspectable> |
|  | OLE 2dbdba9d-20da-519d-9078-09f835bc5bc7 (0.0) -- ITypedEventHandler<UISettings,IInspectable> |
|  | OLE 7d56d344-8464-4faf-aa49-37ea6e2d7bd1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CDataTransfer\_CDragDrop\_CCore\_CICoreDragDropManager |
|  | OLE cd292360-2763-4085-8a9f-74b224a29175 (0.0) -- \_\_x\_Windows\_CUI\_CCore\_CICoreWindowFactory |
|  | OLE 087ca5a4-8cfc-4264-b39d-da2bb2583a11 (0.0) -- ICoreWindowFactoryPriv |
|  | OLE 92cee296-66e6-4678-984a-579e02c88be6 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationViewForceMarshal |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE f5917e6f-5abf-5e65-b5b4-1b9c8d94e788 (0.0) -- ITypedEventHandler<AccessibilitySettings,IInspectable> |
|  | OLE a5322dff-9ebc-5df1-953d-0237cea8614b (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserChangedEventArgs |
|  | OLE ccb96d97-791c-5741-8f33-fb7266d6ea33 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserChangedEventArgs |
|  | OLE fcaeac67-4e77-49c7-b856-dde934fc735b (0.0) -- ILanguageFontGroupFactory |
|  | OLE 00000037-0000-0000-c000-000000000046 (0.0) -- IWeakReference |
|  | OLE a2cd1ad4-df0a-4566-9407-de425b84cc21 (0.0) -- IAsyncWPNInit |
|  | OLE 118ec4a0-443d-467d-b568-de895db52e7b (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CInternal\_CINotifySubscription |
|  | OLE 00000038-0000-0000-c000-000000000046 (0.0) -- IWeakReferenceSource |
|  | OLE 06386a7a-e009-5b0b-ab68-a8e48b516647 (0.0) -- \_\_FIAsyncOperationWithProgressCompletedHandler\_2\_Windows\_\_CStorage\_\_CStreams\_\_CIBuffer\_UINT32 |
|  | OLE 9d4966fa-dbd1-4799-a07f-6a5e1991bda4 (0.0) -- IOplockCallbackEventHandler |
|  | OLE 1726f52d-2b8c-524a-98c6-f2cf0893c0f2 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageStagingEventArgs |
|  | OLE a8a900c6-da0b-5bcc-a71a-be0b9265d87a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageInstallingEventArgs |
|  | OLE c23e15f6-c618-522a-82ab-4fab36665ce5 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageUpdatingEventArgs |
|  | OLE b32d7d63-cd0e-5c2e-a251-fb8d290824e4 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CPackageCatalog\_Windows\_\_CApplicationModel\_\_CPackageStatusChangedEventArgs |
|  | OLE f9e87849-b323-eefa-3204-8a2d2d2b4432 (0.0) -- IImageQueueManager |
|  | OLE e716b283-6be7-4e6f-a88f-1cde47d5e355 (0.0) -- IWpnPresentationTileSink |
|  | OLE 6030e7c3-f93f-5e9c-9ba2-9a018d2b09c0 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CSystem\_\_CAppMemoryUsageLimitChangingEventArgs |
|  | OLE 24a0bf18-6849-4d99-9fc8-48bcabace467 (0.0) -- IHandleDuplicator |
|  | OLE a4ed5c81-76c9-40bd-8be6-b1d90fb20ae7 (0.0) -- IAsyncActionCompletedHandler |
|  | OLE 2ad63a67-f12f-4bd7-b1bf-6213290a552a (0.0) -- IUIAutomationCrossThreadRelease |
|  | OLE e2663f37-2e1b-500c-ad68-c3ed7a8f74c8 (0.0) -- MapChangedEventHandler<HSTRING,HSTRING> |
|  | OLE 60141efb-f2f9-5377-96fd-f8c60d9558b5 (0.0) -- IMapChangedEventArgs<HSTRING> |
|  | OLE c1635471-1417-4750-811f-a6122953c5a3 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CExperience\_CIShellExperiencePrivate |
|  | OLE 13c6456c-c8eb-4f83-91b8-9d425f546210 (0.0) -- INotificationControllerDataSink |
|  | OLE c30dfc1c-e392-4d02-ae09-a8ebf08cbc75 (0.0) -- SystemSettings.DataModel.ISettingsEnvironmentChangedHandler |
|  | OLE 1ada0e3e-e4a2-4123-b451-dc96bf800419 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreImmersiveApplication |
|  | OLE dc471c97-550a-573c-9a01-f94a67aa3850 (0.0) -- \_\_FITypedEventHandler\_2\_IInspectable\_HSTRING |
|  | Endpoints : |
|  | ncalrpc : OLE621C086970BFB63B18AFA3AA98E9 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SearchUI.exe" pid 8484 at 0x5dd8048L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 92696c00-7578-48e1-ac1a-2ca909e2c8cf (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CIActivatableApplication |
|  | OLE 638bb2db-451d-4661-b099-414f34ffb9f1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationView |
|  | OLE 49a07732-e7b8-5c5b-9de7-22e33cb97004 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CApplicationModel\_\_CActivation\_\_CBackgroundActivatedEventArgs |
|  | OLE 2e5500b6-66ad-467f-abb5-022a64283d88 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationViewInternal |
|  | OLE 4f9c5cec-0197-49fe-b800-0d5a72a6c505 (0.0) -- IUiaWindowNotifierCallback |
|  | OLE abadfe7f-04c1-4a9f-9b3c-a323f1c80178 (0.0) -- IScaleChangeSink |
|  | OLE c50898f6-c536-5f47-8583-8b2c2438a13b (0.0) -- Windows.Foundation.IEventHandler<IInspectable> |
|  | OLE 2dbdba9d-20da-519d-9078-09f835bc5bc7 (0.0) -- ITypedEventHandler<UISettings,IInspectable> |
|  | OLE 7d56d344-8464-4faf-aa49-37ea6e2d7bd1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CDataTransfer\_CDragDrop\_CCore\_CICoreDragDropManager |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 297445d3-fb63-4135-8909-4e354c061466 (0.0) -- \_\_x\_Windows\_CSecurity\_CAuthentication\_COnlineId\_CIOnlineIdServiceTicketRequest |
|  | OLE e2663f37-2e1b-500c-ad68-c3ed7a8f74c8 (0.0) -- MapChangedEventHandler<HSTRING,HSTRING> |
|  | OLE 60141efb-f2f9-5377-96fd-f8c60d9558b5 (0.0) -- IMapChangedEventArgs<HSTRING> |
|  | OLE 350e1244-4575-45ee-8595-0aa8c6506fc7 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CBackground\_CIBackgroundWorkManagerInternal |
|  | OLE 6030e7c3-f93f-5e9c-9ba2-9a018d2b09c0 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CSystem\_\_CAppMemoryUsageLimitChangingEventArgs |
|  | Endpoints : |
|  | ncalrpc : OLE1057BCC4108AB8B473FAE4C58C00 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RuntimeBroker.exe" pid 9524 at 0x5dd8240L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 6040ec14-6557-41f9-a3f7-b1cab7b42120 (0.0) -- IRuntimeBroker |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 50a5378f-a64e-4d5a-a911-6342b5ff64c0 (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CInternal\_CISubscriptionManager |
|  | OLE ca2f34cf-283f-453e-b2d2-841b8c2f5c34 (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CInternal\_CITargetedContentCacheReader |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 2f92b529-119b-575a-a419-3904b4e41af2 (0.0) -- IAsyncOperation<IVectorView<HSTRING> > |
|  | OLE 5cc754cf-f82f-471b-ba04-1783588b7144 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CInternal\_CIPackageCatalogInternalStatics |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 230a3751-9de3-4445-be74-91fb325abefe (0.0) -- \_\_x\_Windows\_CApplicationModel\_CIPackageCatalog |
|  | OLE 96a60c36-8ff7-4344-b6bf-ee64c2207ed2 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CIPackageCatalog2 |
|  | OLE 96dd5c88-8837-43f9-9015-033434ba14f3 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CIPackageCatalog3 |
|  | OLE c37c399b-44cc-4b7b-8baf-796c04ead3b9 (0.0) -- |
|  | OLE 2f13c006-a03a-5f69-b090-75a43e33423e (0.0) -- IVectorView<HSTRING> |
|  | OLE 2363a8f9-4138-4c23-a8a4-83fbeecaddc6 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CStartUI\_CITileImageHelperStatics |
|  | OLE 430ecece-1418-5d19-81b2-5ddb381603cc (0.0) -- IAsyncOperation<Windows.Storage.Streams.IRandomAccessStream> |
|  | OLE 905a0fe1-bc53-11df-8c49-001e4fc686da (0.0) -- \_\_x\_Windows\_CFoundation\_CIByteSeeker |
|  | OLE 0000000c-0000-0000-c000-000000000046 (0.0) -- IStream |
|  | OLE fa9812c4-0b34-47d0-9b0b-157fb5b5fdf2 (0.0) -- IDuplicateHandleProvider |
|  | OLE bfb02fed-4c71-40e1-b4f3-ce99c2ff0542 (0.0) -- IObjectWithFileHandle |
|  | OLE 07353932-5353-4df4-94a3-e45d56087018 (0.0) -- SystemSettings.DataModel.ISettingsBroker |
|  | OLE acbe964b-0eed-4d11-9ca9-fdeb63598d2e (0.0) -- SystemSettings.DataModel.ISettingsEnvironmentDatabase |
|  | Endpoints : |
|  | ncalrpc : OLECBB99B2C014572673CE0DC6E6C2A |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RuntimeBroker.exe" pid 10048 at 0x5dd8208L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 6040ec14-6557-41f9-a3f7-b1cab7b42120 (0.0) -- IRuntimeBroker |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE a67b287f-cfe4-43e4-ac63-f74ae08662b9 (0.0) -- \_\_x\_Windows\_CCortana\_CIMSAManagerStatics |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE eb2c0c45-76f9-4a0a-bb73-fcf47d73a4eb (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CWebAuthentication\_CIAuthenticationManager |
|  | OLE cd6f56ba-a90a-5556-a48f-36a097b3ce5c (0.0) -- \_\_FIAsyncOperation\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CWebAuthentication\_\_CUserHostIdentity |
|  | OLE 552b1888-ef6b-4b24-83b2-350ebcd2d7f1 (0.0) -- \_\_x\_Windows\_CCortana\_CIDeviceAccessHelperStatics |
|  | OLE e826ea58-66a9-4d41-83d4-b4c18c87b846 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CBackground\_CIBackgroundExecutionManagerStatics |
|  | OLE b32c133c-e4dd-43a0-b85c-b0e5717683c5 (0.0) -- Windows.Internal.ACGISecurityBroker |
|  | OLE 79882e54-c2ae-4f76-9577-9fe028b48255 (0.0) -- \_\_x\_Windows\_CInternal\_CSecurity\_CWebAuthentication\_CIUserHostIdentity |
|  | OLE 45f03233-e7a8-5ade-9ff3-0b8a1c6ba76b (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_COnlineId\_\_COnlineIdServiceTicket |
|  | OLE c95c547f-d781-4a94-acb8-c59874238c26 (0.0) -- \_\_x\_Windows\_CSecurity\_CAuthentication\_COnlineId\_CIOnlineIdServiceTicket |
|  | Endpoints : |
|  | ncalrpc : OLEE329B116515B4E5F36843BA8E1F7 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ctfmon.exe" pid 11040 at 0x5dd84a8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "nvtray.exe" pid 11888 at 0x5dd87b8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "NvBackend.exe" pid 2112 at 0x5dd8630L> |
|  | 32 |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "MsiTrueColor.exe" pid 12528 at 0x5df2710L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | Endpoints : |
|  | ncalrpc : OLEBFA864DE5B79E1170E71423156F4 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "MsiTrueColorHelper.exe" pid 13136 at 0x5df2ac8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "unsecapp.exe" pid 12240 at 0x5df2898L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 1cfaba8c-1523-11d1-ad79-00c04fd8fdff (0.0) -- IUnsecuredApartment |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE 04963311-c399-408e-ad51-05d01506eed0 (0.0) -- \_IWmiObjectSinkSecurity |
|  | Endpoints : |
|  | ncalrpc : OLEC4B0D8CD5D4D9AF72D731D4318BA |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SCM.exe" pid 1104 at 0x5df20b8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000160-0000-0000-c000-000000000046 (0.0) -- IPrivDragDrop |
|  | OLE 7c857801-7381-11cf-884d-00aa004b2e24 (0.0) -- IWbemObjectSink |
|  | OLE 9556dc99-828c-11cf-a37e-00aa003240c7 (0.0) -- IWbemServices |
|  | Endpoints : |
|  | ncalrpc : OLE12AAE303D38FCDAB183C6DA2640D |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RtkNGUI64.exe" pid 12072 at 0x5df2400L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLE1C92AAFAD9BAEC51921326AF6C08 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "Nahimic2UILauncher.exe" pid 9048 at 0x5df2b70L> |
|  | 32 |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "Nahimic2Svc32.exe" pid 12968 at 0x5df2668L> |
|  | 32 |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "Nahimic2Svc64.exe" pid 7196 at 0x5df22e8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "NetworkManager.exe" pid 3088 at 0x5df27f0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLEBD4B50B33D4F513D28548FDE65E1 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SteelSeriesEngine3.exe" pid 3512 at 0x5df2a20L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "IAStorIcon.exe" pid 1440 at 0x5df2208L> |
|  | 32 |
|  | \[!!\] Invalid bitness |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 2540 at 0x57eddd8L> |
|  | 64 |
|  | \['OneSyncSvc\_184a7aba', 'PimIndexMaintenanceSvc\_184a7aba', 'UnistoreSvc\_184a7aba', 'UserDataSvc\_184a7aba'\] |
|  |  |
|  | Interfaces : |
|  | RPC d2716e94-25cb-4820-bc15-537866578562 (1.0) -- c:\\windows\\system32\\aphostservice.dll |
|  | 0 -> ServerRPC\_SubmitJob |
|  | 1 -> ServerRPC\_GetPendingJobs |
|  | 2 -> ServerRPC\_RetryJobById |
|  | 3 -> ServerRPC\_CancelJobById |
|  | 4 -> ServerRPC\_AdviseNotifications |
|  | 5 -> ServerRPC\_SubscribeNextNotification |
|  | 6 -> ServerRPC\_RegisterAppId |
|  | 7 -> ServerRPC\_UnadviseNotifications |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | RPC 0c53aa2e-fb1c-49c5-bfb6-c54f8e5857cd (1.0) -- C:\\Windows\\System32\\SyncController.dll |
|  | 0 -> ActiveSyncServer\_QuerySyncStatusProps |
|  | 1 -> ActiveSyncServer\_QueryLastSyncResult |
|  | 2 -> ActiveSyncServer\_SetPassword |
|  | 3 -> ActiveSyncServer\_CopyCredentials |
|  | 4 -> ActiveSyncServer\_DeletePassword |
|  | 5 -> ActiveSyncServer\_IsPasswordSet |
|  | 6 -> ActiveSyncServer\_CreateDataStoreLock |
|  | 7 -> ActiveSyncServer\_CloseDataStoreLock |
|  | 8 -> ActiveSyncServer\_SetConversationSyncEnabled |
|  | 9 -> ActiveSyncServer\_GetConversationSyncEnabled |
|  | 10 -> ActiveSyncServer\_SetUnifiedInboxEnabled |
|  | 11 -> ActiveSyncServer\_GetUnifiedInboxEnabled |
|  | 12 -> ActiveSyncServer\_GetUnifiedInboxServerValue |
|  | 13 -> ActiveSyncServer\_GetUserInfoForUnconfiguredAccount |
|  | RPC e8748f69-a2a4-40df-9366-62dbeb696e26 (0.0) -- c:\\windows\\system32\\unistore.dll |
|  | 0 -> USSvcImpl\_Object\_Close |
|  | 1 -> USSvcImpl\_RegisterRundownProtection |
|  | 2 -> USSvcImpl\_ConvertToOtherObject |
|  | 3 -> USSvcImpl\_Manager\_Create |
|  | 4 -> USSvcImpl\_Manager\_CreateStoreGrouping |
|  | 5 -> USSvcImpl\_Manager\_CreateStore |
|  | 6 -> USSvcImpl\_Manager\_GetDeviceStore |
|  | 7 -> USSvcImpl\_Manager\_GetDeviceStoreOid |
|  | 8 -> USSvcImpl\_Manager\_GetHighestStoreBitPosition |
|  | 9 -> USSvcImpl\_Manager\_GetStore |
|  | 10 -> USSvcImpl\_Manager\_GetStoreCollection |
|  | 11 -> USSvcImpl\_Manager\_Notify |
|  | 12 -> USSvcImpl\_Manager\_CustomNotify |
|  | 13 -> USSvcImpl\_Manager\_GetObjectByOid |
|  | 14 -> USSvcImpl\_Manager\_GetAllEmbeddedObjects |
|  | 15 -> USSvcImpl\_Manager\_GetAllItems |
|  | 16 -> USSvcImpl\_Manager\_GetTypeManager |
|  | 17 -> USSvcImpl\_Manager\_StartTransaction |
|  | 18 -> USSvcImpl\_Manager\_EndTransaction |
|  | 19 -> USSvcImpl\_Manager\_CleanupTombstones |
|  | 20 -> USSvcImpl\_Manager\_GetStreamFilePath |
|  | 21 -> USSvcImpl\_Manager\_CleanupTemporaryFolders |
|  | 22 -> USSvcImpl\_Manager\_GetAllAggregateObjects |
|  | 23 -> USSvcImpl\_Manager\_GetAllObjects |
|  | 24 -> USSvcImpl\_Manager\_GetBatchedPropValsFromIdsBlob |
|  | 25 -> USSvcImpl\_Manager\_GetPropValsFromIdBlob |
|  | 26 -> USSvcImpl\_Manager\_MapNamedProps |
|  | 27 -> USSvcImpl\_Manager\_GetDefaultPIMStoreId |
|  | 28 -> USSvcImpl\_Manager\_SetDefaultPIMStoreId |
|  | 29 -> USSvcImpl\_Manager\_GetUnistoreDatabaseRefreshTime |
|  | 30 -> USSvcImpl\_ManagerPriv\_put\_DeviceStoreId |
|  | 31 -> USSvcImpl\_ManagerPriv\_GetNotificationsManager |
|  | 32 -> USSvcImpl\_ManagerPriv\_UnmapNamedProps |
|  | 33 -> USSvcImpl\_ManagerPriv\_GetPerfStats |
|  | 34 -> USSvcImpl\_ManagerPriv\_ResetPerfStats |
|  | 35 -> USSvcImpl\_ManagerPriv\_ToggleRecordingPerfStats |
|  | 36 -> USSvcImpl\_ManagerPriv\_BackupStoreVolume |
|  | 37 -> USSvcImpl\_ManagerPriv\_SetToSuspending |
|  | 38 -> USSvcImpl\_ManagerPriv\_SetToResumed |
|  | 39 -> USSvcImpl\_NotificationManager\_Advise |
|  | 40 -> USSvcImpl\_NotificationManager\_Unadvise |
|  | 41 -> USSvcImpl\_NotificationManager\_Notify |
|  | 42 -> USSvcImpl\_NotificationManager\_SuspendNotifications |
|  | 43 -> USSvcImpl\_NotificationManager\_ResumeNotifications |
|  | 44 -> USSvcImpl\_NotificationManager\_FilterProcessEventsForTests |
|  | 45 -> USSvcImpl\_NotificationManager\_GetAdviseContent |
|  | 46 -> USSvcImpl\_Object\_GetOid |
|  | 47 -> USSvcImpl\_Object\_Delete |
|  | 48 -> USSvcImpl\_Object\_GetPropValsBlob |
|  | 49 -> USSvcImpl\_Object\_GetAllPropValsBlob |
|  | 50 -> USSvcImpl\_Object\_SetPropVals |
|  | 51 -> USSvcImpl\_Object\_SetPropValsEx |
|  | 52 -> USSvcImpl\_Object\_SetStreamProperty |
|  | 53 -> USSvcImpl\_Object\_GetStreamProp |
|  | 54 -> USSvcImpl\_Object\_GetStore |
|  | 55 -> USSvcImpl\_Object\_GetStreamFilePath |
|  | 56 -> USSvcImpl\_Object\_GetAssociatedItems |
|  | 57 -> USSvcImpl\_Object\_CreateEmbeddedObject |
|  | 58 -> USSvcImpl\_Object\_DeleteEmbeddedObjects |
|  | 59 -> USSvcImpl\_Object\_GetEmbeddedObjects |
|  | 60 -> USSvcImpl\_Object\_IncrementRevision |
|  | 61 -> USSvcImpl\_Store\_GetRootFolder |
|  | 62 -> USSvcImpl\_Store\_GetObjectByOid |
|  | 63 -> USSvcImpl\_Store\_CreateAssociateObject |
|  | 64 -> USSvcImpl\_Store\_GetAssociateObjects |
|  | 65 -> USSvcImpl\_Store\_GetEmbeddedObjects |
|  | 66 -> USSvcImpl\_Store\_GetTypeManager |
|  | 67 -> USSvcImpl\_Store\_Flush |
|  | 68 -> USSvcImpl\_Store\_AddSyncPartner |
|  | 69 -> USSvcImpl\_Store\_GetSyncPartner |
|  | 70 -> USSvcImpl\_Store\_GetSyncPartners |
|  | 71 -> USSvcImpl\_Store\_StartFetchSession |
|  | 72 -> USSvcImpl\_Store\_EndFetchSession |
|  | 73 -> USSvcImpl\_Store\_ThreadInFetchSession |
|  | 74 -> USSvcImpl\_Store\_CreateAggregateObject |
|  | 75 -> USSvcImpl\_Store\_GetAggregateObjects |
|  | 76 -> USSvcImpl\_Store\_GetDeletedRevisionItems |
|  | 77 -> USSvcImpl\_Store\_GetLongDeletedRevisionItems |
|  | 78 -> USSvcImpl\_Store\_ResetLongRevisionChangeTracking |
|  | 79 -> USSvcImpl\_Store\_UpdateLongRevisionChangeTracking |
|  | 80 -> USSvcImpl\_Store\_GetLongRevision |
|  | 81 -> USSvcImpl\_Store\_IsObjectRevisionTracked |
|  | 82 -> USSvcImpl\_Store\_GetFolders |
|  | 83 -> USSvcImpl\_Store\_GetStoreGrouping |
|  | 84 -> USSvcImpl\_Folder\_CreateFolder |
|  | 85 -> USSvcImpl\_Folder\_CreateItem |
|  | 86 -> USSvcImpl\_Folder\_DeleteItems |
|  | 87 -> USSvcImpl\_Folder\_GetChildFolders |
|  | 88 -> USSvcImpl\_Folder\_GetItems |
|  | 89 -> USSvcImpl\_Folder\_GetAllItems |
|  | 90 -> USSvcImpl\_Folder\_GetParent |
|  | 91 -> USSvcImpl\_Folder\_IsEmpty |
|  | 92 -> USSvcImpl\_Folder\_CopyToFolder |
|  | 93 -> USSvcImpl\_Folder\_MoveToFolder |
|  | 94 -> USSvcImpl\_Item\_DeleteWithFlags |
|  | 95 -> USSvcImpl\_Item\_GetParent |
|  | 96 -> USSvcImpl\_Item\_CopyToFolder |
|  | 97 -> USSvcImpl\_Item\_MoveToFolder |
|  | 98 -> USSvcImpl\_Item\_AssociateObject |
|  | 99 -> USSvcImpl\_Item\_DeleteAssociations |
|  | 100 -> USSvcImpl\_Item\_DeleteAllAssociations |
|  | 101 -> USSvcImpl\_Item\_GetAssociateObjects |
|  | 102 -> USSvcImpl\_Item\_GetAggregateObject |
|  | 103 -> USSvcImpl\_Item\_AggregateObject |
|  | 104 -> USSvcImpl\_Item\_DeleteAggregation |
|  | 105 -> USSvcImpl\_EmbeddeObject\_GetItem |
|  | 106 -> USSvcImpl\_EmbeddedObject\_GetObject |
|  | 107 -> USSvcImpl\_AssociatedObject\_HasItems |
|  | 108 -> USSvcImpl\_AggregateObject\_GetAggregatedObjects |
|  | 109 -> USSvcImpl\_ObjectCollection\_GetCount |
|  | 110 -> USSvcImpl\_ObjectCollection\_GetCurrentIndex |
|  | 111 -> USSvcImpl\_ObjectCollection\_GetObject |
|  | 112 -> USSvcImpl\_ObjectCollection\_GetPropValsBlob |
|  | 113 -> USSvcImpl\_ObjectCollection\_GetBatchedPropValsBlob |
|  | 114 -> USSvcImpl\_ObjectCollection\_SetPropValsOnAll |
|  | 115 -> USSvcImpl\_ObjectCollection\_GetAllPropValsBlob |
|  | 116 -> USSvcImpl\_ObjectCollection\_Oid |
|  | 117 -> USSvcImpl\_ObjectCollection\_GetBookmark |
|  | 118 -> USSvcImpl\_ObjectCollection\_Move |
|  | 119 -> USSvcImpl\_ObjectCollection\_DeleteAllObjects |
|  | 120 -> USSvcImpl\_SyncPartnerEnum\_Next |
|  | 121 -> USSvcImpl\_SyncPartnerEnum\_Skip |
|  | 122 -> USSvcImpl\_SyncPartnerEnum\_Reset |
|  | 123 -> USSvcImpl\_SyncPartnerEnum\_Clone |
|  | 124 -> USSvcImpl\_TypeManager\_MapNamedProps |
|  | 125 -> USSvcImpl\_TypeManager\_GetSchemaPropertiesFromObjectType |
|  | 126 -> USSvcImpl\_Stream\_Seek |
|  | 127 -> USSvcImpl\_Stream\_SetSize |
|  | 128 -> USSvcImpl\_Stream\_Commit |
|  | 129 -> USSvcImpl\_Stream\_Revert |
|  | 130 -> USSvcImpl\_Stream\_LockRegion |
|  | 131 -> USSvcImpl\_Stream\_UnlockRegion |
|  | 132 -> USSvcImpl\_Stream\_Stat |
|  | 133 -> USSvcImpl\_Stream\_Clone |
|  | 134 -> USSvcImpl\_Stream\_Read |
|  | 135 -> USSvcImpl\_Stream\_Write |
|  | 136 -> USSvcImpl\_SyncPartner\_GetPropsBlob |
|  | 137 -> USSvcImpl\_SyncPartner\_SetProps |
|  | 138 -> USSvcImpl\_SyncPartner\_GetName |
|  | 139 -> USSvcImpl\_SyncPartner\_GetGuid |
|  | 140 -> USSvcImpl\_SyncPartner\_GetStoreId |
|  | 141 -> USSvcImpl\_SyncPartner\_GetPartnerId |
|  | 142 -> USSvcImpl\_SyncPartner\_EnableFolderForSync |
|  | 143 -> USSvcImpl\_SyncPartner\_IsFolderEnabledForSync |
|  | 144 -> USSvcImpl\_SyncPartner\_HasChanges |
|  | 145 -> USSvcImpl\_SyncPartner\_GetChangeCount |
|  | 146 -> USSvcImpl\_SyncPartner\_StartSyncSession |
|  | 147 -> USSvcImpl\_SyncPartner\_StartSyncSessionNoContext |
|  | 148 -> USSvcImpl\_SyncPartner\_GetNextChange |
|  | 149 -> USSvcImpl\_SyncPartner\_GetChangeForObject |
|  | 150 -> USSvcImpl\_SyncPartner\_SetExceptionOnChange |
|  | 151 -> USSvcImpl\_SyncPartner\_SetExceptionOnChangeUnits |
|  | 152 -> USSvcImpl\_SyncPartner\_ResetChangeEnumeration |
|  | 153 -> USSvcImpl\_SyncPartner\_EndSyncSession |
|  | 154 -> USSvcImpl\_SyncPartner\_GetRootFolder |
|  | 155 -> USSvcImpl\_SyncPartner\_LookupFolderObjectId |
|  | 156 -> USSvcImpl\_SyncPartner\_LookupFolderRemoteId |
|  | 157 -> USSvcImpl\_SyncPartner\_GetFolders |
|  | 158 -> USSvcImpl\_SyncPartner\_LookupItemObjectId |
|  | 159 -> USSvcImpl\_SyncPartner\_UpdateSyncPartnerSchema |
|  | 160 -> USSvcImpl\_SyncPartner\_Delete |
|  | 161 -> USSvcImpl\_SyncPartner\_SetMeetingResponse |
|  | 162 -> USSvcImpl\_SyncPartner\_GetAllMeetingResponses |
|  | 163 -> USSvcImpl\_SyncPartner\_DefragmentKnowledge |
|  | 164 -> USSvcImpl\_ObjectMetadata\_GetPropsBlob |
|  | 165 -> USSvcImpl\_ObjectMetadata\_SetProps |
|  | 166 -> USSvcImpl\_ObjectMetadata\_GetObjectId |
|  | 167 -> USSvcImpl\_ObjectMetadata\_GetPartner |
|  | 168 -> USSvcImpl\_ObjectMetadata\_GetRemoteId |
|  | 169 -> USSvcImpl\_ObjectMetadata\_SetRemoteId |
|  | 170 -> USSvcImpl\_ObjectMetadata\_GetParent |
|  | 171 -> USSvcImpl\_ObjectMetadata\_SetParent |
|  | 172 -> USSvcImpl\_ItemMetadata\_Move |
|  | 173 -> USSvcImpl\_ItemMetadata\_SetMeetingResponse |
|  | 174 -> USSvcImpl\_ItemMetadata\_GetMeetingResponses |
|  | 175 -> USSvcImpl\_ItemMetadata\_Delete |
|  | 176 -> USSvcImpl\_FolderMetadata\_GetFolderName |
|  | 177 -> USSvcImpl\_FolderMetadata\_GetFolderType |
|  | 178 -> USSvcImpl\_FolderMetadata\_GetRemoteKnowledge |
|  | 179 -> USSvcImpl\_FolderMetadata\_SetRemoteKnowledge |
|  | 180 -> USSvcImpl\_FolderMetadata\_AddItem |
|  | 181 -> USSvcImpl\_FolderMetadata\_LookupItemObjectId |
|  | 182 -> USSvcImpl\_FolderMetadata\_LookupItemRemoteId |
|  | 183 -> USSvcImpl\_FolderMetadata\_GetItems |
|  | 184 -> USSvcImpl\_FolderMetadata\_AddFolder |
|  | 185 -> USSvcImpl\_FolderMetadata\_LookupFolderObjectId |
|  | 186 -> USSvcImpl\_FolderMetadata\_LookupFolderRemoteId |
|  | 187 -> USSvcImpl\_FolderMetadata\_GetChildFolders |
|  | 188 -> USSvcImpl\_FolderMetadata\_Delete |
|  | 189 -> USSvcImpl\_FolderMetadata\_DeleteInBatches |
|  | 190 -> USSvcImpl\_MeetingResponse\_GetResponseId |
|  | 191 -> USSvcImpl\_MeetingResponse\_GetMeetingMetadata |
|  | 192 -> USSvcImpl\_MeetingResponse\_GetMeetingPermanentId |
|  | 193 -> USSvcImpl\_MeetingResponse\_GetMeetingInstanceId |
|  | 194 -> USSvcImpl\_MeetingResponse\_GetResponseType |
|  | 195 -> USSvcImpl\_MeetingResponse\_GetMeetingUserComments |
|  | 196 -> USSvcImpl\_MeetingResponse\_GetPlaceholderMeetingObjectId |
|  | 197 -> USSvcImpl\_MeetingResponse\_GetPropsBlob |
|  | 198 -> USSvcImpl\_MeetingResponse\_SetProps |
|  | 199 -> USSvcImpl\_MeetingResponse\_Delete |
|  | 200 -> USSvcImpl\_ItemMetadataEnum\_Next |
|  | 201 -> USSvcImpl\_ItemMetadataEnum\_Skip |
|  | 202 -> USSvcImpl\_ItemMetadataEnum\_Reset |
|  | 203 -> USSvcImpl\_ItemMetadataEnum\_Clone |
|  | 204 -> USSvcImpl\_FolderMetadataEnum\_Next |
|  | 205 -> USSvcImpl\_FolderMetadataEnum\_Skip |
|  | 206 -> USSvcImpl\_FolderMetadataEnum\_Reset |
|  | 207 -> USSvcImpl\_FolderMetadataEnum\_Clone |
|  | 208 -> USSvcImpl\_EnumMeetingResponses\_Next |
|  | 209 -> USSvcImpl\_EnumMeetingResponses\_Skip |
|  | 210 -> USSvcImpl\_EnumMeetingResponses\_Reset |
|  | 211 -> USSvcImpl\_EnumMeetingResponses\_Clone |
|  | RPC c8ba73d2-3d55-429c-8e9a-c44f006f69fc (0.0) -- c:\\windows\\system32\\userdataservice.dll |
|  | 0 -> UdmSvcImpl\_CloseEnumHandle |
|  | 1 -> UdmSvcImpl\_CloseSessionHandle |
|  | 2 -> UdmSvcImpl\_OpenSession |
|  | 3 -> UdmSvcImpl\_CreateSessionWithSameSecurityContext |
|  | 4 -> UdmSvcImpl\_OpenCallHistorySession |
|  | 5 -> UdmSvcImpl\_EnableProcessForTesting |
|  | 6 -> UdmSvcImpl\_EnableUserDataServiceBackgroundNotification |
|  | 7 -> UdmSvcImpl\_CheckObjectExistence |
|  | 8 -> UdmSvcImpl\_GetObjectProperties |
|  | 9 -> UdmSvcImpl\_GetObjectPropertiesWithScope |
|  | 10 -> UdmSvcImpl\_GetAppointmentProperties |
|  | 11 -> UdmSvcImpl\_GetCallHistoryEnum |
|  | 12 -> UdmSvcImpl\_DeleteCallHistory |
|  | 13 -> UdmSvcImpl\_MarkCallHistorySeen |
|  | 14 -> UdmSvcImpl\_CreateCallHistoryItem |
|  | 15 -> UdmSvcImpl\_GetUnseenCallCount |
|  | 16 -> UdmSvcImpl\_UpdateCallDetails |
|  | 17 -> UdmSvcImpl\_ResolveCalls |
|  | 18 -> UdmSvcImpl\_GetCallHistoryEntryEnum |
|  | 19 -> UdmSvcImpl\_UpdateEnumPropertySet |
|  | 20 -> UdmSvcImpl\_EnumFetchObjects |
|  | 21 -> UdmSvcImpl\_EnumFetchMatchingObjects |
|  | 22 -> UdmSvcImpl\_EnumGetCount |
|  | 23 -> UdmSvcImpl\_EnumGetState |
|  | 24 -> UdmSvcImpl\_EnumMoveFirst |
|  | 25 -> UdmSvcImpl\_EnumMoveLast |
|  | 26 -> UdmSvcImpl\_CreateCallFavoriteItem |
|  | 27 -> UdmSvcImpl\_DeleteCallFavorite |
|  | 28 -> UdmSvcImpl\_MoveCallFavoriteItem |
|  | 29 -> UdmSvcImpl\_ReorderGroups |
|  | 30 -> UdmSvcImpl\_ResolveFavorites |
|  | 31 -> UdmSvcImpl\_GetCallFavoriteEnum |
|  | 32 -> UdmSvcImpl\_ControlSessionNotifies |
|  | 33 -> UdmSvcImpl\_Advise |
|  | 34 -> UdmSvcImpl\_Unadvise |
|  | 35 -> UdmSvcImpl\_HasNotifications |
|  | 36 -> UdmSvcImpl\_GetNotifyMessage |
|  | 37 -> UdmSvcImpl\_GetFilePropertyStream |
|  | 38 -> UdmSvcImpl\_UpdateCallHistoryObjects |
|  | 39 -> UdmSvcImpl\_UpdateCalendarObjects |
|  | 40 -> UdmSvcImpl\_GetUnexpandedAppointmentEnum |
|  | 41 -> UdmSvcImpl\_GetCalendarEnum |
|  | 42 -> UdmSvcImpl\_GetAppointmentEnum |
|  | 43 -> UdmSvcImpl\_GetSingleAppointmentEnum |
|  | 44 -> UdmSvcImpl\_GetAppointmentSearchEnum |
|  | 45 -> UdmSvcImpl\_GetAppointmentExceptionEnum |
|  | 46 -> UdmSvcImpl\_GetAppointmentRevisionEnum |
|  | 47 -> UdmSvcImpl\_GetConflictInfoById |
|  | 48 -> UdmSvcImpl\_GetConflictInfoByProperties |
|  | 49 -> UdmSvcImpl\_GetAppointmentAppInfo |
|  | 50 -> UdmSvcImpl\_GetLocalIdArrayFromAppointmentRemoteObjectId |
|  | 51 -> UdmSvcImpl\_SetAutoReplySettings |
|  | 52 -> UdmSvcImpl\_GetAutoReplySettings |
|  | 53 -> UdmSvcImpl\_StartOrResetChangeTracking |
|  | 54 -> UdmSvcImpl\_ValidateCallerAccess |
|  | 55 -> UdmSvcImpl\_GenerateValidationToken |
|  | 56 -> UdmSvcImpl\_RedeemValidationToken |
|  | 57 -> UdmSvcImpl\_DeleteAllPackageData |
|  | 58 -> UdmSvcImpl\_CleanupStaleAppData |
|  | 59 -> UdmSvcImpl\_UpdateChatObjects |
|  | 60 -> UdmSvcImpl\_UpdateChangeTracking |
|  | 61 -> UdmSvcImpl\_ValidateChatMessage |
|  | 62 -> UdmSvcImpl\_GetChatObjectProperties |
|  | 63 -> UdmSvcImpl\_GetChatMessageEnum |
|  | 64 -> UdmSvcImpl\_GetChatRevisionMessageEnum |
|  | 65 -> UdmSvcImpl\_EnumFetchChatMessages |
|  | 66 -> UdmSvcImpl\_GetChatConversationEnum |
|  | 67 -> UdmSvcImpl\_GetChatSearchEnum |
|  | 68 -> UdmSvcImpl\_GetChatConversationIdFromThreadingInfo |
|  | 69 -> UdmSvcImpl\_GetChatTransports |
|  | 70 -> UdmSvcImpl\_RegisterChatTransport |
|  | 71 -> UdmSvcImpl\_GetChatApps |
|  | 72 -> UdmSvcImpl\_GetDefaultChatApp |
|  | 73 -> UdmSvcImpl\_SetDefaultChatApp |
|  | 74 -> UdmSvcImpl\_NotifyChatApp |
|  | 75 -> UdmSvcImpl\_UpdateAnnotationObjects |
|  | 76 -> UdmSvcImpl\_GetContactMatchSuggestions |
|  | 77 -> UdmSvcImpl\_UpdateContactObjects |
|  | 78 -> UdmSvcImpl\_ContactLinking |
|  | 79 -> UdmSvcImpl\_SetContactPreference |
|  | 80 -> UdmSvcImpl\_SetRemoteIdentificationInformation |
|  | 81 -> UdmSvcImpl\_GetMeContactId |
|  | 82 -> UdmSvcImpl\_VCardToContact |
|  | 83 -> UdmSvcImpl\_ContactToVCard |
|  | 84 -> UdmSvcImpl\_SetContactNameOrder |
|  | 85 -> UdmSvcImpl\_SetContactNameIncludeMiddle |
|  | 86 -> UdmSvcImpl\_ToggleContactMaintenance |
|  | 87 -> UdmSvcImpl\_GetObjectByRemoteId |
|  | 88 -> UdmSvcImpl\_GetAnnotationListEnum |
|  | 89 -> UdmSvcImpl\_GetContactListEnum |
|  | 90 -> UdmSvcImpl\_GetContactEnum |
|  | 91 -> UdmSvcImpl\_GetAnnotationEnum |
|  | 92 -> UdmSvcImpl\_GetContactRevisionEnum |
|  | 93 -> UdmSvcImpl\_UpdateEmailObjects |
|  | 94 -> UdmSvcImpl\_GetEmailFolderMessageCounts |
|  | 95 -> UdmSvcImpl\_GetEmailMailboxEnum |
|  | 96 -> UdmSvcImpl\_GetEmailFolderEnum |
|  | 97 -> UdmSvcImpl\_GetEmailRevisionEnum |
|  | 98 -> UdmSvcImpl\_GetEmailMessageEnum |
|  | 99 -> UdmSvcImpl\_GetEmailConversationEnum |
|  | 100 -> UdmSvcImpl\_IsChangeTrackingEnabled |
|  | 101 -> UdmSvcImpl\_EmptyEmailFolder |
|  | 102 -> UdmSvcImpl\_CreateResponseMessage |
|  | 103 -> UdmSvcImpl\_MoveFolder |
|  | 104 -> UdmSvcImpl\_CreateFolder |
|  | 105 -> UdmSvcImpl\_RespondToMeeting |
|  | 106 -> UdmSvcImpl\_ForwardMeeting |
|  | 107 -> UdmSvcImpl\_ProposeNewTimeForMeeting |
|  | 108 -> UdmSvcImpl\_ResolveRecipients |
|  | 109 -> UdmSvcImpl\_ValidateCertificates |
|  | 110 -> UdmSvcImpl\_GetMessageIdFromAttachmentId |
|  | 111 -> UdmSvcImpl\_RegisterSyncManager |
|  | 112 -> UdmSvcImpl\_SyncObject |
|  | 113 -> UdmSvcImpl\_GetUserDataAccountEnum |
|  | 114 -> UdmSvcImpl\_UpdateUserDataAccountObjects |
|  | 115 -> UdmSvcImpl\_MakeDefaultAccount |
|  | 116 -> UdmSvcImpl\_GetCachedChatCapabilities |
|  | 117 -> UdmSvcImpl\_GetChatCapabilitiesFromNetwork |
|  | 118 -> UdmSvcImpl\_GetRcsServiceStatus |
|  | 119 -> UdmSvcImpl\_SendLocalParticipantComposing |
|  | 120 -> UdmSvcImpl\_RaiseRemoteParticipantComposing |
|  | 121 -> UdmSvcImpl\_AdviseForConversationComposingStatusChanges |
|  | 122 -> UdmSvcImpl\_UnadviseFromConversationComposingStatusChanges |
|  | 123 -> UdmSvcImpl\_GetChatCloudServiceSettings |
|  | 124 -> UdmSvcImpl\_SetChatCloudServiceSettings |
|  | 125 -> UdmSvcImpl\_UpdateRcsEndUserMessage |
|  | 126 -> UdmSvcImpl\_StartCloudServiceSync |
|  | 127 -> UdmSvcImpl\_UpdateTaskObjects |
|  | 128 -> UdmSvcImpl\_GetTaskListEnum |
|  | 129 -> UdmSvcImpl\_GetTaskEnum |
|  | 130 -> UdmSvcImpl\_UpdateContactGroupObjects |
|  | 131 -> UdmSvcImpl\_GetContactGroupEnum |
|  | 132 -> UdmSvcImpl\_GetContactGroupMemberEnum |
|  | RPC 43890c94-bfd7-4655-ad6a-b4a68397cdcb (0.0) -- c:\\windows\\system32\\pimindexmaintenance.dll |
|  | 0 -> PimIMService\_UpdateStores |
|  | 1 -> PimIMService\_UpdateItems |
|  | 2 -> PimIMService\_RebuildAggregateCache |
|  | 3 -> PimIMService\_Suspend |
|  | 4 -> PimIMService\_Resume |
|  | 5 -> PimIMService\_CacheAggregateCacheFileMapping |
|  | 6 -> PimIMService\_LoadAggregateCache |
|  | 7 -> PimIMService\_CreateIndexedFilter |
|  | 8 -> PimIMService\_SetStaticFilter |
|  | 9 -> PimIMService\_GetIndexedProperties |
|  | 10 -> PimIMService\_FindNextServerMatch |
|  | 11 -> PimIMService\_SetFilter |
|  | 12 -> PimIMService\_Reset |
|  | 13 -> PimIMService\_CloseIndexedFilter |
|  | RPC 923c9623-db7f-4b34-9e6d-e86580f8ca2a (1.0) -- C:\\Windows\\System32\\SyncController.dll |
|  | 0 -> AccountsMgmtRpcCreateAccount |
|  | 1 -> AccountsMgmtRpcDeleteAccount |
|  | 2 -> AccountsMgmtRpcConvertWebAccountIdFromAppSpecificId |
|  | 3 -> AccountsMgmtRpcConvertWebAccountIdToAppSpecificId |
|  | 4 -> AccountsMgmtRpcSyncAccount |
|  | 5 -> AccountsMgmtRpcSyncAccountAndWaitForCompletion |
|  | 6 -> AccountsMgmtRpcQueryAccountProperties |
|  | 7 -> AccountsMgmtRpcSaveAccountProperties |
|  | 8 -> AccountsMgmtRpcEnumAccounts |
|  | 9 -> AccountsMgmtRpcAdviseAccount |
|  | 10 -> AccountsMgmtRpcUnadviseAccount |
|  | 11 -> AccountsMgmtRpcGetNotifications |
|  | 12 -> AccountsMgmtRpcDiscoverExchangeServerConfig |
|  | 13 -> AccountsMgmtRpcDiscoverExchangeServerAuthType |
|  | 14 -> AccountsMgmtRpcVerifyExchangeMailBoxTokenAuth |
|  | 15 -> AccountsMgmtRpcDiscoverInternetMailServerConfig |
|  | 16 -> AccountsMgmtRpcCancelDiscoverInternetMailServerConfig |
|  | 17 -> AccountsMgmtRpcMayIgnoreInvalidServerCertificate |
|  | OLE c092cc2f-5eca-5a5d-9c9c-f050e892dd97 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountAddedEventArgs |
|  | OLE dc8b9f35-216c-54ff-99db-cd7e04c6a074 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountChangedEventArgs |
|  | OLE df3657fc-19c8-5e99-b48f-4a59b98d4e8a (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CTokenBrokerInternal\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CWebAccountDeletedEventArgs |
|  | OLE 51aa6c40-b054-5c68-801e-03b75f43e2a1 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CInternal\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CGetDefaultSignInAccountResult |
|  | OLE 9477622b-1340-5574-81fc-5013581f57c9 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccountProvider |
|  | OLE 4bd6f1e5-ca89-5240-8f3d-7f1b54ae90a7 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CCredentials\_\_CWebAccount |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE deb54b22-70f2-55ab-97c0-6cbdc5ddb6f0 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenRequestResult |
|  | OLE ac7f26f2-feb7-5b2a-8ac4-345bc62caede (0.0) -- IMapView<HSTRING,HSTRING> |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | OLE 199e065c-8195-55da-9c10-8aeaf9ac1062 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CSecurity\_\_CAuthentication\_\_CWeb\_\_CCore\_\_CWebTokenResponse |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 8142b78c-3c08-53fe-a74e-506063c49063 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_PhoneInternal\_\_CExperiences\_\_CSync\_\_CAccount |
|  | OLE a4ed5c81-76c9-40bd-8be6-b1d90fb20ae7 (0.0) -- IAsyncActionCompletedHandler |
|  | OLE 62e9e23a-de30-5736-b0e5-9e9925442328 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_PhoneInternal\_\_CExperiences\_\_CSync\_\_CAccountStatus |
|  | OLE 826bd12f-c1bb-5730-bf72-05db739871ae (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_PhoneInternal\_\_CExperiences\_\_CSync\_\_CAccountErrorInformation |
|  | OLE c1f995d7-c911-57c7-99e0-38239f48cfe1 (0.0) -- \_\_FIAsyncOperationCompletedHandler\_1\_PhoneInternal\_\_CExperiences\_\_CSync\_\_CAccountSyncScheduleInformation |
|  | Endpoints : |
|  | ncalrpc : LRPC-a792c135343a94d522 |
|  | ncalrpc : OLEB787535FB75A9891F1EF1878FDC8 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "ProcessHacker.exe" pid 372 at 0x5df26d8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "TrustedInstaller.exe" pid 5924 at 0x5df23c8L> |
|  | 64 |
|  | \['TrustedInstaller'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 839d7762-5121-4009-9234-4f0d19394f04 (0.0) -- ITaskHandler |
|  | OLE 365de52e-ee7e-4975-aec8-06588234bb3c (0.0) -- ITrustedInstallerService |
|  | RPC c9ac6db5-82b7-4e55-ae8a-e464ed7b4277 (1.0) -- C:\\WINDOWS\\SYSTEM32\\SysNtfy.dll |
|  | 0 -> s\_OnInitialConnection |
|  | 1 -> s\_OnCreateSession |
|  | 2 -> s\_OnStartScreenSaverAsDefaultUser |
|  | 3 -> s\_OnStopScreenSaverAsDefaultUser |
|  | 4 -> s\_OnLogon |
|  | 5 -> s\_OnLock |
|  | 6 -> s\_OnUnlock |
|  | 7 -> s\_OnStartScreenSaverAsUser |
|  | 8 -> s\_OnStopScreenSaverAsUser |
|  | 9 -> s\_OnDisconnect |
|  | 10 -> s\_OnReconnect |
|  | 11 -> s\_OnLogoff |
|  | 12 -> s\_OnTerminateSession |
|  | 13 -> s\_OnStartShell |
|  | 14 -> s\_OnEndShell |
|  | OLE 75207391-23f2-4396-85f0-8fdb879ed0ed (0.0) -- ICbsSession |
|  | OLE f568c899-af4f-4eaa-b12a-b8e5f1b219de (0.0) -- ICbsSession8 |
|  | OLE 75207393-23f2-4396-85f0-8fdb879ed0ed (0.0) -- ICbsPackage |
|  | OLE 9c7e3cf3-4c97-4d36-bdeb-e3093c228c22 (0.0) -- ICbsSession9 |
|  | OLE 75207392-23f2-4396-85f0-8fdb879ed0ed (0.0) -- ICbsUIHandler |
|  | OLE a69c1e5a-5e02-4f6c-bc7d-2c47407ff617 (0.0) -- ICbsUIHandler8 |
|  | Endpoints : |
|  | ncalrpc : OLECF2785D903096AC007F929FDF195 |
|  | ncalrpc : LRPC-176764d40c88472d4a |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SettingSyncHost.exe" pid 1252 at 0x5df2fd0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE b00f21cd-fe89-47c7-9eb0-29348eaf996d (0.0) -- ISettingSyncEngine |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 9c0ce862-0b63-46bc-b252-03904d16286b (0.0) -- ISettingSyncTask |
|  | Endpoints : |
|  | ncalrpc : OLE79A5886F97EB5606DB8D2C835202 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RuntimeBroker.exe" pid 9064 at 0x5df2470L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 6040ec14-6557-41f9-a3f7-b1cab7b42120 (0.0) -- IRuntimeBroker |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 4a8a1adf-fea8-481d-88d1-aee47d8d6a05 (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CJumpView\_CIJumpViewBrokerStatics |
|  | OLE cd17328b-e4ef-4215-a92d-62a914658f82 (0.0) -- IObjectWithCachedState |
|  | OLE 430ecece-1418-5d19-81b2-5ddb381603cc (0.0) -- IAsyncOperation<Windows.Storage.Streams.IRandomAccessStream> |
|  | OLE 905a0fe1-bc53-11df-8c49-001e4fc686da (0.0) -- \_\_x\_Windows\_CFoundation\_CIByteSeeker |
|  | OLE 0000000c-0000-0000-c000-000000000046 (0.0) -- IStream |
|  | OLE fa9812c4-0b34-47d0-9b0b-157fb5b5fdf2 (0.0) -- IDuplicateHandleProvider |
|  | OLE bfb02fed-4c71-40e1-b4f3-ce99c2ff0542 (0.0) -- IObjectWithFileHandle |
|  | OLE 58eefd30-1eb3-4a11-bf49-ac7c098d7f7f (0.0) -- |
|  | OLE 4f61ca7c-ace7-4091-bd5d-4561242e1bae (0.0) -- |
|  | OLE 6d5140c1-7436-11ce-8034-00aa006009fa (0.0) -- IServiceProvider |
|  | OLE 667708d1-a931-4a85-9999-609eaa7dd85a (0.0) -- ILocalCopyDownloadSettings |
|  | OLE 23710692-92e0-4a33-a781-a81596a4cd7d (0.0) -- IShouldSwitchToDesktop |
|  | OLE 9c2a41f8-3641-5881-a1b3-4d4076649598 (0.0) -- \_\_FIVectorView\_1\_Windows\_\_CInternal\_\_CShell\_\_CJumpView\_\_CContextMenuItemWrapper |
|  | OLE d1273efa-b70c-4397-94a6-882233dcbb2f (0.0) -- \_\_x\_Windows\_CInternal\_CShell\_CJumpView\_CIContextMenuItemWrapper |
|  | Endpoints : |
|  | ncalrpc : OLEAC8920F314AA72872A94D92B9D09 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "LockApp.exe" pid 8308 at 0x5df2080L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 638bb2db-451d-4661-b099-414f34ffb9f1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationView |
|  | OLE 92696c00-7578-48e1-ac1a-2ca909e2c8cf (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CIActivatableApplication |
|  | OLE 49a07732-e7b8-5c5b-9de7-22e33cb97004 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CApplicationModel\_\_CActivation\_\_CBackgroundActivatedEventArgs |
|  | OLE 2e5500b6-66ad-467f-abb5-022a64283d88 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationViewInternal |
|  | OLE 4f9c5cec-0197-49fe-b800-0d5a72a6c505 (0.0) -- IUiaWindowNotifierCallback |
|  | OLE abadfe7f-04c1-4a9f-9b3c-a323f1c80178 (0.0) -- IScaleChangeSink |
|  | OLE c50898f6-c536-5f47-8583-8b2c2438a13b (0.0) -- Windows.Foundation.IEventHandler<IInspectable> |
|  | OLE 2dbdba9d-20da-519d-9078-09f835bc5bc7 (0.0) -- ITypedEventHandler<UISettings,IInspectable> |
|  | OLE 7d56d344-8464-4faf-aa49-37ea6e2d7bd1 (0.0) -- \_\_x\_Windows\_CApplicationModel\_CDataTransfer\_CDragDrop\_CCore\_CICoreDragDropManager |
|  | OLE f59aa65c-9711-4dc9-a630-95b6cb8cdad0 (0.0) -- Windows.ApplicationModel.LockScreen.ILockScreenInfo |
|  | OLE 76b5212e-ef05-417d-813a-8241d965e43f (0.0) -- lockframework.ILockScreenInfoPrivate |
|  | OLE 118ec4a0-443d-467d-b568-de895db52e7b (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CInternal\_CINotifySubscription |
|  | OLE 00000038-0000-0000-c000-000000000046 (0.0) -- IWeakReferenceSource |
|  | OLE 00000037-0000-0000-c000-000000000046 (0.0) -- IWeakReference |
|  | OLE 17b0e613-942a-422d-904c-f90dc71a7dae (0.0) -- \_\_x\_Windows\_CApplicationModel\_CCore\_CICoreApplicationPrivate |
|  | OLE 61ee6ad0-2c83-421b-8467-413eaf1aeb97 (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CITargetedContentSubscriptionOptions |
|  | OLE f6d1f700-49c2-52ae-8154-826f9908773c (0.0) -- IMap<HSTRING,HSTRING> |
|  | OLE e9bdaaf0-cbf6-5c72-be90-29cbf3a1319b (0.0) -- IIterable<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 05eb86f1-7140-5517-b88d-cbaebe57e6b1 (0.0) -- IIterator<IKeyValuePair<HSTRING,HSTRING> > |
|  | OLE 60310303-49c5-52e6-abc6-a9b36eccc716 (0.0) -- IKeyValuePair<HSTRING,HSTRING> |
|  | OLE 98b9acc1-4b56-532e-ac73-03d5291cca90 (0.0) -- IVector<HSTRING> |
|  | OLE e2fcc7c1-3bfc-5a0b-b2b0-72e769d1cb7e (0.0) -- IIterable<HSTRING> |
|  | OLE 8c304ebb-6615-50a4-8829-879ecd443236 (0.0) -- IIterator<HSTRING> |
|  | OLE 002e5776-8a5b-5b93-8c6c-9c4c8788f5b4 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CApplicationModel\_\_CLockScreen\_\_CLockApplicationHost\_Windows\_\_CApplicationModel\_\_CLockScreen\_\_CLockScreenUnlockingEventArgs |
|  | OLE d25f31a2-8cae-4058-967e-8a4497e1cdbc (0.0) -- INowPlayingSessionManagerEventHandler |
|  | OLE 06386a7a-e009-5b0b-ab68-a8e48b516647 (0.0) -- \_\_FIAsyncOperationWithProgressCompletedHandler\_2\_Windows\_\_CStorage\_\_CStreams\_\_CIBuffer\_UINT32 |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 6030e7c3-f93f-5e9c-9ba2-9a018d2b09c0 (0.0) -- \_\_FIEventHandler\_1\_Windows\_\_CSystem\_\_CAppMemoryUsageLimitChangingEventArgs |
|  | Endpoints : |
|  | ncalrpc : OLE4C6536A0364D8599CF5BAF7FCA0F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "RuntimeBroker.exe" pid 4964 at 0x5df27b8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 6040ec14-6557-41f9-a3f7-b1cab7b42120 (0.0) -- IRuntimeBroker |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE 35e95279-8863-4bf6-81e6-c1aeeb4c66bd (0.0) -- lockframework.ILockAppBrokerStatics2 |
|  | OLE fcc7498e-d8cf-4993-a9ae-804193af19d7 (0.0) -- lockframework.ILockAppBrokerStatics |
|  | OLE 307abe8d-6ef9-4c30-8eda-1ee87a04951d (0.0) -- lockframework.ILockScreenInfoAgent |
|  | OLE ac2e38a7-89bb-416d-9245-f63b83fd5ff9 (0.0) -- ILockScreenInfoSubscription |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 50a5378f-a64e-4d5a-a911-6342b5ff64c0 (0.0) -- \_\_x\_Windows\_CServices\_CTargetedContent\_CInternal\_CISubscriptionManager |
|  | OLE 940c223d-5bdc-49db-968c-e4f3ef9b9270 (0.0) -- IImmersiveMonitorNotification |
|  | OLE 3ee9d3ad-b607-40ae-b426-7631d9821269 (0.0) -- \_\_x\_Windows\_CSystem\_CUserProfile\_CILockScreenStatics |
|  | OLE fb37854f-513a-4ca8-9a06-4adab5968a23 (0.0) -- ILockScreenCreativeConfig |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 1bdb56d8-fce7-4c5c-a06a-45e7ea7970d6 (0.0) -- lockframework.ILockCreative |
|  | OLE 28fe486d-6853-4c62-81ab-4bdc6b9c1a9d (0.0) -- Windows.ApplicationModel.LockScreen.ILockFrameworkBrokerStatics |
|  | OLE 38ee31ad-d94f-4e7c-81fa-4f4436506281 (0.0) -- Windows.ApplicationModel.LockScreen.ILockApplicationHost |
|  | OLE d9ca44ee-3a6f-44c4-a796-32248c285250 (0.0) -- lockframework.ILockApplicationHostPrivate |
|  | OLE fa4270e8-4902-44b7-9686-0a5166efcee8 (0.0) -- ILockAppBrokerEndpoint |
|  | OLE 8fe60a8a-32ac-4604-804a-a17d67f878b8 (0.0) -- lockframework.ILockStatusProvider |
|  | OLE 905a0fe1-bc53-11df-8c49-001e4fc686da (0.0) -- \_\_x\_Windows\_CFoundation\_CIByteSeeker |
|  | OLE 0000000c-0000-0000-c000-000000000046 (0.0) -- IStream |
|  | OLE a5322dff-9ebc-5df1-953d-0237cea8614b (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CPrimaryTileUserChangedEventArgs |
|  | OLE ccb96d97-791c-5741-8f33-fb7266d6ea33 (0.0) -- \_\_FITypedEventHandler\_2\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserNotifier\_Windows\_\_CInternal\_\_CStateRepository\_\_CSecondaryTileUserChangedEventArgs |
|  | OLE e716b283-6be7-4e6f-a88f-1cde47d5e355 (0.0) -- IWpnPresentationTileSink |
|  | OLE 44e6c007-75fb-4abb-9f8b-824748900c71 (0.0) -- Windows.ApplicationModel.LockScreen.ILockScreenUnlockingEventArgs |
|  | OLE 7e7d1ad6-5203-43e7-9bd6-7c3947d1e3fe (0.0) -- Windows.ApplicationModel.LockScreen.ILockScreenUnlockingDeferral |
|  | Endpoints : |
|  | ncalrpc : OLE957A3E46D14941766634AA49BA2E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 9472 at 0x5df2748L> |
|  | 64 |
|  | \['NcdAutoSetup'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 1299cf18-c4f5-4b6a-bb0f-2299f0398e27 (0.0) -- INotifyNetworkListManagerEvents |
|  | OLE 22d2e146-1a68-40b8-949c-8fd848b415e6 (0.0) -- INotifyNetworkEvents |
|  | OLE 2abc0864-9677-42e5-882a-d415c556c284 (0.0) -- INotifyNetworkInterfaceEvents |
|  | OLE 733b7764-5c0c-4ad6-bb4b-d0585e993e0e (0.0) -- INotifyNetworkGlobalCostEvents |
|  | Endpoints : |
|  | ncalrpc : OLEF1218720DC9BD56DEC103CDDB392 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11400 (DEAD) at 0x5df20f0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "OpenWith.exe" pid 11228 at 0x5df2550L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 7f9185b0-cb92-43c5-80a9-92277a4f7b54 (0.0) -- IExecuteCommand |
|  | OLE fc4801a3-2ba9-11cf-a229-00aa003d7352 (0.0) -- IObjectWithSite |
|  | OLE 1c9cd5bb-98e9-4491-a60f-31aacc72b83c (0.0) -- IObjectWithSelection |
|  | OLE 85075acf-231f-40ea-9610-d26b7b58f638 (0.0) -- IInitializeCommand |
|  | OLE 18b21aa9-e184-4ff0-9f5e-f882d03771b3 (0.0) -- IExecuteCommandApplicationHostEnvironment |
|  | OLE eb9d0454-25db-5620-98b8-be4c5d0dbc67 (0.0) -- Windows.Foundation.TypedEventHandler\[Windows.System.UserWatcher, Windows.System.UserChangedEventArgs\] |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 016f611a-b360-4768-8b28-6779ddfde2e0 (0.0) -- |
|  | OLE 8d4d1ec2-4740-4fc5-b4b1-6dc3722a2eeb (0.0) -- ILightDismissNotification |
|  | Endpoints : |
|  | ncalrpc : OLE62B7976F39A13C06E3572AF8183F |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "TiWorker.exe" pid 2848 at 0x5df2f28L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\Windows\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE a70dbecc-3734-4b22-b2d1-648c0e43e177 (0.0) -- ICbsWorker |
|  | OLE f568c899-af4f-4eaa-b12a-b8e5f1b219de (0.0) -- ICbsSession8 |
|  | OLE f112757a-565b-4260-bd05-9fa34417349a (0.0) -- ICbsSession10 |
|  | OLE 75207396-23f2-4396-85f0-8fdb879ed0ed (0.0) -- ICbsIdentity |
|  | OLE 75207397-23f2-4396-85f0-8fdb879ed0ed (0.0) -- IEnumCbsIdentity |
|  | OLE 75207393-23f2-4396-85f0-8fdb879ed0ed (0.0) -- ICbsPackage |
|  | Endpoints : |
|  | ncalrpc : OLE493FAEE6837AD7B280FB1CEFDEB3 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "dllhost.exe" pid 364 at 0x5df2dd8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 000001a0-0000-0000-c000-000000000046 (0.0) -- ISystemActivator |
|  | OLE 75121952-e0d0-43e5-9380-1d80483acf72 (0.0) -- ICreateObject |
|  | OLE e357fccd-a995-4576-b01f-234630154e96 (0.0) -- IThumbnailProvider |
|  | OLE 7f73be3f-fb79-493c-a6c7-7ee14e245841 (0.0) -- IInitializeWithItem |
|  | OLE b824b49d-22ac-4161-ac8a-9916e8fa3f7f (0.0) -- IInitializeWithStream |
|  | OLE 9d4966fa-dbd1-4799-a07f-6a5e1991bda4 (0.0) -- IOplockCallbackEventHandler |
|  | OLE 24a0bf18-6849-4d99-9fc8-48bcabace467 (0.0) -- IHandleDuplicator |
|  | Endpoints : |
|  | ncalrpc : OLEF20A24D51DA7E136E1AFFA9063BF |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 6432 at 0x5df2198L> |
|  | 64 |
|  | \['lmhosts'\] |
|  |  |
|  | Interfaces : |
|  | RPC 30adc50c-5cbc-46ce-9a0e-91914789e23c (1.0) -- c:\\windows\\system32\\nrpsrv.DLL |
|  | 0 -> RpcNrpGetAddrInfo |
|  | 1 -> RpcNrpGetNameInfo |
|  | Endpoints : |
|  | ncalrpc : LRPC-64bba7c0828029142e |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11996 (DEAD) at 0x5df2f60L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 13272 at 0x5df2a90L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000160-0000-0000-c000-000000000046 (0.0) -- IPrivDragDrop |
|  | OLE 0000010e-0000-0000-c000-000000000046 (0.0) -- IDataObject |
|  | Endpoints : |
|  | ncalrpc : OLEB9FD6AF18AC202C665EE24F4D01E |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 5820 at 0x5df28d0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 4892 at 0x5df2da0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11184 at 0x5df2b38L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | Endpoints : |
|  | ncalrpc : OLEA7A93B2869257E9C7728E37C74E2 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 3396 at 0x5df2d30L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 6400 at 0x5df2ef0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 1424 at 0x5df22b0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 8248 at 0x5df2630L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 12400 at 0x5df2cc0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 5412 at 0x5df2518L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11528 at 0x5df26a0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 4572 at 0x5df29b0L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11864 at 0x5df2908L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 7156 at 0x5df2ba8L> |
|  | 64 |
|  | \['WinHttpAutoProxySvc'\] |
|  |  |
|  | Interfaces : |
|  | RPC 3473dd4d-2e88-4006-9cba-22570909dd10 (5.1) -- c:\\windows\\system32\\winhttp.dll |
|  | 0 -> GetProxyForUrl |
|  | 1 -> ResetAutoProxy |
|  | 2 -> SaveProxyCredentials |
|  | 3 -> StoreSavedProxyCredentialsForCurrentUser |
|  | 4 -> DeleteSavedProxyCredentials |
|  | 5 -> ReindicateAllProxies |
|  | 6 -> ReadProxySettings |
|  | 7 -> WriteProxySettings |
|  | 8 -> ConnectionUpdateIfIndexTable |
|  | 9 -> ConnectionSetPolicyEntries |
|  | 10 -> ConnectionDeletePolicyEntries |
|  | Endpoints : |
|  | ncalrpc : LRPC-6462626a527cfed452 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 3036 at 0x5df2438L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 2024 at 0x5df2390L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 10584 at 0x5df2e48L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 6860 at 0x5df2160L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "audiodg.exe" pid 12832 at 0x5df24a8L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | RPC de3b9bc8-bef7-4578-a0de-f089048442db (1.0) -- C:\\WINDOWS\\system32\\AUDIODG.EXE |
|  | 0 -> AudioDGShutdownADG |
|  | 1 -> AudioDGGetStartupStatus |
|  | 2 -> AudioDGChallenge |
|  | 3 -> AudioDGGetStreamVpoDescription |
|  | 4 -> AudioDGSetStreamVpoPolicySchemas |
|  | 5 -> AudioDGCloseStreamVpo |
|  | 6 -> AudioDGGetDeviceGraphWnfStateName |
|  | 7 -> AudioDGGetVpoFromVpoContext |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE 69fed9b6-5405-48b8-3db0-4ca492fc3677 (0.0) -- IAPOWrapperSrv |
|  | OLE fd7f2b29-24d0-4b5c-b177-592c39f9ca10 (0.0) -- iaudioprocessingobject |
|  | OLE 816e5b3e-5523-4efc-9223-98ec4214c3a0 (0.0) -- IStreamGroup |
|  | OLE 5d857e80-f074-4ad8-a9ce-0ddca68d8212 (0.0) -- IProcessSubmix |
|  | OLE d81229b1-5a43-480c-92f7-be0f7f4eab60 (0.0) -- iaudiovolume |
|  | OLE 885c7b80-3fa2-4e5a-be07-cf01e1d6e2cd (0.0) -- iaudiomuteapo |
|  | OLE 419b26e3-fa99-4408-83de-cc1276efa489 (0.0) -- iaudiometer |
|  | OLE 69e1f79f-6eae-4517-be9f-13aa90e30014 (0.0) -- iaudioprocessingobjectinternal |
|  | OLE 3c169ff7-37b2-484c-b199-c3155590f316 (0.0) -- iaudiodevicegraph |
|  | OLE 610c5f91-da25-52b0-ae7d-2d3a45cdf4ef (0.0) -- ITypedEventHandler\_2\_Windows\_\_CMedia\_\_CDevices\_\_CInternal\_\_CAudioDeviceBroker\_Windows\_\_CMedia\_\_CDevices\_\_CInternal\_\_CAudioDeviceBrokerChangedEventArgs |
|  | Endpoints : |
|  | ncalrpc : AudioDeviceGraph |
|  | ncalrpc : OLEFC07AE218C36E20B32DDF1039276 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 8164 at 0x5df2860L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11404 at 0x5df2358L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 2116 at 0x5df2828L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 7632 at 0x5df2d68L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "chrome.exe" pid 11116 at 0x5df29e8L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SystemSettingsBroker.exe" pid 5100 at 0x5df2978L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | OLE af86e2e0-b12d-4c6a-9c5a-d7aa65101e90 (0.0) -- IInspectable |
|  | OLE d68a97b7-4f47-4cb6-9e1f-a01c1232f755 (0.0) -- SystemSettings.DataModel.ISettingsDatabase |
|  | OLE 40c037cc-d8bf-489e-8697-d66baa3221bf (0.0) -- SystemSettings.DataModel.ISettingItem |
|  | OLE 2ec6feac-b62e-4499-a136-ffcba5e05f0b (0.0) -- ITabletModeAvailabilityChangeListener |
|  | OLE 00000141-0000-0000-c000-000000000046 (0.0) -- IDLLHost |
|  | OLE 00000035-0000-0000-c000-000000000046 (0.0) -- IActivationFactory |
|  | OLE b453e674-f489-41c5-9955-983c9fc264b2 (0.0) -- IUIRadioManagerNotifySink |
|  | Endpoints : |
|  | ncalrpc : OLEE70D98A7F7AC0F2F140F44B79590 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "svchost.exe" pid 8492 at 0x5df2eb8L> |
|  | 64 |
|  | \['lfsvc'\] |
|  |  |
|  | Interfaces : |
|  | OLE 00000134-0000-0000-c000-000000000046 (0.0) -- IRundown |
|  | RPC 18f70770-8e64-11cf-9af1-0020af6e72f4 (0.0) -- C:\\WINDOWS\\System32\\combase.dll |
|  | 0 -> \_UseProtseq |
|  | 1 -> \_GetCustomProtseqInfo |
|  | 2 -> \_UpdateResolverBindings |
|  | 3 -> \_NotifyFDT |
|  | 4 -> \_ControlTracing |
|  | OLE 00000131-0000-0000-c000-000000000046 (0.0) -- IRemUnknown |
|  | OLE 00000143-0000-0000-c000-000000000046 (0.0) -- IRemUnknown2 |
|  | OLE 00000132-0000-0000-c000-000000000046 (0.0) -- ILocalSystemActivator |
|  | RPC d09bdeb5-6171-4a34-bfe2-06fa82652568 (1.0) -- c:\\windows\\system32\\BrokerLib.dll |
|  | 0 -> \_BriCreateEvent |
|  | 1 -> \_BriDeleteEvent |
|  | 2 -> BriDisableEvent |
|  | 3 -> BriEnableEvent |
|  | 4 -> BriSignalEvent |
|  | OLE bb31bcf1-230a-4bea-abef-26a3887f122a (0.0) -- ILocationManagerInternal |
|  | OLE 3d0423b1-bbd4-4c4a-8f20-da15228e0f3d (0.0) -- ILocationManager |
|  | Endpoints : |
|  | ncalrpc : OLEC6CB94C23234E3CB7E40389FD434 |
|  | ncalrpc : LRPC-1cce524080fb596c61 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "smartscreen.exe" pid 9732 at 0x5df25f8L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "cmd.exe" pid 4748 at 0x5df2b00L> |
|  | 64 |
|  | \[!!\] Invalid rpcrt4 base: 0x0 vs 0x7ff868230000 |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "conhost.exe" pid 12380 at 0x5df2e80L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SearchProtocolHost.exe" pid 6808 at 0x5df2780L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "SearchFilterHost.exe" pid 12844 at 0x5df2a58L> |
|  | \-\-\------------------------------------------------------------------------------ |
|  | <WinProcess "python.exe" pid 8052 at 0x5df2588L> |
|  | 64 |
|  |  |
|  | Interfaces : |
|  | Endpoints : |

[Sign up for free](https://gist.github.com/join?source=comment-gist) **to join this conversation on GitHub**.
Already have an account?
[Sign in to comment](https://gist.github.com/login?return_to=https%3A%2F%2Fgist.github.com%2Fenigma0x3%2F092da9f249499391adffe2c46abfa1a1)

You can’t perform that action at this time.