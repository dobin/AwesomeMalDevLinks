# https://github.com/HullaBrian/COMmander?tab=readme-ov-file

[Skip to content](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/HullaBrian/COMmander?tab=readme-ov-file) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/HullaBrian/COMmander?tab=readme-ov-file) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/HullaBrian/COMmander?tab=readme-ov-file) to refresh your session.Dismiss alert

{{ message }}

[HullaBrian](https://github.com/HullaBrian)/ **[COMmander](https://github.com/HullaBrian/COMmander)** Public

- [Notifications](https://github.com/login?return_to=%2FHullaBrian%2FCOMmander) You must be signed in to change notification settings
- [Fork\\
9](https://github.com/login?return_to=%2FHullaBrian%2FCOMmander)
- [Star\\
101](https://github.com/login?return_to=%2FHullaBrian%2FCOMmander)


.NET tool used to enrich RPC telemetry


### License

[GPL-3.0 license](https://github.com/HullaBrian/COMmander/blob/main/LICENSE)

[101\\
stars](https://github.com/HullaBrian/COMmander/stargazers) [9\\
forks](https://github.com/HullaBrian/COMmander/forks) [Branches](https://github.com/HullaBrian/COMmander/branches) [Tags](https://github.com/HullaBrian/COMmander/tags) [Activity](https://github.com/HullaBrian/COMmander/activity)

[Star](https://github.com/login?return_to=%2FHullaBrian%2FCOMmander)

[Notifications](https://github.com/login?return_to=%2FHullaBrian%2FCOMmander) You must be signed in to change notification settings

# HullaBrian/COMmander

main

[**1** Branch](https://github.com/HullaBrian/COMmander/branches) [**1** Tag](https://github.com/HullaBrian/COMmander/tags)

[Go to Branches page](https://github.com/HullaBrian/COMmander/branches)[Go to Tags page](https://github.com/HullaBrian/COMmander/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![HullaBrian](https://avatars.githubusercontent.com/u/62084657?v=4&size=40)](https://github.com/HullaBrian)[HullaBrian](https://github.com/HullaBrian/COMmander/commits?author=HullaBrian)<br>[Update README.md](https://github.com/HullaBrian/COMmander/commit/3700d1c60dc856b229660bd61e74a27d37755ab2)<br>last monthJan 24, 2026<br>[3700d1c](https://github.com/HullaBrian/COMmander/commit/3700d1c60dc856b229660bd61e74a27d37755ab2) · last monthJan 24, 2026<br>## History<br>[26 Commits](https://github.com/HullaBrian/COMmander/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/HullaBrian/COMmander/commits/main/) 26 Commits |
| [COMmander](https://github.com/HullaBrian/COMmander/tree/main/COMmander "COMmander") | [COMmander](https://github.com/HullaBrian/COMmander/tree/main/COMmander "COMmander") | [Changes](https://github.com/HullaBrian/COMmander/commit/cd6cb763ae682711e94dde9b1689945728e8c7eb "Changes") | 8 months agoJun 12, 2025 |
| [COMmanderService](https://github.com/HullaBrian/COMmander/tree/main/COMmanderService "COMmanderService") | [COMmanderService](https://github.com/HullaBrian/COMmander/tree/main/COMmanderService "COMmanderService") | [Changes](https://github.com/HullaBrian/COMmander/commit/cd6cb763ae682711e94dde9b1689945728e8c7eb "Changes") | 8 months agoJun 12, 2025 |
| [Rules](https://github.com/HullaBrian/COMmander/tree/main/Rules "Rules") | [Rules](https://github.com/HullaBrian/COMmander/tree/main/Rules "Rules") | [Pushed ruleset](https://github.com/HullaBrian/COMmander/commit/171d3e995deab56acbba00be34b576a447fb8067 "Pushed ruleset") | 8 months agoJun 12, 2025 |
| [.gitattributes](https://github.com/HullaBrian/COMmander/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/HullaBrian/COMmander/blob/main/.gitattributes ".gitattributes") | [Initial commit](https://github.com/HullaBrian/COMmander/commit/f33136057e74d2761bef3a24305f6cb1fe1cb634 "Initial commit") | 9 months agoMay 15, 2025 |
| [.gitignore](https://github.com/HullaBrian/COMmander/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/HullaBrian/COMmander/blob/main/.gitignore ".gitignore") | [Cleanup COMmander standalone tool code](https://github.com/HullaBrian/COMmander/commit/f8049efe35e8cef572755340eee7eba32cbcf52d "Cleanup COMmander standalone tool code") | 9 months agoMay 27, 2025 |
| [COMmander.sln](https://github.com/HullaBrian/COMmander/blob/main/COMmander.sln "COMmander.sln") | [COMmander.sln](https://github.com/HullaBrian/COMmander/blob/main/COMmander.sln "COMmander.sln") | [Added service and installation scripts](https://github.com/HullaBrian/COMmander/commit/d66bdefd76553c35ce1fdc0f75e3a95a019e1a0f "Added service and installation scripts") | 9 months agoMay 24, 2025 |
| [InstallService.ps1](https://github.com/HullaBrian/COMmander/blob/main/InstallService.ps1 "InstallService.ps1") | [InstallService.ps1](https://github.com/HullaBrian/COMmander/blob/main/InstallService.ps1 "InstallService.ps1") | [Changes](https://github.com/HullaBrian/COMmander/commit/cd6cb763ae682711e94dde9b1689945728e8c7eb "Changes") | 8 months agoJun 12, 2025 |
| [LICENSE](https://github.com/HullaBrian/COMmander/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/HullaBrian/COMmander/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/HullaBrian/COMmander/commit/f33136057e74d2761bef3a24305f6cb1fe1cb634 "Initial commit") | 9 months agoMay 15, 2025 |
| [README.md](https://github.com/HullaBrian/COMmander/blob/main/README.md "README.md") | [README.md](https://github.com/HullaBrian/COMmander/blob/main/README.md "README.md") | [Update README.md](https://github.com/HullaBrian/COMmander/commit/3700d1c60dc856b229660bd61e74a27d37755ab2 "Update README.md") | last monthJan 24, 2026 |
| [UninstallService.ps1](https://github.com/HullaBrian/COMmander/blob/main/UninstallService.ps1 "UninstallService.ps1") | [UninstallService.ps1](https://github.com/HullaBrian/COMmander/blob/main/UninstallService.ps1 "UninstallService.ps1") | [Added service and installation scripts](https://github.com/HullaBrian/COMmander/commit/d66bdefd76553c35ce1fdc0f75e3a95a019e1a0f "Added service and installation scripts") | 9 months agoMay 24, 2025 |
| View all files |

## Repository files navigation

# COMmander

[Permalink: COMmander](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#commander)

COMmander is a tool written in C# that can enrich defensive telemetry around RPC and COM.
For a detailed blog post on the development of the tool and ruleset, see
[Jacob Acuna's](https://www.linkedin.com/in/jacob-acuna1) [blog post](https://jacobacuna.me/2025-06-12-COMmander/)

COMmander leverages the `Microsoft-Windows-RPC` ETW provider to tap into low level RPC events.
This provides detailed RPC-related events on the system that can provide defenders
with details about RPC, as well as layers of abstraction built on top of it, such as COM.

The way COMmander works is very simple - you provide a configuration file containing detection
rules. These rules consist of various filters that provide granular control over what COMmander will
detect (See the configuration file section for more details). After running the binary, that's
all you have to do - COMmander will monitor the system for events that match the filters you provided
and send alerts in the terminal if any are encountered.

One of the issues with handling so many events is that it often requires a significant amount
of resources to run. However, COMmander is extremely lightweight, and consistently uses minimal
resources while still providing detection functionality.

[![image](https://private-user-images.githubusercontent.com/62084657/444845897-916bb7e0-70d5-41a9-98e1-c87e3a680593.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDQ4NDU4OTctOTE2YmI3ZTAtNzBkNS00MWE5LTk4ZTEtYzg3ZTNhNjgwNTkzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTNkNzg1YzlhODU2Yzg2NjQ3MzhiZmQ4YzE4ZGI1ODE0NjMzY2IzOWIzZDMwMGYxMzNmNzkyY2JiMjM1NGM4NWImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.xV5W-DkiuErg1bw7BOQpfGcij9MYoY8dENE1RLGQWn0)](https://private-user-images.githubusercontent.com/62084657/444845897-916bb7e0-70d5-41a9-98e1-c87e3a680593.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDQ4NDU4OTctOTE2YmI3ZTAtNzBkNS00MWE5LTk4ZTEtYzg3ZTNhNjgwNTkzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTNkNzg1YzlhODU2Yzg2NjQ3MzhiZmQ4YzE4ZGI1ODE0NjMzY2IzOWIzZDMwMGYxMzNmNzkyY2JiMjM1NGM4NWImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.xV5W-DkiuErg1bw7BOQpfGcij9MYoY8dENE1RLGQWn0)

Warning

Running the CLI application and service binary at the same time will break the service. Restart
the service if this occurs.

# Build Instructions

[Permalink: Build Instructions](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#build-instructions)

Open in Visual Studio and press the build button.

# Service Usage

[Permalink: Service Usage](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#service-usage)

## Installation

[Permalink: Installation](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#installation)

1. Download the latest release from this repository.
2. Run the `InstallService.ps1` powershell script as an **administrator**
   - Service files are stored in `C:\Program Files\COMmander`
   - The service is called `COMmander` and runs as the local system account
3. Run `Start-Service COMmander` if it isn't started already

Note

During the installation process, the script may open a window asking for the credentials
for the local system account. If this occurs, simply press enter.

## Uninstall

[Permalink: Uninstall](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#uninstall)

To uninstall COMmander, run the `UninstallService.ps1` script included in the releases
of this repository as an **administrator**.

## Event Viewer

[Permalink: Event Viewer](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#event-viewer)

COMmander's service will attempt to log events in the Windows Event Viewer, under the name
`COMmander` beneath the `Application and Service Logs` section.

[![image](https://private-user-images.githubusercontent.com/62084657/447290968-9495e225-e1d4-49a5-9844-963e4dd2ccc0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDcyOTA5NjgtOTQ5NWUyMjUtZTFkNC00OWE1LTk4NDQtOTYzZTRkZDJjY2MwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTE3OTQ1Zjk3OWI4OWUwZTkyMjdlMTM3M2Q1MTNjZmQ5YzRjNWVmNTJkYjJkNGU2MjA2OGRjYjExMWVkYTc2MzEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.7EZ-rA4RTWI_2gtFaGRPZIQWXYYWaWv-yr-u0YwRw2A)](https://private-user-images.githubusercontent.com/62084657/447290968-9495e225-e1d4-49a5-9844-963e4dd2ccc0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDcyOTA5NjgtOTQ5NWUyMjUtZTFkNC00OWE1LTk4NDQtOTYzZTRkZDJjY2MwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTE3OTQ1Zjk3OWI4OWUwZTkyMjdlMTM3M2Q1MTNjZmQ5YzRjNWVmNTJkYjJkNGU2MjA2OGRjYjExMWVkYTc2MzEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.7EZ-rA4RTWI_2gtFaGRPZIQWXYYWaWv-yr-u0YwRw2A)

Below are the event IDs that you will see in the event viewer.

| Event ID | Event Type | Description |
| --- | --- | --- |
| 1 | Information | The service is starting |
| 2 | Information | The service is stopping |
| 3 | Information | A rule was loaded |
| 4 | Error | There was an error during runtime |
| 5 | Warning | A detection was triggered |

[![image](https://private-user-images.githubusercontent.com/62084657/447292427-2ba136c4-e3a8-4a8f-9fd1-c8f4ba816183.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDcyOTI0MjctMmJhMTM2YzQtZTNhOC00YThmLTlmZDEtYzhmNGJhODE2MTgzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWFlZTY5ZDZhMWY2NGM2NTZmZmQ0NDJiNDgwZTI2YzI2OWI5YTBjMWViYjI4YjdjOGMyZmYxODlkZjBiM2YzZjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Pgria8poiahT22a4uO4dORcGPvB421luOCYD8KOJ1l4)](https://private-user-images.githubusercontent.com/62084657/447292427-2ba136c4-e3a8-4a8f-9fd1-c8f4ba816183.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDcyOTI0MjctMmJhMTM2YzQtZTNhOC00YThmLTlmZDEtYzhmNGJhODE2MTgzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWFlZTY5ZDZhMWY2NGM2NTZmZmQ0NDJiNDgwZTI2YzI2OWI5YTBjMWViYjI4YjdjOGMyZmYxODlkZjBiM2YzZjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Pgria8poiahT22a4uO4dORcGPvB421luOCYD8KOJ1l4)

# Command-Line Usage

[Permalink: Command-Line Usage](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#command-line-usage)

```
COMmander.exe
```

[![COMmander-Preview(1)](https://private-user-images.githubusercontent.com/62084657/444845410-c61dcb4b-3447-42c6-9bf9-342c3e3a1349.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDQ4NDU0MTAtYzYxZGNiNGItMzQ0Ny00MmM2LTliZjktMzQyYzNlM2ExMzQ5LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTAxOTg2N2UwOTVkM2QzODEzODJjMzFlMzU1NjI4NjI3MGEyYmIwOTBiOTYyZGJjZTI5M2MxZDc0N2E0YTk2MTkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.8ONULjtoZZtpjmByJPgWtVuPmfiM1sN4RdVHLKT-mRY)](https://private-user-images.githubusercontent.com/62084657/444845410-c61dcb4b-3447-42c6-9bf9-342c3e3a1349.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwOTksIm5iZiI6MTc3MTQxMTc5OSwicGF0aCI6Ii82MjA4NDY1Ny80NDQ4NDU0MTAtYzYxZGNiNGItMzQ0Ny00MmM2LTliZjktMzQyYzNlM2ExMzQ5LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDk1OVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTAxOTg2N2UwOTVkM2QzODEzODJjMzFlMzU1NjI4NjI3MGEyYmIwOTBiOTYyZGJjZTI5M2MxZDc0N2E0YTk2MTkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.8ONULjtoZZtpjmByJPgWtVuPmfiM1sN4RdVHLKT-mRY)

# Configuration File

[Permalink: Configuration File](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#configuration-file)

By default, COMmander will attempt to find a configuration file called `config.xml` in the
same directory as the binary. Rules may include a combination of rule types, but for the time
being may only include a single instance of a rule type (ie you can only have one `OpNum`
filter). Below is a table containing the possible values to use in the detection rules.

| Rule Type | Example Value |
| --- | --- |
| InterfaceUUID | `06bba54a-be05-49f9-b0a0-30f790261023` |
| OpNum | `13` |
| Endpoint | `\PIPE\DAV RPC SERVICE` |
| NetworkAddress | `NULL` |
| ProcessName | `lsass` |

Below is a sample configuration file template:

```
<Rules>
	<Rule name="DCOM Invoked WebClient">
		<InterfaceUUID>c8cb7687-e6d3-11d2-a958-00c04f682e16</InterfaceUUID>
		<Endpoint>\PIPE\DAV RPC SERVICE</Endpoint>
	</Rule>
	<Rule name="Authentication Coercion using PetitPotam EfsRpcOpenFileRaw">
		<InterfaceUUID>c681d488-d850-11d0-8c52-00c04fd90f7e</InterfaceUUID>
		<OpNum>0</OpNum>
	</Rule>
</Rules>
```

## About

.NET tool used to enrich RPC telemetry


### Resources

[Readme](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/HullaBrian/COMmander?tab=readme-ov-file#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/HullaBrian/COMmander?tab=readme-ov-file).

[Activity](https://github.com/HullaBrian/COMmander/activity)

### Stars

[**101**\\
stars](https://github.com/HullaBrian/COMmander/stargazers)

### Watchers

[**2**\\
watching](https://github.com/HullaBrian/COMmander/watchers)

### Forks

[**9**\\
forks](https://github.com/HullaBrian/COMmander/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FHullaBrian%2FCOMmander&report=HullaBrian+%28user%29)

## [Releases\  1](https://github.com/HullaBrian/COMmander/releases)

[COMmander 1.0\\
Latest\\
\\
on Jun 12, 2025Jun 13, 2025](https://github.com/HullaBrian/COMmander/releases/tag/v1.0)

## Languages

- [C#97.3%](https://github.com/HullaBrian/COMmander/search?l=c%23)
- [PowerShell2.7%](https://github.com/HullaBrian/COMmander/search?l=powershell)

You can’t perform that action at this time.