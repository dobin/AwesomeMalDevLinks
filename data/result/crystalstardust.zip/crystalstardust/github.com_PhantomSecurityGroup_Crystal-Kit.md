# https://github.com/PhantomSecurityGroup/Crystal-Kit

[Skip to content](https://github.com/PhantomSecurityGroup/Crystal-Kit#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/PhantomSecurityGroup/Crystal-Kit) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/PhantomSecurityGroup/Crystal-Kit) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/PhantomSecurityGroup/Crystal-Kit) to refresh your session.Dismiss alert

{{ message }}

[PhantomSecurityGroup](https://github.com/PhantomSecurityGroup)/ **[Crystal-Kit](https://github.com/PhantomSecurityGroup/Crystal-Kit)** Public

forked from [rasta-mouse/Crystal-Kit](https://github.com/rasta-mouse/Crystal-Kit)

- [Notifications](https://github.com/login?return_to=%2FPhantomSecurityGroup%2FCrystal-Kit) You must be signed in to change notification settings
- [Fork\\
0](https://github.com/login?return_to=%2FPhantomSecurityGroup%2FCrystal-Kit)
- [Star\\
30](https://github.com/login?return_to=%2FPhantomSecurityGroup%2FCrystal-Kit)


Evasion kit for Cobalt Strike


### License

[MIT license](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/LICENSE)

[30\\
stars](https://github.com/PhantomSecurityGroup/Crystal-Kit/stargazers) [45\\
forks](https://github.com/PhantomSecurityGroup/Crystal-Kit/forks) [Branches](https://github.com/PhantomSecurityGroup/Crystal-Kit/branches) [Tags](https://github.com/PhantomSecurityGroup/Crystal-Kit/tags) [Activity](https://github.com/PhantomSecurityGroup/Crystal-Kit/activity)

[Star](https://github.com/login?return_to=%2FPhantomSecurityGroup%2FCrystal-Kit)

[Notifications](https://github.com/login?return_to=%2FPhantomSecurityGroup%2FCrystal-Kit) You must be signed in to change notification settings

# PhantomSecurityGroup/Crystal-Kit

main

[**1** Branch](https://github.com/PhantomSecurityGroup/Crystal-Kit/branches) [**0** Tags](https://github.com/PhantomSecurityGroup/Crystal-Kit/tags)

[Go to Branches page](https://github.com/PhantomSecurityGroup/Crystal-Kit/branches)[Go to Tags page](https://github.com/PhantomSecurityGroup/Crystal-Kit/tags)

Go to file

Code

Open more actions menu

This branch is [9 commits ahead of](https://github.com/PhantomSecurityGroup/Crystal-Kit/compare/rasta-mouse%3ACrystal-Kit%3Amain...main) and [2 commits behind](https://github.com/PhantomSecurityGroup/Crystal-Kit/compare/main...rasta-mouse%3ACrystal-Kit%3Amain) rasta-mouse/Crystal-Kit:main.

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![gsmith257-cyber](https://avatars.githubusercontent.com/u/55564824?v=4&size=40)](https://github.com/gsmith257-cyber)[gsmith257-cyber](https://github.com/PhantomSecurityGroup/Crystal-Kit/commits?author=gsmith257-cyber)<br>[feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac)<br>Open commit details<br>last monthJan 15, 2026<br>[ec438f4](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac) · last monthJan 15, 2026<br>## History<br>[33 Commits](https://github.com/PhantomSecurityGroup/Crystal-Kit/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/PhantomSecurityGroup/Crystal-Kit/commits/main/) 33 Commits |
| [loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/loader "loader") | [loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/loader "loader") | [feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac "feat: Added hooks - Added strreps - update gitignore - fixed code size (#5)  * update gitignore  * Fixed code size issue and added all hooks  * Add hooking for HttpSendRequestA - add multiple modules to do stack spoofing with call instructions before gadget - update cna strreps") | last monthJan 15, 2026 |
| [local-loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/local-loader "local-loader") | [local-loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/local-loader "local-loader") | [feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac "feat: Added hooks - Added strreps - update gitignore - fixed code size (#5)  * update gitignore  * Fixed code size issue and added all hooks  * Add hooking for HttpSendRequestA - add multiple modules to do stack spoofing with call instructions before gadget - update cna strreps") | last monthJan 15, 2026 |
| [postex-loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/postex-loader "postex-loader") | [postex-loader](https://github.com/PhantomSecurityGroup/Crystal-Kit/tree/main/postex-loader "postex-loader") | [feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac "feat: Added hooks - Added strreps - update gitignore - fixed code size (#5)  * update gitignore  * Fixed code size issue and added all hooks  * Add hooking for HttpSendRequestA - add multiple modules to do stack spoofing with call instructions before gadget - update cna strreps") | last monthJan 15, 2026 |
| [.gitattributes](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/.gitattributes ".gitattributes") | [Initial commit](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/2a4da97c4e45ea453ee03b3b933668598e42c5be "Initial commit") | 4 months agoOct 12, 2025 |
| [.gitignore](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/.gitignore ".gitignore") | [feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac "feat: Added hooks - Added strreps - update gitignore - fixed code size (#5)  * update gitignore  * Fixed code size issue and added all hooks  * Add hooking for HttpSendRequestA - add multiple modules to do stack spoofing with call instructions before gadget - update cna strreps") | last monthJan 15, 2026 |
| [LICENSE](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/LICENSE "LICENSE") | [Update LICENSE](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/3205c7b3d823dfb552bd04a8234ee42a863e66f0 "Update LICENSE") | 4 months agoOct 30, 2025 |
| [Makefile](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/Makefile "Makefile") | [Makefile](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/Makefile "Makefile") | [big update](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| [README.md](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/README.md "README.md") | [README.md](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/README.md "README.md") | [big update](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| [crystalkit.cna](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/crystalkit.cna "crystalkit.cna") | [crystalkit.cna](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/crystalkit.cna "crystalkit.cna") | [feat: Added hooks - Added strreps - update gitignore - fixed code size (](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/ec438f41d58526d57b62c0a564754673b5be90ac "feat: Added hooks - Added strreps - update gitignore - fixed code size (#5)  * update gitignore  * Fixed code size issue and added all hooks  * Add hooking for HttpSendRequestA - add multiple modules to do stack spoofing with call instructions before gadget - update cna strreps") | last monthJan 15, 2026 |
| [libtcg.x64.zip](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/libtcg.x64.zip "libtcg.x64.zip") | [libtcg.x64.zip](https://github.com/PhantomSecurityGroup/Crystal-Kit/blob/main/libtcg.x64.zip "libtcg.x64.zip") | [big update](https://github.com/PhantomSecurityGroup/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| View all files |

## Repository files navigation

# Crystal Kit

[Permalink: Crystal Kit](https://github.com/PhantomSecurityGroup/Crystal-Kit#crystal-kit)

This repo is a technical and social experiment to explore whether replacing Cobalt Strike's evasion primitives (Sleepmask/BeaconGate) with a [Crystal Palace](https://tradecraftgarden.org/) PICO is feasible (or even desirable) for advanced evasion scenarios.

## Usage

[Permalink: Usage](https://github.com/PhantomSecurityGroup/Crystal-Kit#usage)

1. Disable the sleepmask and stage obfuscations in Malleable C2.

```
stage {
    set sleep_mask "false";
    set cleanup "true";
    transform-obfuscate { }
}

post-ex {
    set cleanup "true";
    set smartinject "true";
}
```

2. Copy `crystalpalace.jar` to your Cobalt Strike client directory.
3. Load `crystalkit.cna`.

### Notes

[Permalink: Notes](https://github.com/PhantomSecurityGroup/Crystal-Kit#notes)

- Tested on Cobalt Strike 4.12.
- Can work with any post-ex DLL capability.

## About

Evasion kit for Cobalt Strike


### Resources

[Readme](https://github.com/PhantomSecurityGroup/Crystal-Kit#readme-ov-file)

### License

[MIT license](https://github.com/PhantomSecurityGroup/Crystal-Kit#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/PhantomSecurityGroup/Crystal-Kit).

[Activity](https://github.com/PhantomSecurityGroup/Crystal-Kit/activity)

[Custom properties](https://github.com/PhantomSecurityGroup/Crystal-Kit/custom-properties)

### Stars

[**30**\\
stars](https://github.com/PhantomSecurityGroup/Crystal-Kit/stargazers)

### Watchers

[**0**\\
watching](https://github.com/PhantomSecurityGroup/Crystal-Kit/watchers)

### Forks

[**0**\\
forks](https://github.com/PhantomSecurityGroup/Crystal-Kit/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FPhantomSecurityGroup%2FCrystal-Kit&report=PhantomSecurityGroup+%28user%29)

## [Releases](https://github.com/PhantomSecurityGroup/Crystal-Kit/releases)

No releases published

## [Packages\  0](https://github.com/orgs/PhantomSecurityGroup/packages?repo_name=Crystal-Kit)

No packages published

## Languages

- C83.8%
- Assembly9.1%
- Ruby5.6%
- Makefile1.3%
- Python0.2%

You can’t perform that action at this time.