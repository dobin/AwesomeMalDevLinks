# https://github.com/Cracked5pider/Stardust

[Skip to content](https://github.com/Cracked5pider/Stardust#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Cracked5pider/Stardust) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Cracked5pider/Stardust) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Cracked5pider/Stardust) to refresh your session.Dismiss alert

{{ message }}

[Cracked5pider](https://github.com/Cracked5pider)/ **[Stardust](https://github.com/Cracked5pider/Stardust)** Public

- [Notifications](https://github.com/login?return_to=%2FCracked5pider%2FStardust) You must be signed in to change notification settings
- [Fork\\
210](https://github.com/login?return_to=%2FCracked5pider%2FStardust)
- [Star\\
1.3k](https://github.com/login?return_to=%2FCracked5pider%2FStardust)


A modern 32/64-bit position independent implant template


[5pider.net/blog/2024/01/27/modern-shellcode-implant-design](https://5pider.net/blog/2024/01/27/modern-shellcode-implant-design "https://5pider.net/blog/2024/01/27/modern-shellcode-implant-design")

[1.3k\\
stars](https://github.com/Cracked5pider/Stardust/stargazers) [210\\
forks](https://github.com/Cracked5pider/Stardust/forks) [Branches](https://github.com/Cracked5pider/Stardust/branches) [Tags](https://github.com/Cracked5pider/Stardust/tags) [Activity](https://github.com/Cracked5pider/Stardust/activity)

[Star](https://github.com/login?return_to=%2FCracked5pider%2FStardust)

[Notifications](https://github.com/login?return_to=%2FCracked5pider%2FStardust) You must be signed in to change notification settings

# Cracked5pider/Stardust

main

[**2** Branches](https://github.com/Cracked5pider/Stardust/branches) [**0** Tags](https://github.com/Cracked5pider/Stardust/tags)

[Go to Branches page](https://github.com/Cracked5pider/Stardust/branches)[Go to Tags page](https://github.com/Cracked5pider/Stardust/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Cracked5pider](https://avatars.githubusercontent.com/u/51360176?v=4&size=40)](https://github.com/Cracked5pider)[Cracked5pider](https://github.com/Cracked5pider/Stardust/commits?author=Cracked5pider)<br>[fix: resolve issue](https://github.com/Cracked5pider/Stardust/commit/5304dfbe2e08e2a2514c022fca699da68fa39960) [#9](https://github.com/Cracked5pider/Stardust/issues/9) [now](https://github.com/Cracked5pider/Stardust/commit/5304dfbe2e08e2a2514c022fca699da68fa39960)<br>11 months agoMar 21, 2025<br>[5304dfb](https://github.com/Cracked5pider/Stardust/commit/5304dfbe2e08e2a2514c022fca699da68fa39960) · 11 months agoMar 21, 2025<br>## History<br>[19 Commits](https://github.com/Cracked5pider/Stardust/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Cracked5pider/Stardust/commits/main/) 19 Commits |
| [bin/obj](https://github.com/Cracked5pider/Stardust/tree/main/bin/obj "This path skips through empty directories") | [bin/obj](https://github.com/Cracked5pider/Stardust/tree/main/bin/obj "This path skips through empty directories") | [commit Stardust](https://github.com/Cracked5pider/Stardust/commit/9b2d9f0c3ea1cfc2be8426ede0aaba7e4e0c8528 "commit Stardust") | 2 years agoJan 27, 2024 |
| [include](https://github.com/Cracked5pider/Stardust/tree/main/include "include") | [include](https://github.com/Cracked5pider/Stardust/tree/main/include "include") | [Removed Python dependency in favor of objcopy. Fixed issue with DBG\_P…](https://github.com/Cracked5pider/Stardust/commit/b1fca298905f03f67124b938316be6d0f4573b01 "Removed Python dependency in favor of objcopy. Fixed issue with DBG_PRINTF macro. Updated resolver to use OriginalBase as OPSEC improvement.") | 11 months agoMar 15, 2025 |
| [scripts](https://github.com/Cracked5pider/Stardust/tree/main/scripts "scripts") | [scripts](https://github.com/Cracked5pider/Stardust/tree/main/scripts "scripts") | [Removed Python dependency in favor of objcopy. Fixed issue with DBG\_P…](https://github.com/Cracked5pider/Stardust/commit/b1fca298905f03f67124b938316be6d0f4573b01 "Removed Python dependency in favor of objcopy. Fixed issue with DBG_PRINTF macro. Updated resolver to use OriginalBase as OPSEC improvement.") | 11 months agoMar 15, 2025 |
| [src](https://github.com/Cracked5pider/Stardust/tree/main/src "src") | [src](https://github.com/Cracked5pider/Stardust/tree/main/src "src") | [fix: resolve issue](https://github.com/Cracked5pider/Stardust/commit/5304dfbe2e08e2a2514c022fca699da68fa39960 "fix: resolve issue #9 now") [#9](https://github.com/Cracked5pider/Stardust/issues/9) [now](https://github.com/Cracked5pider/Stardust/commit/5304dfbe2e08e2a2514c022fca699da68fa39960 "fix: resolve issue #9 now") | 11 months agoMar 21, 2025 |
| [static](https://github.com/Cracked5pider/Stardust/tree/main/static "static") | [static](https://github.com/Cracked5pider/Stardust/tree/main/static "static") | [refactor: rewrote the template](https://github.com/Cracked5pider/Stardust/commit/f754b986176ec204cfbfaa97f17b84c0d082d5be "refactor: rewrote the template") | 11 months agoMar 13, 2025 |
| [test](https://github.com/Cracked5pider/Stardust/tree/main/test "test") | [test](https://github.com/Cracked5pider/Stardust/tree/main/test "test") | [refactor: rewrote the template](https://github.com/Cracked5pider/Stardust/commit/f754b986176ec204cfbfaa97f17b84c0d082d5be "refactor: rewrote the template") | 11 months agoMar 13, 2025 |
| [CMakeLists.txt](https://github.com/Cracked5pider/Stardust/blob/main/CMakeLists.txt "CMakeLists.txt") | [CMakeLists.txt](https://github.com/Cracked5pider/Stardust/blob/main/CMakeLists.txt "CMakeLists.txt") | [refactor: rewrote the template](https://github.com/Cracked5pider/Stardust/commit/f754b986176ec204cfbfaa97f17b84c0d082d5be "refactor: rewrote the template") | 11 months agoMar 13, 2025 |
| [Makefile](https://github.com/Cracked5pider/Stardust/blob/main/Makefile "Makefile") | [Makefile](https://github.com/Cracked5pider/Stardust/blob/main/Makefile "Makefile") | [Removed Python dependency in favor of objcopy. Fixed issue with DBG\_P…](https://github.com/Cracked5pider/Stardust/commit/b1fca298905f03f67124b938316be6d0f4573b01 "Removed Python dependency in favor of objcopy. Fixed issue with DBG_PRINTF macro. Updated resolver to use OriginalBase as OPSEC improvement.") | 11 months agoMar 15, 2025 |
| [README.md](https://github.com/Cracked5pider/Stardust/blob/main/README.md "README.md") | [README.md](https://github.com/Cracked5pider/Stardust/blob/main/README.md "README.md") | [Removed Python dependency in favor of objcopy. Fixed issue with DBG\_P…](https://github.com/Cracked5pider/Stardust/commit/b1fca298905f03f67124b938316be6d0f4573b01 "Removed Python dependency in favor of objcopy. Fixed issue with DBG_PRINTF macro. Updated resolver to use OriginalBase as OPSEC improvement.") | 11 months agoMar 15, 2025 |
| View all files |

## Repository files navigation

# Stardust

[Permalink: Stardust](https://github.com/Cracked5pider/Stardust#stardust)

A modern and easy to use 32/64-bit shellcode template.

- raw strings
- C++20 project
- uses compile time hashing with fnv1a for both function and module resolving

### Basic Usage

[Permalink: Basic Usage](https://github.com/Cracked5pider/Stardust#basic-usage)

resolving modules from PEB using `resolve::module`:

```
if ( ! (( ntdll.handle = resolve::module( expr::hash_string<wchar_t>( L"ntdll.dll" ) ) )) ) {
    return;
}

if ( ! (( kernel32.handle = resolve::module( expr::hash_string<wchar_t>( L"kernel32.dll" ) ) )) ) {
    return;
}
```

resolving function apis using either `RESOLVE_API` macro or `resolve::api` function:

```
const auto user32 = kernel32.LoadLibraryA( symbol<const char*>( "user32.dll" ) );

decltype( MessageBoxA ) * msgbox = RESOLVE_API( reinterpret_cast<uintptr_t>( user32 ), MessageBoxA );

msgbox( nullptr, symbol<const char*>( "Hello world" ), symbol<const char*>( "caption" ), MB_OK );
```

The `RESOLVE_API` is a wrapper around `resolve::api` to automatically hashes the function name and cast the function pointer to the function type.

string hashing for both UTF-8 and UTF-16 using the compile time `expr::hash_string` function:

```
auto user32_hash      = expr::hash_string<wchar_t>( L"user32.dll" );
auto loadlibrary_hash = expr::hash_string<char>( "LoadLibraryA" );
```

raw strings support for both 32/64-bit by using the `symbol` function:

```
auto caption_string = symbol<const char*>( "hello from stardust" );

user32.MessageBoxA( nullptr, caption_string, symbol<const char*>( "message title" ), MB_OK );
```

easy to add new apis and modules to the instance. Under `include/common.h` the following entry has to be made:

```
class instance {
    ...

    struct
    {
        uintptr_t handle; // base address to user32.dll

        struct {
            D_API( MessageBoxA );
            // more entries can be added here
        };
    } user32 = {
        RESOLVE_TYPE( MessageBoxA ),
        // more entries can be added here
    };

    ...
```

while the `src/main.cc` should resolve the base address of user32 and resolve the api pointer:

```
declfn instance::instance(
    void
) {
    ...
    //
    // resolve user32.dll from PEB if loaded
    if ( ! (( user32.handle = resolve::module( expr::hash_string<wchar_t>( L"user32.dll" ) ) )) ) {
        return;
    }

    //
    // automatically resolve every entry imported
    // by user32 from the structure
    RESOLVE_IMPORT( user32 );
    ...
}
```

semi friendly debugging capabilities via DbgPrint. The project althought needs to be compiled in debug mode by specifying `make debug`. Usage:

```
const auto user32 = kernel32.LoadLibraryA( symbol<const char*>( "user32.dll" ) );

if ( user32 ) {
    DBG_PRINTF( "oh wow look we loaded user32.dll -> %p\n", user32 );
} else {
    DBG_PRINTF( "okay something went wrong. failed to load user32 :/\n" );
}

DBG_PRINTF( "running from %ls (Pid: %d)\n",
    NtCurrentPeb()->ProcessParameters->ImagePathName.Buffer,
    NtCurrentTeb()->ClientId.UniqueProcess );

DBG_PRINTF( "shellcode @ %p [%d bytes]\n", base.address, base.length );
```

### Building

[Permalink: Building](https://github.com/Cracked5pider/Stardust#building)

Build in release mode:

```
$ make                                                                                                                                                                                                                                                                                  20:17:26
-> compiling src/main.cc to main.x64.obj
-> compiling src/resolve.cc to resolve.x64.obj
compiling x64 project
/usr/bin/x86_64-w64-mingw32-ld: bin/stardust.x64.exe:.text: section below image base
-> compiling src/main.cc to main.x86.obj
-> compiling src/resolve.cc to resolve.x86.obj
compiling x86 project
/usr/bin/i686-w64-mingw32-ld: bin/stardust.x86.exe:.text: section below image base
$ ll bin                                                                                                                                                                                                                                                                                20:57:10
drwxr-xr-x spider spider 4.0 KB Thu Mar 13 20:57:10 2025 obj
.rw-r--r-- spider spider 752 B  Thu Mar 13 20:57:10 2025 stardust.x64.bin
.rw-r--r-- spider spider 672 B  Thu Mar 13 20:57:10 2025 stardust.x86.bin
```

Build in debug mode:

```
$ make debug                                                                                                                                                                                                                                                                            20:57:14
-> compiling src/main.cc to main.x64.obj
-> compiling src/resolve.cc to resolve.x64.obj
compiling x64 project
/usr/bin/x86_64-w64-mingw32-ld: bin/stardust.x64.exe:.text: section below image base
-> compiling src/main.cc to main.x86.obj
-> compiling src/resolve.cc to resolve.x86.obj
compiling x86 project
/usr/bin/i686-w64-mingw32-ld: bin/stardust.x86.exe:.text: section below image base
$ ll bin                                                                                                                                                                                                                                                                                20:58:13
drwxr-xr-x spider spider 4.0 KB Thu Mar 13 20:58:13 2025 obj
.rw-r--r-- spider spider 1.2 KB Thu Mar 13 20:58:13 2025 stardust.x64.bin
.rw-r--r-- spider spider 1.1 KB Thu Mar 13 20:58:13 2025 stardust.x86.bin
```

## Demo

[Permalink: Demo](https://github.com/Cracked5pider/Stardust#demo)

x64:
[![x64](https://github.com/Cracked5pider/Stardust/raw/main/static/stomper.x64.png)](https://github.com/Cracked5pider/Stardust/blob/main/static/stomper.x64.png)

x86:
[![x86](https://github.com/Cracked5pider/Stardust/raw/main/static/stomper.x86.png)](https://github.com/Cracked5pider/Stardust/blob/main/static/stomper.x86.png)

## About

A modern 32/64-bit position independent implant template


[5pider.net/blog/2024/01/27/modern-shellcode-implant-design](https://5pider.net/blog/2024/01/27/modern-shellcode-implant-design "https://5pider.net/blog/2024/01/27/modern-shellcode-implant-design")

### Resources

[Readme](https://github.com/Cracked5pider/Stardust#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Cracked5pider/Stardust).

[Activity](https://github.com/Cracked5pider/Stardust/activity)

### Stars

[**1.3k**\\
stars](https://github.com/Cracked5pider/Stardust/stargazers)

### Watchers

[**23**\\
watching](https://github.com/Cracked5pider/Stardust/watchers)

### Forks

[**210**\\
forks](https://github.com/Cracked5pider/Stardust/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FCracked5pider%2FStardust&report=Cracked5pider+%28user%29)

## [Releases](https://github.com/Cracked5pider/Stardust/releases)

No releases published

## [Packages\  0](https://github.com/users/Cracked5pider/packages?repo_name=Stardust)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Cracked5pider/Stardust).

## [Contributors\  4](https://github.com/Cracked5pider/Stardust/graphs/contributors)

- [![@Cracked5pider](https://avatars.githubusercontent.com/u/51360176?s=64&v=4)](https://github.com/Cracked5pider)[**Cracked5pider** 5pider](https://github.com/Cracked5pider)
- [![@0xVavaldi](https://avatars.githubusercontent.com/u/33965786?s=64&v=4)](https://github.com/0xVavaldi)[**0xVavaldi** Vavaldi](https://github.com/0xVavaldi)
- [![@Cerbersec](https://avatars.githubusercontent.com/u/58052983?s=64&v=4)](https://github.com/Cerbersec)[**Cerbersec** Cerbersec](https://github.com/Cerbersec)
- [![@imposecost](https://avatars.githubusercontent.com/u/156708357?s=64&v=4)](https://github.com/imposecost)[**imposecost**](https://github.com/imposecost)

## Languages

- [C97.0%](https://github.com/Cracked5pider/Stardust/search?l=c)
- [C++2.4%](https://github.com/Cracked5pider/Stardust/search?l=c%2B%2B)
- Other0.6%

You can’t perform that action at this time.