# https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file#bytecode_jiu-jitsu

[Skip to content](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file) to refresh your session.Dismiss alert

{{ message }}

[ntt-zerolab](https://github.com/ntt-zerolab)/ **[Bytecode\_Jiu-Jitsu](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu)** Public

- [Notifications](https://github.com/login?return_to=%2Fntt-zerolab%2FBytecode_Jiu-Jitsu) You must be signed in to change notification settings
- [Fork\\
1](https://github.com/login?return_to=%2Fntt-zerolab%2FBytecode_Jiu-Jitsu)
- [Star\\
22](https://github.com/login?return_to=%2Fntt-zerolab%2FBytecode_Jiu-Jitsu)


PoC tools of Bytecode Jiu-Jitsu presented at Black Hat USA 2024 Briefings


### License

[View license](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/LICENSE)

[22\\
stars](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/stargazers) [1\\
fork](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/forks) [Branches](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/branches) [Tags](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tags) [Activity](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/activity)

[Star](https://github.com/login?return_to=%2Fntt-zerolab%2FBytecode_Jiu-Jitsu)

[Notifications](https://github.com/login?return_to=%2Fntt-zerolab%2FBytecode_Jiu-Jitsu) You must be signed in to change notification settings

# ntt-zerolab/Bytecode\_Jiu-Jitsu

main

[**1** Branch](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/branches) [**0** Tags](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tags)

[Go to Branches page](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/branches)[Go to Tags page](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![hex86-64](https://avatars.githubusercontent.com/u/177284697?v=4&size=40)](https://github.com/hex86-64)[hex86-64](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commits?author=hex86-64)<br>[Update README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/5de8a4643e9b12a11d6a37eacf32b0a7529c9cd3)<br>6 months agoAug 31, 2025<br>[5de8a46](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/5de8a4643e9b12a11d6a37eacf32b0a7529c9cd3) · 6 months agoAug 31, 2025<br>## History<br>[13 Commits](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commits/main/) 13 Commits |
| [Extractor-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Extractor-BJJ "Extractor-BJJ") | [Extractor-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Extractor-BJJ "Extractor-BJJ") | [Initial commit](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/dad8a826dd106072c0e96b856931b5e31f771ab5 "Initial commit") | 6 months agoAug 31, 2025 |
| [Injector-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Injector-BJJ "Injector-BJJ") | [Injector-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Injector-BJJ "Injector-BJJ") | [Initial commit](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/dad8a826dd106072c0e96b856931b5e31f771ab5 "Initial commit") | 6 months agoAug 31, 2025 |
| [STAGER-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/STAGER-BJJ "STAGER-BJJ") | [STAGER-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/STAGER-BJJ "STAGER-BJJ") | [Update README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/ee530bd261545f208f3da1fd4550e0c4b68bd2c4 "Update README.md") | 6 months agoAug 31, 2025 |
| [Tracer-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Tracer-BJJ "Tracer-BJJ") | [Tracer-BJJ](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/tree/main/Tracer-BJJ "Tracer-BJJ") | [Update README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/ad93b5b6042df4c4539bb5c73f63f573bf2298e2 "Update README.md") | 6 months agoAug 31, 2025 |
| [LICENSE](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/LICENSE "LICENSE") | [Create LICENSE](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/a9a62bbcf6276b67aebd5be3a55b5786c79bfe27 "Create LICENSE") | 6 months agoAug 31, 2025 |
| [README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/README.md "README.md") | [README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/README.md "README.md") | [Update README.md](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/5de8a4643e9b12a11d6a37eacf32b0a7529c9cd3 "Update README.md") | 6 months agoAug 31, 2025 |
| [demo\_sample\_pass=infected.zip](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/demo_sample_pass%3Dinfected.zip "demo_sample_pass=infected.zip") | [demo\_sample\_pass=infected.zip](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/blob/main/demo_sample_pass%3Dinfected.zip "demo_sample_pass=infected.zip") | [Add a PoC binary used in the demo.](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/commit/6c32de9d4055bcb4a43ed4cb5035bd31bba6f9a6 "Add a PoC binary used in the demo.") | 6 months agoAug 31, 2025 |
| View all files |

## Repository files navigation

# Bytecode\_Jiu-Jitsu

[Permalink: Bytecode_Jiu-Jitsu](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file#bytecode_jiu-jitsu)

PoC tools of Bytecode Jiu-Jitsu presented at Black Hat USA 2024 Briefings.

The presentation material is available here:
[https://www.blackhat.com/us-24/briefings/schedule/#bytecode-jiu-jitsu-choking-interpreters-to-force-execution-of-malicious-bytecode-38682](https://www.blackhat.com/us-24/briefings/schedule/#bytecode-jiu-jitsu-choking-interpreters-to-force-execution-of-malicious-bytecode-38682)

The PoC Injector binary we used in the presentation:
[https://www.virustotal.com/gui/file/3dd69181f59fbea2f95cb2ccf0d9827dc70f38c844f465abeeeed42c3f12f9f9](https://www.virustotal.com/gui/file/3dd69181f59fbea2f95cb2ccf0d9827dc70f38c844f465abeeeed42c3f12f9f9)

The workflow to use our tools for injection:

\[Target interpreter\] -> Tracer-BJJ -\[Trace log\]-> STAGER-BJJ -\[Interpreter's internal structure\]-> Extractor-BJJ -\[Extracted bytecode and symbol tables\]-> Injector-BJJ

For more information, please see README.md of each tool.

If any abuse of our tools in the wild is identified and action is required, please contact us through the inquiry desk: [tos.usui@ntt.com](mailto:tos.usui@ntt.com).
We are prepared to discuss measures such as sharing information with security vendors and law enforcement, as well as the potential withdrawal of this repository.

## About

PoC tools of Bytecode Jiu-Jitsu presented at Black Hat USA 2024 Briefings


### Resources

[Readme](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file#readme-ov-file)

### License

[View license](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file#License-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu?tab=readme-ov-file).

[Activity](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/activity)

[Custom properties](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/custom-properties)

### Stars

[**22**\\
stars](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/stargazers)

### Watchers

[**5**\\
watching](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/watchers)

### Forks

[**1**\\
fork](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fntt-zerolab%2FBytecode_Jiu-Jitsu&report=ntt-zerolab+%28user%29)

## [Releases](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/releases)

No releases published

## [Packages\  0](https://github.com/orgs/ntt-zerolab/packages?repo_name=Bytecode_Jiu-Jitsu)

No packages published

## Languages

- [C++69.4%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=c%2B%2B)
- [Python24.3%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=python)
- [C4.4%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=c)
- [Makefile1.2%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=makefile)
- [PowerShell0.3%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=powershell)
- [Shell0.2%](https://github.com/ntt-zerolab/Bytecode_Jiu-Jitsu/search?l=shell)
- Other0.2%

You can’t perform that action at this time.