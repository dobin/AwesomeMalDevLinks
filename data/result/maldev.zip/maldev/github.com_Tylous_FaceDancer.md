# https://github.com/Tylous/FaceDancer

[Skip to content](https://github.com/Tylous/FaceDancer#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Tylous/FaceDancer) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Tylous/FaceDancer) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Tylous/FaceDancer) to refresh your session.Dismiss alert

{{ message }}

[Tylous](https://github.com/Tylous)/ **[FaceDancer](https://github.com/Tylous/FaceDancer)** Public

- [Notifications](https://github.com/login?return_to=%2FTylous%2FFaceDancer) You must be signed in to change notification settings
- [Fork\\
51](https://github.com/login?return_to=%2FTylous%2FFaceDancer)
- [Star\\
398](https://github.com/login?return_to=%2FTylous%2FFaceDancer)


FaceDancer is an exploitation tool aimed at creating hijackable, proxy-based DLLs by taking advantage of COM-based system DLL image loading


### License

[MIT license](https://github.com/Tylous/FaceDancer/blob/main/LICENSE)

[398\\
stars](https://github.com/Tylous/FaceDancer/stargazers) [51\\
forks](https://github.com/Tylous/FaceDancer/forks) [Branches](https://github.com/Tylous/FaceDancer/branches) [Tags](https://github.com/Tylous/FaceDancer/tags) [Activity](https://github.com/Tylous/FaceDancer/activity)

[Star](https://github.com/login?return_to=%2FTylous%2FFaceDancer)

[Notifications](https://github.com/login?return_to=%2FTylous%2FFaceDancer) You must be signed in to change notification settings

# Tylous/FaceDancer

main

[**1** Branch](https://github.com/Tylous/FaceDancer/branches) [**1** Tag](https://github.com/Tylous/FaceDancer/tags)

[Go to Branches page](https://github.com/Tylous/FaceDancer/branches)[Go to Tags page](https://github.com/Tylous/FaceDancer/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Tylous](https://avatars.githubusercontent.com/u/15052743?v=4&size=40)](https://github.com/Tylous)[Tylous](https://github.com/Tylous/FaceDancer/commits?author=Tylous)<br>[Update README.md](https://github.com/Tylous/FaceDancer/commit/981559a07708b637caa021ff7e476b2f8cbe58db)<br>2 years agoSep 26, 2024<br>[981559a](https://github.com/Tylous/FaceDancer/commit/981559a07708b637caa021ff7e476b2f8cbe58db) · 2 years agoSep 26, 2024<br>## History<br>[3 Commits](https://github.com/Tylous/FaceDancer/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Tylous/FaceDancer/commits/main/) 3 Commits |
| [Screenshots](https://github.com/Tylous/FaceDancer/tree/main/Screenshots "Screenshots") | [Screenshots](https://github.com/Tylous/FaceDancer/tree/main/Screenshots "Screenshots") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [build](https://github.com/Tylous/FaceDancer/tree/main/build "build") | [build](https://github.com/Tylous/FaceDancer/tree/main/build "build") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [exports](https://github.com/Tylous/FaceDancer/tree/main/exports "exports") | [exports](https://github.com/Tylous/FaceDancer/tree/main/exports "exports") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [lib](https://github.com/Tylous/FaceDancer/tree/main/lib "lib") | [lib](https://github.com/Tylous/FaceDancer/tree/main/lib "lib") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [src](https://github.com/Tylous/FaceDancer/tree/main/src "src") | [src](https://github.com/Tylous/FaceDancer/tree/main/src "src") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [.gitignore](https://github.com/Tylous/FaceDancer/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/Tylous/FaceDancer/blob/main/.gitignore ".gitignore") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [Cargo.toml](https://github.com/Tylous/FaceDancer/blob/main/Cargo.toml "Cargo.toml") | [Cargo.toml](https://github.com/Tylous/FaceDancer/blob/main/Cargo.toml "Cargo.toml") | [v1.0](https://github.com/Tylous/FaceDancer/commit/df5a0ac28eaf49428aef6d6d6928ebfac194a869 "v1.0") | 2 years agoSep 25, 2024 |
| [LICENSE](https://github.com/Tylous/FaceDancer/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/Tylous/FaceDancer/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/Tylous/FaceDancer/commit/58b6c1e6a0a344ce124e72b2a7070f8e38828108 "Initial commit") | 2 years agoSep 24, 2024 |
| [README.md](https://github.com/Tylous/FaceDancer/blob/main/README.md "README.md") | [README.md](https://github.com/Tylous/FaceDancer/blob/main/README.md "README.md") | [Update README.md](https://github.com/Tylous/FaceDancer/commit/981559a07708b637caa021ff7e476b2f8cbe58db "Update README.md") | 2 years agoSep 26, 2024 |
| View all files |

## Repository files navigation

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/FaceDancer_logo.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/FaceDancer_logo.png)

**FaceDancer**

## Description

[Permalink: Description](https://github.com/Tylous/FaceDancer#description)

FaceDancer is an exploitation tool aimed at creating hijackable, proxy-based DLLs. FaceDancer performs two main functions:

- Recon: Scans a given DLL to create the export definition file for proxying.
- Attack: Creates a malicious DLL containing shellcode that can proxy valid function requests to the legitimate DLL.

FaceDancer contains numerous methods for performing DLL hijacking. These DLLs take advantage of either weak permissions on installation folders or COM-based system DLL image loading to load a malicious version of a legitimate DLL. Once loaded, the DLL executes the embedded shellcode while proxying valid requests for DLL functions to the legitimate DLL. This is done using a .def file to map the valid requests to the correct DLL, allowing a low-privilege user to proxy a legitimate DLL through a malicious one. This bypasses application whitelisting controls as FaceDancer targets native processes needed for standard operation, making it effective for initial access or persistence.

FaceDancer contains zero evasion techniques. FaceDancer’s sole focus is discovering and generating DLLs for proxying. It is important that the inputted DLL contains all the necessary evasion techniques. For more information about the techniques and how they are discovered, please see my [blog](https://www.blackhillsinfosec.com/a-different-take-on-dll-hijacking/).

#### Microsoft's Response

[Permalink: Microsoft's Response](https://github.com/Tylous/FaceDancer#microsofts-response)

As of now, Microsoft has no plans to fix or remediate these issues but acknowledges them as valid vulnerabilities.

## Attack Methods

[Permalink: Attack Methods](https://github.com/Tylous/FaceDancer#attack-methods)

### DLL Based Proxy

[Permalink: DLL Based Proxy](https://github.com/Tylous/FaceDancer#dll-based-proxy)

At a high level, this involves exploiting DLLs that reside in folders that are not properly protected when installed, allowing an attacker to abuse the Load Image operation when the application is launched via DLL proxying. The overarching issue is that when Microsoft Teams is configured with an account, the application installs some additional plugins (including an Outlook plugin). Some of these plugins are installed in the user’s AppData folder with overly permissive permissions (i.e., write permission). Because of this, an attacker can rename a valid DLL in one of these directories that a process loads when it first launches and place their own malicious DLL in the same folder to have it automatically load and execute. This does not require admin privileges.

#### Example OneAuth.DLL

[Permalink: Example OneAuth.DLL](https://github.com/Tylous/FaceDancer#example-oneauthdll)

When Microsoft Teams v2 (aka Microsoft Teams for Work and School) is configured with a user’s profile, it installs a package called TeamsMeetingAddin into Outlook (if Outlook is installed). The folder containing the associated DLLs for this add-in can be modified by low-privilege users to both rename the legitimate DLLs and add malicious DLLs. This means the next time Outlook is launched, the malicious DLL is loaded by Outlook, leading to code execution as the Outlook process.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/OneAuth_ImageLoad.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/OneAuth_ImageLoad.png)

All files in this directory can be modified by a low-privilege user.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/OneAuth_Permissions.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/OneAuth_Permissions.png)

A DLL proxy attack is necessary to ensure that the original DLL is still loaded, preventing Outlook from crashing. The screenshot below demonstrates using this attack to execute arbitrary code, in this case, a Rust “Hello, World!” program, via Outlook.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Hello_World.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Hello_World.png)

### Proxying Function Requests

[Permalink: Proxying Function Requests](https://github.com/Tylous/FaceDancer#proxying-function-requests)

Using definition files (.def), which are text files containing one or more module statements that describe various attributes of a DLL, we can define all the exported functions and proxy them to the legitimate DLL that contains the requested functions. By using an export.def file, we can rename the legitimate DLL to whatever we want (in the example below, we append -old to the name), place our DLL in the same folder, and when a process loads it, our DLL will proxy any requests for one of the DLL’s functions to the legitimate one.

```
    EXPORTS
    ?IsZero@UUID@Authentication@Microsoft@@QEBA_NXZ=OneAuth-old.?IsZero@UUID@Authentication@Microsoft@@QEBA_NXZ @1
    GetLastOneAuthError=OneAuth-old.GetLastOneAuthError @2
    InitializeTelemetryCallbacks=OneAuth-old.InitializeTelemetryCallbacks @3
```

Because of this only one DLL is ever loaded (not OneAuth and OneAuth-legitmate) but when we look at the DLL's export functions we can see that each of the proxyed functions call back to OneAuth-legitmate.dll.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Process_Running.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Process_Running.png)

### COM based Proxying

[Permalink: COM based Proxying](https://github.com/Tylous/FaceDancer#com-based-proxying)

COM-based DLL proxying takes a different approach. It exploits dependencies in numerous native Windows and third-party applications. When executed, as these processes start up, they query the registry for COM objects to find the path to certain system DLLs to load. What makes these requests interesting is that they first check the Current User (HKCU) section of the registry. If they are unable to find the values there, they fail over to another section of the registry where the entries exist.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Olk_Calling_Com.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Olk_Calling_Com.png)

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Com_Value.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Com_Value.png)

By creating the COM entries they look for, we can control which DLLs they load. Using the same proxy technique mentioned previously, we can load a DLL from anywhere as a system DLL and still proxy the traffic to the valid system DLL that resides in system32. This ensures there is no disruption to the process’s operation by still providing the valid functions. This all can be done as a low-privilege user without needing any privilege escalation or elevated permissions.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/msedge.dll.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/msedge.dll.png)

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Beacon.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Beacon.png)

It works against Microsoft’s WindowsApp-based applications, including the new versions of Outlook (olk.exe) and Teams (ms-teams.exe). Applications in this folder are blocked even from Administrators. Attempting to access the folder to view the contents results in denied access, even when running as an Administrator.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/WindowApps.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/WindowApps.png)

This makes sideloading into these applications extremely difficult; however, they still rely on COM objects to load DLLs.

[![](https://github.com/Tylous/FaceDancer/raw/main/Screenshots/Olk_Loading.png)](https://github.com/Tylous/FaceDancer/blob/main/Screenshots/Olk_Loading.png)

# How To Use

[Permalink: How To Use](https://github.com/Tylous/FaceDancer#how-to-use)

## Recon Mode

[Permalink: Recon Mode](https://github.com/Tylous/FaceDancer#recon-mode)

This mode allows FaceDancer to scan a specified DLL to generate the .def file for you. With this, you can then generate your own DLLs using FaceDancer rather then the pre-defined ones.

### Recon

[Permalink: Recon](https://github.com/Tylous/FaceDancer#recon)

```
    ___________                   ________
    \_   _____/____    ____  ____ \______ \ _____    ____   ____  ___________
     |    __) \__  \ _/ ___\/ __ \ |    |  \\__  \  /    \_/ ___\/ __ \_  __ \
     |     \   / __ \\  \__\  ___/ |    `   \/ __ \|   |  \  \__\  ___/|  | \/
     \___  /  (____  /\___  >___  >_______  (____  /___|  /\___  >___  >__|
         \/        \/     \/    \/        \/     \/     \/     \/    \/
                                    (@Tyl0us)

Reconnaissance tools

Usage: FaceDancer recon [OPTIONS]

Options:
  -I, --Input <INPUT>  Path to the DLL to examine.
  -E, --exports        Displays the exported functions for the targeted DLL (only will show the first 20)
  -G, --generate       Generates the necessary .def for proxying
  -h, --help           Print help
```

## Attack Mode

[Permalink: Attack Mode](https://github.com/Tylous/FaceDancer#attack-mode)

This mode generates the actual DLLs used for proxying attacks. It works by taking an existing malicious DLL containing your shellcode and converting it into shellcode. Since FaceDancer does not contain any EDR evasion techniques, it is important that the inputted DLL includes all the necessary evasion techniques. This also means any type of DLL (not just Rust DLLs) can be used. Additionally, you can select the type of DLL attack you want to execute:

- `DLL` \- Generates a DLL to be dropped into a specific folder. Depending on which DLL you generate, you need to navigate to a different directory. Once there, rename the original DLL, paste your DLL in that folder.
- `COM` \- Generates a DLL along with the required registry entries to exploit it. With this type of DLL, any process that calls that COM object will load the DLL and execute the shellcode. For this to work, the provided registry keys need to be added to the HKCU section of the registry.
- `Process` \- Generates a DLL along with the required registry entries to exploit it. With this type of DLL, only when the specified process loads the DLL will the shellcode execute. For this to work, the provided registry keys need to be added to the HKCU section of the registry.

### Attack

[Permalink: Attack](https://github.com/Tylous/FaceDancer#attack)

```
    ___________                   ________
    \_   _____/____    ____  ____ \______ \ _____    ____   ____  ___________
     |    __) \__  \ _/ ___\/ __ \ |    |  \\__  \  /    \_/ ___\/ __ \_  __ \
     |     \   / __ \\  \__\  ___/ |    `   \/ __ \|   |  \  \__\  ___/|  | \/
     \___  /  (____  /\___  >___  >_______  (____  /___|  /\___  >___  >__|
         \/        \/     \/    \/        \/     \/     \/     \/    \/
                                    (@Tyl0us)

Attack tools

Usage: FaceDancer attack [OPTIONS]

Options:
  -O, --Output <OUTPUT>    Name of output DLL file.
  -I, --Input <INPUT>      Path to the 64-bit DLL.
  -D, --DLL <DLL>          The DLL to proxy:
                                               [1] OneAuth.dll
                                               [2] ffmpeg.dll (warning can be unstable)
                                               [3] skypert.dll
                                               [4] SlimCV.dll
  -C, --COM <COM>          The COM-DLL to proxy:
                                               [1] ExplorerFrame.dll
                                               [2] fastprox.dll
                                               [3] mssprxy.dll
                                               [4] netprofm.dll
                                               [5] npmproxy.dll
                                               [6] OneCoreCommonProxyStub.dll
                                               [7] propsys.dll
                                               [8] stobject.dll
                                               [9] wbemprox.dll
                                               [10] webplatstorageserver.dll
                                               [11] Windows.StateRepositoryPS.dll
                                               [12] windows.storage.dll
                                               [13] wpnapps.dll
  -P, --PROCESS <PROCESS>  Process to proxy load into:
                                               [1] Outlook
                                               [2] Excel
                                               [3] svchost
                                               [4] Explorer
                                               [5] sihost
                                               [6] msedge
                                               [7] OneDriveStandaloneUpdater
                                               [8] SSearchProtocolHost
                                               [9] Olk
                                               [10] Teams
                                               [11] Werfault
                                               [12] Sdxhelper
                                               [13] AppHostRegistrationVerifier
                                               [14] rdpclip
                                               [15] Microsoft.SharePoint
                                               [16] MusNotificationUx
                                               [17] PhoneExperienceHost
                                               [18] taskhostw
                                               [19] DllHost

  -s, --sandbox            Enables sandbox evasion by checking:
                                               - Is Endpoint joined to a domain?
                                               - Is the file's name the same as its SHA256 value?
  -h, --help               Print help
```

## Contributing

[Permalink: Contributing](https://github.com/Tylous/FaceDancer#contributing)

FaceDancer was developed in Rust.

## Help

[Permalink: Help](https://github.com/Tylous/FaceDancer#help)

```

    ___________                   ________
    \_   _____/____    ____  ____ \______ \ _____    ____   ____  ___________
     |    __) \__  \ _/ ___\/ __ \ |    |  \\__  \  /    \_/ ___\/ __ \_  __ \
     |     \   / __ \\  \__\  ___/ |    `   \/ __ \|   |  \  \__\  ___/|  | \/
     \___  /  (____  /\___  >___  >_______  (____  /___|  /\___  >___  >__|
         \/        \/     \/    \/        \/     \/     \/     \/    \/
                                    (@Tyl0us)

Does awesome things

Usage: FaceDancer [COMMAND]

Commands:
  recon   Reconnaissance tools
  attack  Attack tools
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
```

## Install

[Permalink: Install](https://github.com/Tylous/FaceDancer#install)

#### Note Please Ensure All Dependencies Are Installed

[Permalink: Note Please Ensure All Dependencies Are Installed](https://github.com/Tylous/FaceDancer#note-please-ensure-all-dependencies-are-installed)

If `Rust` and `Rustup` is not installed please install them. If you are compiling it from OSX or Linux sure you have the target "x86\_64-pc-windows-gnu" added. To so run the following command:

```
rustup target add x86_64-pc-windows-gnu
```

Once done you can compile FaceDancer, run the following commands, or use the compiled binary (found in the pre-compiled folder):

```
cargo build --release
```

From there the compiled version will be found in in target/release (note if you don't put `--release` the file will be in target/debug/ )

### Credit

[Permalink: Credit](https://github.com/Tylous/FaceDancer#credit)

Special thanks to Teach2Breach for developing [dll2shell](https://github.com/Teach2Breach/dll2shell/tree/main)

## About

FaceDancer is an exploitation tool aimed at creating hijackable, proxy-based DLLs by taking advantage of COM-based system DLL image loading


### Resources

[Readme](https://github.com/Tylous/FaceDancer#readme-ov-file)

### License

[MIT license](https://github.com/Tylous/FaceDancer#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Tylous/FaceDancer).

[Activity](https://github.com/Tylous/FaceDancer/activity)

### Stars

[**398**\\
stars](https://github.com/Tylous/FaceDancer/stargazers)

### Watchers

[**5**\\
watching](https://github.com/Tylous/FaceDancer/watchers)

### Forks

[**51**\\
forks](https://github.com/Tylous/FaceDancer/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FTylous%2FFaceDancer&report=Tylous+%28user%29)

## [Releases\  1](https://github.com/Tylous/FaceDancer/releases)

[V1.0\\
Latest\\
\\
on Sep 25, 2024Sep 25, 2024](https://github.com/Tylous/FaceDancer/releases/tag/v1.0)

## [Packages\  0](https://github.com/users/Tylous/packages?repo_name=FaceDancer)

No packages published

## Languages

- [Rust100.0%](https://github.com/Tylous/FaceDancer/search?l=rust)

You can’t perform that action at this time.