# https://github.com/monoxgas/sRDI

[Skip to content](https://github.com/monoxgas/sRDI#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/monoxgas/sRDI) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/monoxgas/sRDI) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/monoxgas/sRDI) to refresh your session.Dismiss alert

{{ message }}

[monoxgas](https://github.com/monoxgas)/ **[sRDI](https://github.com/monoxgas/sRDI)** Public

- [Notifications](https://github.com/login?return_to=%2Fmonoxgas%2FsRDI) You must be signed in to change notification settings
- [Fork\\
499](https://github.com/login?return_to=%2Fmonoxgas%2FsRDI)
- [Star\\
2.5k](https://github.com/login?return_to=%2Fmonoxgas%2FsRDI)


Shellcode implementation of Reflective DLL Injection. Convert DLLs to position independent shellcode


### License

[View license](https://github.com/monoxgas/sRDI/blob/master/LICENSE)

[2.5k\\
stars](https://github.com/monoxgas/sRDI/stargazers) [499\\
forks](https://github.com/monoxgas/sRDI/forks) [Branches](https://github.com/monoxgas/sRDI/branches) [Tags](https://github.com/monoxgas/sRDI/tags) [Activity](https://github.com/monoxgas/sRDI/activity)

[Star](https://github.com/login?return_to=%2Fmonoxgas%2FsRDI)

[Notifications](https://github.com/login?return_to=%2Fmonoxgas%2FsRDI) You must be signed in to change notification settings

# monoxgas/sRDI

master

[**2** Branches](https://github.com/monoxgas/sRDI/branches) [**0** Tags](https://github.com/monoxgas/sRDI/tags)

[Go to Branches page](https://github.com/monoxgas/sRDI/branches)[Go to Tags page](https://github.com/monoxgas/sRDI/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![monoxgas](https://avatars.githubusercontent.com/u/1223016?v=4&size=40)](https://github.com/monoxgas)[monoxgas](https://github.com/monoxgas/sRDI/commits?author=monoxgas)<br>[Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c)<br>4 years agoJun 17, 2022<br>[9fdd5c4](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c) · 4 years agoJun 17, 2022<br>## History<br>[91 Commits](https://github.com/monoxgas/sRDI/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/monoxgas/sRDI/commits/master/) 91 Commits |
| [DotNet](https://github.com/monoxgas/sRDI/tree/master/DotNet "DotNet") | [DotNet](https://github.com/monoxgas/sRDI/tree/master/DotNet "DotNet") | [Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c "Hash lookup changes") | 4 years agoJun 17, 2022 |
| [FunctionTest](https://github.com/monoxgas/sRDI/tree/master/FunctionTest "FunctionTest") | [FunctionTest](https://github.com/monoxgas/sRDI/tree/master/FunctionTest "FunctionTest") | [Update build tools versions](https://github.com/monoxgas/sRDI/commit/4aecf9923581224621394a9ae514d2df4ad8282b "Update build tools versions") | 6 years agoSep 14, 2020 |
| [Native](https://github.com/monoxgas/sRDI/tree/master/Native "Native") | [Native](https://github.com/monoxgas/sRDI/tree/master/Native "Native") | [Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c "Hash lookup changes") | 4 years agoJun 17, 2022 |
| [PowerShell](https://github.com/monoxgas/sRDI/tree/master/PowerShell "PowerShell") | [PowerShell](https://github.com/monoxgas/sRDI/tree/master/PowerShell "PowerShell") | [Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c "Hash lookup changes") | 4 years agoJun 17, 2022 |
| [Python](https://github.com/monoxgas/sRDI/tree/master/Python "Python") | [Python](https://github.com/monoxgas/sRDI/tree/master/Python "Python") | [Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c "Hash lookup changes") | 4 years agoJun 17, 2022 |
| [ShellcodeRDI](https://github.com/monoxgas/sRDI/tree/master/ShellcodeRDI "ShellcodeRDI") | [ShellcodeRDI](https://github.com/monoxgas/sRDI/tree/master/ShellcodeRDI "ShellcodeRDI") | [Hash lookup changes](https://github.com/monoxgas/sRDI/commit/9fdd5c44383039519accd1e6bac4acd5a046a92c "Hash lookup changes") | 4 years agoJun 17, 2022 |
| [TestDLL](https://github.com/monoxgas/sRDI/tree/master/TestDLL "TestDLL") | [TestDLL](https://github.com/monoxgas/sRDI/tree/master/TestDLL "TestDLL") | [Update build tools versions](https://github.com/monoxgas/sRDI/commit/4aecf9923581224621394a9ae514d2df4ad8282b "Update build tools versions") | 6 years agoSep 14, 2020 |
| [bin](https://github.com/monoxgas/sRDI/tree/master/bin "bin") | [bin](https://github.com/monoxgas/sRDI/tree/master/bin "bin") | [Add Bin directory](https://github.com/monoxgas/sRDI/commit/cbd19211e86fedfd42107e9cdd6e12228c1dfdfe "Add Bin directory") | 9 years agoJul 28, 2017 |
| [lib](https://github.com/monoxgas/sRDI/tree/master/lib "lib") | [lib](https://github.com/monoxgas/sRDI/tree/master/lib "lib") | [Fix Python + EncodeBlobs bug](https://github.com/monoxgas/sRDI/commit/5c4fae4a9f4d4e0ffc1f0fb6dcadde417e232fd9 "Fix Python + EncodeBlobs bug  Change to bytes") | 7 years agoAug 23, 2019 |
| [.gitignore](https://github.com/monoxgas/sRDI/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/monoxgas/sRDI/blob/master/.gitignore ".gitignore") | [Add Bin directory](https://github.com/monoxgas/sRDI/commit/cbd19211e86fedfd42107e9cdd6e12228c1dfdfe "Add Bin directory") | 9 years agoJul 28, 2017 |
| [LICENSE](https://github.com/monoxgas/sRDI/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/monoxgas/sRDI/blob/master/LICENSE "LICENSE") | [Update License - RDI](https://github.com/monoxgas/sRDI/commit/92f0207f0d819de9cbe2c8b8e12b736e44d60a4b "Update License - RDI  Added license information for Dan Staples and Stephen Fewer") | 9 years agoJul 31, 2017 |
| [README.md](https://github.com/monoxgas/sRDI/blob/master/README.md "README.md") | [README.md](https://github.com/monoxgas/sRDI/blob/master/README.md "README.md") | [Add support for passing the shellcode base address to the module export](https://github.com/monoxgas/sRDI/commit/e32abbe82e1f957fb058c3770375da3bf71a8cab "Add support for passing the shellcode base address to the module export Some cleanup and additional notes to the README") | 4 years agoMay 9, 2022 |
| [ShellcodeRDI.sln](https://github.com/monoxgas/sRDI/blob/master/ShellcodeRDI.sln "ShellcodeRDI.sln") | [ShellcodeRDI.sln](https://github.com/monoxgas/sRDI/blob/master/ShellcodeRDI.sln "ShellcodeRDI.sln") | [Add support for passing the shellcode base address to the module export](https://github.com/monoxgas/sRDI/commit/e32abbe82e1f957fb058c3770375da3bf71a8cab "Add support for passing the shellcode base address to the module export Some cleanup and additional notes to the README") | 4 years agoMay 9, 2022 |
| View all files |

## Repository files navigation

# sRDI - Shellcode Reflective DLL Injection

[Permalink: sRDI - Shellcode Reflective DLL Injection](https://github.com/monoxgas/sRDI#srdi---shellcode-reflective-dll-injection)

sRDI allows for the conversion of DLL files to position independent shellcode. It attempts to be a fully functional PE loader supporting proper section permissions, TLS callbacks, and sanity checks. It can be thought of as a shellcode PE loader strapped to a packed DLL.

Functionality is accomplished via two components:

- C project which compiles a PE loader implementation (RDI) to shellcode
- Conversion code which attaches the DLL, RDI, and user data together with a bootstrap

This project is comprised of the following elements:

- **ShellcodeRDI:** Compiles shellcode for the DLL loader
- **NativeLoader:** Converts DLL to shellcode if neccesarry, then injects into memory
- **DotNetLoader:** C# implementation of NativeLoader
- **Python\\ConvertToShellcode.py:** Convert DLL to shellcode in place
- **Python\\EncodeBlobs.py:** Encodes compiled sRDI blobs for static embedding
- **PowerShell\\ConvertTo-Shellcode.ps1:** Convert DLL to shellcode in place
- **FunctionTest:** Imports sRDI C function for debug testing
- **TestDLL:** Example DLL that includes two exported functions for call on Load and after

**The DLL does not need to be compiled with RDI, however the technique is cross compatiable.**

## Use Cases / Examples

[Permalink: Use Cases / Examples](https://github.com/monoxgas/sRDI#use-cases--examples)

Before use, I recommend you become familiar with [Reflective DLL Injection](https://disman.tl/2015/01/30/an-improved-reflective-dll-injection-technique.html) and it's purpose.

#### Convert DLL to shellcode using python

[Permalink: Convert DLL to shellcode using python](https://github.com/monoxgas/sRDI#convert-dll-to-shellcode-using-python)

```
from ShellcodeRDI import *

dll = open("TestDLL_x86.dll", 'rb').read()
shellcode = ConvertToShellcode(dll)
```

#### Load DLL into memory using C\# loader

[Permalink: Load DLL into memory using C# loader](https://github.com/monoxgas/sRDI#load-dll-into-memory-using-c-loader)

```
DotNetLoader.exe TestDLL_x64.dll
```

#### Convert DLL with python script and load with Native EXE

[Permalink: Convert DLL with python script and load with Native EXE](https://github.com/monoxgas/sRDI#convert-dll-with-python-script-and-load-with-native-exe)

```
python ConvertToShellcode.py TestDLL_x64.dll
NativeLoader.exe TestDLL_x64.bin
```

#### Convert DLL with powershell and load with Invoke-Shellcode

[Permalink: Convert DLL with powershell and load with Invoke-Shellcode](https://github.com/monoxgas/sRDI#convert-dll-with-powershell-and-load-with-invoke-shellcode)

```
Import-Module .\Invoke-Shellcode.ps1
Import-Module .\ConvertTo-Shellcode.ps1
Invoke-Shellcode -Shellcode (ConvertTo-Shellcode -File TestDLL_x64.dll)
```

## Flags

[Permalink: Flags](https://github.com/monoxgas/sRDI#flags)

The PE loader code uses `flags` argument to control the various options of loading logic:

- `SRDI_CLEARHEADER` \[0x1\]: The DOS Header and DOS Stub for the target DLL are completley wiped with null bytes on load (Except for e\_lfanew). This might cause issues with stock windows APIs when supplying the base address as a psuedo `HMODULE`.
- `SRDI_CLEARMEMORY` \[0x2\]: After calling functions in the loaded module (`DllMain` and any exports), the DLL data will be cleared from memory. This is dangerous if you expect to continue executing code out of the module (Threads / `GetProcAddressR`).
- `SRDI_OBFUSCATEIMPORTS` \[0x4\]: The order of imports in the module will be randomized before starting IAT patching. Additionally, the high 16 bits of the flag can be used to store the number of seconds to pause before processing the next import. For example, `flags | (3 << 16)` will pause 3 seconds between every import.
- `SRDI_PASS_SHELLCODE_BASE` \[0x8\]: As opposed to passing supplied user data to the exported function, sRDI will instead pass the base address of the currently executing shellcode block. This can be useful for self-cleanup inside more advanced modules.

## Building

[Permalink: Building](https://github.com/monoxgas/sRDI#building)

This project is built using Visual Studio 2019 (v142) and Windows SDK 10. The python script is written using Python 3.

The Python and Powershell scripts are located at:

- `Python\ConvertToShellcode.py`
- `PowerShell\ConvertTo-Shellcode.ps1`

After building the project, the other binaries will be located at:

- `bin\NativeLoader.exe`
- `bin\DotNetLoader.exe`
- `bin\TestDLL_<arch>.dll`
- `bin\ShellcodeRDI_<arch>.bin`

If you would like to update the static blobs inside any of the tools:

```
> python .\lib\Python\EncodeBlobs.py -h
usage: EncodeBlobs.py [-h] solution_dir

sRDI Blob Encoder

positional arguments:
  solution_dir  Solution Directory

optional arguments:
  -h, --help    show this help message and exit

> python lib\Python\EncodeBlobs.py C:\code\srdi

[+] Updated C:\code\srdi\Native/Loader.cpp
[+] Updated C:\code\srdi\DotNet/Program.cs
[+] Updated C:\code\srdi\Python/ShellcodeRDI.py
[+] Updated C:\code\srdi\PowerShell/ConvertTo-Shellcode.ps1
```

## Alternatives

[Permalink: Alternatives](https://github.com/monoxgas/sRDI#alternatives)

If you find my code disgusting, or just looking for an alternative memory-PE loader project, check out some of these:

- [https://github.com/fancycode/MemoryModule](https://github.com/fancycode/MemoryModule) \- Probably one of the cleanest PE loaders out there, great reference.
- [https://github.com/TheWover/donut](https://github.com/TheWover/donut) \- Want to convert .NET assemblies? Or how about JScript?
- [https://github.com/hasherezade/pe\_to\_shellcode](https://github.com/hasherezade/pe_to_shellcode) \- Generates a polymorphic PE+shellcode hybrids.
- [https://github.com/DarthTon/Blackbone](https://github.com/DarthTon/Blackbone) \- Large library with many memory hacking/hooking primitives.

## Credits

[Permalink: Credits](https://github.com/monoxgas/sRDI#credits)

The basis of this project is derived from ["Improved Reflective DLL Injection" from Dan Staples](https://disman.tl/2015/01/30/an-improved-reflective-dll-injection-technique.html) which itself is derived from the original project by [Stephen Fewer](https://github.com/stephenfewer/ReflectiveDLLInjection).

The project framework for compiling C code as shellcode is taken from [Mathew Graeber's reasearch "PIC\_BindShell"](http://www.exploit-monday.com/2013/08/writing-optimized-windows-shellcode-in-c.html)

## About

Shellcode implementation of Reflective DLL Injection. Convert DLLs to position independent shellcode


### Resources

[Readme](https://github.com/monoxgas/sRDI#readme-ov-file)

### License

[View license](https://github.com/monoxgas/sRDI#License-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/monoxgas/sRDI).

[Activity](https://github.com/monoxgas/sRDI/activity)

### Stars

[**2.5k**\\
stars](https://github.com/monoxgas/sRDI/stargazers)

### Watchers

[**58**\\
watching](https://github.com/monoxgas/sRDI/watchers)

### Forks

[**499**\\
forks](https://github.com/monoxgas/sRDI/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fmonoxgas%2FsRDI&report=monoxgas+%28user%29)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/monoxgas/sRDI).

## [Contributors\  6](https://github.com/monoxgas/sRDI/graphs/contributors)

- [![@monoxgas](https://avatars.githubusercontent.com/u/1223016?s=64&v=4)](https://github.com/monoxgas)
- [![@zeroSteiner](https://avatars.githubusercontent.com/u/2058303?s=64&v=4)](https://github.com/zeroSteiner)
- [![@funoverip](https://avatars.githubusercontent.com/u/7892650?s=64&v=4)](https://github.com/funoverip)
- [![@coldfusion39](https://avatars.githubusercontent.com/u/2766715?s=64&v=4)](https://github.com/coldfusion39)
- [![@jnokin](https://avatars.githubusercontent.com/u/4225057?s=64&v=4)](https://github.com/jnokin)
- [![@hmnthabit](https://avatars.githubusercontent.com/u/35005725?s=64&v=4)](https://github.com/hmnthabit)

## Languages

- [PowerShell43.7%](https://github.com/monoxgas/sRDI/search?l=powershell)
- [C#21.9%](https://github.com/monoxgas/sRDI/search?l=c%23)
- [C++13.4%](https://github.com/monoxgas/sRDI/search?l=c%2B%2B)
- [Python12.6%](https://github.com/monoxgas/sRDI/search?l=python)
- [C8.4%](https://github.com/monoxgas/sRDI/search?l=c)

You can’t perform that action at this time.