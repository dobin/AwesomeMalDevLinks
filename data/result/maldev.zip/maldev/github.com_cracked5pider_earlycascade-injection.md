# https://github.com/Cracked5pider/earlycascade-injection

[Skip to content](https://github.com/Cracked5pider/earlycascade-injection#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Cracked5pider/earlycascade-injection) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Cracked5pider/earlycascade-injection) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Cracked5pider/earlycascade-injection) to refresh your session.Dismiss alert

{{ message }}

This repository was archived by the owner on Jan 23, 2025. It is now read-only.


[Cracked5pider](https://github.com/Cracked5pider)/ **[earlycascade-injection](https://github.com/Cracked5pider/earlycascade-injection)** Public archive

- [Notifications](https://github.com/login?return_to=%2FCracked5pider%2Fearlycascade-injection) You must be signed in to change notification settings
- [Fork\\
34](https://github.com/login?return_to=%2FCracked5pider%2Fearlycascade-injection)
- [Star\\
236](https://github.com/login?return_to=%2FCracked5pider%2Fearlycascade-injection)


early cascade injection PoC based on Outflanks blog post


[236\\
stars](https://github.com/Cracked5pider/earlycascade-injection/stargazers) [34\\
forks](https://github.com/Cracked5pider/earlycascade-injection/forks) [Branches](https://github.com/Cracked5pider/earlycascade-injection/branches) [Tags](https://github.com/Cracked5pider/earlycascade-injection/tags) [Activity](https://github.com/Cracked5pider/earlycascade-injection/activity)

[Star](https://github.com/login?return_to=%2FCracked5pider%2Fearlycascade-injection)

[Notifications](https://github.com/login?return_to=%2FCracked5pider%2Fearlycascade-injection) You must be signed in to change notification settings

# Cracked5pider/earlycascade-injection

main

[**1** Branch](https://github.com/Cracked5pider/earlycascade-injection/branches) [**0** Tags](https://github.com/Cracked5pider/earlycascade-injection/tags)

[Go to Branches page](https://github.com/Cracked5pider/earlycascade-injection/branches)[Go to Tags page](https://github.com/Cracked5pider/earlycascade-injection/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Cracked5pider](https://avatars.githubusercontent.com/u/51360176?v=4&size=40)](https://github.com/Cracked5pider)[Cracked5pider](https://github.com/Cracked5pider/earlycascade-injection/commits?author=Cracked5pider)<br>[Update README.md](https://github.com/Cracked5pider/earlycascade-injection/commit/8a9c010b275b413ef0318b7fd4973e4a4e69d779)<br>2 years agoNov 7, 2024<br>[8a9c010](https://github.com/Cracked5pider/earlycascade-injection/commit/8a9c010b275b413ef0318b7fd4973e4a4e69d779) · 2 years agoNov 7, 2024<br>## History<br>[2 Commits](https://github.com/Cracked5pider/earlycascade-injection/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Cracked5pider/earlycascade-injection/commits/main/) 2 Commits |
| [src](https://github.com/Cracked5pider/earlycascade-injection/tree/main/src "src") | [src](https://github.com/Cracked5pider/earlycascade-injection/tree/main/src "src") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| [stub](https://github.com/Cracked5pider/earlycascade-injection/tree/main/stub "stub") | [stub](https://github.com/Cracked5pider/earlycascade-injection/tree/main/stub "stub") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| [README.md](https://github.com/Cracked5pider/earlycascade-injection/blob/main/README.md "README.md") | [README.md](https://github.com/Cracked5pider/earlycascade-injection/blob/main/README.md "README.md") | [Update README.md](https://github.com/Cracked5pider/earlycascade-injection/commit/8a9c010b275b413ef0318b7fd4973e4a4e69d779 "Update README.md") | 2 years agoNov 7, 2024 |
| [cascade-injection.sln](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.sln "cascade-injection.sln") | [cascade-injection.sln](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.sln "cascade-injection.sln") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| [cascade-injection.vcxproj](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj "cascade-injection.vcxproj") | [cascade-injection.vcxproj](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj "cascade-injection.vcxproj") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| [cascade-injection.vcxproj.filters](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj.filters "cascade-injection.vcxproj.filters") | [cascade-injection.vcxproj.filters](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj.filters "cascade-injection.vcxproj.filters") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| [cascade-injection.vcxproj.user](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj.user "cascade-injection.vcxproj.user") | [cascade-injection.vcxproj.user](https://github.com/Cracked5pider/earlycascade-injection/blob/main/cascade-injection.vcxproj.user "cascade-injection.vcxproj.user") | [Add files via upload](https://github.com/Cracked5pider/earlycascade-injection/commit/064934c73cccc342dedfcee35b57b05e055acb43 "Add files via upload") | 2 years agoNov 7, 2024 |
| View all files |

## Repository files navigation

# Early Cascade Injection PoC

[Permalink: Early Cascade Injection PoC](https://github.com/Cracked5pider/earlycascade-injection#early-cascade-injection-poc)

This is just a simple PoC implementation of the early cascade injection technique documented by the [Outflank blog post](https://www.outflank.nl/blog/2024/10/15/introducing-early-cascade-injection-from-windows-process-creation-to-stealthy-injection/).

All credits go to the people who found and documented the technique. I merely wrote the code now because I was bored. Cheers.

The `g_ShimsEnabled` and `g_pfnSE_DllLoaded` offsets/pointers are hardcoded because I couldn't be bothered to write code to dynamically find them.
This code was tested on `Microsoft Windows [Version 10.0.22631.4317]`

Reference / Credit:

- [https://www.outflank.nl/blog/2024/10/15/introducing-early-cascade-injection-from-windows-process-creation-to-stealthy-injection/](https://www.outflank.nl/blog/2024/10/15/introducing-early-cascade-injection-from-windows-process-creation-to-stealthy-injection/)
- [https://malwaretech.com/2024/02/bypassing-edrs-with-edr-preload.html](https://malwaretech.com/2024/02/bypassing-edrs-with-edr-preload.html)

## About

early cascade injection PoC based on Outflanks blog post


### Resources

[Readme](https://github.com/Cracked5pider/earlycascade-injection#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Cracked5pider/earlycascade-injection).

[Activity](https://github.com/Cracked5pider/earlycascade-injection/activity)

### Stars

[**236**\\
stars](https://github.com/Cracked5pider/earlycascade-injection/stargazers)

### Watchers

[**5**\\
watching](https://github.com/Cracked5pider/earlycascade-injection/watchers)

### Forks

[**34**\\
forks](https://github.com/Cracked5pider/earlycascade-injection/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FCracked5pider%2Fearlycascade-injection&report=Cracked5pider+%28user%29)

## [Releases](https://github.com/Cracked5pider/earlycascade-injection/releases)

No releases published

## [Packages\  0](https://github.com/users/Cracked5pider/packages?repo_name=earlycascade-injection)

No packages published

## Languages

- [C++90.2%](https://github.com/Cracked5pider/earlycascade-injection/search?l=c%2B%2B)
- [Python7.1%](https://github.com/Cracked5pider/earlycascade-injection/search?l=python)
- [Makefile2.7%](https://github.com/Cracked5pider/earlycascade-injection/search?l=makefile)

You can’t perform that action at this time.