# https://github.com/georgesotiriadis/Chimera

[Skip to content](https://github.com/georgesotiriadis/Chimera#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/georgesotiriadis/Chimera) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/georgesotiriadis/Chimera) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/georgesotiriadis/Chimera) to refresh your session.Dismiss alert

{{ message }}

[georgesotiriadis](https://github.com/georgesotiriadis)/ **[Chimera](https://github.com/georgesotiriadis/Chimera)** Public

- [Notifications](https://github.com/login?return_to=%2Fgeorgesotiriadis%2FChimera) You must be signed in to change notification settings
- [Fork\\
59](https://github.com/login?return_to=%2Fgeorgesotiriadis%2FChimera)
- [Star\\
502](https://github.com/login?return_to=%2Fgeorgesotiriadis%2FChimera)


Automated DLL Sideloading Tool With EDR Evasion Capabilities


### License

[MIT license](https://github.com/georgesotiriadis/Chimera/blob/main/LICENSE)

[502\\
stars](https://github.com/georgesotiriadis/Chimera/stargazers) [59\\
forks](https://github.com/georgesotiriadis/Chimera/forks) [Branches](https://github.com/georgesotiriadis/Chimera/branches) [Tags](https://github.com/georgesotiriadis/Chimera/tags) [Activity](https://github.com/georgesotiriadis/Chimera/activity)

[Star](https://github.com/login?return_to=%2Fgeorgesotiriadis%2FChimera)

[Notifications](https://github.com/login?return_to=%2Fgeorgesotiriadis%2FChimera) You must be signed in to change notification settings

# georgesotiriadis/Chimera

main

[**7** Branches](https://github.com/georgesotiriadis/Chimera/branches) [**3** Tags](https://github.com/georgesotiriadis/Chimera/tags)

[Go to Branches page](https://github.com/georgesotiriadis/Chimera/branches)[Go to Tags page](https://github.com/georgesotiriadis/Chimera/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![georgesotiriadis](https://avatars.githubusercontent.com/u/40565316?v=4&size=40)](https://github.com/georgesotiriadis)[georgesotiriadis](https://github.com/georgesotiriadis/Chimera/commits?author=georgesotiriadis)<br>[Rename image5.png to image 5.png](https://github.com/georgesotiriadis/Chimera/commit/6b972a3af9b0b84a101099a2354ac276999a4c92)<br>3 years agoDec 19, 2023<br>[6b972a3](https://github.com/georgesotiriadis/Chimera/commit/6b972a3af9b0b84a101099a2354ac276999a4c92) · 3 years agoDec 19, 2023<br>## History<br>[94 Commits](https://github.com/georgesotiriadis/Chimera/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/georgesotiriadis/Chimera/commits/main/) 94 Commits |
| [Dll\_Exports](https://github.com/georgesotiriadis/Chimera/tree/main/Dll_Exports "Dll_Exports") | [Dll\_Exports](https://github.com/georgesotiriadis/Chimera/tree/main/Dll_Exports "Dll_Exports") | [V 2.0](https://github.com/georgesotiriadis/Chimera/commit/52d7f5e82fadefe84aa72be3c8d4210cbd4fb97e "V 2.0  Code is refactored structure changed") | 3 years agoJun 27, 2023 |
| [Dll\_Names](https://github.com/georgesotiriadis/Chimera/tree/main/Dll_Names "Dll_Names") | [Dll\_Names](https://github.com/georgesotiriadis/Chimera/tree/main/Dll_Names "Dll_Names") | [Updated Readme](https://github.com/georgesotiriadis/Chimera/commit/0d9cf8eddafc2e7679861836f9b985c379d1030c "Updated Readme") | 3 years agoDec 16, 2023 |
| [Encryption](https://github.com/georgesotiriadis/Chimera/tree/main/Encryption "Encryption") | [Encryption](https://github.com/georgesotiriadis/Chimera/tree/main/Encryption "Encryption") | [Final Changes](https://github.com/georgesotiriadis/Chimera/commit/9928799c3a08bf18854b4b04a118e99710434f93 "Final Changes  code splitted corrected aes corrected in the previous update") | 3 years agoDec 15, 2023 |
| [Evasion](https://github.com/georgesotiriadis/Chimera/tree/main/Evasion "Evasion") | [Evasion](https://github.com/georgesotiriadis/Chimera/tree/main/Evasion "Evasion") | [Massive Changes](https://github.com/georgesotiriadis/Chimera/commit/bf70b19dc2e8d349b9ff0027e6193a4f9c927471 "Massive Changes  sys3 added shellcoded is splitied into a seperate file.") | 3 years agoNov 5, 2023 |
| [Images](https://github.com/georgesotiriadis/Chimera/tree/main/Images "Images") | [Images](https://github.com/georgesotiriadis/Chimera/tree/main/Images "Images") | [Rename image5.png to image 5.png](https://github.com/georgesotiriadis/Chimera/commit/6b972a3af9b0b84a101099a2354ac276999a4c92 "Rename image5.png to image 5.png") | 3 years agoDec 19, 2023 |
| [Injection](https://github.com/georgesotiriadis/Chimera/tree/main/Injection "Injection") | [Injection](https://github.com/georgesotiriadis/Chimera/tree/main/Injection "Injection") | [Final Changes](https://github.com/georgesotiriadis/Chimera/commit/9928799c3a08bf18854b4b04a118e99710434f93 "Final Changes  code splitted corrected aes corrected in the previous update") | 3 years agoDec 15, 2023 |
| [Templates](https://github.com/georgesotiriadis/Chimera/tree/main/Templates "Templates") | [Templates](https://github.com/georgesotiriadis/Chimera/tree/main/Templates "Templates") | [Updated Readme](https://github.com/georgesotiriadis/Chimera/commit/0d9cf8eddafc2e7679861836f9b985c379d1030c "Updated Readme") | 3 years agoDec 16, 2023 |
| [Visualstudio\_Files](https://github.com/georgesotiriadis/Chimera/tree/main/Visualstudio_Files "Visualstudio_Files") | [Visualstudio\_Files](https://github.com/georgesotiriadis/Chimera/tree/main/Visualstudio_Files "Visualstudio_Files") | [Delete .syscalls.c.swp](https://github.com/georgesotiriadis/Chimera/commit/0c1405a124af473c0716143490e80b93c1ace477 "Delete .syscalls.c.swp") | 3 years agoDec 17, 2023 |
| [.gitignore](https://github.com/georgesotiriadis/Chimera/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/georgesotiriadis/Chimera/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/georgesotiriadis/Chimera/commit/42aeabcf25134528830daf5e0ffbc675e7cf3cac "Initial commit") | 3 years agoMay 14, 2023 |
| [Chimera.py](https://github.com/georgesotiriadis/Chimera/blob/main/Chimera.py "Chimera.py") | [Chimera.py](https://github.com/georgesotiriadis/Chimera/blob/main/Chimera.py "Chimera.py") | [V 2.0](https://github.com/georgesotiriadis/Chimera/commit/52414b7711a12f65e3016aad85c69f9e57bcb062 "V 2.0  Refactored More Code Cleaned Up Many Stuff") | 3 years agoJun 28, 2023 |
| [LICENSE](https://github.com/georgesotiriadis/Chimera/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/georgesotiriadis/Chimera/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/georgesotiriadis/Chimera/commit/42aeabcf25134528830daf5e0ffbc675e7cf3cac "Initial commit") | 3 years agoMay 14, 2023 |
| [README.md](https://github.com/georgesotiriadis/Chimera/blob/main/README.md "README.md") | [README.md](https://github.com/georgesotiriadis/Chimera/blob/main/README.md "README.md") | [Update README.md](https://github.com/georgesotiriadis/Chimera/commit/47b9990cbece34213c12188826f408387757038e "Update README.md") | 3 years agoDec 19, 2023 |
| View all files |

## Repository files navigation

## Chimera Unlea$ed

[Permalink: Chimera Unlea$ed ](https://github.com/georgesotiriadis/Chimera#chimera-unleaed)

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/Chimera.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/Chimera.png)

## Tool Background

[Permalink: Tool Background ](https://github.com/georgesotiriadis/Chimera#tool-background)

* * *

While DLL sideloading can be used for legitimate purposes, such as loading necessary libraries for a program to function, it can also be used for malicious purposes. Attackers can use DLL sideloading to execute arbitrary code on a target system, often by exploiting vulnerabilities in legitimate applications that are used to load DLLs.

To automate the DLL sideloading process and make it more effective, Chimera was created a tool that includes evasion methodologies to bypass EDR/AV products. This tool can automatically encrypt a shellcode via XOR with a random key and create template Images that can be imported into Visual Studio to create a malicious DLL.

Also, Dynamic Syscalls from SysWhispers3 is used and a modified assembly version to evade the pattern that the EDR search for, Random nop sleds are added and registers are moved. Furthermore, Early Bird Injection is also used to inject the shellcode in another process which the user can specify with Sandbox Evasion mechanisms like HardDisk check & if the process is being debugged. Finally Timing attack is placed in the loader which uses waitable timers to delay the execution of the shellcode.

This tool has been tested and shown to be effective at bypassing EDR/AV products and executing arbitrary code on a target system.

The updated version of Chimera Unleashed has demonstrated significant advancements in evading both static and dynamic analysis, particularly in the context of Microsoft 365's Endpoint Detection and Response (EDR) system. The tool's sideloading techniques, even when applied to well-known binaries like OneDrive, successfully eluded detection. However, it's noteworthy that while the sideloading aspect remained undetected, the Early Bird Injection process employed by the tool was identified by the EDR system. This highlights an area for further refinement in enhancing the tool's overall stealth capabilities.

## Tool Usage

[Permalink: Tool Usage](https://github.com/georgesotiriadis/Chimera#tool-usage)

* * *

Key Updates and Features:

- **Reformatted Structure**: The entire program has been restructured for enhanced development ease and future maintainability.
- **Polymorphic Code Integration**: Incorporation of polymorphic code, significantly enhancing evasion capabilities and making the tool more resilient against static analysis.
- **SysWhispers 3 Integration**: Transitioned from SysWhispers 2 to a modified version of SysWhispers 3. This update improves the tool's ability to evade pattern recognition mechanisms employed by EDR systems, using dynamic syscalls and modified assembly techniques.
- **AES Encryption**: Implemented AES encryption to secure shellcode, adding an additional layer of security and obfuscation.
- **Early Bird Injection**: The tool employs Early Bird Injection techniques, allowing for stealthier code execution within target processes.
- **Module Stomping**: Will be added in the future also you can implement your own code injection technique in the tool.

Chimera is written in python3  and there is no need to install any extra dependencies.

Chimera currently supports two DLL options either Microsoft teams or Microsoft OneDrive.

Someone can create userenv.dll which is a missing DLL from Microsoft Teams and insert it into the specific folder to

`⁠%USERPROFILE%/Appdata/local/Microsoft/Teams/current`

For Microsoft OneDrive the script uses version DLL which is common because it's missing from the binary example onedriveupdater.exe

### Command-Line Arguments

[Permalink: Command-Line Arguments](https://github.com/georgesotiriadis/Chimera#command-line-arguments)

Chimera Unleashed uses `argparser` for command-line argument parsing. The following arguments are available:

- `--raw` or `-r`: Path to file containing shellcode. Required.
- `--path` or `-p`: Path to output the C template file. Required.
- `--pname` or `-n`: Name of process to inject shellcode into. Required.
- `--dexports` or `-d`: Specify which DLL Exports to use (either 'teams' or 'onedrive'). Required.
- `--enc` or `-e`: Specify preferred encryption (XOR / AES). Required.
- `--inj` or `-i`: Specify preferred injection technique (EB / MS). Required.
- `--rshell` or `-s`: \[Optional\] Replace shellcode variable name with a unique name. Default is 'encoded\_shell'.
- `--rxor` or `-x`: \[Optional\] Replace xor encryption name with a unique name. Default is 'do\_xor'.
- `--rkey` or `-k`: \[Optional\] Replace key variable name with a unique name. Default is 'key'.
- `--rsleep` or `-z`: \[Optional\] Total sleep time to include during execution (seconds). Default is 4000.
- `--size` or `-f`: \[Optional\] File size of junk data in KB. Zero (0) is disabled, and one (1) is random filesize. Default is 0.

Example usage: `python Chimera.py --raw <path_to_shellcode> --path <output_path> --pname <process_name> --dexports <exports_file> --enc AES --inj EB --rshell my_shellcode`

### Useful Note

[Permalink: Useful Note](https://github.com/georgesotiriadis/Chimera#useful-note)

Once the compilation process is complete, a DLL will be generated, which should include either "version.dll" for OneDrive or "userenv.dll" for Microsoft Teams. Next, it is necessary to rename the original DLLs.

For instance, the original "userenv.dll" should be renamed as "tmpB0F7.dll," while the original "version.dll" should be renamed as "tmp44BC.dll." Additionally, you have the option to modify the name of the proxy DLL as desired by altering the source code of the DLL exports instead of using the default script names.

code.h file contains the shellcode.

## Visual Studio Project Setup

[Permalink: Visual Studio Project Setup](https://github.com/georgesotiriadis/Chimera#visual-studio-project-setup)

* * *

Step 1: Creating a New Visual Studio Project with DLL Template

1. Launch Visual Studio and click on "Create a new project" or go to "File" -> "New" -> "Project."
2. In the project templates window, select "Visual C++" from the left-hand side.
3. Choose "Empty Project" from the available templates.
4. Provide a suitable name and location for the project, then click "OK."
5. On the project properties window, navigate to "Configuration Properties" -> "General" and set the "Configuration Type" to "Dynamic Library (.dll)."
6. Configure other project settings as desired and save the project.

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image.png)

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%202.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%202.png)

Step 2: Importing Files into the Visual Studio Project

1. Locate the "chimera\_automation" folder containing the necessary Images.
2. Open the folder and identify the following files: main.c, syscalls.c, syscallsstubs.std.x64.asm.
3. In Visual Studio, right-click on the project in the "Solution Explorer" panel and select "Add" -> "Existing Item."
4. Browse to the location of each file (main.c, syscalls.c, syscallsstubs.std.x64.asm) and select them one by one. Click "Add" to import them into the project.
5. Create a folder named "header\_files" within the project directory if it doesn't exist already.
6. Locate the "syscalls\_mem.h" header file in the "header\_files" folder of the "chimera\_automation" directory.
7. Right-click on the "header\_files" folder in Visual Studio's "Solution Explorer" panel and select "Add" -> "Existing Item."
8. Browse to the location of "syscalls\_mem.h" and select it. Click "Add" to import it into the project.

Step 3: Build Customization

1. In the project properties window, navigate to "Configuration Properties" -> "Build Customizations."
2. Click the "Build Customizations" button to open the build customization dialog.

Step 4: Enable MASM

1. In the build customization dialog, check the box next to "masm" to enable it.
2. Click "OK" to close the build customization dialog.

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%203.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%203.png)

Step 5:

1. Right-click in the assembly file → properties and choose the following
2. Exclude from build → No
3. Content → Yes
4. Item type → Microsoft Macro Assembler

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%204.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%204.png)

### Final Project Setup

[Permalink: Final Project Setup](https://github.com/georgesotiriadis/Chimera#final-project-setup)

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%205.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%205.png)

## Compiler Optimizations

[Permalink: Compiler Optimizations ](https://github.com/georgesotiriadis/Chimera#compiler-optimizations)

* * *

Step 1: Change optimization

1. In Visual Studio choose Project → properties
2. C/C++ Optimization and change to the following

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%206.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%206.png)

Step 2: Remove Debug Information

1. In Visual Studio choose Project → properties
2. Linker → Debugging → Generate Debug Info → No

[![](https://github.com/georgesotiriadis/Chimera/raw/main/Images/image%207.png)](https://github.com/georgesotiriadis/Chimera/blob/main/Images/image%207.png)

## Contributors

[Permalink: Contributors](https://github.com/georgesotiriadis/Chimera#contributors)

**Original Contributor:**

- George Sotiriadis
  - Initial release and concept.
  - Code refactoring in the updated version.
  - Modified SysWhispers3 in the updated version.

**Contributor:**

- Efstratios Chatzoglou
  - Added polymorphic code, obfuscator, and AES encryption in the updated version.
  - Assisted in code refactoring and further development.

## Liability Disclaimer:

[Permalink: Liability Disclaimer:](https://github.com/georgesotiriadis/Chimera#liability-disclaimer)

* * *

_To the maximum extent permitted by applicable law, myself(George Sotiriadis) and/or affiliates who have submitted content to my repo, shall not be liable for any indirect, incidental, special, consequential or punitive damages, or any loss of profits or revenue, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses, resulting from (i) your access to this resource and/or inability to access this resource; (ii) any conduct or content of any third party referenced by this resource, including without limitation, any defamatory, offensive or illegal conduct or other users or third parties; (iii) any content obtained from this resource_

## References

[Permalink: References ](https://github.com/georgesotiriadis/Chimera#references)

* * *

[https://www.ired.team/offensive-security/code-injection-process-injection/early-bird-apc-queue-code-injection](https://www.ired.team/offensive-security/code-injection-process-injection/early-bird-apc-queue-code-injection)

[https://evasions.checkpoint.com/](https://evasions.checkpoint.com/)

[https://github.com/Flangvik/SharpDllProxy](https://github.com/Flangvik/SharpDllProxy)

[https://github.com/jthuraisamy/SysWhispers2](https://github.com/jthuraisamy/SysWhispers2 "https://github.com/jthuraisamy/SysWhispers2")[https://github.com/jthuraisamy/SysWhispers2](https://github.com/jthuraisamy/SysWhispers2)

[https://systemweakness.com/on-disk-detection-bypass-avs-edr-s-using-syscalls-with-legacy-instruction-series-of-instructions-5c1f31d1af7d](https://systemweakness.com/on-disk-detection-bypass-avs-edr-s-using-syscalls-with-legacy-instruction-series-of-instructions-5c1f31d1af7d)

[https://github.com/Mr-Un1k0d3r](https://github.com/Mr-Un1k0d3r)

## About

Automated DLL Sideloading Tool With EDR Evasion Capabilities


### Topics

[cpp](https://github.com/topics/cpp "Topic: cpp") [assembly](https://github.com/topics/assembly "Topic: assembly") [python3](https://github.com/topics/python3 "Topic: python3") [offensive-security](https://github.com/topics/offensive-security "Topic: offensive-security") [edr-bypass](https://github.com/topics/edr-bypass "Topic: edr-bypass") [dll-sideloading](https://github.com/topics/dll-sideloading "Topic: dll-sideloading")

### Resources

[Readme](https://github.com/georgesotiriadis/Chimera#readme-ov-file)

### License

[MIT license](https://github.com/georgesotiriadis/Chimera#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/georgesotiriadis/Chimera).

[Activity](https://github.com/georgesotiriadis/Chimera/activity)

### Stars

[**502**\\
stars](https://github.com/georgesotiriadis/Chimera/stargazers)

### Watchers

[**7**\\
watching](https://github.com/georgesotiriadis/Chimera/watchers)

### Forks

[**59**\\
forks](https://github.com/georgesotiriadis/Chimera/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fgeorgesotiriadis%2FChimera&report=georgesotiriadis+%28user%29)

## [Releases\  3](https://github.com/georgesotiriadis/Chimera/releases)

[v 1.0\\
Latest\\
\\
on Dec 17, 2023Dec 17, 2023](https://github.com/georgesotiriadis/Chimera/releases/tag/v1.0)

[\+ 2 releases](https://github.com/georgesotiriadis/Chimera/releases)

## [Packages\  0](https://github.com/users/georgesotiriadis/packages?repo_name=Chimera)

No packages published

## [Contributors\  2](https://github.com/georgesotiriadis/Chimera/graphs/contributors)

- [![@georgesotiriadis](https://avatars.githubusercontent.com/u/40565316?s=64&v=4)](https://github.com/georgesotiriadis)[**georgesotiriadis**](https://github.com/georgesotiriadis)
- [![@efchatz](https://avatars.githubusercontent.com/u/43434138?s=64&v=4)](https://github.com/efchatz)[**efchatz**](https://github.com/efchatz)

## Languages

- [Python72.9%](https://github.com/georgesotiriadis/Chimera/search?l=python)
- [C20.9%](https://github.com/georgesotiriadis/Chimera/search?l=c)
- [Assembly6.2%](https://github.com/georgesotiriadis/Chimera/search?l=assembly)

You can’t perform that action at this time.