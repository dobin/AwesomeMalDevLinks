# https://github.com/monoxgas/Koppeling

[Skip to content](https://github.com/monoxgas/Koppeling#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/monoxgas/Koppeling) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/monoxgas/Koppeling) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/monoxgas/Koppeling) to refresh your session.Dismiss alert

{{ message }}

[monoxgas](https://github.com/monoxgas)/ **[Koppeling](https://github.com/monoxgas/Koppeling)** Public

- [Notifications](https://github.com/login?return_to=%2Fmonoxgas%2FKoppeling) You must be signed in to change notification settings
- [Fork\\
135](https://github.com/login?return_to=%2Fmonoxgas%2FKoppeling)
- [Star\\
807](https://github.com/login?return_to=%2Fmonoxgas%2FKoppeling)


Adaptive DLL hijacking / dynamic export forwarding


### License

[GPL-3.0 license](https://github.com/monoxgas/Koppeling/blob/master/LICENSE)

[807\\
stars](https://github.com/monoxgas/Koppeling/stargazers) [135\\
forks](https://github.com/monoxgas/Koppeling/forks) [Branches](https://github.com/monoxgas/Koppeling/branches) [Tags](https://github.com/monoxgas/Koppeling/tags) [Activity](https://github.com/monoxgas/Koppeling/activity)

[Star](https://github.com/login?return_to=%2Fmonoxgas%2FKoppeling)

[Notifications](https://github.com/login?return_to=%2Fmonoxgas%2FKoppeling) You must be signed in to change notification settings

# monoxgas/Koppeling

master

[**1** Branch](https://github.com/monoxgas/Koppeling/branches) [**0** Tags](https://github.com/monoxgas/Koppeling/tags)

[Go to Branches page](https://github.com/monoxgas/Koppeling/branches)[Go to Tags page](https://github.com/monoxgas/Koppeling/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>Nick Landers<br>[Remove .dll extension from forwards (lookup failure causes crashes on…](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8)<br>Open commit details<br>6 years agoJul 6, 2020<br>[c2eafe1](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8) · 6 years agoJul 6, 2020<br>## History<br>[8 Commits](https://github.com/monoxgas/Koppeling/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/monoxgas/Koppeling/commits/master/) 8 Commits |
| [Functions](https://github.com/monoxgas/Koppeling/tree/master/Functions "Functions") | [Functions](https://github.com/monoxgas/Koppeling/tree/master/Functions "Functions") | [Initial Commit](https://github.com/monoxgas/Koppeling/commit/c661ae3c4601cb6ff79da5d04f2fea98809dfbf5 "Initial Commit") | 6 years agoFeb 18, 2020 |
| [Harness](https://github.com/monoxgas/Koppeling/tree/master/Harness "Harness") | [Harness](https://github.com/monoxgas/Koppeling/tree/master/Harness "Harness") | [Remove .dll extension from forwards (lookup failure causes crashes on…](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8 "Remove .dll extension from forwards (lookup failure causes crashes on some 2k8/w7 hosts)") | 6 years agoJul 6, 2020 |
| [NetClone](https://github.com/monoxgas/Koppeling/tree/master/NetClone "NetClone") | [NetClone](https://github.com/monoxgas/Koppeling/tree/master/NetClone "NetClone") | [Remove .dll extension from forwards (lookup failure causes crashes on…](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8 "Remove .dll extension from forwards (lookup failure causes crashes on some 2k8/w7 hosts)") | 6 years agoJul 6, 2020 |
| [PyClone](https://github.com/monoxgas/Koppeling/tree/master/PyClone "PyClone") | [PyClone](https://github.com/monoxgas/Koppeling/tree/master/PyClone "PyClone") | [Remove .dll extension from forwards (lookup failure causes crashes on…](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8 "Remove .dll extension from forwards (lookup failure causes crashes on some 2k8/w7 hosts)") | 6 years agoJul 6, 2020 |
| [Theif](https://github.com/monoxgas/Koppeling/tree/master/Theif "Theif") | [Theif](https://github.com/monoxgas/Koppeling/tree/master/Theif "Theif") | [Remove .dll extension from forwards (lookup failure causes crashes on…](https://github.com/monoxgas/Koppeling/commit/c2eafe11e6c31e1f64438a88d283ce3b0e4536a8 "Remove .dll extension from forwards (lookup failure causes crashes on some 2k8/w7 hosts)") | 6 years agoJul 6, 2020 |
| [.gitignore](https://github.com/monoxgas/Koppeling/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/monoxgas/Koppeling/blob/master/.gitignore ".gitignore") | [Initial Commit](https://github.com/monoxgas/Koppeling/commit/c661ae3c4601cb6ff79da5d04f2fea98809dfbf5 "Initial Commit") | 6 years agoFeb 18, 2020 |
| [Koppeling.sln](https://github.com/monoxgas/Koppeling/blob/master/Koppeling.sln "Koppeling.sln") | [Koppeling.sln](https://github.com/monoxgas/Koppeling/blob/master/Koppeling.sln "Koppeling.sln") | [Initial Commit](https://github.com/monoxgas/Koppeling/commit/c661ae3c4601cb6ff79da5d04f2fea98809dfbf5 "Initial Commit") | 6 years agoFeb 18, 2020 |
| [LICENSE](https://github.com/monoxgas/Koppeling/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/monoxgas/Koppeling/blob/master/LICENSE "LICENSE") | [Add license and readme](https://github.com/monoxgas/Koppeling/commit/f302303fedaaa9bc0365f346b454a12bdb475a30 "Add license and readme") | 6 years agoFeb 18, 2020 |
| [README.md](https://github.com/monoxgas/Koppeling/blob/master/README.md "README.md") | [README.md](https://github.com/monoxgas/Koppeling/blob/master/README.md "README.md") | [Add example to README](https://github.com/monoxgas/Koppeling/commit/ed66f00f16363ba197ea0b67a5eea5ca9ea2e200 "Add example to README") | 6 years agoFeb 19, 2020 |
| View all files |

## Repository files navigation

# Koppeling

[Permalink: Koppeling](https://github.com/monoxgas/Koppeling#koppeling)

This project is a demonstration of advanced DLL hijack techniques. It was released in conjunction with the " [Adaptive DLL Hijacking](https://silentbreaksecurity.com/adaptive-dll-hijacking/)" blog post. I recommend you start there to contextualize this code.

This project is comprised of the following elements:

- **Harness.exe:** The "victim" application which is vulnerable to hijacking (static/dynamic)
- **Functions.dll:** The "real" library which exposes valid functionality to the harness
- **Theif.dll:** The "evil" library which is attempting to gain execution
- **NetClone.exe:** A C# application which will clone exports from one DLL to another
- **PyClone.py:** A python 3 script which mimics NetClone functionality

The VS solution itself supports 4 build configurations which map to 4 different methods of proxying functionality. This should provide a nice scalable way of demonstrating more techniques in the future.

- **Stc-Forward:** Forwards export names during the build process using linker comments
- **Dyn-NetClone:** Clones the export table from _functions.dll_ onto _theif.dll_ post-build using NetClone
- **Dyn-PyClone:** Clones the export table from _functions.dll_ onto _theif.dll_ post-build using PyClone
- **Dyn-Rebuild:** Rebuilds the export table and patches linked import tables post-load to dynamically prepare for function proxying

The goal of each technique is to successfully capture code execution while proxying functionality to the legitimate DLL. Each technique is tested to ensure static and dynamic sink situations are handled. This is by far not every primitive or technique variation. The post above goes into more detail.

## Example

[Permalink: Example](https://github.com/monoxgas/Koppeling#example)

Prepare a hijack scenario with an obviously incorrect DLL

```
> copy C:\windows\system32\whoami.exe .\whoami.exe
        1 file(s) copied.

> copy C:\windows\system32\kernel32.dll .\wkscli.dll
        1 file(s) copied.
```

Executing in the current configuration should result in an error

```
> whoami.exe

"Entry Point Not Found"
```

Convert kernel32 to proxy functionality for wkscli

```
> NetClone.exe --target C:\windows\system32\kernel32.dll --reference C:\windows\system32\wkscli.dll --output wkscli.dll
[+] Done.

> whoami.exe
COMPUTER\User
```

## About

Adaptive DLL hijacking / dynamic export forwarding


### Resources

[Readme](https://github.com/monoxgas/Koppeling#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/monoxgas/Koppeling#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/monoxgas/Koppeling).

[Activity](https://github.com/monoxgas/Koppeling/activity)

### Stars

[**807**\\
stars](https://github.com/monoxgas/Koppeling/stargazers)

### Watchers

[**21**\\
watching](https://github.com/monoxgas/Koppeling/watchers)

### Forks

[**135**\\
forks](https://github.com/monoxgas/Koppeling/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fmonoxgas%2FKoppeling&report=monoxgas+%28user%29)

## [Releases](https://github.com/monoxgas/Koppeling/releases)

No releases published

## [Packages\  0](https://github.com/users/monoxgas/packages?repo_name=Koppeling)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/monoxgas/Koppeling).

## Languages

- [C++39.9%](https://github.com/monoxgas/Koppeling/search?l=c%2B%2B)
- [C#36.6%](https://github.com/monoxgas/Koppeling/search?l=c%23)
- [Python23.5%](https://github.com/monoxgas/Koppeling/search?l=python)

You can’t perform that action at this time.