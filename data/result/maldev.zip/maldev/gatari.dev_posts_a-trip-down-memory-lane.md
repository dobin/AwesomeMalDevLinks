# https://gatari.dev/posts/a-trip-down-memory-lane/

# 404 NOT FOUND

You just hit a route that doesn't exist.

 [Go to top](https://gatari.dev/posts/a-trip-down-memory-lane/# "Go to top")