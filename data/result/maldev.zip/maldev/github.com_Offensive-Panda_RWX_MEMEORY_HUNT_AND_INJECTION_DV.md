# https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV

[Skip to content](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV) to refresh your session.Dismiss alert

{{ message }}

[Offensive-Panda](https://github.com/Offensive-Panda)/ **[RWX\_MEMEORY\_HUNT\_AND\_INJECTION\_DV](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV)** Public

- [Notifications](https://github.com/login?return_to=%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV) You must be signed in to change notification settings
- [Fork\\
49](https://github.com/login?return_to=%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV)
- [Star\\
288](https://github.com/login?return_to=%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV)


Abusing Windows fork API and OneDrive.exe process to inject the malicious shellcode without allocating new RWX memory region.


[offensive-panda.github.io/DefenseEvasionTechniques/](https://offensive-panda.github.io/DefenseEvasionTechniques/ "https://offensive-panda.github.io/DefenseEvasionTechniques/")

### License

[MIT license](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/blob/main/LICENSE)

[288\\
stars](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/stargazers) [49\\
forks](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/forks) [Branches](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/branches) [Tags](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/tags) [Activity](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/activity)

[Star](https://github.com/login?return_to=%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV)

[Notifications](https://github.com/login?return_to=%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV) You must be signed in to change notification settings

# Offensive-Panda/RWX\_MEMEORY\_HUNT\_AND\_INJECTION\_DV

main

[**1** Branch](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/branches) [**0** Tags](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/tags)

[Go to Branches page](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/branches)[Go to Tags page](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Offensive-Panda](https://avatars.githubusercontent.com/u/76246439?v=4&size=40)](https://github.com/Offensive-Panda)[Offensive-Panda](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commits?author=Offensive-Panda)<br>[Update README.md](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commit/391c96b85ef2d48609a34f0d8105b5dba8545524)<br>2 years agoMay 27, 2024<br>[391c96b](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commit/391c96b85ef2d48609a34f0d8105b5dba8545524) · 2 years agoMay 27, 2024<br>## History<br>[6 Commits](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commits/main/) 6 Commits |
| [RWX\_MEMORY\_HUNT\_INJECT\_DV](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/tree/main/RWX_MEMORY_HUNT_INJECT_DV "RWX_MEMORY_HUNT_INJECT_DV") | [RWX\_MEMORY\_HUNT\_INJECT\_DV](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/tree/main/RWX_MEMORY_HUNT_INJECT_DV "RWX_MEMORY_HUNT_INJECT_DV") | [Added New](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commit/7a028d2ef3f24e8f9230bc0bb297f3f14b94efe0 "Added New") | 2 years agoMay 24, 2024 |
| [LICENSE](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commit/1b15078a54953258ec44c848f751e6212cdbc4aa "Initial commit") | 2 years agoMay 24, 2024 |
| [README.md](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/blob/main/README.md "README.md") | [README.md](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/blob/main/README.md "README.md") | [Update README.md](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/commit/391c96b85ef2d48609a34f0d8105b5dba8545524 "Update README.md") | 2 years agoMay 27, 2024 |
| View all files |

## Repository files navigation

# RWX\_MEMEORY\_HUNT\_AND\_INJECTION\_DV

[Permalink: RWX_MEMEORY_HUNT_AND_INJECTION_DV](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#rwx_memeory_hunt_and_injection_dv)

Abusing Windows fork API and OneDrive.exe process to inject the malicious shellcode without allocating new RWX memory region. This technique is finding RWX region in already running processes in this case OneDrive.exe and Write shellcode into that region and execute it without calling VirtualProtect, VirtualAllocEx, VirtualAlloc.

## Usage

[Permalink: Usage](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#usage)

Just compile the program and run the (EXE) without any paremeter.

## Steps

[Permalink: Steps](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#steps)

- Find the OneDrive.exe in running processes.
- Get the handle of OneDrive.exe.
- Query remote process memory information.
- look for RWX memory regions.
- Write shellcode into found region of OneDrive.exe
- Fork OneDrive.exe into a new process.
- Set the forked process's start address to the cloned shellcode.
- Terminate the cloned process after execution.

## Shellcode

[Permalink: Shellcode](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#shellcode)

This technique will work with ntdll based shellcode which is not dependent on any section. I used [https://github.com/rainerzufalldererste/windows\_x64\_shellcode\_template](https://github.com/rainerzufalldererste/windows_x64_shellcode_template) to generate my shellcode.

## Shellcode Creation

[Permalink: Shellcode Creation](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#shellcode-creation)

- Edit the shellcode template file funtion 'shellcode\_template' according to instructions given on [https://github.com/rainerzufalldererste/windows\_x64\_shellcode\_template](https://github.com/rainerzufalldererste/windows_x64_shellcode_template)
- Compile the code and open .EXE file in any hex editor (HxD)
- Extract the .text section and use that in given project file.
- To extract the shellcode there are other methods also explained in the repository.

## Only for educational purposes.

[Permalink: Only for educational purposes.](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#only-for-educational-purposes)

### DEMO

[Permalink: DEMO](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#demo)

[https://www.linkedin.com/posts/usman-sikander13\_%3F%3F%3F-%3F%3F%3F%3F%3F%3F-activity-7196426924351488001-RXOk?utm\_source=share&utm\_medium=member\_desktop](https://www.linkedin.com/posts/usman-sikander13_%3F%3F%3F-%3F%3F%3F%3F%3F%3F-activity-7196426924351488001-RXOk?utm_source=share&utm_medium=member_desktop)

## About

Abusing Windows fork API and OneDrive.exe process to inject the malicious shellcode without allocating new RWX memory region.


[offensive-panda.github.io/DefenseEvasionTechniques/](https://offensive-panda.github.io/DefenseEvasionTechniques/ "https://offensive-panda.github.io/DefenseEvasionTechniques/")

### Topics

[shellcode](https://github.com/topics/shellcode "Topic: shellcode") [malware-development](https://github.com/topics/malware-development "Topic: malware-development") [fud](https://github.com/topics/fud "Topic: fud") [avbypass](https://github.com/topics/avbypass "Topic: avbypass") [edr-bypass](https://github.com/topics/edr-bypass "Topic: edr-bypass")

### Resources

[Readme](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#readme-ov-file)

### License

[MIT license](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV).

[Activity](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/activity)

### Stars

[**288**\\
stars](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/stargazers)

### Watchers

[**6**\\
watching](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/watchers)

### Forks

[**49**\\
forks](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FOffensive-Panda%2FRWX_MEMEORY_HUNT_AND_INJECTION_DV&report=Offensive-Panda+%28user%29)

## [Releases](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/releases)

No releases published

## [Packages\  0](https://github.com/users/Offensive-Panda/packages?repo_name=RWX_MEMEORY_HUNT_AND_INJECTION_DV)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV).

## Languages

- [C++100.0%](https://github.com/Offensive-Panda/RWX_MEMEORY_HUNT_AND_INJECTION_DV/search?l=c%2B%2B)

You can’t perform that action at this time.