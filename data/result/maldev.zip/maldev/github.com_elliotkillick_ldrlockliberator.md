# https://github.com/ElliotKillick/LdrLockLiberator

[Skip to content](https://github.com/ElliotKillick/LdrLockLiberator#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ElliotKillick/LdrLockLiberator) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ElliotKillick/LdrLockLiberator) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ElliotKillick/LdrLockLiberator) to refresh your session.Dismiss alert

{{ message }}

[ElliotKillick](https://github.com/ElliotKillick)/ **[LdrLockLiberator](https://github.com/ElliotKillick/LdrLockLiberator)** Public

- [Notifications](https://github.com/login?return_to=%2FElliotKillick%2FLdrLockLiberator) You must be signed in to change notification settings
- [Fork\\
72](https://github.com/login?return_to=%2FElliotKillick%2FLdrLockLiberator)
- [Star\\
424](https://github.com/login?return_to=%2FElliotKillick%2FLdrLockLiberator)


For when DLLMain is the only way


[elliotonsecurity.com](https://elliotonsecurity.com/ "https://elliotonsecurity.com")

### License

[MIT license](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/LICENSE)

[424\\
stars](https://github.com/ElliotKillick/LdrLockLiberator/stargazers) [72\\
forks](https://github.com/ElliotKillick/LdrLockLiberator/forks) [Branches](https://github.com/ElliotKillick/LdrLockLiberator/branches) [Tags](https://github.com/ElliotKillick/LdrLockLiberator/tags) [Activity](https://github.com/ElliotKillick/LdrLockLiberator/activity)

[Star](https://github.com/login?return_to=%2FElliotKillick%2FLdrLockLiberator)

[Notifications](https://github.com/login?return_to=%2FElliotKillick%2FLdrLockLiberator) You must be signed in to change notification settings

# ElliotKillick/LdrLockLiberator

main

[**1** Branch](https://github.com/ElliotKillick/LdrLockLiberator/branches) [**0** Tags](https://github.com/ElliotKillick/LdrLockLiberator/tags)

[Go to Branches page](https://github.com/ElliotKillick/LdrLockLiberator/branches)[Go to Tags page](https://github.com/ElliotKillick/LdrLockLiberator/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![ElliotKillick](https://avatars.githubusercontent.com/u/58203150?v=4&size=40)](https://github.com/ElliotKillick)[ElliotKillick](https://github.com/ElliotKillick/LdrLockLiberator/commits?author=ElliotKillick)<br>[Fix bug](https://github.com/ElliotKillick/LdrLockLiberator/commit/cc7606e66a6c9602f2fe0fe926537303c0772b37)<br>2 years agoOct 29, 2024<br>[cc7606e](https://github.com/ElliotKillick/LdrLockLiberator/commit/cc7606e66a6c9602f2fe0fe926537303c0772b37) · 2 years agoOct 29, 2024<br>## History<br>[18 Commits](https://github.com/ElliotKillick/LdrLockLiberator/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ElliotKillick/LdrLockLiberator/commits/main/) 18 Commits |
| [LdrLockLiberatorWDK](https://github.com/ElliotKillick/LdrLockLiberator/tree/main/LdrLockLiberatorWDK "LdrLockLiberatorWDK") | [LdrLockLiberatorWDK](https://github.com/ElliotKillick/LdrLockLiberator/tree/main/LdrLockLiberatorWDK "LdrLockLiberatorWDK") | [Update](https://github.com/ElliotKillick/LdrLockLiberator/commit/10f54a96670890293cfaf8248ff12a634d4d07d2 "Update") | 2 years agoOct 16, 2024 |
| [.gitignore](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/ElliotKillick/LdrLockLiberator/commit/2497bb9fff493574e7dfa858359f1279e8ea2161 "Initial commit") | 3 years agoOct 31, 2023 |
| [LICENSE](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/LICENSE "LICENSE") | [Update](https://github.com/ElliotKillick/LdrLockLiberator/commit/10f54a96670890293cfaf8248ff12a634d4d07d2 "Update") | 2 years agoOct 16, 2024 |
| [LdrLockLiberator.c](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/LdrLockLiberator.c "LdrLockLiberator.c") | [LdrLockLiberator.c](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/LdrLockLiberator.c "LdrLockLiberator.c") | [Fix bug](https://github.com/ElliotKillick/LdrLockLiberator/commit/cc7606e66a6c9602f2fe0fe926537303c0772b37 "Fix bug") | 2 years agoOct 29, 2024 |
| [README.md](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/README.md "README.md") | [README.md](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/README.md "README.md") | [Update](https://github.com/ElliotKillick/LdrLockLiberator/commit/10f54a96670890293cfaf8248ff12a634d4d07d2 "Update") | 2 years agoOct 16, 2024 |
| [logo.webp](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/logo.webp "logo.webp") | [logo.webp](https://github.com/ElliotKillick/LdrLockLiberator/blob/main/logo.webp "logo.webp") | [Refresh logo](https://github.com/ElliotKillick/LdrLockLiberator/commit/0aaea77e57585fd8452fb50e4c6c03cd77759b13 "Refresh logo  Shiny!") | 2 years agoApr 13, 2024 |
| View all files |

## Repository files navigation

[![Logo](https://github.com/ElliotKillick/LdrLockLiberator/raw/main/logo.webp)](https://github.com/ElliotKillick/LdrLockLiberator)

## LdrLockLiberator

[Permalink:\
    LdrLockLiberator\
](https://github.com/ElliotKillick/LdrLockLiberator#----ldrlockliberator)

For when **DLLMain** is the only way

LdrLockLiberator is a collection of techniques for escaping or otherwise forgoing Loader Lock while executing your code from `DllMain` or anywhere else the lock may be present. It was released in conjunction with the ["Perfect DLL Hijacking"](https://elliotonsecurity.com/perfect-dll-hijacking) article. We give you the **key** to unlock the library loader and do what you want with your loader (on your own computer)!

The techniques are intended to be **universal, clean, and 100% safe** where possible. They're designed to work without modifying memory protection or pointers. This is important for staying compatible with modern exploit mitigations. The only officially supported architecture is x86-64 (32-bits is largely extinct).

Want to learn the architectural reasons as to why `DllMain` is so troublesome on Windows whereas Unix-like operating systems don't struggle here? [Please, be my guest!](https://github.com/ElliotKillick/windows-vs-linux-loader-architecture#the-root-of-dllmain-problems).

## Techniques

[Permalink: Techniques](https://github.com/ElliotKillick/LdrLockLiberator#techniques)

### LdrFullUnlock

[Permalink: LdrFullUnlock](https://github.com/ElliotKillick/LdrLockLiberator#ldrfullunlock)

It's exactly what it sounds like. Unlock Loader Lock, set loader events, and flip `LdrpWorkInProgress`. It's recommended to keep `RUN_PAYLOAD_DIRECTLY_FROM_DLLMAIN` undefined for the best stability.

**DO NOT USE THIS TECHNIQUE IN PROUDCTION CODE.** This was created as a byproduct of my sheer curiosity and will to leave no stone unturned. Anything you do with this code is on you.

### Escaping at the Exit

[Permalink: Escaping at the Exit](https://github.com/ElliotKillick/LdrLockLiberator#escaping-at-the-exit)

We use the CRT `atexit` typically used by EXEs in our DLL code to escape Loader Lock when the program exits. For dynamic loads (using LoadLibrary), this is made **100% safe** by pinning (`LDR_ADDREF_DLL_PIN`) our library using `LdrAddRefDll` so a following `FreeLibrary` won't remove our DLL from memory.

### Using Locks to Our Advantage

[Permalink: Using Locks to Our Advantage](https://github.com/ElliotKillick/LdrLockLiberator#using-locks-to-our-advantage)

Coming soon!

## Samples

[Permalink: Samples](https://github.com/ElliotKillick/LdrLockLiberator#samples)

The provided samples hijack `MpClient.dll` from `C:\Program Files\Windows Defender\Offline\OfflineScannerShell.exe`. Instructions are provided in the source code comments to easily adapt this for any other DLL and program pairing (primarily just updating the exports for static loads)!

As a proof of concept, we run `ShellExecute` as the default payload. However, you can make this do anything you want!

## Compilation

[Permalink: Compilation](https://github.com/ElliotKillick/LdrLockLiberator#compilation)

### Visual Studio

[Permalink: Visual Studio](https://github.com/ElliotKillick/LdrLockLiberator#visual-studio)

The `LdrLockLiberator.c` at the root of this project has been tested to compile on Visual Studio 2022.

Link to NTDLL by selecting the current Visual Studio project in the Solution Explorer window, then navigating to `Project > Properties` in the menu bar. From the drop-down `Configuration` menus at the top, select `All Configurations` and `All Platforms`. Now, go to `Linker > Input` then append to `Additional Dependencies`: `ntdll.lib`.

### WDK

[Permalink: WDK](https://github.com/ElliotKillick/LdrLockLiberator#wdk)

#### Installing the Correct WDK

[Permalink: Installing the Correct WDK](https://github.com/ElliotKillick/LdrLockLiberator#installing-the-correct-wdk)

1. Go to the [WDK download page](https://learn.microsoft.com/en-us/windows-hardware/drivers/other-wdk-downloads#step-2-install-the-wdk)
2. Click on the Windows 7 [WDK 7.1.0](https://www.microsoft.com/en-us/download/confirmation.aspx?id=11800) link to start download the correct WDK version

- This is the last public WDK that **officially** supports linking to the original MSVCRT (`C:\Windows\System32\msvcrt.dll`)
- SHA-256 checksum: `5edc723b50ea28a070cad361dd0927df402b7a861a036bbcf11d27ebba77657d`

3. Mount the downloaded ISO then run `KitSetup.exe`
4. Click through the installation process using the default options

#### Compiling

[Permalink: Compiling](https://github.com/ElliotKillick/LdrLockLiberator#compiling)

1. In the Start menu, search for "x64 Free Build Environment" then open it
2. Navigate (using `cd`) to `LdrLockLiberatorWDK` in this repo
3. Run `build`

Done! Your DLL is built and ready for use!

As an alternative to WDK, compiling with MinGW would also probably work.

## License

[Permalink: License](https://github.com/ElliotKillick/LdrLockLiberator#license)

MIT License - Copyright (C) 2023-2024 Elliot Killick [contact@elliotkillick.com](mailto:contact@elliotkillick.com)

## About

For when DLLMain is the only way


[elliotonsecurity.com](https://elliotonsecurity.com/ "https://elliotonsecurity.com")

### Topics

[dll](https://github.com/topics/dll "Topic: dll") [dllmain](https://github.com/topics/dllmain "Topic: dllmain") [dll-hijacking](https://github.com/topics/dll-hijacking "Topic: dll-hijacking") [loader-lock](https://github.com/topics/loader-lock "Topic: loader-lock")

### Resources

[Readme](https://github.com/ElliotKillick/LdrLockLiberator#readme-ov-file)

### License

[MIT license](https://github.com/ElliotKillick/LdrLockLiberator#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ElliotKillick/LdrLockLiberator).

[Activity](https://github.com/ElliotKillick/LdrLockLiberator/activity)

### Stars

[**424**\\
stars](https://github.com/ElliotKillick/LdrLockLiberator/stargazers)

### Watchers

[**10**\\
watching](https://github.com/ElliotKillick/LdrLockLiberator/watchers)

### Forks

[**72**\\
forks](https://github.com/ElliotKillick/LdrLockLiberator/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FElliotKillick%2FLdrLockLiberator&report=ElliotKillick+%28user%29)

## [Releases](https://github.com/ElliotKillick/LdrLockLiberator/releases)

No releases published

## [Packages\  0](https://github.com/users/ElliotKillick/packages?repo_name=LdrLockLiberator)

No packages published

## Languages

- [C100.0%](https://github.com/ElliotKillick/LdrLockLiberator/search?l=c)

You can’t perform that action at this time.