# https://github.com/cpu0x00/Ghost

[Skip to content](https://github.com/cpu0x00/Ghost#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/cpu0x00/Ghost) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/cpu0x00/Ghost) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/cpu0x00/Ghost) to refresh your session.Dismiss alert

{{ message }}

[cpu0x00](https://github.com/cpu0x00)/ **[Ghost](https://github.com/cpu0x00/Ghost)** Public

- [Notifications](https://github.com/login?return_to=%2Fcpu0x00%2FGhost) You must be signed in to change notification settings
- [Fork\\
65](https://github.com/login?return_to=%2Fcpu0x00%2FGhost)
- [Star\\
397](https://github.com/login?return_to=%2Fcpu0x00%2FGhost)


Evasive shellcode loader


[397\\
stars](https://github.com/cpu0x00/Ghost/stargazers) [65\\
forks](https://github.com/cpu0x00/Ghost/forks) [Branches](https://github.com/cpu0x00/Ghost/branches) [Tags](https://github.com/cpu0x00/Ghost/tags) [Activity](https://github.com/cpu0x00/Ghost/activity)

[Star](https://github.com/login?return_to=%2Fcpu0x00%2FGhost)

[Notifications](https://github.com/login?return_to=%2Fcpu0x00%2FGhost) You must be signed in to change notification settings

# cpu0x00/Ghost

main

[**1** Branch](https://github.com/cpu0x00/Ghost/branches) [**0** Tags](https://github.com/cpu0x00/Ghost/tags)

[Go to Branches page](https://github.com/cpu0x00/Ghost/branches)[Go to Tags page](https://github.com/cpu0x00/Ghost/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![cpu0x00](https://avatars.githubusercontent.com/u/86830248?v=4&size=40)](https://github.com/cpu0x00)[cpu0x00](https://github.com/cpu0x00/Ghost/commits?author=cpu0x00)<br>[Merge pull request](https://github.com/cpu0x00/Ghost/commit/bf67313c72d1df48117daf4aeca604e83a570280) [#1](https://github.com/cpu0x00/Ghost/pull/1) [from xcalibure2/check-if-build-folder-exists](https://github.com/cpu0x00/Ghost/commit/bf67313c72d1df48117daf4aeca604e83a570280)<br>Open commit details<br>2 years agoOct 17, 2024<br>[bf67313](https://github.com/cpu0x00/Ghost/commit/bf67313c72d1df48117daf4aeca604e83a570280) · 2 years agoOct 17, 2024<br>## History<br>[9 Commits](https://github.com/cpu0x00/Ghost/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/cpu0x00/Ghost/commits/main/) 9 Commits |
| [image](https://github.com/cpu0x00/Ghost/tree/main/image "image") | [image](https://github.com/cpu0x00/Ghost/tree/main/image "image") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [AES.h](https://github.com/cpu0x00/Ghost/blob/main/AES.h "AES.h") | [AES.h](https://github.com/cpu0x00/Ghost/blob/main/AES.h "AES.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [Ghost.cpp](https://github.com/cpu0x00/Ghost/blob/main/Ghost.cpp "Ghost.cpp") | [Ghost.cpp](https://github.com/cpu0x00/Ghost/blob/main/Ghost.cpp "Ghost.cpp") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [README.md](https://github.com/cpu0x00/Ghost/blob/main/README.md "README.md") | [README.md](https://github.com/cpu0x00/Ghost/blob/main/README.md "README.md") | [Update README.md](https://github.com/cpu0x00/Ghost/commit/ba303a1958be9d5f1594264c6ecc2e9c6f54e25f "Update README.md") | 2 years agoOct 15, 2024 |
| [Resource.rc](https://github.com/cpu0x00/Ghost/blob/main/Resource.rc "Resource.rc") | [Resource.rc](https://github.com/cpu0x00/Ghost/blob/main/Resource.rc "Resource.rc") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [allocator.h](https://github.com/cpu0x00/Ghost/blob/main/allocator.h "allocator.h") | [allocator.h](https://github.com/cpu0x00/Ghost/blob/main/allocator.h "allocator.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [build.py](https://github.com/cpu0x00/Ghost/blob/main/build.py "build.py") | [build.py](https://github.com/cpu0x00/Ghost/blob/main/build.py "build.py") | [Update build.py](https://github.com/cpu0x00/Ghost/commit/0582124092d5d7eec47416aa2a1f4fe00fe2b5ea "Update build.py  added a check of existance of build folder., and otherwise create it.") | 2 years agoOct 16, 2024 |
| [defs.h](https://github.com/cpu0x00/Ghost/blob/main/defs.h "defs.h") | [defs.h](https://github.com/cpu0x00/Ghost/blob/main/defs.h "defs.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [etw.h](https://github.com/cpu0x00/Ghost/blob/main/etw.h "etw.h") | [etw.h](https://github.com/cpu0x00/Ghost/blob/main/etw.h "etw.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [functions.h](https://github.com/cpu0x00/Ghost/blob/main/functions.h "functions.h") | [functions.h](https://github.com/cpu0x00/Ghost/blob/main/functions.h "functions.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [hash.h](https://github.com/cpu0x00/Ghost/blob/main/hash.h "hash.h") | [hash.h](https://github.com/cpu0x00/Ghost/blob/main/hash.h "hash.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [hook.h](https://github.com/cpu0x00/Ghost/blob/main/hook.h "hook.h") | [hook.h](https://github.com/cpu0x00/Ghost/blob/main/hook.h "hook.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [ntprocessapi.h](https://github.com/cpu0x00/Ghost/blob/main/ntprocessapi.h "ntprocessapi.h") | [ntprocessapi.h](https://github.com/cpu0x00/Ghost/blob/main/ntprocessapi.h "ntprocessapi.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [resolvers.h](https://github.com/cpu0x00/Ghost/blob/main/resolvers.h "resolvers.h") | [resolvers.h](https://github.com/cpu0x00/Ghost/blob/main/resolvers.h "resolvers.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [resource1.h](https://github.com/cpu0x00/Ghost/blob/main/resource1.h "resource1.h") | [resource1.h](https://github.com/cpu0x00/Ghost/blob/main/resource1.h "resource1.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [retaddrspoof.asm](https://github.com/cpu0x00/Ghost/blob/main/retaddrspoof.asm "retaddrspoof.asm") | [retaddrspoof.asm](https://github.com/cpu0x00/Ghost/blob/main/retaddrspoof.asm "retaddrspoof.asm") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [retaddrspoof.h](https://github.com/cpu0x00/Ghost/blob/main/retaddrspoof.h "retaddrspoof.h") | [retaddrspoof.h](https://github.com/cpu0x00/Ghost/blob/main/retaddrspoof.h "retaddrspoof.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [rsrc.h](https://github.com/cpu0x00/Ghost/blob/main/rsrc.h "rsrc.h") | [rsrc.h](https://github.com/cpu0x00/Ghost/blob/main/rsrc.h "rsrc.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [structs.h](https://github.com/cpu0x00/Ghost/blob/main/structs.h "structs.h") | [structs.h](https://github.com/cpu0x00/Ghost/blob/main/structs.h "structs.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [syscalls.asm](https://github.com/cpu0x00/Ghost/blob/main/syscalls.asm "syscalls.asm") | [syscalls.asm](https://github.com/cpu0x00/Ghost/blob/main/syscalls.asm "syscalls.asm") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| [types.h](https://github.com/cpu0x00/Ghost/blob/main/types.h "types.h") | [types.h](https://github.com/cpu0x00/Ghost/blob/main/types.h "types.h") | [Update types.h](https://github.com/cpu0x00/Ghost/commit/797b1e59e164b52b05d9b7ca033c84d446c45dad "Update types.h") | 2 years agoOct 15, 2024 |
| [unhook.h](https://github.com/cpu0x00/Ghost/blob/main/unhook.h "unhook.h") | [unhook.h](https://github.com/cpu0x00/Ghost/blob/main/unhook.h "unhook.h") | [Add files via upload](https://github.com/cpu0x00/Ghost/commit/d11264c5c3a90e0f18a9d0396fa4e3c891162949 "Add files via upload") | 2 years agoOct 15, 2024 |
| View all files |

## Repository files navigation

# Ghost

[Permalink: Ghost](https://github.com/cpu0x00/Ghost#ghost)

Ghost is a shellcode loader project designed to bypass multiple detection capabilities that are usually implemented by an EDR

## Detection 1 - kernel callbacks

[Permalink: Detection 1 - kernel callbacks](https://github.com/cpu0x00/Ghost#detection-1---kernel-callbacks)

kernel callbacks are implemented by an EDR to harness kernel level visiblity of events taking place on a system and that suggests that edrs can see whenever an execution attempt of a thread or a process is attempted

ghost makes use of Fiber threads to circumvent this detection technique, fiber threads are userland only execution units that does not alert any registered kernel callbacks

## Detection 2 - stack unwinding

[Permalink: Detection 2 - stack unwinding](https://github.com/cpu0x00/Ghost#detection-2---stack-unwinding)

stack unwinding is a technique implemented by EDRs to detect anomalous function calls including direct and indirect syscalls

ghost makes use of 2 stack spoofing techniques to evade such detection

1 - the first one is Return Address Spoofing to hide normal function and indirect syscall invokations from the callstack
2 - the second technique is using Function Hooking and switching between fiber threads to hide the entire beacon call stack during its sleeping period (all the fiber switching is also invisible to kernel)

## detection 3 - memory scanning

[Permalink: detection 3 - memory scanning](https://github.com/cpu0x00/Ghost#detection-3---memory-scanning)

detection softwares often make use of memory scanning to identify malicious shellcode in a process' memory space

ghost implements a shellcode hiding technique originally implemented by _roshtyak_ by allocating a very large memory space , filling this memory with random cryptographic data using SystemFunction036 (RtlGenRandom) and placing the shellcode in a random place between all the cryptographic data making it harder to detect during both manual and automated scanning

## other more minor evasion techniques are implemented such as

[Permalink: other more minor evasion techniques are implemented such as](https://github.com/cpu0x00/Ghost#other-more-minor-evasion-techniques-are-implemented-such-as)

- making use of suspended processes and indirect syscalls to remove any function hooks installed by an EDR

- stopping ETW by patching its core functions in memory

- custom API hashing for resolving functions and system service numbers (SSNs)

- putting shellcode in resources (this was shockingly effective xD)


### Note

[Permalink: Note](https://github.com/cpu0x00/Ghost#note)

Ghost heavily relies on understanding how your beacon sleeps , in case of cobalt strike the kernel32!Sleep function is hooked and replaced with fiber calls to allow switching and hiding the beacon callstack

if you want to use it with other C2 beacons you will need to use a tool like apimonitor to intercept api calls for your "beacon" , detect the api called on sleep and replacing it in Ghost.cpp to hook it , for example for MDSec's NightHawk one of the CreateThreadPool APIs needs to be hooked

### build

[Permalink: build](https://github.com/cpu0x00/Ghost#build)

To build the binary use the python `build.py` script providing the shellcode

ex: `python3 build.py -i shellcode.bin`

the compilation is done on linux using the MinGW suite

[![](https://github.com/cpu0x00/Ghost/raw/main/image/image.png)](https://github.com/cpu0x00/Ghost/blob/main/image/image.png)

_above is an example of a beacons stack gets hidden during its sleep time_

### Resources

[Permalink: Resources](https://github.com/cpu0x00/Ghost#resources)

- [https://github.com/Kudaes/Fiber](https://github.com/Kudaes/Fiber)
- [https://github.com/LloydLabs/shellcode-plain-sight](https://github.com/LloydLabs/shellcode-plain-sight)
- [https://decoded.avast.io/janvojtesek/raspberry-robins-roshtyak-a-little-lesson-in-trickery/](https://decoded.avast.io/janvojtesek/raspberry-robins-roshtyak-a-little-lesson-in-trickery/)

## About

Evasive shellcode loader


### Resources

[Readme](https://github.com/cpu0x00/Ghost#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/cpu0x00/Ghost).

[Activity](https://github.com/cpu0x00/Ghost/activity)

### Stars

[**397**\\
stars](https://github.com/cpu0x00/Ghost/stargazers)

### Watchers

[**7**\\
watching](https://github.com/cpu0x00/Ghost/watchers)

### Forks

[**65**\\
forks](https://github.com/cpu0x00/Ghost/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fcpu0x00%2FGhost&report=cpu0x00+%28user%29)

## [Releases](https://github.com/cpu0x00/Ghost/releases)

No releases published

## [Packages\  0](https://github.com/users/cpu0x00/packages?repo_name=Ghost)

No packages published

## [Contributors\  2](https://github.com/cpu0x00/Ghost/graphs/contributors)

- [![@cpu0x00](https://avatars.githubusercontent.com/u/86830248?s=64&v=4)](https://github.com/cpu0x00)[**cpu0x00**](https://github.com/cpu0x00)
- [![@xcalibure2](https://avatars.githubusercontent.com/u/104156209?s=64&v=4)](https://github.com/xcalibure2)[**xcalibure2**](https://github.com/xcalibure2)

## Languages

- [C++49.1%](https://github.com/cpu0x00/Ghost/search?l=c%2B%2B)
- [C39.2%](https://github.com/cpu0x00/Ghost/search?l=c)
- [Python7.7%](https://github.com/cpu0x00/Ghost/search?l=python)
- [Assembly4.0%](https://github.com/cpu0x00/Ghost/search?l=assembly)

You can’t perform that action at this time.