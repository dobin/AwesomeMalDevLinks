# https://github.com/namazso/dll-proxy-generator

[Skip to content](https://github.com/namazso/dll-proxy-generator#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/namazso/dll-proxy-generator) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/namazso/dll-proxy-generator) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/namazso/dll-proxy-generator) to refresh your session.Dismiss alert

{{ message }}

[namazso](https://github.com/namazso)/ **[dll-proxy-generator](https://github.com/namazso/dll-proxy-generator)** Public

- [Notifications](https://github.com/login?return_to=%2Fnamazso%2Fdll-proxy-generator) You must be signed in to change notification settings
- [Fork\\
15](https://github.com/login?return_to=%2Fnamazso%2Fdll-proxy-generator)
- [Star\\
220](https://github.com/login?return_to=%2Fnamazso%2Fdll-proxy-generator)


Generate a proxy dll for arbitrary dll


### License

[0BSD license](https://github.com/namazso/dll-proxy-generator/blob/master/LICENSE)

[220\\
stars](https://github.com/namazso/dll-proxy-generator/stargazers) [15\\
forks](https://github.com/namazso/dll-proxy-generator/forks) [Branches](https://github.com/namazso/dll-proxy-generator/branches) [Tags](https://github.com/namazso/dll-proxy-generator/tags) [Activity](https://github.com/namazso/dll-proxy-generator/activity)

[Star](https://github.com/login?return_to=%2Fnamazso%2Fdll-proxy-generator)

[Notifications](https://github.com/login?return_to=%2Fnamazso%2Fdll-proxy-generator) You must be signed in to change notification settings

# namazso/dll-proxy-generator

master

[**1** Branch](https://github.com/namazso/dll-proxy-generator/branches) [**2** Tags](https://github.com/namazso/dll-proxy-generator/tags)

[Go to Branches page](https://github.com/namazso/dll-proxy-generator/branches)[Go to Tags page](https://github.com/namazso/dll-proxy-generator/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![namazso](https://avatars.githubusercontent.com/u/8676443?v=4&size=40)](https://github.com/namazso)[namazso](https://github.com/namazso/dll-proxy-generator/commits?author=namazso)<br>[Bump version](https://github.com/namazso/dll-proxy-generator/commit/97a257a7152c9af2cf1dfeb31bfad74b9cebecc6)<br>2 years agoOct 18, 2024<br>[97a257a](https://github.com/namazso/dll-proxy-generator/commit/97a257a7152c9af2cf1dfeb31bfad74b9cebecc6) · 2 years agoOct 18, 2024<br>## History<br>[8 Commits](https://github.com/namazso/dll-proxy-generator/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/namazso/dll-proxy-generator/commits/master/) 8 Commits |
| [.github/workflows](https://github.com/namazso/dll-proxy-generator/tree/master/.github/workflows "This path skips through empty directories") | [.github/workflows](https://github.com/namazso/dll-proxy-generator/tree/master/.github/workflows "This path skips through empty directories") | [v4 no longer allows same name artifacts](https://github.com/namazso/dll-proxy-generator/commit/52402e3a8470e32cba58ae001fbfaaf1adf4f13e "v4 no longer allows same name artifacts") | 2 years agoOct 8, 2024 |
| [src](https://github.com/namazso/dll-proxy-generator/tree/master/src "src") | [src](https://github.com/namazso/dll-proxy-generator/tree/master/src "src") | [Fix ordinals](https://github.com/namazso/dll-proxy-generator/commit/88b3078a381babd3e6e56c323c3e3dcb198ee7a6 "Fix ordinals") | 2 years agoOct 18, 2024 |
| [.gitignore](https://github.com/namazso/dll-proxy-generator/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/namazso/dll-proxy-generator/blob/master/.gitignore ".gitignore") | [Initial commit](https://github.com/namazso/dll-proxy-generator/commit/68b47d8cb17e5812b3e9cf696004d76ada54c97e "Initial commit") | 2 years agoOct 8, 2024 |
| [Cargo.lock](https://github.com/namazso/dll-proxy-generator/blob/master/Cargo.lock "Cargo.lock") | [Cargo.lock](https://github.com/namazso/dll-proxy-generator/blob/master/Cargo.lock "Cargo.lock") | [Initial commit](https://github.com/namazso/dll-proxy-generator/commit/68b47d8cb17e5812b3e9cf696004d76ada54c97e "Initial commit") | 2 years agoOct 8, 2024 |
| [Cargo.toml](https://github.com/namazso/dll-proxy-generator/blob/master/Cargo.toml "Cargo.toml") | [Cargo.toml](https://github.com/namazso/dll-proxy-generator/blob/master/Cargo.toml "Cargo.toml") | [Bump version](https://github.com/namazso/dll-proxy-generator/commit/97a257a7152c9af2cf1dfeb31bfad74b9cebecc6 "Bump version") | 2 years agoOct 18, 2024 |
| [LICENSE](https://github.com/namazso/dll-proxy-generator/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/namazso/dll-proxy-generator/blob/master/LICENSE "LICENSE") | [Initial commit](https://github.com/namazso/dll-proxy-generator/commit/68b47d8cb17e5812b3e9cf696004d76ada54c97e "Initial commit") | 2 years agoOct 8, 2024 |
| [README.md](https://github.com/namazso/dll-proxy-generator/blob/master/README.md "README.md") | [README.md](https://github.com/namazso/dll-proxy-generator/blob/master/README.md "README.md") | [Add credits for the path](https://github.com/namazso/dll-proxy-generator/commit/20809c2c304dfb3a5c413f4220537334af6b7552 "Add credits for the path") | 2 years agoOct 8, 2024 |
| View all files |

## Repository files navigation

# DLL Proxy Generator

[Permalink: DLL Proxy Generator](https://github.com/namazso/dll-proxy-generator#dll-proxy-generator)

Generate a proxy dll for arbitrary dll, while also loading a user-defined secondary dll.

## Usage

[Permalink: Usage](https://github.com/namazso/dll-proxy-generator#usage)

`dll-proxy-generator.exe [OPTIONS] --import-dll <IMPORT_DLL> --import <IMPORT> <DLL>`

### Arguments

[Permalink: Arguments](https://github.com/namazso/dll-proxy-generator#arguments)

`<DLL>  Path to dll to proxy`

### Options

[Permalink: Options](https://github.com/namazso/dll-proxy-generator#options)

```
-d, --import-dll <IMPORT_DLL>      Extra dll to import
-i, --import <IMPORT>              Import name or ordinal
-p, --proxy-target <PROXY_TARGET>  Target of proxy, defaults to path of same file in System32
-o, --output <OUTPUT>              Output file
-m, --machine <MACHINE>            COFF Machine magic. Defaults to x64's [default: 34404]
-h, --help                         Print help
-V, --version                      Print version
```

## Credits

[Permalink: Credits](https://github.com/namazso/dll-proxy-generator#credits)

Thanks to [@mrexodia](https://github.com/mrexodia) for the [target dll trick](https://github.com/mrexodia/perfect-dll-proxy/)

## About

Generate a proxy dll for arbitrary dll


### Resources

[Readme](https://github.com/namazso/dll-proxy-generator#readme-ov-file)

### License

[0BSD license](https://github.com/namazso/dll-proxy-generator#0BSD-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/namazso/dll-proxy-generator).

[Activity](https://github.com/namazso/dll-proxy-generator/activity)

### Stars

[**220**\\
stars](https://github.com/namazso/dll-proxy-generator/stargazers)

### Watchers

[**3**\\
watching](https://github.com/namazso/dll-proxy-generator/watchers)

### Forks

[**15**\\
forks](https://github.com/namazso/dll-proxy-generator/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fnamazso%2Fdll-proxy-generator&report=namazso+%28user%29)

## [Releases\  2](https://github.com/namazso/dll-proxy-generator/releases)

[0.1.1: Fix ordinals\\
Latest\\
\\
on Oct 18, 2024Oct 19, 2024](https://github.com/namazso/dll-proxy-generator/releases/tag/0.1.1)

[\+ 1 release](https://github.com/namazso/dll-proxy-generator/releases)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/namazso/dll-proxy-generator).

## Languages

- [Rust100.0%](https://github.com/namazso/dll-proxy-generator/search?l=rust)

You can’t perform that action at this time.