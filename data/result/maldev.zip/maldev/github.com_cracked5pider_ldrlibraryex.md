# https://github.com/Cracked5pider/LdrLibraryEx

[Skip to content](https://github.com/Cracked5pider/LdrLibraryEx#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Cracked5pider/LdrLibraryEx) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Cracked5pider/LdrLibraryEx) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Cracked5pider/LdrLibraryEx) to refresh your session.Dismiss alert

{{ message }}

This repository was archived by the owner on Apr 6, 2024. It is now read-only.


[Cracked5pider](https://github.com/Cracked5pider)/ **[LdrLibraryEx](https://github.com/Cracked5pider/LdrLibraryEx)** Public archive

- [Notifications](https://github.com/login?return_to=%2FCracked5pider%2FLdrLibraryEx) You must be signed in to change notification settings
- [Fork\\
79](https://github.com/login?return_to=%2FCracked5pider%2FLdrLibraryEx)
- [Star\\
456](https://github.com/login?return_to=%2FCracked5pider%2FLdrLibraryEx)


A small x64 library to load dll's into memory.


[456\\
stars](https://github.com/Cracked5pider/LdrLibraryEx/stargazers) [79\\
forks](https://github.com/Cracked5pider/LdrLibraryEx/forks) [Branches](https://github.com/Cracked5pider/LdrLibraryEx/branches) [Tags](https://github.com/Cracked5pider/LdrLibraryEx/tags) [Activity](https://github.com/Cracked5pider/LdrLibraryEx/activity)

[Star](https://github.com/login?return_to=%2FCracked5pider%2FLdrLibraryEx)

[Notifications](https://github.com/login?return_to=%2FCracked5pider%2FLdrLibraryEx) You must be signed in to change notification settings

# Cracked5pider/LdrLibraryEx

main

[**1** Branch](https://github.com/Cracked5pider/LdrLibraryEx/branches) [**0** Tags](https://github.com/Cracked5pider/LdrLibraryEx/tags)

[Go to Branches page](https://github.com/Cracked5pider/LdrLibraryEx/branches)[Go to Tags page](https://github.com/Cracked5pider/LdrLibraryEx/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Cracked5pider](https://avatars.githubusercontent.com/u/51360176?v=4&size=40)](https://github.com/Cracked5pider)[Cracked5pider](https://github.com/Cracked5pider/LdrLibraryEx/commits?author=Cracked5pider)<br>[edit typo](https://github.com/Cracked5pider/LdrLibraryEx/commit/cfe92fc085f0ab6296c20cf6e6a8379e10017b15)<br>3 years agoNov 6, 2023<br>[cfe92fc](https://github.com/Cracked5pider/LdrLibraryEx/commit/cfe92fc085f0ab6296c20cf6e6a8379e10017b15) · 3 years agoNov 6, 2023<br>## History<br>[2 Commits](https://github.com/Cracked5pider/LdrLibraryEx/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Cracked5pider/LdrLibraryEx/commits/main/) 2 Commits |
| [include](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/include "include") | [include](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/include "include") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| [scripts](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/scripts "scripts") | [scripts](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/scripts "scripts") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| [src](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/src "src") | [src](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/src "src") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| [tests](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/tests "tests") | [tests](https://github.com/Cracked5pider/LdrLibraryEx/tree/main/tests "tests") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| [CMakeLists.txt](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/CMakeLists.txt "CMakeLists.txt") | [CMakeLists.txt](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/CMakeLists.txt "CMakeLists.txt") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| [README.md](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/README.md "README.md") | [README.md](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/README.md "README.md") | [edit typo](https://github.com/Cracked5pider/LdrLibraryEx/commit/cfe92fc085f0ab6296c20cf6e6a8379e10017b15 "edit typo") | 3 years agoNov 6, 2023 |
| [makefile](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/makefile "makefile") | [makefile](https://github.com/Cracked5pider/LdrLibraryEx/blob/main/makefile "makefile") | [init commit](https://github.com/Cracked5pider/LdrLibraryEx/commit/a8b4f8f0be9894ed1b5446ea27ffe81927bee6d3 "init commit") | 3 years agoNov 6, 2023 |
| View all files |

## Repository files navigation

# LdrLibraryEx

[Permalink: LdrLibraryEx](https://github.com/Cracked5pider/LdrLibraryEx#ldrlibraryex)

A small x64 library to load dll's into memory.

### Features

[Permalink: Features](https://github.com/Cracked5pider/LdrLibraryEx#features)

- low dependencies & function use (only ntdll.dll used)
- position independent code
- lightweight and minimal
- easy to use
- load modules from memory
- load modules from disk
- api sets support
- bypass image load callbacks (using private memory)
- support for images with delayed import, tls, seh, etc.

### Documentation

[Permalink: Documentation](https://github.com/Cracked5pider/LdrLibraryEx#documentation)

#### Library Flags

[Permalink: Library Flags](https://github.com/Cracked5pider/LdrLibraryEx#library-flags)

Flags can be combined

`LIBRARYEX_NONE`: Map module from disk into memory and execute entrypoint.

`LIBRARYEX_BYPASS_LOAD_CALLBACK`: Map module from disk into private memory (unbacked) which bypasses image load callbacks (`PsSetLoadImageNotifyRoutine`)

`LIBRARYEX_NO_ENTRY`: Do not execute the entrypoint of the module.

`LIBRARYEX_BUFFER`: Map the module from memory instead from disk.

#### Function: `LdrLibrary`

[Permalink: Function: LdrLibrary](https://github.com/Cracked5pider/LdrLibraryEx#function-ldrlibrary)

Easy to use function to load a library into memory. The first param, based on what flags has been specified, can be either a wide string module name to load or memory address where the PE is located at.

```
/*!
 * @brief
 *  load library into memory
 *
 * @param Buffer
 *  buffer context to load library
 *  either a wide string or a buffer pointer
 *  the to PE file to map (LIBRARYEX_BUFFER)
 *
 * @param Library
 *  loaded library pointer
 *
 * @param Flags
 *  flags
 *
 * @return
 *  status of function
 */
NTSTATUS LdrLibrary(
    _In_  PVOID  Buffer,
    _Out_ PVOID* Library,
    _In_  ULONG  Flags
);
```

This example shows how to load a module from disk (from the System32 path):

```
PVOID Module = { 0 };
ULONG Flags  = { 0 };

//
// mapping flags to be used by the library
//
Flags = LIBRARYEX_NONE;

//
// map file into memory
//
if ( ! NT_SUCCESS( Status = LdrLibrary( L"advapi32.dll", &Module, Flags ) ) ) {
    printf( "[-] LdrLibraryEx Failed: %p\n", Status );
    return;
}

printf( "[*] Module @ %p\n", Module );
```

This examples shows how to load a module from a memory buffer:

```
PVOID Module = { 0 };
ULONG Flags  = { 0 };

//
// mapping flags to be used by the library
//
Flags = LIBRARYEX_NONE  |
        LIBRARYEX_BUFFER;

//
// read file on disk into memory
//
if ( ! ( Image = ReadFileBuffer( L"C:\\Windows\\System32\\advapi32.dll", NULL ) ) ) {
    puts( "[-] ReadFileBuffer Failed" );
    return;
}

//
// map file into memory
//
if ( ! NT_SUCCESS( Status = LdrLibrary( Image, &Module, Flags ) ) ) {
    printf( "[-] LdrLibraryEx Failed: %p\n", Status );
    return;
}

printf( "[*] Module @ %p\n", Module );
```

It is also possible to load modules based on their api set (win10+ support only):

```
//
// map file into memory
//
if ( ! NT_SUCCESS( Status = LdrLibrary( L"api-ms-win-base-util-l1-1-0.dll", &Module, Flags ) ) ) {
    printf( "[-] LdrLibraryEx Failed: %p\n", Status );
    return;
}

printf( "[*] Module @ %p\n",  );
```

#### Function: `LdrLibraryEx`

[Permalink: Function: LdrLibraryEx](https://github.com/Cracked5pider/LdrLibraryEx#function-ldrlibraryex)

LdrLibraryEx allows to hook certain functions to modify the behaviour of how a library should be mapped into memory.

```
//
// mapping flags to be used by the library
// and insert the loaded module into Peb
//
Flags = LIBRARYEX_BYPASS_LOAD_CALLBACK |
        LIBRARYEX_NO_ENTRY;

//
// init LibraryEx context
//
if ( ! NT_SUCCESS( Status = LdrLibraryCtx( &Ctx, Flags ) ) ) {
    printf( "[-] LdrLibraryCtx Failed: %d\n", Status );
    goto END;
}

//
// hook function
//
Ctx.LdrLoadDll = C_PTR( HookLdrLoadDll );

//
// map file into memory
//
if ( ! NT_SUCCESS( Status = LdrLibraryEx( &Ctx, L"cryptsp.dll", &Module, Flags ) ) ) {
    printf( "[-] LdrLibraryEx Failed: %p\n", Status );
    return;
}
```

### Note

[Permalink: Note](https://github.com/Cracked5pider/LdrLibraryEx#note)

This codebase is written and optimized for x86\_64-mingw and it most likely not going to work and or compile under Visual Studio.

## Credits

[Permalink: Credits](https://github.com/Cracked5pider/LdrLibraryEx#credits)

Huge credit goes out to following resources and projects:

- [DarkLoadLibrary](https://github.com/bats3c/DarkLoadLibrary)
- [MDSec: Bypassing Image loader kernel callbacks](https://www.mdsec.co.uk/2021/06/bypassing-image-load-kernel-callbacks/)
- [ReactOS LdrLoadDll](https://doxygen.reactos.org/d7/d55/ldrapi_8c.html#a7671bda932dbb5096570f431ff83474c)
- [Vergilius Project](https://www.vergiliusproject.com/)

this project shouldn't be used in a real world env or operation. I mainly wrote this to understand and learn more about how windows loader works. I wrote it as a library because I wanted to use this for other type of public and private projects. I achieved my goal. Cya.

## About

A small x64 library to load dll's into memory.


### Resources

[Readme](https://github.com/Cracked5pider/LdrLibraryEx#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Cracked5pider/LdrLibraryEx).

[Activity](https://github.com/Cracked5pider/LdrLibraryEx/activity)

### Stars

[**456**\\
stars](https://github.com/Cracked5pider/LdrLibraryEx/stargazers)

### Watchers

[**11**\\
watching](https://github.com/Cracked5pider/LdrLibraryEx/watchers)

### Forks

[**79**\\
forks](https://github.com/Cracked5pider/LdrLibraryEx/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FCracked5pider%2FLdrLibraryEx&report=Cracked5pider+%28user%29)

## [Releases](https://github.com/Cracked5pider/LdrLibraryEx/releases)

No releases published

## [Packages\  0](https://github.com/users/Cracked5pider/packages?repo_name=LdrLibraryEx)

No packages published

## Languages

- [C99.6%](https://github.com/Cracked5pider/LdrLibraryEx/search?l=c)
- Other0.4%

You can’t perform that action at this time.