# https://github.com/HulkOperator/CallStackSpoofer

[Skip to content](https://github.com/HulkOperator/CallStackSpoofer#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/HulkOperator/CallStackSpoofer) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/HulkOperator/CallStackSpoofer) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/HulkOperator/CallStackSpoofer) to refresh your session.Dismiss alert

{{ message }}

[HulkOperator](https://github.com/HulkOperator)/ **[CallStackSpoofer](https://github.com/HulkOperator/CallStackSpoofer)** Public

- [Notifications](https://github.com/login?return_to=%2FHulkOperator%2FCallStackSpoofer) You must be signed in to change notification settings
- [Fork\\
5](https://github.com/login?return_to=%2FHulkOperator%2FCallStackSpoofer)
- [Star\\
64](https://github.com/login?return_to=%2FHulkOperator%2FCallStackSpoofer)


### License

[MIT license](https://github.com/HulkOperator/CallStackSpoofer/blob/main/LICENSE)

[64\\
stars](https://github.com/HulkOperator/CallStackSpoofer/stargazers) [5\\
forks](https://github.com/HulkOperator/CallStackSpoofer/forks) [Branches](https://github.com/HulkOperator/CallStackSpoofer/branches) [Tags](https://github.com/HulkOperator/CallStackSpoofer/tags) [Activity](https://github.com/HulkOperator/CallStackSpoofer/activity)

[Star](https://github.com/login?return_to=%2FHulkOperator%2FCallStackSpoofer)

[Notifications](https://github.com/login?return_to=%2FHulkOperator%2FCallStackSpoofer) You must be signed in to change notification settings

# HulkOperator/CallStackSpoofer

main

[**1** Branch](https://github.com/HulkOperator/CallStackSpoofer/branches) [**0** Tags](https://github.com/HulkOperator/CallStackSpoofer/tags)

[Go to Branches page](https://github.com/HulkOperator/CallStackSpoofer/branches)[Go to Tags page](https://github.com/HulkOperator/CallStackSpoofer/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![HulkOperator](https://avatars.githubusercontent.com/u/90966834?v=4&size=40)](https://github.com/HulkOperator)[HulkOperator](https://github.com/HulkOperator/CallStackSpoofer/commits?author=HulkOperator)<br>[Update README.md](https://github.com/HulkOperator/CallStackSpoofer/commit/1b84053f3342a836ef799777275c7fa869aa2183)<br>2 years agoDec 19, 2024<br>[1b84053](https://github.com/HulkOperator/CallStackSpoofer/commit/1b84053f3342a836ef799777275c7fa869aa2183) · 2 years agoDec 19, 2024<br>## History<br>[3 Commits](https://github.com/HulkOperator/CallStackSpoofer/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/HulkOperator/CallStackSpoofer/commits/main/) 3 Commits |
| [.gitignore](https://github.com/HulkOperator/CallStackSpoofer/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/HulkOperator/CallStackSpoofer/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/HulkOperator/CallStackSpoofer/commit/bf0c1f166461d079f7dd9c8917c46e2f97a50bea "Initial commit") | 2 years agoDec 19, 2024 |
| [Call\_Stack\_Spoofing.sln](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.sln "Call_Stack_Spoofing.sln") | [Call\_Stack\_Spoofing.sln](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.sln "Call_Stack_Spoofing.sln") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [Call\_Stack\_Spoofing.vcxproj](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.vcxproj "Call_Stack_Spoofing.vcxproj") | [Call\_Stack\_Spoofing.vcxproj](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.vcxproj "Call_Stack_Spoofing.vcxproj") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [Call\_Stack\_Spoofing.vcxproj.filters](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.vcxproj.filters "Call_Stack_Spoofing.vcxproj.filters") | [Call\_Stack\_Spoofing.vcxproj.filters](https://github.com/HulkOperator/CallStackSpoofer/blob/main/Call_Stack_Spoofing.vcxproj.filters "Call_Stack_Spoofing.vcxproj.filters") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [LICENSE](https://github.com/HulkOperator/CallStackSpoofer/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/HulkOperator/CallStackSpoofer/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/HulkOperator/CallStackSpoofer/commit/bf0c1f166461d079f7dd9c8917c46e2f97a50bea "Initial commit") | 2 years agoDec 19, 2024 |
| [README.md](https://github.com/HulkOperator/CallStackSpoofer/blob/main/README.md "README.md") | [README.md](https://github.com/HulkOperator/CallStackSpoofer/blob/main/README.md "README.md") | [Update README.md](https://github.com/HulkOperator/CallStackSpoofer/commit/1b84053f3342a836ef799777275c7fa869aa2183 "Update README.md") | 2 years agoDec 19, 2024 |
| [main.c](https://github.com/HulkOperator/CallStackSpoofer/blob/main/main.c "main.c") | [main.c](https://github.com/HulkOperator/CallStackSpoofer/blob/main/main.c "main.c") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [spoof.asm](https://github.com/HulkOperator/CallStackSpoofer/blob/main/spoof.asm "spoof.asm") | [spoof.asm](https://github.com/HulkOperator/CallStackSpoofer/blob/main/spoof.asm "spoof.asm") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [spoofer.h](https://github.com/HulkOperator/CallStackSpoofer/blob/main/spoofer.h "spoofer.h") | [spoofer.h](https://github.com/HulkOperator/CallStackSpoofer/blob/main/spoofer.h "spoofer.h") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| [structs.h](https://github.com/HulkOperator/CallStackSpoofer/blob/main/structs.h "structs.h") | [structs.h](https://github.com/HulkOperator/CallStackSpoofer/blob/main/structs.h "structs.h") | [First Commit](https://github.com/HulkOperator/CallStackSpoofer/commit/058a8c559011459361c1d77831aa99168c3fedaa "First Commit") | 2 years agoDec 19, 2024 |
| View all files |

## Repository files navigation

# CallStackSpoofer

[Permalink: CallStackSpoofer](https://github.com/HulkOperator/CallStackSpoofer#callstackspoofer)

This project is a pingback to my [blog post](https://hulkops.gitbook.io/blog/red-team/x64-call-stack-spoofing)

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/HulkOperator/CallStackSpoofer#readme-ov-file)

### License

[MIT license](https://github.com/HulkOperator/CallStackSpoofer#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/HulkOperator/CallStackSpoofer).

[Activity](https://github.com/HulkOperator/CallStackSpoofer/activity)

### Stars

[**64**\\
stars](https://github.com/HulkOperator/CallStackSpoofer/stargazers)

### Watchers

[**1**\\
watching](https://github.com/HulkOperator/CallStackSpoofer/watchers)

### Forks

[**5**\\
forks](https://github.com/HulkOperator/CallStackSpoofer/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FHulkOperator%2FCallStackSpoofer&report=HulkOperator+%28user%29)

## [Releases](https://github.com/HulkOperator/CallStackSpoofer/releases)

No releases published

## [Packages\  0](https://github.com/users/HulkOperator/packages?repo_name=CallStackSpoofer)

No packages published

## Languages

- [C64.6%](https://github.com/HulkOperator/CallStackSpoofer/search?l=c)
- [Assembly35.4%](https://github.com/HulkOperator/CallStackSpoofer/search?l=assembly)

You can’t perform that action at this time.