# https://github.com/NtDallas/OdinLdr

[Skip to content](https://github.com/NtDallas/OdinLdr#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/NtDallas/OdinLdr) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/NtDallas/OdinLdr) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/NtDallas/OdinLdr) to refresh your session.Dismiss alert

{{ message }}

[NtDallas](https://github.com/NtDallas)/ **[OdinLdr](https://github.com/NtDallas/OdinLdr)** Public

- [Notifications](https://github.com/login?return_to=%2FNtDallas%2FOdinLdr) You must be signed in to change notification settings
- [Fork\\
25](https://github.com/login?return_to=%2FNtDallas%2FOdinLdr)
- [Star\\
183](https://github.com/login?return_to=%2FNtDallas%2FOdinLdr)


Cobaltstrike Reflective Loader with Synthetic Stackframe


[183\\
stars](https://github.com/NtDallas/OdinLdr/stargazers) [25\\
forks](https://github.com/NtDallas/OdinLdr/forks) [Branches](https://github.com/NtDallas/OdinLdr/branches) [Tags](https://github.com/NtDallas/OdinLdr/tags) [Activity](https://github.com/NtDallas/OdinLdr/activity)

[Star](https://github.com/login?return_to=%2FNtDallas%2FOdinLdr)

[Notifications](https://github.com/login?return_to=%2FNtDallas%2FOdinLdr) You must be signed in to change notification settings

# NtDallas/OdinLdr

main

[**1** Branch](https://github.com/NtDallas/OdinLdr/branches) [**0** Tags](https://github.com/NtDallas/OdinLdr/tags)

[Go to Branches page](https://github.com/NtDallas/OdinLdr/branches)[Go to Tags page](https://github.com/NtDallas/OdinLdr/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>NtDallas<br>[update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499)<br>last monthJan 17, 2026<br>[5dde743](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499) · last monthJan 17, 2026<br>## History<br>[4 Commits](https://github.com/NtDallas/OdinLdr/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/NtDallas/OdinLdr/commits/main/) 4 Commits |
| [Bin](https://github.com/NtDallas/OdinLdr/tree/main/Bin "Bin") | [Bin](https://github.com/NtDallas/OdinLdr/tree/main/Bin "Bin") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [Common](https://github.com/NtDallas/OdinLdr/tree/main/Common "Common") | [Common](https://github.com/NtDallas/OdinLdr/tree/main/Common "Common") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [Img](https://github.com/NtDallas/OdinLdr/tree/main/Img "Img") | [Img](https://github.com/NtDallas/OdinLdr/tree/main/Img "Img") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [Utils](https://github.com/NtDallas/OdinLdr/tree/main/Utils "Utils") | [Utils](https://github.com/NtDallas/OdinLdr/tree/main/Utils "Utils") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [beacon](https://github.com/NtDallas/OdinLdr/tree/main/beacon "beacon") | [beacon](https://github.com/NtDallas/OdinLdr/tree/main/beacon "beacon") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [postex](https://github.com/NtDallas/OdinLdr/tree/main/postex "postex") | [postex](https://github.com/NtDallas/OdinLdr/tree/main/postex "postex") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [Makefile](https://github.com/NtDallas/OdinLdr/blob/main/Makefile "Makefile") | [Makefile](https://github.com/NtDallas/OdinLdr/blob/main/Makefile "Makefile") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [OdinLdr.cna](https://github.com/NtDallas/OdinLdr/blob/main/OdinLdr.cna "OdinLdr.cna") | [OdinLdr.cna](https://github.com/NtDallas/OdinLdr/blob/main/OdinLdr.cna "OdinLdr.cna") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| [README.md](https://github.com/NtDallas/OdinLdr/blob/main/README.md "README.md") | [README.md](https://github.com/NtDallas/OdinLdr/blob/main/README.md "README.md") | [update](https://github.com/NtDallas/OdinLdr/commit/5dde7433bc3d67d07a8f4ea118552a52c65d4499 "update") | last monthJan 17, 2026 |
| View all files |

## Repository files navigation

# OdinLdr

[Permalink: OdinLdr](https://github.com/NtDallas/OdinLdr#odinldr)

[![OdinLdr](https://github.com/NtDallas/OdinLdr/raw/main/Img/Odin.jpg)](https://github.com/NtDallas/OdinLdr/blob/main/Img/Odin.jpg)

Cobaltstrike reflective loader for beacon and postex

# UDRL

[Permalink: UDRL](https://github.com/NtDallas/OdinLdr#udrl)

- Use Indirect Syscall with Synthetic Stackframe for Nt-Allocate/Protect-VirtualMemory

```
 # Child-SP          RetAddr               Call Site
00 00000000`00cdf5d8 00007ffc`d9a12c66     ntdll!NtAllocateVirtualMemory+0x12
01 00000000`00cdf5e0 00007ffc`da8c7388     KERNELBASE!Internal_EnumSystemLocales+0x406
02 00000000`00cdf9c0 00007ffc`dbefcca5     KERNEL32!BaseThreadInitThunk+0x28
03 00000000`00cdf9f0 00000000`00000000     ntdll!RtlUserThreadStart+0x35
```

- Call LoadLibraryA with Synthetic Stackframe

```
 # Child-SP          RetAddr               Call Site
00 00000000`00c3f518 00007ffc`d9a12c66     KERNEL32!LoadLibraryAStub
01 00000000`00c3f520 00007ffc`da8c7388     KERNELBASE!Internal_EnumSystemLocales+0x406
02 00000000`00c3f900 00007ffc`dbefcca5     KERNEL32!BaseThreadInitThunk+0x28
03 00000000`00c3f930 00000000`00000000     ntdll!RtlUserThreadStart+0x35
```

- Use gadget to read module header and avoid presence of EAF

[![Beacon_Eaf_Exec](https://github.com/NtDallas/OdinLdr/raw/main/Img/Beacon_EAF.jpg)](https://github.com/NtDallas/OdinLdr/blob/main/Img/Beacon_EAF.jpg)[![Beacon_Eaf_Callback](https://github.com/NtDallas/OdinLdr/raw/main/Img/Beacon_Callback.jpg)](https://github.com/NtDallas/OdinLdr/blob/main/Img/Beacon_Callback.jpg)

# Credit

[Permalink: Credit](https://github.com/NtDallas/OdinLdr#credit)

- Sektor7 : [https://institute.sektor7.net/](https://institute.sektor7.net/)
- Cobaltstrike : [https://www.cobaltstrike.com/](https://www.cobaltstrike.com/)
- susMdT : [https://github.com/susMdT/LoudSunRun](https://github.com/susMdT/LoudSunRun)

# Thanks

[Permalink: Thanks](https://github.com/NtDallas/OdinLdr#thanks)

- m\_101 : Tips to bypass EAF
- Tripané : Help for debug

## About

Cobaltstrike Reflective Loader with Synthetic Stackframe


### Resources

[Readme](https://github.com/NtDallas/OdinLdr#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/NtDallas/OdinLdr).

[Activity](https://github.com/NtDallas/OdinLdr/activity)

### Stars

[**183**\\
stars](https://github.com/NtDallas/OdinLdr/stargazers)

### Watchers

[**2**\\
watching](https://github.com/NtDallas/OdinLdr/watchers)

### Forks

[**25**\\
forks](https://github.com/NtDallas/OdinLdr/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FNtDallas%2FOdinLdr&report=NtDallas+%28user%29)

## [Releases](https://github.com/NtDallas/OdinLdr/releases)

No releases published

## [Packages\  0](https://github.com/users/NtDallas/packages?repo_name=OdinLdr)

No packages published

## Languages

- [C++85.5%](https://github.com/NtDallas/OdinLdr/search?l=c%2B%2B)
- [C12.0%](https://github.com/NtDallas/OdinLdr/search?l=c)
- [Assembly1.9%](https://github.com/NtDallas/OdinLdr/search?l=assembly)
- Other0.6%

You can’t perform that action at this time.