# https://github.com/Meowmycks/koneko

[Skip to content](https://github.com/Meowmycks/koneko#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Meowmycks/koneko) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Meowmycks/koneko) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Meowmycks/koneko) to refresh your session.Dismiss alert

{{ message }}

[Meowmycks](https://github.com/Meowmycks)/ **[koneko](https://github.com/Meowmycks/koneko)** Public

- [Notifications](https://github.com/login?return_to=%2FMeowmycks%2Fkoneko) You must be signed in to change notification settings
- [Fork\\
28](https://github.com/login?return_to=%2FMeowmycks%2Fkoneko)
- [Star\\
200](https://github.com/login?return_to=%2FMeowmycks%2Fkoneko)


Robust Cobalt Strike shellcode loader with multiple advanced evasion features


[200\\
stars](https://github.com/Meowmycks/koneko/stargazers) [28\\
forks](https://github.com/Meowmycks/koneko/forks) [Branches](https://github.com/Meowmycks/koneko/branches) [Tags](https://github.com/Meowmycks/koneko/tags) [Activity](https://github.com/Meowmycks/koneko/activity)

[Star](https://github.com/login?return_to=%2FMeowmycks%2Fkoneko)

[Notifications](https://github.com/login?return_to=%2FMeowmycks%2Fkoneko) You must be signed in to change notification settings

# Meowmycks/koneko

main

[**1** Branch](https://github.com/Meowmycks/koneko/branches) [**0** Tags](https://github.com/Meowmycks/koneko/tags)

[Go to Branches page](https://github.com/Meowmycks/koneko/branches)[Go to Tags page](https://github.com/Meowmycks/koneko/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Meowmycks](https://avatars.githubusercontent.com/u/45502375?v=4&size=40)](https://github.com/Meowmycks)[Meowmycks](https://github.com/Meowmycks/koneko/commits?author=Meowmycks)<br>[Update main.cpp](https://github.com/Meowmycks/koneko/commit/07a662cd3e85f2ea42cd7a45956d5a6176a77239)<br>Open commit details<br>10 months agoApr 21, 2025<br>[07a662c](https://github.com/Meowmycks/koneko/commit/07a662cd3e85f2ea42cd7a45956d5a6176a77239) · 10 months agoApr 21, 2025<br>## History<br>[9 Commits](https://github.com/Meowmycks/koneko/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Meowmycks/koneko/commits/main/) 9 Commits |
| [headers](https://github.com/Meowmycks/koneko/tree/main/headers "headers") | [headers](https://github.com/Meowmycks/koneko/tree/main/headers "headers") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [scripts](https://github.com/Meowmycks/koneko/tree/main/scripts "scripts") | [scripts](https://github.com/Meowmycks/koneko/tree/main/scripts "scripts") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [README.md](https://github.com/Meowmycks/koneko/blob/main/README.md "README.md") | [README.md](https://github.com/Meowmycks/koneko/blob/main/README.md "README.md") | [Update README.md](https://github.com/Meowmycks/koneko/commit/9fb1ff8cccfe4eb07e1a5dd21c2d95958e556d4c "Update README.md") | 10 months agoApr 15, 2025 |
| [callme.asm](https://github.com/Meowmycks/koneko/blob/main/callme.asm "callme.asm") | [callme.asm](https://github.com/Meowmycks/koneko/blob/main/callme.asm "callme.asm") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [callr12.asm](https://github.com/Meowmycks/koneko/blob/main/callr12.asm "callr12.asm") | [callr12.asm](https://github.com/Meowmycks/koneko/blob/main/callr12.asm "callr12.asm") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [callstackspoof.cpp](https://github.com/Meowmycks/koneko/blob/main/callstackspoof.cpp "callstackspoof.cpp") | [callstackspoof.cpp](https://github.com/Meowmycks/koneko/blob/main/callstackspoof.cpp "callstackspoof.cpp") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [main.cpp](https://github.com/Meowmycks/koneko/blob/main/main.cpp "main.cpp") | [main.cpp](https://github.com/Meowmycks/koneko/blob/main/main.cpp "main.cpp") | [Update main.cpp](https://github.com/Meowmycks/koneko/commit/07a662cd3e85f2ea42cd7a45956d5a6176a77239 "Update main.cpp  Removed the commented second test shellcode, killswitched and wouldn't work on public Internet") | 10 months agoApr 21, 2025 |
| [sleep.cpp](https://github.com/Meowmycks/koneko/blob/main/sleep.cpp "sleep.cpp") | [sleep.cpp](https://github.com/Meowmycks/koneko/blob/main/sleep.cpp "sleep.cpp") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [spoof.asm](https://github.com/Meowmycks/koneko/blob/main/spoof.asm "spoof.asm") | [spoof.asm](https://github.com/Meowmycks/koneko/blob/main/spoof.asm "spoof.asm") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| [syscalls.cpp](https://github.com/Meowmycks/koneko/blob/main/syscalls.cpp "syscalls.cpp") | [syscalls.cpp](https://github.com/Meowmycks/koneko/blob/main/syscalls.cpp "syscalls.cpp") | [Add files via upload](https://github.com/Meowmycks/koneko/commit/8d23b1aeddd07ae7a622d9cfab61735368c9929a "Add files via upload") | 10 months agoApr 13, 2025 |
| View all files |

## Repository files navigation

# koneko

[Permalink: koneko](https://github.com/Meowmycks/koneko#koneko)

A Cobalt Strike shellcode loader with multiple advanced evasion features.

[![1739210063119](https://private-user-images.githubusercontent.com/45502375/433988547-1d3d84fc-edf1-4e1a-b754-bdb382de5f36.jpg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MTIsIm5iZiI6MTc3MTQxMjQxMiwicGF0aCI6Ii80NTUwMjM3NS80MzM5ODg1NDctMWQzZDg0ZmMtZWRmMS00ZTFhLWI3NTQtYmRiMzgyZGU1ZjM2LmpwZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAxMlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWRlNWRhYzAyM2MyMTI1ZTMzODFlZWUwMjA4ZjhmYWJjZjhlNDY2YjgyYmZjZmM4ZDE5YzcyZjQ1ODMwZGYwMzAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.HlFNYUN5xHk0KGEEIdERcocI3u4tpWIy37RBYJ2YeK4)](https://private-user-images.githubusercontent.com/45502375/433988547-1d3d84fc-edf1-4e1a-b754-bdb382de5f36.jpg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MTIsIm5iZiI6MTc3MTQxMjQxMiwicGF0aCI6Ii80NTUwMjM3NS80MzM5ODg1NDctMWQzZDg0ZmMtZWRmMS00ZTFhLWI3NTQtYmRiMzgyZGU1ZjM2LmpwZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAxMlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWRlNWRhYzAyM2MyMTI1ZTMzODFlZWUwMjA4ZjhmYWJjZjhlNDY2YjgyYmZjZmM4ZDE5YzcyZjQ1ODMwZGYwMzAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.HlFNYUN5xHk0KGEEIdERcocI3u4tpWIy37RBYJ2YeK4)

## Disclaimer

[Permalink: Disclaimer](https://github.com/Meowmycks/koneko#disclaimer)

Don't be evil with this. I created this tool to learn. I'm not responsible if the Feds knock on your door.

* * *

Historically was able to (and may still) bypass

- Palo Alto Cortex xDR
- Microsoft Defender for Endpoints
- Windows Defender
- Malwarebytes Anti-Malware

[![cortex](https://private-user-images.githubusercontent.com/45502375/433991861-340b46f1-f123-4c4a-ab57-9eabae38865e.jpg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MTIsIm5iZiI6MTc3MTQxMjQxMiwicGF0aCI6Ii80NTUwMjM3NS80MzM5OTE4NjEtMzQwYjQ2ZjEtZjEyMy00YzRhLWFiNTctOWVhYmFlMzg4NjVlLmpwZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAxMlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTJhZTA4MDEwOGE0OWM2M2MwYWRlOWRkNTJlZTg3YTA3NjMyMDVhMTEwNGFiNDZhNDVjYzczNWM3MmIzZmU3N2EmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.PkZCsutrRRT-Lc4G4NFEj23TNpDaIlr7Pa-aOZqIztE)](https://private-user-images.githubusercontent.com/45502375/433991861-340b46f1-f123-4c4a-ab57-9eabae38865e.jpg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MTIsIm5iZiI6MTc3MTQxMjQxMiwicGF0aCI6Ii80NTUwMjM3NS80MzM5OTE4NjEtMzQwYjQ2ZjEtZjEyMy00YzRhLWFiNTctOWVhYmFlMzg4NjVlLmpwZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAxMlomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTJhZTA4MDEwOGE0OWM2M2MwYWRlOWRkNTJlZTg3YTA3NjMyMDVhMTEwNGFiNDZhNDVjYzczNWM3MmIzZmU3N2EmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.PkZCsutrRRT-Lc4G4NFEj23TNpDaIlr7Pa-aOZqIztE)

## Features

[Permalink: Features](https://github.com/Meowmycks/koneko#features)

- Fully custom sleep implementation with thread callstack spoofing using NtCreateEvent and NtWaitForSingleObject
- Inline hook on Sleep/SleepEx to redirect to said custom sleep implementation
- Switching between Fiber threads to further avoid memory scanning
- Return address spoofing on (almost?) every other API/NTAPI call
- All the indirect syscalls!
- Bunch of anti-VM and anti-debugger checks
- Splitting and hiding shellcode as a bunch of x64 addresses with the EncodePointer API
- Probably other stuff I forgot to mention here

## Negatives

[Permalink: Negatives](https://github.com/Meowmycks/koneko#negatives)

- It's not a UDRL loader, these spoof tricks are limited to only the running executable and will go away when you process inject to something else.
- The sleep obfuscation is tailored to Cobalt Strike. To work with other C2s you'd need to tailor how the hooking happens. Use a tool like `apimonitor` to intercept API calls from your beacon, detect the API(s) called on the sleep cycle, and then adjust the hooks as needed.

## About

Robust Cobalt Strike shellcode loader with multiple advanced evasion features


### Resources

[Readme](https://github.com/Meowmycks/koneko#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Meowmycks/koneko).

[Activity](https://github.com/Meowmycks/koneko/activity)

### Stars

[**200**\\
stars](https://github.com/Meowmycks/koneko/stargazers)

### Watchers

[**1**\\
watching](https://github.com/Meowmycks/koneko/watchers)

### Forks

[**28**\\
forks](https://github.com/Meowmycks/koneko/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FMeowmycks%2Fkoneko&report=Meowmycks+%28user%29)

## [Releases](https://github.com/Meowmycks/koneko/releases)

No releases published

## [Packages\  0](https://github.com/users/Meowmycks/packages?repo_name=koneko)

No packages published

## Languages

- [C++50.2%](https://github.com/Meowmycks/koneko/search?l=c%2B%2B)
- [C36.7%](https://github.com/Meowmycks/koneko/search?l=c)
- [Assembly10.7%](https://github.com/Meowmycks/koneko/search?l=assembly)
- [Python2.4%](https://github.com/Meowmycks/koneko/search?l=python)

You can’t perform that action at this time.