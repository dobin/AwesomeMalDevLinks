# https://github.com/oldboy21/RflDllOb

[Skip to content](https://github.com/oldboy21/RflDllOb#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/oldboy21/RflDllOb) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/oldboy21/RflDllOb) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/oldboy21/RflDllOb) to refresh your session.Dismiss alert

{{ message }}

[oldboy21](https://github.com/oldboy21)/ **[RflDllOb](https://github.com/oldboy21/RflDllOb)** Public

- [Notifications](https://github.com/login?return_to=%2Foldboy21%2FRflDllOb) You must be signed in to change notification settings
- [Fork\\
50](https://github.com/login?return_to=%2Foldboy21%2FRflDllOb)
- [Star\\
249](https://github.com/login?return_to=%2Foldboy21%2FRflDllOb)


Reflective DLL Injection Made Bella


### License

[GPL-2.0 license](https://github.com/oldboy21/RflDllOb/blob/main/LICENSE)

[249\\
stars](https://github.com/oldboy21/RflDllOb/stargazers) [50\\
forks](https://github.com/oldboy21/RflDllOb/forks) [Branches](https://github.com/oldboy21/RflDllOb/branches) [Tags](https://github.com/oldboy21/RflDllOb/tags) [Activity](https://github.com/oldboy21/RflDllOb/activity)

[Star](https://github.com/login?return_to=%2Foldboy21%2FRflDllOb)

[Notifications](https://github.com/login?return_to=%2Foldboy21%2FRflDllOb) You must be signed in to change notification settings

# oldboy21/RflDllOb

main

[**1** Branch](https://github.com/oldboy21/RflDllOb/branches) [**0** Tags](https://github.com/oldboy21/RflDllOb/tags)

[Go to Branches page](https://github.com/oldboy21/RflDllOb/branches)[Go to Tags page](https://github.com/oldboy21/RflDllOb/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![oldboy21](https://avatars.githubusercontent.com/u/87986485?v=4&size=40)](https://github.com/oldboy21)[oldboy21](https://github.com/oldboy21/RflDllOb/commits?author=oldboy21)<br>[new year, better sleap](https://github.com/oldboy21/RflDllOb/commit/1c693e539c1d3e6e7b32c73e9d08d83b30da854d)<br>2 years agoJan 6, 2025<br>[1c693e5](https://github.com/oldboy21/RflDllOb/commit/1c693e539c1d3e6e7b32c73e9d08d83b30da854d) · 2 years agoJan 6, 2025<br>## History<br>[29 Commits](https://github.com/oldboy21/RflDllOb/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/oldboy21/RflDllOb/commits/main/) 29 Commits |
| [RflDllOb-Bambini](https://github.com/oldboy21/RflDllOb/tree/main/RflDllOb-Bambini "RflDllOb-Bambini") | [RflDllOb-Bambini](https://github.com/oldboy21/RflDllOb/tree/main/RflDllOb-Bambini "RflDllOb-Bambini") | [Timer callback spoofing](https://github.com/oldboy21/RflDllOb/commit/7d072527b9ac1bb1a089fabd365f9a121e1fc67b "Timer callback spoofing") | 2 years agoSep 30, 2024 |
| [RflDllOb-NG](https://github.com/oldboy21/RflDllOb/tree/main/RflDllOb-NG "RflDllOb-NG") | [RflDllOb-NG](https://github.com/oldboy21/RflDllOb/tree/main/RflDllOb-NG "RflDllOb-NG") | [new year, better sleap](https://github.com/oldboy21/RflDllOb/commit/1c693e539c1d3e6e7b32c73e9d08d83b30da854d "new year, better sleap") | 2 years agoJan 6, 2025 |
| [imgs](https://github.com/oldboy21/RflDllOb/tree/main/imgs "imgs") | [imgs](https://github.com/oldboy21/RflDllOb/tree/main/imgs "imgs") | [Timer callback spoofing](https://github.com/oldboy21/RflDllOb/commit/97de6a7092b2be27b9e6caf7de6b7416602d41db "Timer callback spoofing") | 2 years agoSep 30, 2024 |
| [.gitignore](https://github.com/oldboy21/RflDllOb/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/oldboy21/RflDllOb/blob/main/.gitignore ".gitignore") | [first commit bella](https://github.com/oldboy21/RflDllOb/commit/9da0d09e75430ea61bbe9088e711e60b83a42f6b "first commit bella") | 3 years agoDec 21, 2023 |
| [LICENSE](https://github.com/oldboy21/RflDllOb/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/oldboy21/RflDllOb/blob/main/LICENSE "LICENSE") | [RflDll - Ob](https://github.com/oldboy21/RflDllOb/commit/4e5b68f31eed1543d7c5ef604e080656b183e52e "RflDll - Ob") | 2 years agoJun 9, 2024 |
| [README.md](https://github.com/oldboy21/RflDllOb/blob/main/README.md "README.md") | [README.md](https://github.com/oldboy21/RflDllOb/blob/main/README.md "README.md") | [Timer callback spoofing](https://github.com/oldboy21/RflDllOb/commit/e2ca95e3fb2c4648b375fcc1bd77af7d5dd96eb7 "Timer callback spoofing") | 2 years agoOct 1, 2024 |
| View all files |

## Repository files navigation

# RflDllOb - Bambini

[Permalink: RflDllOb - Bambini](https://github.com/oldboy21/RflDllOb#rfldllob---bambini)

Reflective DLL Injection - M++

Reflective DLL and its very personal Injector.
Please refer to [my blog](https://oldboy21.github.io/posts/2023/12/all-i-want-for-christmas-is-reflective-dll-injection/) about this development journey.

# RflDllOb - Next Gen

[Permalink: RflDllOb - Next Gen](https://github.com/oldboy21/RflDllOb#rfldllob---next-gen)

Finally after months of research, the pumped-up version of RflDll-Ob is available. Couple of things to keep in mind:

- It works only with the logic implemented in this [Injector](https://github.com/oldboy21/RflDllOb/tree/main/RflDllOb-NG/ReflectiveDLLInjector-NG).
- Code is not perfect, might definitely contain some errors, if you want use it please review first. Do not do nasty stuff though, educational purposes only!

This version is based on the following:

- [YOLO: You Only Load Once](https://oldboy21.github.io/posts/2024/01/yolo-you-only-load-once/)
- [Reflective DLL Got Indirect Syscall skills](https://oldboy21.github.io/posts/2024/02/reflective-dll-got-indirect-syscall-skills/)
- [SWAPPALA: Why Change When You Can Hide?](https://oldboy21.github.io/posts/2024/05/swappala-why-change-when-you-can-hide/)
- [SLE(A)PING Issues: SWAPPALA and Reflective DLL Friends Forever](https://oldboy21.github.io/posts/2024/06/sleaping-issues-swappala-and-reflective-dll-friends-forever/)
- [Timer Callbacks Spoofing to Improve your SLEAP and SWAPPALA Untold](https://oldboy21.github.io/posts/2024/09/timer-callbacks-spoofing-to-improve-your-sleap-and-swappala-untold/)

## RflDllOb-NG VS In-memory Scanners

[Permalink: RflDllOb-NG VS In-memory Scanners](https://github.com/oldboy21/RflDllOb#rfldllob-ng-vs-in-memory-scanners)

Results at the time of the commit, who knows how it is going to be (!?)

[![HSB](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/hsb.png?raw=true)](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/hsb.png?raw=true)

[![Moneta](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/moneta.png?raw=true)](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/moneta.png?raw=true)

[![pesieve](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/pesieve.png?raw=true)](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/pesieve.png?raw=true)

## Sit down, I will tell you a story

[Permalink: Sit down, I will tell you a story](https://github.com/oldboy21/RflDllOb#sit-down-i-will-tell-you-a-story)

If you do not want to read my blogs and miss all the memes and the GIFs:

This is about an R&D journey that started naturally, just as a pure passion of knowing something more about a topic. Some months ago I picked Reflective Loading as topic to dissect and learn more about. Why Reflective Loading? Well, old but gold. It is some years old but still very widely used among the good and (unfortunately) bad players in this cyber game. Although widely used, I felt like there were not many resources deeply explaining the idea around it, so couple of days before Christmas I wrote a “definitely too long” blog and I have published repository where I explain step by step the Reflective Loading process among the other challenges. Really fun and great feedback. Motivated by that feeling of sharing something nice with the community I have kept working on it, kinda wandering through spot ideas inspired by detections, other talks, open source community or just a beer with a colleague. Without knowing, I was sailing towards a nice R&D adventure. First challenge I have picked was hiding the ReflectiveLoader function. That is the position independent code (PIC) function that loads the DLL in memory, core of this whole concept. Sometimes its logic is detected, even just by static analysis so I decided to implement YOLO (You Only Load Once). The idea relies on the fact you need the Reflective Loader function only once, hence finding the function boundaries parsing PE headers, I was able to encrypt it before the injection, decrypt it in memory when i needed it and discard it once it came the moment of loading. Cool, in Italy we say “The more I eat the bigger my appetite gets,” so the next idea was to implement indirect syscalls for the whole loading process. I have picked the “what I thought to be the most reliable method” to enumerate SSN (FreshyCalls and Syswhysperer3) and dove completely into the challenge of enumerating syscall identifiers using PIC. Not as painful as fun, once I overcame the stack size challenges with some math, the Reflective Loader was loading the DLL bypassing user-land hooks with a mix of PIC C++ and Assembly. The final villain(s) were waiting at the end of the journey: in-memory scanners. Here is where my research intensified, inspired by Sektor7 course and Ekko sleep, I was dreaming of a Reflectively loaded DLL that would hide itself in memory by swapping with a legit DLL at the same address. But what were the challenges? A DLL loaded via LoadLibraryA has its handles (File/Section) closed by the end of the function, and mapping a DLL without using LoadLibraryA would require annoying PEB manipulation and lots of IOC. Furthermore, in-memory sleeping technique using Windows timers like Ekko, does not support Windows APIs that take more than 4 arguments (due to the fact a single thread is used and the ROP chain contexts point to the same stack). Scary times.

For what it concerned the missing Section handle, hardware breakpoint came to the rescue. By hooking and detour-ing the ZwClose function, I was able to keep a connection with the kernel object by forcing ZwClose to return before it reached the point where it would have closed the handle. By reversing the code of System Informer (former Process Hacker) I found a way to get my hands back to that handle too. Phew, the logic of swapping malicious and sacrificial DLL turned out to be possible and that was named SWAPPALA right away.

Honestly excited by the first achievement, I was moving forward to the next challenge of creating a sleep mask that would match the SWAPPALA logics: mapping a section to a specific address requires the usage of MapViewOfFileEx Win API that is not compatible with the actual implementation of Ekko sleep due to the amount of arguments required for its correct operation.

Before having my own successful implementation I had adapted Ekko sleep mask to my needs, coming up with EkkoQua which uses duplicated stack for two of the functions part of the sleeping ROP chain in order to handle Win32 APIs that takes more than 4 arguments (Little pills of Windows calling convention here). Despite limited success with EkkoQua, some tests made me realize that EkkoQua does not work in the context of processes with enabled security protections as stack cookie, control flow guard (despite whitelisting NtContinue as valid targets) etc. After realizing that NtContinue also ignores the debug registers (hence officially destroying another idea I had) I have decided to drop the goal of adapting existing sleep mask and come up with my own: SLE(A)PING.

SLEAPING makes use of timer thread workers in order to resume threads I had previously created in a suspended state and with a crafted context. This time the threads working during the “Sleep” time have their own stack so they do not step on each other, moreover as bonus point the ResumeThread function (as substitute for NtContinue) used by the timer thread does not need to be added as a valid target in the Control Flow Guard table, meaning one less IOC.

Last update (September 2024) also includes the logic for spoofing the callback address of the OS timers used to implement SLEAPING technique. This makes RflDllOb-NG more resilient against in-memory scanners by modifying the timer callback addresses at sleeping time.

To conclude: SWAPPALA and SLEAPING are used to load the reflective DLL in a private mapping backed by physical memory and swap-it with a memory mapping backed by a legit DLL on disk, at its very own legit address. All of this orchestrated at sleeping time by worker threads created in a suspended state and resumed via OS timers.

## Little Demo

[Permalink: Little Demo](https://github.com/oldboy21/RflDllOb#little-demo)

This demo helps to understand how the Reflective DLL Ob hides itself behind a legit dll at sleeping time.

[![Reflective DLL Next Gen](https://raw.githubusercontent.com/oldboy21/RflDllOb/main/imgs/rfldllobng.png)](https://vimeo.com/955537475?share=copy)

Fun fact: at a certain point in the video, exactly when the Reflective DLL mapping pops up, the song "Suddenly I see" of KT Tunstall starts playing. Nothing of that was planned in advance.

## Credits

[Permalink: Credits](https://github.com/oldboy21/RflDllOb#credits)

Aia, almost forgot:

- [MalDev Academy](https://maldevacademy.com/)
- [Hunt Sleeping Beacons Author](https://github.com/thefLink/Hunt-Sleeping-Beacons)
- Thanks to whoever post code and resources online, Mal Dev Academy, Sektor7, open source community and all the people that helps brainstorming, you are golden

## About

Reflective DLL Injection Made Bella


### Topics

[c](https://github.com/topics/c "Topic: c") [programming](https://github.com/topics/programming "Topic: programming") [reflectivedll](https://github.com/topics/reflectivedll "Topic: reflectivedll") [maldev](https://github.com/topics/maldev "Topic: maldev") [swappala](https://github.com/topics/swappala "Topic: swappala") [sleaping](https://github.com/topics/sleaping "Topic: sleaping")

### Resources

[Readme](https://github.com/oldboy21/RflDllOb#readme-ov-file)

### License

[GPL-2.0 license](https://github.com/oldboy21/RflDllOb#GPL-2.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/oldboy21/RflDllOb).

[Activity](https://github.com/oldboy21/RflDllOb/activity)

### Stars

[**249**\\
stars](https://github.com/oldboy21/RflDllOb/stargazers)

### Watchers

[**8**\\
watching](https://github.com/oldboy21/RflDllOb/watchers)

### Forks

[**50**\\
forks](https://github.com/oldboy21/RflDllOb/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Foldboy21%2FRflDllOb&report=oldboy21+%28user%29)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/oldboy21/RflDllOb).

## Languages

- [C60.1%](https://github.com/oldboy21/RflDllOb/search?l=c)
- [C++38.9%](https://github.com/oldboy21/RflDllOb/search?l=c%2B%2B)
- [Assembly1.0%](https://github.com/oldboy21/RflDllOb/search?l=assembly)

You can’t perform that action at this time.