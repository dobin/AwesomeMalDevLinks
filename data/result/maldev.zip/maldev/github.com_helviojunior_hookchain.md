# https://github.com/helviojunior/hookchain/

[Skip to content](https://github.com/helviojunior/hookchain/#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/helviojunior/hookchain/) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/helviojunior/hookchain/) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/helviojunior/hookchain/) to refresh your session.Dismiss alert

{{ message }}

[helviojunior](https://github.com/helviojunior)/ **[hookchain](https://github.com/helviojunior/hookchain)** Public

- [Notifications](https://github.com/login?return_to=%2Fhelviojunior%2Fhookchain) You must be signed in to change notification settings
- [Fork\\
97](https://github.com/login?return_to=%2Fhelviojunior%2Fhookchain)
- [Star\\
590](https://github.com/login?return_to=%2Fhelviojunior%2Fhookchain)


HookChain: A new perspective for Bypassing EDR Solutions


[590\\
stars](https://github.com/helviojunior/hookchain/stargazers) [97\\
forks](https://github.com/helviojunior/hookchain/forks) [Branches](https://github.com/helviojunior/hookchain/branches) [Tags](https://github.com/helviojunior/hookchain/tags) [Activity](https://github.com/helviojunior/hookchain/activity)

[Star](https://github.com/login?return_to=%2Fhelviojunior%2Fhookchain)

[Notifications](https://github.com/login?return_to=%2Fhelviojunior%2Fhookchain) You must be signed in to change notification settings

# helviojunior/hookchain

main

[**2** Branches](https://github.com/helviojunior/hookchain/branches) [**0** Tags](https://github.com/helviojunior/hookchain/tags)

[Go to Branches page](https://github.com/helviojunior/hookchain/branches)[Go to Tags page](https://github.com/helviojunior/hookchain/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![helviojunior](https://avatars.githubusercontent.com/u/34519097?v=4&size=40)](https://github.com/helviojunior)[helviojunior](https://github.com/helviojunior/hookchain/commits?author=helviojunior)<br>[Update README.md](https://github.com/helviojunior/hookchain/commit/44df0719b12e92e18927a32c40b11fc8c222f32e)<br>2 years agoJan 5, 2025<br>[44df071](https://github.com/helviojunior/hookchain/commit/44df0719b12e92e18927a32c40b11fc8c222f32e) · 2 years agoJan 5, 2025<br>## History<br>[22 Commits](https://github.com/helviojunior/hookchain/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/helviojunior/hookchain/commits/main/) 22 Commits |
| [HookChain](https://github.com/helviojunior/hookchain/tree/main/HookChain "HookChain") | [HookChain](https://github.com/helviojunior/hookchain/tree/main/HookChain "HookChain") | [BugFix](https://github.com/helviojunior/hookchain/commit/264f676aa548dc36660101f075ceb3cde72e77c4 "BugFix") | 2 years agoAug 27, 2024 |
| [enum](https://github.com/helviojunior/hookchain/tree/main/enum "enum") | [enum](https://github.com/helviojunior/hookchain/tree/main/enum "enum") | [Public release](https://github.com/helviojunior/hookchain/commit/53ba5471aecc9eac697b91d2d9deed8e3e2db6f3 "Public release") | 2 years agoAug 10, 2024 |
| [.gitattributes](https://github.com/helviojunior/hookchain/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/helviojunior/hookchain/blob/main/.gitattributes ".gitattributes") | [Public release](https://github.com/helviojunior/hookchain/commit/53ba5471aecc9eac697b91d2d9deed8e3e2db6f3 "Public release") | 2 years agoAug 10, 2024 |
| [.gitignore](https://github.com/helviojunior/hookchain/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/helviojunior/hookchain/blob/main/.gitignore ".gitignore") | [Public release](https://github.com/helviojunior/hookchain/commit/53ba5471aecc9eac697b91d2d9deed8e3e2db6f3 "Public release") | 2 years agoAug 10, 2024 |
| [HookChain\_en\_v1.5.pdf](https://github.com/helviojunior/hookchain/blob/main/HookChain_en_v1.5.pdf "HookChain_en_v1.5.pdf") | [HookChain\_en\_v1.5.pdf](https://github.com/helviojunior/hookchain/blob/main/HookChain_en_v1.5.pdf "HookChain_en_v1.5.pdf") | [Add English version](https://github.com/helviojunior/hookchain/commit/9588432d55264a80eea0cda5c0d4fe1786cacaca "Add English version") | 2 years agoAug 16, 2024 |
| [HookChain\_pt\_v1.5.pdf](https://github.com/helviojunior/hookchain/blob/main/HookChain_pt_v1.5.pdf "HookChain_pt_v1.5.pdf") | [HookChain\_pt\_v1.5.pdf](https://github.com/helviojunior/hookchain/blob/main/HookChain_pt_v1.5.pdf "HookChain_pt_v1.5.pdf") | [Update PT version](https://github.com/helviojunior/hookchain/commit/aba3d0d3796c749a5bf4f51ac1ad603805a9aca8 "Update PT version") | 2 years agoAug 16, 2024 |
| [README.md](https://github.com/helviojunior/hookchain/blob/main/README.md "README.md") | [README.md](https://github.com/helviojunior/hookchain/blob/main/README.md "README.md") | [Update README.md](https://github.com/helviojunior/hookchain/commit/44df0719b12e92e18927a32c40b11fc8c222f32e "Update README.md") | 2 years agoJan 5, 2025 |
| View all files |

## Repository files navigation

# Hookchain

[Permalink: Hookchain](https://github.com/helviojunior/hookchain/#hookchain)

## Abstract - EN

[Permalink: Abstract - EN](https://github.com/helviojunior/hookchain/#abstract---en)

In the current digital security ecosystem, where threats evolve rapidly and with complexity, companies developing Endpoint Detection and Response (EDR) solutions are in constant search for innovations that not only keep up but also anticipate emerging attack vectors.

In this context, this article introduces the HookChain, a look from another perspective at widely known techniques, which when combined, provide an additional layer of sophisticated evasion against traditional EDR systems.

Through a precise combination of IAT Hooking techniques, dynamic SSN resolution, and indirect system calls, HookChain redirects the execution flow of Windows subsystems in a way that remains invisible to the vigilant eyes of EDRs that only act on Ntdll.dll, without requiring changes to the source code of the applications and malwares involved.

This work not only challenges current conventions in cybersecurity but also sheds light on a promising path for future protection strategies, leveraging the understanding that continuous evolution is key to the effectiveness of digital security.

By developing and exploring the HookChain technique, this study significantly contributes to the body of knowledge in endpoint security, stimulating the development of more robust and adaptive solutions that can effectively address the ever-changing dynamics of digital threats. This work aspires to inspire deep reflection and advancement in the research and development of security technologies that are always several steps ahead of adversaries.

## Abstract - PT-BR

[Permalink: Abstract - PT-BR](https://github.com/helviojunior/hookchain/#abstract---pt-br)

No atual ecossistema de segurança digital, onde ameaças evoluem com rapidez e complexidade, as empresas desenvolvedoras de soluções de detecção e resposta em endpoints (EDR) estão em constante busca por inovações que não apenas acompanhem, mas antecipem os vetores de ataque emergentes. Nesse contexto, este artigo introduz o HookChain, um olhar sob outro ponto de vista de técnicas amplamente conhecidas, porém quando combinadas proporciona uma camada adicional de evasão sofisticada frente aos tradicionais sistemas EDR.

Através de uma combinação precisa de técnicas de IAT Hooking, resolução dinâmica de SSNs e chamadas de sistema indiretas, o HookChain redireciona o fluxo de execução dos subsistemas do Windows de maneira que permanece invisível aos olhares vigilantes dos EDRs que atuam somente na Ntdll.dll, sem necessitar de alterações no código-fonte das aplicações e malwares envolvidos.

Este trabalho não apenas desafia as convenções atuais em segurança cibernética, mas também ilumina um caminho promissor para futuras estratégias de proteção, alavancando a compreensão de que a evolução contínua é fundamental para a eficácia da segurança digital.

Ao desenvolver e explorar a técnica HookChain, este estudo contribui significativamente para o corpo de conhecimento em segurança de endpoints, estimulando o desenvolvimento de soluções mais robustas e adaptativas que possam efetivamente enfrentar a dinâmica sempre em transformação das ameaças digitais. Este trabalho aspira a inspirar uma reflexão profunda e o avanço na pesquisa e desenvolvimento de tecnologias de segurança que estejam sempre vários passos à frente dos adversários.

## ACM Reference Format

[Permalink: ACM Reference Format](https://github.com/helviojunior/hookchain/#acm-reference-format)

```
Helvio Carvalho Junior. 2024. HookChain: A new perspective for Bypassing EDR Solutions. Curitiba, PR, BRAZIL. https://arxiv.org/abs/2404.16856
```

## HookChain Talks

[Permalink: HookChain Talks](https://github.com/helviojunior/hookchain/#hookchain-talks)

- [Sector/BlackHat Toronto](https://youtu.be/Rxw0DFkMeQ8)
- [DEFCON 32](https://youtu.be/AfDXAdLJ7dU?si=Q5BTLWIfeSRUwaK3)
- [MindTheSec 2024](https://www.youtube.com/watch?v=EM5xejYhl1s)

## White paper

[Permalink: White paper](https://github.com/helviojunior/hookchain/#white-paper)

- [English v1.5](https://github.com/helviojunior/hookchain/blob/main/HookChain_en_v1.5.pdf)
- [English arXiv:2404.16856](https://arxiv.org/abs/2404.16856)
- [Portugues v1.5](https://github.com/helviojunior/hookchain/blob/main/HookChain_pt_v1.5.pdf)

## Contact

[Permalink: Contact](https://github.com/helviojunior/hookchain/#contact)

- LinkedIn contact: [https://www.linkedin.com/in/helviojunior/](https://www.linkedin.com/in/helviojunior/)
- Telegram contact: [https://t.me/helviojunior](https://t.me/helviojunior)

## My public releases regarding HookChain:

[Permalink: My public releases regarding HookChain:](https://github.com/helviojunior/hookchain/#my-public-releases-regarding-hookchain)

- [Cylance bypass](https://www.linkedin.com/posts/helviojunior_hookchain-edrbypass-lsassdump-activity-7212439618598686720-mfNm?utm_source=share&utm_medium=member_desktop)
- [SentinelOne bypass](https://www.linkedin.com/posts/helviojunior_hookchain-edrbypass-lsassdump-activity-7208853059592982530-0Ufa?utm_source=share&utm_medium=member_desktop)
- [CrowdStrike bypass](https://www.linkedin.com/posts/helviojunior_hookchain-havoc-edr-activity-7181441094356783104-nyk_?utm_source=share&utm_medium=member_desktop)
- [CrowdStrike bypass - again](https://www.linkedin.com/posts/helviojunior_hookchain-edrbypass-lsassdump-activity-7188911783510724609-iaoV?utm_source=share&utm_medium=member_desktop)
- [Trend Apex One bypass](https://www.linkedin.com/posts/helviojunior_hookchain-havoc-edr-activity-7183817134488051713-J3d-?utm_source=share&utm_medium=member_desktop)
- [BitDefender bypass](https://www.linkedin.com/posts/helviojunior_bypass-bypassedr-hookchain-activity-7179578975701123072-tISP?utm_source=share&utm_medium=member_desktop)
- [Call for EDR/XDR product with zero answers](https://www.linkedin.com/posts/helviojunior_hookchain-edrbypass-xdrbypass-activity-7188225698434596865-3Jxy?utm_source=share&utm_medium=member_desktop)

## About

HookChain: A new perspective for Bypassing EDR Solutions


### Topics

[bypass-edr](https://github.com/topics/bypass-edr "Topic: bypass-edr") [hookchain](https://github.com/topics/hookchain "Topic: hookchain") [evading-edr](https://github.com/topics/evading-edr "Topic: evading-edr") [m4v3r1ck](https://github.com/topics/m4v3r1ck "Topic: m4v3r1ck")

### Resources

[Readme](https://github.com/helviojunior/hookchain/#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/helviojunior/hookchain/).

[Activity](https://github.com/helviojunior/hookchain/activity)

### Stars

[**590**\\
stars](https://github.com/helviojunior/hookchain/stargazers)

### Watchers

[**11**\\
watching](https://github.com/helviojunior/hookchain/watchers)

### Forks

[**97**\\
forks](https://github.com/helviojunior/hookchain/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fhelviojunior%2Fhookchain&report=helviojunior+%28user%29)

## [Releases](https://github.com/helviojunior/hookchain/releases)

No releases published

## [Packages\  0](https://github.com/users/helviojunior/packages?repo_name=hookchain)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/helviojunior/hookchain/).

## Languages

- [C51.6%](https://github.com/helviojunior/hookchain/search?l=c)
- [Assembly48.4%](https://github.com/helviojunior/hookchain/search?l=assembly)

You can’t perform that action at this time.