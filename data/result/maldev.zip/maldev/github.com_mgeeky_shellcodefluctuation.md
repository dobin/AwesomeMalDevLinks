# https://github.com/mgeeky/ShellcodeFluctuation

[Skip to content](https://github.com/mgeeky/ShellcodeFluctuation#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/mgeeky/ShellcodeFluctuation) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/mgeeky/ShellcodeFluctuation) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/mgeeky/ShellcodeFluctuation) to refresh your session.Dismiss alert

{{ message }}

[mgeeky](https://github.com/mgeeky)/ **[ShellcodeFluctuation](https://github.com/mgeeky/ShellcodeFluctuation)** Public

- [Sponsor](https://github.com/sponsors/mgeeky)
- [Notifications](https://github.com/login?return_to=%2Fmgeeky%2FShellcodeFluctuation) You must be signed in to change notification settings
- [Fork\\
165](https://github.com/login?return_to=%2Fmgeeky%2FShellcodeFluctuation)
- [Star\\
1.1k](https://github.com/login?return_to=%2Fmgeeky%2FShellcodeFluctuation)


An advanced in-memory evasion technique fluctuating shellcode's memory protection between RW/NoAccess & RX and then encrypting/decrypting its contents


### License

[MIT license](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/LICENSE.txt)

[1.1k\\
stars](https://github.com/mgeeky/ShellcodeFluctuation/stargazers) [165\\
forks](https://github.com/mgeeky/ShellcodeFluctuation/forks) [Branches](https://github.com/mgeeky/ShellcodeFluctuation/branches) [Tags](https://github.com/mgeeky/ShellcodeFluctuation/tags) [Activity](https://github.com/mgeeky/ShellcodeFluctuation/activity)

[Star](https://github.com/login?return_to=%2Fmgeeky%2FShellcodeFluctuation)

[Notifications](https://github.com/login?return_to=%2Fmgeeky%2FShellcodeFluctuation) You must be signed in to change notification settings

# mgeeky/ShellcodeFluctuation

master

[**2** Branches](https://github.com/mgeeky/ShellcodeFluctuation/branches) [**1** Tag](https://github.com/mgeeky/ShellcodeFluctuation/tags)

[Go to Branches page](https://github.com/mgeeky/ShellcodeFluctuation/branches)[Go to Tags page](https://github.com/mgeeky/ShellcodeFluctuation/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![mgeeky](https://avatars.githubusercontent.com/u/654344?v=4&size=40)](https://github.com/mgeeky)[mgeeky](https://github.com/mgeeky/ShellcodeFluctuation/commits?author=mgeeky)<br>[Merge pull request](https://github.com/mgeeky/ShellcodeFluctuation/commit/424c6d09608821b761f90d0eb4aaa794f79b480a) [#4](https://github.com/mgeeky/ShellcodeFluctuation/pull/4) [from mgeeky/add-code-of-conduct-1](https://github.com/mgeeky/ShellcodeFluctuation/commit/424c6d09608821b761f90d0eb4aaa794f79b480a)<br>Open commit details<br>4 years agoJun 17, 2022<br>[424c6d0](https://github.com/mgeeky/ShellcodeFluctuation/commit/424c6d09608821b761f90d0eb4aaa794f79b480a) · 4 years agoJun 17, 2022<br>## History<br>[37 Commits](https://github.com/mgeeky/ShellcodeFluctuation/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/mgeeky/ShellcodeFluctuation/commits/master/) 37 Commits |
| [ShellcodeFluctuation](https://github.com/mgeeky/ShellcodeFluctuation/tree/master/ShellcodeFluctuation "ShellcodeFluctuation") | [ShellcodeFluctuation](https://github.com/mgeeky/ShellcodeFluctuation/tree/master/ShellcodeFluctuation "ShellcodeFluctuation") | [Generalised memory protection revert to reuse protection originally m…](https://github.com/mgeeky/ShellcodeFluctuation/commit/21a7194ca70b5a2133457047350595ee0856a284 "Generalised memory protection revert to reuse protection originally met after locating shellcode for the first time.") | 5 years agoOct 7, 2021 |
| [images](https://github.com/mgeeky/ShellcodeFluctuation/tree/master/images "images") | [images](https://github.com/mgeeky/ShellcodeFluctuation/tree/master/images "images") | [readme](https://github.com/mgeeky/ShellcodeFluctuation/commit/6a32579edf252a1a74312e88ed2363571391519d "readme") | 5 years agoSep 30, 2021 |
| [CODE\_OF\_CONDUCT.md](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/CODE_OF_CONDUCT.md "CODE_OF_CONDUCT.md") | [CODE\_OF\_CONDUCT.md](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/CODE_OF_CONDUCT.md "CODE_OF_CONDUCT.md") | [Create CODE\_OF\_CONDUCT.md](https://github.com/mgeeky/ShellcodeFluctuation/commit/5564afc53749ec985b698a76dd3574ddbc800c0a "Create CODE_OF_CONDUCT.md") | 4 years agoJun 17, 2022 |
| [LICENSE.txt](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/LICENSE.txt "LICENSE.txt") | [LICENSE.txt](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/LICENSE.txt "LICENSE.txt") | [Added MIT License.](https://github.com/mgeeky/ShellcodeFluctuation/commit/aeebb66c33a4283f77a1b6f0fc55712831a6a9dd "Added MIT License.") | 5 years agoOct 19, 2021 |
| [README.md](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/README.md "README.md") | [README.md](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/README.md "README.md") | [update](https://github.com/mgeeky/ShellcodeFluctuation/commit/43400b8003e3b0841382d8701a982bcaef7b521d "update") | 5 years agoOct 2, 2021 |
| [ShellcodeFluctuation.sln](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/ShellcodeFluctuation.sln "ShellcodeFluctuation.sln") | [ShellcodeFluctuation.sln](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/ShellcodeFluctuation.sln "ShellcodeFluctuation.sln") | [first](https://github.com/mgeeky/ShellcodeFluctuation/commit/f59df4c1eafbdf2443faec4c2ad46e943c4f4484 "first") | 5 years agoSep 29, 2021 |
| View all files |

## Repository files navigation

# Shellcode Fluctuation PoC

[Permalink: Shellcode Fluctuation PoC](https://github.com/mgeeky/ShellcodeFluctuation#shellcode-fluctuation-poc)

A PoC implementation for an another in-memory evasion technique that cyclically encrypts and decrypts shellcode's contents to then make it fluctuate between `RW` (or `NoAccess`) and `RX` memory protection.
When our shellcode resides in `RW` or `NoAccess` memory pages, scanners such as [`Moneta`](https://github.com/forrest-orr/moneta) or [`pe-sieve`](https://github.com/hasherezade/pe-sieve) will be unable to track it down and dump it for further analysis.

## Intro

[Permalink: Intro](https://github.com/mgeeky/ShellcodeFluctuation#intro)

After releasing [ThreadStackSpoofer](https://github.com/mgeeky/ThreadStackSpoofer) I've received a few questions about the following README's point:

> Change your Beacon's memory pages protection to RW (from RX/RWX) and encrypt their contents before sleeping (that could evade scanners such as Moneta or pe-sieve)

Beforewards I was pretty sure the community already know how to encrypt/decrypt their payloads and flip their memory protections to simply evade memory scanners looking for anomalous executable regions.
Questions proven otherwise so I decided to release this unweaponized PoC to document yet another evasion strategy and offer sample implementation for the community to work with.

This PoC is a demonstration of rather simple technique, already known to the offensive community (so I'm not bringin anything new here really) in hope to disclose secrecy behind magic showed by some commercial frameworks that demonstrate their evasion capabilities targeting both aforementioned memory scanners.

**Here's a comparison when fluctuating to RW** (another option is to fluctuate to `PAGE_NOACCESS` \- described below):

1. Beacon not encrypted
2. **Beacon encrypted** ( _fluctuating_)

[![comparison](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/comparison.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/comparison.png)

This implementation along with my [ThreadStackSpoofer](https://github.com/mgeeky/ThreadStackSpoofer) brings Offensive Security community sample implementations to catch up on the offering made by commercial C2 products, so that we can do no worse in our Red Team toolings. 💪

* * *

## How it works?

[Permalink: How it works?](https://github.com/mgeeky/ShellcodeFluctuation#how-it-works)

This program performs self-injection shellcode (roughly via classic `VirtualAlloc` \+ `memcpy` \+ `CreateThread`).
When shellcode runs (this implementation specifically targets Cobalt Strike Beacon implants) a Windows function will be hooked intercepting moment when Beacon falls asleep `kernel32!Sleep`.
Whenever hooked `MySleep` function gets invoked, it will localise its memory allocation boundaries, flip their protection to `RW` and `xor32` all the bytes stored there.
Having awaited for expected amount of time, when shellcode gets back to our `MySleep` handler, we'll decrypt shellcode's data and flip protection back to `RX`.

### Fluctuation to `PAGE_READWRITE` works as follows

[Permalink: Fluctuation to PAGE_READWRITE works as follows](https://github.com/mgeeky/ShellcodeFluctuation#fluctuation-to-page_readwrite-works-as-follows)

1. Read shellcode's contents from file.
2. Hook `kernel32!Sleep` pointing back to our callback.
3. Inject and launch shellcode via `VirtualAlloc` \+ `memcpy` \+ `CreateThread`. In contrary to what we had in `ThreadStackSpoofer`, here we're not hooking anything in ntdll to launch our shellcode but rather jump to it from our own function. This attempts to avoid leaving simple IOCs in memory pointing at modified ntdll memory.
4. As soon as Beacon attempts to sleep, our `MySleep` callback gets invoked.
5. Beacon's memory allocation gets encrypted and protection flipped to `RW`
6. We then unhook original `kernel32!Sleep` to avoid leaving simple IOC in memory pointing that `Sleep` have been trampolined (in-line hooked).
7. A call to original `::Sleep` is made to let the Beacon's sleep while waiting for further communication.
8. After Sleep is finished, we decrypt our shellcode's data, flip it memory protections back to `RX` and then re-hook `kernel32!Sleep` to ensure interception of subsequent sleep.

### Fluctuation to `PAGE_NOACCESS` works as follows

[Permalink: Fluctuation to PAGE_NOACCESS works as follows](https://github.com/mgeeky/ShellcodeFluctuation#fluctuation-to-page_noaccess-works-as-follows)

01. Read shellcode's contents from file.
02. Hook `kernel32!Sleep` pointing back to our callback.
03. Inject and launch shellcode via `VirtualAlloc` \+ `memcpy` \+ `CreateThread` ...
04. Initialize Vectored Exception Handler (VEH) to setup our own handler that will catch _Access Violation_ exceptions.
05. As soon as Beacon attempts to sleep, our `MySleep` callback gets invoked.
06. Beacon's memory allocation gets encrypted and protection flipped to `PAGE_NOACCESS`
07. We then unhook original `kernel32!Sleep` to avoid leaving simple IOC in memory pointing that `Sleep` have been trampolined (in-line hooked).
08. A call to original `::Sleep` is made to let the Beacon's sleep while waiting for further communication.
09. After Sleep is finished, we re-hook `kernel32!Sleep` to ensure interception of subsequent sleep.
10. Shellcode then attempts to resume its execution which results in Access Violation being throwed since its pages are marked NoAccess.
11. Our VEH Handler catches the exception, decrypts and flips memory protections back to `RX` and shellcode's is resumed.

* * *

### It's not a novel technique

[Permalink: It's not a novel technique](https://github.com/mgeeky/ShellcodeFluctuation#its-not-a-novel-technique)

The technique is not brand new, nothing that I've devised myself. Merely an implementation showing the concept and its practical utilisation to let our Offensive Security community catch up on offering made by commercial C2 frameworks.

Actually, I've been introduced to the idea of flipping shellcode's memory protection couple of years back through the work of [**Josh Lospinoso**](https://github.com/JLospinoso) in his amazing [Gargoyle](https://github.com/JLospinoso/gargoyle).

Here's more background:

- [gargoyle, a memory scanning evasion technique](https://lospi.net/security/assembly/c/cpp/developing/software/2017/03/04/gargoyle-memory-analysis-evasion.html)
- [Bypassing Memory Scanners with Cobalt Strike and Gargoyle](https://labs.f-secure.com/blog/experimenting-bypassing-memory-scanners-with-cobalt-strike-and-gargoyle/)

**Gargoyle** takes the concept of self-aware and self-fluctuating shellcode a way further, by leveraging ROP sequence calling out to `VirtualProtect`.
However the technique is impressive, its equally hard to leverage it with Cobalt Strike's Beacon without having to kill its thread and keep re-initializing Beacon while in memory.

That's far from perfect, however since we already operate from the grounds of our own self-injection loader process, we're able to do whatever we want with the environment in which shellcode operate and hide it however we like. This technique (and the previous one being [ThreadStackSpoofer](https://github.com/mgeeky/ThreadStackSpoofer)) shows advantages from running our shellcodes this way.

The implementation of fluctuating to `PAGE_NOACCESS` is inspired by [ORCA666](https://github.com/ORCA666)'s work presented in his [https://github.com/ORCA666/0x41](https://github.com/ORCA666/0x41) injector.
He showed that:

1. we can initialize a vectored exception handler (VEH),
2. flip shellcode's pages to no-access
3. and then catch Access Violation exceptions that will occur as soon as the shellcode wants to resume its execution and decrypt + flip its memory pages back to Read+Execute.

This implementation contains this idea implemented, available with option `2` in `<fluctuate>`.
Be sure to check out other his projects as well.

* * *

## Demo

[Permalink: Demo](https://github.com/mgeeky/ShellcodeFluctuation#demo)

The tool `ShellcodeFluctuation` accepts three parameters: first one being path to the shellcode and the second one modifier of our functionality.

```
Usage: ShellcodeFluctuation.exe <shellcode> <fluctuate>
<fluctuate>:
        -1 - Read shellcode but dont inject it. Run in an infinite loop.
        0 - Inject the shellcode but don't hook kernel32!Sleep and don't encrypt anything
        1 - Inject shellcode and start fluctuating its memory with standard PAGE_READWRITE.
        2 - Inject shellcode and start fluctuating its memory with ORCA666's PAGE_NOACCESS.
```

### Moneta (seemingly) False Positive

[Permalink: Moneta (seemingly) False Positive](https://github.com/mgeeky/ShellcodeFluctuation#moneta-seemingly-false-positive)

```
C:\> ShellcodeFluctuation.exe beacon64.bin -1
```

So firstly we'll see what `Moneta64` scanner thinks about process that does nothing dodgy and simply resorts to run an infinite loop:

[![moneta false positive](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/false-positive.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/false-positive.png)

As we can see there's some **false positive** (at least how I consider it) allegdly detecting `Mismatching PEB module` / `Phantom image`.
The memory boundaries point at the `ShellcodeFluctuate.exe` module itself and could indicate that this module however being of `MEM_IMAGE` type, is not linked in process' PEB - which is unsual and sounds rather odd.
The reason for this IOC is not known to me and I didn't attempt to understand it better, yet it isn't something we should be concerned about really.

If anyone knows what's the reason for this detection, I'd be very curious to hear! Please do reach out.

### Not Encrypted Beacon

[Permalink: Not Encrypted Beacon](https://github.com/mgeeky/ShellcodeFluctuation#not-encrypted-beacon)

```
C:\> ShellcodeFluctuation.exe beacon64.bin 0
```

The second use case presents Memory IOCs of a Beacon operating within our process, which does not utilise any sorts of customised `Artifact Kits`, `User-Defined Reflective Loaders` (such as my [`ElusiveMice`](https://github.com/mgeeky/ElusiveMice)), neither any initial actions that would spoil our results.

[![moneta not encrypted](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/not-encrypted.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/not-encrypted.png)

We can see that `Moneta64` correctly recognizes `Abnormal private executable memory` pointing at the location where our shellcode resides.
That's really strong Memory IOC exposing our shellcode for getting dumped and analysed by automated scanners. Not cool.

### Encrypted Beacon with RW protections

[Permalink: Encrypted Beacon with RW protections](https://github.com/mgeeky/ShellcodeFluctuation#encrypted-beacon-with-rw-protections)

```
C:\> ShellcodeFluctuation.exe beacon64.bin 1
```

Now the third, most interesting from perspective of this implementation, use case being _fluctuating_ Beacon.

[![moneta encrypted](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/encrypted.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/encrypted.png)

Apart from the first IOC, considered somewhat _false positive_, we see a new one pointing that `kernel32.dll` memory was modified.
However, no `Abnormal private executable memory` IOC this time. Our fluctuation (repeated encryption/decryption and memory protections flipping is active).

And for the record, `pe-sieve` also detects implanted PE when used with `/data 3` option (unless this option is given, no detection will be made):

[![pe-sieve](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/pe-sieve3.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/pe-sieve3.png)

My current assumption is that PE-Sieve is picking up on the same traits that Moneta does (described below in _Modified code in kernel32.dll_) \- the fact that PE mapped module has a non-empty Working set, being an evident fact of code injection of some sort.
That is labeled as _Implanted PE_ / _Implanted_. If that's the case, conclusion is similar to the Moneta's observation. I don't think we should care that much about that IOC detection-wise.

Currently I thought of no better option to intercept shellcode's execution in the middle (now speaking of Cobalt Strike), other than to hook `kernel32!Sleep`. Thus, we are bound to leave these sorts of IOCs.

But hey, still none of the bytes differ compared to what is lying out there on the filesystem (`C:\Windows\System32\kernel32.dll`) and no function is hooked, what's the deal? 😉

### Encrypted Beacon with PAGE\_NOACCESS protections

[Permalink: Encrypted Beacon with PAGE_NOACCESS protections](https://github.com/mgeeky/ShellcodeFluctuation#encrypted-beacon-with-page_noaccess-protections)

```
C:\> ShellcodeFluctuation.exe beacon64.bin 2
```

[![no-access](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/no-access1.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/no-access1.png)

That will cause the shellcode to fluctuate between `RX` and `NA` pages effectively.

At the moment I'm not sure of benefits of flipping into `PAGE_NOACCESS` instead of `PAGE_READWRITE`.

### Modified code in kernel32.dll

[Permalink: Modified code in kernel32.dll](https://github.com/mgeeky/ShellcodeFluctuation#modified-code-in-kernel32dll)

So what about that modified `kernel32` IOC?

Now, let us attempt to get to the bottom of this IOC and see what's the deal here.

Firstly, we'll dump mentioned memory region - being `.text` (code) section of `kernel32.dll`. Let us use `ProcessHacker` for that purpose to utilise publicly known and stable tooling:

[![dump-kernel](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/dump-kernel.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/dump-kernel.png)

We dump code section of allegedly modified kernel32 and then we do the same for the kernel32 running in process that did not modify that area.

Having acquired two dumps, we can then compare them byte-wise (using my [expdevBadChars](https://github.com/mgeeky/expdevBadChars)) to look for any inconsitencies:

[![bindiff](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/bindiff0.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/bindiff0.png)

Just to see that they match one another. Clearly there isn't a single byte modified in `kernel32.dll` and the reason for that is because we're unhooking `kernel32!Sleep` before calling it out:

`main.cpp:31:`

```
    HookTrampolineBuffers buffers = { 0 };
    buffers.originalBytes = g_hookedSleep.sleepStub;
    buffers.originalBytesSize = sizeof(g_hookedSleep.sleepStub);

    //
    // Unhook kernel32!Sleep to evade hooked Sleep IOC.
    // We leverage the fact that the return address left on the stack will make the thread
    // get back to our handler anyway.
    //
    fastTrampoline(false, (BYTE*)::Sleep, &MySleep, &buffers);

    // Perform sleep emulating originally hooked functionality.
    ::Sleep(dwMilliseconds);
```

So what's causing the IOC being triggered? Let us inspect `Moneta` more closely:

[![moneta](https://github.com/mgeeky/ShellcodeFluctuation/raw/master/images/moneta.png)](https://github.com/mgeeky/ShellcodeFluctuation/blob/master/images/moneta.png)

Breaking into Moneta's `Ioc.cpp` just around the 104 line where it reports `MODIFIED_CODE` IOC, we can modify the code a little to better expose the exact moment when it analyses kernel32 pool.
Now:

1. The check is made to ensure that kernel32's region is executable. We see that in fact that region is executable `a = true`
2. Amount of that module's private memory is acquired. Here we see that `kernel32` has `b = 0x1000` private bytes. How come? There should be `0` of them.
3. If executable allocation is having more than 0 bytes of private memory (`a && b`) the IOC is reported
4. And that's a proof we were examining kernel32 at that time.

When Windows Image Loader maps a DLL module into process' memory space, the underlying memory pages will be labeled as `MEM_MAPPED` or `MEM_IMAGE` depending on scenario.
Whenever we modify even a single byte of the `MEM_MAPPED`/`MEM_IMAGE` allocation, the system will separate a single memory page (assuming we modified less then `PAGE_SIZE` bytes and did not cross page boundary) to indicate fragment that does not maps back to the original image.

This observation is then utilised as an IOC - an image should not have `MEM_PRIVATE` allocations within its memory region (inside of it) because that would indicate that some bytes where once modified within that region. Moneta is correctly picking up on code modification if though bytes were matching original module's bytes at the time of comparison.

For a comprehensive explanation of how Moneta, process injection implementation and related IOC works under the hood, read following top quality articles by **Forrest Orr**:

1. [Masking Malicious Memory Artifacts – Part I: Phantom DLL Hollowing](https://www.forrest-orr.net/post/malicious-memory-artifacts-part-i-dll-hollowing)
2. [Masking Malicious Memory Artifacts – Part II: Blending in with False Positives](https://www.forrest-orr.net/post/masking-malicious-memory-artifacts-part-ii-insights-from-moneta)
3. [Masking Malicious Memory Artifacts – Part III: Bypassing Defensive Scanners](https://www.cyberark.com/resources/threat-research-blog/masking-malicious-memory-artifacts-part-iii-bypassing-defensive-scanners)

That's a truly outstanding research and documentation done by Forrest, great work pal!

Especially the second article outlines the justification for this detection, as we read what Forrest teaches us:

> In the event that the module had been legitimately loaded and added to the PEB, the shellcode implant would still have been detected due to the 0x1000 bytes (1 page) of memory privately mapped into the address space and retrieved by Moneta by querying its working set - resulting in a modified code IOC as seen above.

To summarise, we're leaving an IOC behind but should we be worried about that?
Even if there's an IOC there are no stolen bytes visible, so no immediate reference pointing back to our shellcode or distinguishing our shellcode's technique from others.

Long story short - we shouldn't be really worried about that IOC. :-)

### But commercial frameworks leave no IOCs

[Permalink: But commercial frameworks leave no IOCs](https://github.com/mgeeky/ShellcodeFluctuation#but-commercial-frameworks-leave-no-iocs)

One can say, that this implementation is far from perfect because it leaves something, still there are IOCs and the commercial products show they don't have similar traits.

When that argument's on the table I need to remind, that, the commercial frameworks have complete control over source code of their implants, shellcode loaders and thus can nicely integrate one with another to avoid necessity of hooking and hacking around their shellcode themselves. Here, we need to hook `kernel32!Sleep` to intercept Cobalt Strike's Beacon execution just before it falls asleep in order to kick on with our housekeeping. If there was a better mechanism for us kicking in without having to hook sleep - that would be perfect.

However there is a notion of [_Sleep Mask_](https://www.cobaltstrike.com/help-sleep-mask-kit) introduced to Cobalt Strike, the size restrictions for being hundreds of byte makes us totally unable to introduce this logic to the mask itself (otherwise we'd be able not to hook `Sleep` as well, leaving no IOCs just like commercial products do).

Another argument might be, that commercial framework integrate these sorts of logic into their _Reflective Loaders_ and here we instead leave it in EXE harness.
That's true, but the reason for such a decision is twofold:

1. I need to be really careful with releasing this kind of technology to avoid the risk of helping weaponize the real-world criminals with an implementation that will haunt us back with another Petya. In that manner I decided to skip some of the gore details that I use in my professional tooling used to deliver commercial, contracted Adversary Simulation exercises. Giving out the seed hopefully will be met with community professionals able to grow the concept in their own toolings, assuming they'll have apropriate skills.

2. I'd far prefer to move this entire logic to the [_User-Defined Reflective Loader_](https://www.cobaltstrike.com/help-user-defined-reflective-loader) of Cobalt Strike facilitating Red Team groups in elevated chances for their delivery phase. But firstly, see point (1), secondly that technology is currently limited to 5KBs size for their RDLLs, making me completely unable to implement it there as well. For those of us who build custom C2 & implants for in-house Adversary Simulation engagements - they now have received a sample implementation that will surely help them embellishing their tooling accordingly.


* * *

## How do I use it?

[Permalink: How do I use it?](https://github.com/mgeeky/ShellcodeFluctuation#how-do-i-use-it)

Look at the code and its implementation, understand the concept and re-implement the concept within your own Shellcode Loaders that you utilise to deliver your Red Team engagements.
This is an yet another technique for advanced in-memory evasion that increases your Teams' chances for not getting caught by Anti-Viruses, EDRs and Malware Analysts taking look at your implants.

While developing your advanced shellcode loader, you might also want to implement:

- **Process Heap Encryption** \- take an inspiration from this blog post: [Hook Heaps and Live Free](https://www.arashparsa.com/hook-heaps-and-live-free/) \- which can let you evade Beacon configuration extractors like [`BeaconEye`](https://github.com/CCob/BeaconEye)
- [**Spoof your thread's call stack**](https://github.com/mgeeky/ThreadStackSpoofer) before sleeping (that could evade scanners attempting to examine process' threads and their call stacks in attempt to hunt for `MEM_PRIVATE` memory allocations referenced by these threads)
- **Clear out any leftovers from Reflective Loader** to avoid in-memory signatured detections
- **Unhook everything you might have hooked** (such as AMSI, ETW, WLDP) before sleeping and then re-hook afterwards.

* * *

## Example run

[Permalink: Example run](https://github.com/mgeeky/ShellcodeFluctuation#example-run)

Use case:

```
Usage: ShellcodeFluctuation.exe <shellcode> <fluctuate>
<fluctuate>:
        -1 - Read shellcode but dont inject it. Run in an infinite loop.
        0 - Inject the shellcode but don't hook kernel32!Sleep and don't encrypt anything
        1 - Inject shellcode and start fluctuating its memory with standard PAGE_READWRITE.
        2 - Inject shellcode and start fluctuating its memory with ORCA666's PAGE_NOACCESS.
```

Where:

- `<shellcode>` is a path to the shellcode file
- `<fluctuate>` as described above, takes `-1`, `0` or `1`

Example run that spoofs beacon's thread call stack:

```
C:\> ShellcodeFluctuation.exe ..\..\tests\beacon64.bin 1

[.] Reading shellcode bytes...
[.] Hooking kernel32!Sleep...
[.] Injecting shellcode...
[+] Shellcode is now running. PID = 9456
[+] Fluctuation initialized.
    Shellcode resides at 0x000002210C091000 and occupies 176128 bytes. XOR32 key: 0x1e602f0d
[>] Flipped to RW. Encoding...

===> MySleep(5000)

[.] Decoding...
[>] Flipped to RX.
[>] Flipped to RW. Encoding...

===> MySleep(5000)
```

* * *

## Word of caution

[Permalink: Word of caution](https://github.com/mgeeky/ShellcodeFluctuation#word-of-caution)

If you plan on adding this functionality to your own shellcode loaders / toolings be sure to **AVOID** unhooking `kernel32.dll`.
An attempt to unhook `kernel32` will restore original `Sleep` functionality preventing our callback from being called.
If our callback is not called, the thread will be unable to spoof its own call stack by itself.

If that's what you want to have, than you might need to run another, watchdog thread, making sure that the Beacons thread will get spoofed whenever it sleeps.

If you're using Cobalt Strike and a BOF `unhook-bof` by Raphael's Mudge, be sure to check out my [Pull Request](https://github.com/Cobalt-Strike/unhook-bof/pull/1) that adds optional parameter to the BOF specifying libraries that should not be unhooked.

This way you can maintain your hooks in kernel32:

```
beacon> unhook kernel32
[*] Running unhook.
    Will skip these modules: wmp.dll, kernel32.dll
[+] host called home, sent: 9475 bytes
[+] received output:
ntdll.dll            <.text>
Unhook is done.
```

[Modified `unhook-bof` with option to ignore specified modules](https://github.com/mgeeky/unhook-bof)

* * *

## Final remark

[Permalink: Final remark](https://github.com/mgeeky/ShellcodeFluctuation#final-remark)

This PoC was designed to work with Cobalt Strike's Beacon shellcodes. The Beacon is known to call out to `kernel32!Sleep` to await further instructions from its C2.
This loader leverages that fact by hooking `Sleep` in order to perform its housekeeping.

This implementation might not work with other shellcodes in the market (such as _Meterpreter_) if they don't use `Sleep` to cool down.
Since this is merely a _Proof of Concept_ showing the technique, I don't intend on adding support for any other C2 framework.

When you understand the concept, surely you'll be able to translate it into your shellcode requirements and adapt the solution for your advantage.

Please do not open Github issues related to "this code doesn't work with XYZ shellcode", they'll be closed immediately.

* * *

### ☕ Show Support ☕

[Permalink: ☕ Show Support ☕](https://github.com/mgeeky/ShellcodeFluctuation#-show-support-)

This and other projects are outcome of sleepless nights and **plenty of hard work**. If you like what I do and appreciate that I always give back to the community,
[Consider buying me a coffee](https://github.com/sponsors/mgeeky) _(or better a beer)_ just to say thank you! 💪

* * *

## Author

[Permalink: Author](https://github.com/mgeeky/ShellcodeFluctuation#author)

```
   Mariusz Banach / mgeeky, 21
   <mb [at] binary-offensive.com>
   (https://github.com/mgeeky)
```

## About

An advanced in-memory evasion technique fluctuating shellcode's memory protection between RW/NoAccess & RX and then encrypting/decrypting its contents


### Resources

[Readme](https://github.com/mgeeky/ShellcodeFluctuation#readme-ov-file)

### License

[MIT license](https://github.com/mgeeky/ShellcodeFluctuation#MIT-1-ov-file)

### Code of conduct

[Code of conduct](https://github.com/mgeeky/ShellcodeFluctuation#coc-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mgeeky/ShellcodeFluctuation).

[Activity](https://github.com/mgeeky/ShellcodeFluctuation/activity)

### Stars

[**1.1k**\\
stars](https://github.com/mgeeky/ShellcodeFluctuation/stargazers)

### Watchers

[**18**\\
watching](https://github.com/mgeeky/ShellcodeFluctuation/watchers)

### Forks

[**165**\\
forks](https://github.com/mgeeky/ShellcodeFluctuation/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fmgeeky%2FShellcodeFluctuation&report=mgeeky+%28user%29)

## [Releases\  1](https://github.com/mgeeky/ShellcodeFluctuation/releases)

[v0.2\\
Latest\\
\\
on Oct 7, 2021Oct 7, 2021](https://github.com/mgeeky/ShellcodeFluctuation/releases/tag/v0.2)

## Sponsor this project

[![@mgeeky](https://avatars.githubusercontent.com/u/654344?s=64&v=4)](https://github.com/mgeeky)[**mgeeky** Mariusz Banach](https://github.com/mgeeky)

[Sponsor](https://github.com/sponsors/mgeeky)

[Learn more about GitHub Sponsors](https://github.com/sponsors)

## [Packages\  0](https://github.com/users/mgeeky/packages?repo_name=ShellcodeFluctuation)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mgeeky/ShellcodeFluctuation).

## Languages

- [C++100.0%](https://github.com/mgeeky/ShellcodeFluctuation/search?l=c%2B%2B)

You can’t perform that action at this time.