# https://github.com/aahmad097/AlternativeShellcodeExec

[Skip to content](https://github.com/aahmad097/AlternativeShellcodeExec#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/aahmad097/AlternativeShellcodeExec) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/aahmad097/AlternativeShellcodeExec) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/aahmad097/AlternativeShellcodeExec) to refresh your session.Dismiss alert

{{ message }}

[aahmad097](https://github.com/aahmad097)/ **[AlternativeShellcodeExec](https://github.com/aahmad097/AlternativeShellcodeExec)** Public

- [Notifications](https://github.com/login?return_to=%2Faahmad097%2FAlternativeShellcodeExec) You must be signed in to change notification settings
- [Fork\\
330](https://github.com/login?return_to=%2Faahmad097%2FAlternativeShellcodeExec)
- [Star\\
1.7k](https://github.com/login?return_to=%2Faahmad097%2FAlternativeShellcodeExec)


Alternative Shellcode Execution Via Callbacks


### License

[MIT license](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/LICENSE)

[1.7k\\
stars](https://github.com/aahmad097/AlternativeShellcodeExec/stargazers) [330\\
forks](https://github.com/aahmad097/AlternativeShellcodeExec/forks) [Branches](https://github.com/aahmad097/AlternativeShellcodeExec/branches) [Tags](https://github.com/aahmad097/AlternativeShellcodeExec/tags) [Activity](https://github.com/aahmad097/AlternativeShellcodeExec/activity)

[Star](https://github.com/login?return_to=%2Faahmad097%2FAlternativeShellcodeExec)

[Notifications](https://github.com/login?return_to=%2Faahmad097%2FAlternativeShellcodeExec) You must be signed in to change notification settings

# aahmad097/AlternativeShellcodeExec

master

[**2** Branches](https://github.com/aahmad097/AlternativeShellcodeExec/branches) [**0** Tags](https://github.com/aahmad097/AlternativeShellcodeExec/tags)

[Go to Branches page](https://github.com/aahmad097/AlternativeShellcodeExec/branches)[Go to Tags page](https://github.com/aahmad097/AlternativeShellcodeExec/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![aahmad097](https://avatars.githubusercontent.com/u/37748671?v=4&size=40)](https://github.com/aahmad097)[aahmad097](https://github.com/aahmad097/AlternativeShellcodeExec/commits?author=aahmad097)<br>[Merge pull request](https://github.com/aahmad097/AlternativeShellcodeExec/commit/205314a5b99ceed0b76813ed4b7697aea16fc9b2) [#4](https://github.com/aahmad097/AlternativeShellcodeExec/pull/4) [from danikdanik/master](https://github.com/aahmad097/AlternativeShellcodeExec/commit/205314a5b99ceed0b76813ed4b7697aea16fc9b2)<br>Open commit details<br>4 years agoNov 10, 2022<br>[205314a](https://github.com/aahmad097/AlternativeShellcodeExec/commit/205314a5b99ceed0b76813ed4b7697aea16fc9b2) · 4 years agoNov 10, 2022<br>## History<br>[54 Commits](https://github.com/aahmad097/AlternativeShellcodeExec/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/aahmad097/AlternativeShellcodeExec/commits/master/) 54 Commits |
| [CertEnumSystemStore](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CertEnumSystemStore "CertEnumSystemStore") | [CertEnumSystemStore](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CertEnumSystemStore "CertEnumSystemStore") | [HUEHUEHUE](https://github.com/aahmad097/AlternativeShellcodeExec/commit/264bbb94358f0f62abcd2a4eeaf682df0c088416 "HUEHUEHUE") | 5 years agoMar 12, 2021 |
| [CertEnumSystemStoreLocation](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CertEnumSystemStoreLocation "CertEnumSystemStoreLocation") | [CertEnumSystemStoreLocation](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CertEnumSystemStoreLocation "CertEnumSystemStoreLocation") | [You Only Yolo Once](https://github.com/aahmad097/AlternativeShellcodeExec/commit/f4bd5db9d6d0455c1c80500147f7717330bce240 "You Only Yolo Once") | 5 years agoMar 14, 2021 |
| [CopyFile2](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CopyFile2 "CopyFile2") | [CopyFile2](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CopyFile2 "CopyFile2") | [Another One.](https://github.com/aahmad097/AlternativeShellcodeExec/commit/74b2407f8883fd071cc163881f43fe06ac44eece "Another One.") | 5 years agoMar 1, 2021 |
| [CopyFileEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CopyFileEx "CopyFileEx") | [CopyFileEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CopyFileEx "CopyFileEx") | [I never CALLBACK :P](https://github.com/aahmad097/AlternativeShellcodeExec/commit/802cfa901fc6bc1c3d75e00927e8572663360802 "I never CALLBACK :P") | 5 years agoMar 7, 2021 |
| [CreateThreadPoolWait](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CreateThreadPoolWait "CreateThreadPoolWait") | [CreateThreadPoolWait](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CreateThreadPoolWait "CreateThreadPoolWait") | [Dank in 60 seconds](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2a21a7bb96d601a3a651e09885ff3e9111e7f05c "Dank in 60 seconds") | 5 years agoMar 19, 2021 |
| [CreateTimerQueueTimer\_Tech](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CreateTimerQueueTimer_Tech "CreateTimerQueueTimer_Tech") | [CreateTimerQueueTimer\_Tech](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CreateTimerQueueTimer_Tech "CreateTimerQueueTimer_Tech") | [I am Ali, and I delete TTPs thinking they're faulty without checking …](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c7622e86a8b43a3603949638f80d7b1f47576ea8 "I am Ali, and I delete TTPs thinking they're faulty without checking if the shellcode I was using was the problem.") | 5 years agoMar 1, 2021 |
| [CryptEnumOIDInfo](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CryptEnumOIDInfo "CryptEnumOIDInfo") | [CryptEnumOIDInfo](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/CryptEnumOIDInfo "CryptEnumOIDInfo") | [Added CryptEnumOIDInfo](https://github.com/aahmad097/AlternativeShellcodeExec/commit/54a3844db258ebf78a571b38a757968fad2b0875 "Added CryptEnumOIDInfo") | 5 years agoMay 6, 2021 |
| [EnumCalendarInfo](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumCalendarInfo "EnumCalendarInfo") | [EnumCalendarInfo](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumCalendarInfo "EnumCalendarInfo") | [Adding EnumCalendarInfo & EnumCalendarInfoEx functions](https://github.com/aahmad097/AlternativeShellcodeExec/commit/fa503fd97646291c899d05863b7806970b9e01b6 "Adding EnumCalendarInfo & EnumCalendarInfoEx functions") | 4 years agoOct 15, 2022 |
| [EnumCalendarInfoEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumCalendarInfoEx "EnumCalendarInfoEx") | [EnumCalendarInfoEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumCalendarInfoEx "EnumCalendarInfoEx") | [Adding EnumCalendarInfo & EnumCalendarInfoEx functions](https://github.com/aahmad097/AlternativeShellcodeExec/commit/fa503fd97646291c899d05863b7806970b9e01b6 "Adding EnumCalendarInfo & EnumCalendarInfoEx functions") | 4 years agoOct 15, 2022 |
| [EnumChildWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumChildWindows "EnumChildWindows") | [EnumChildWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumChildWindows "EnumChildWindows") | [I am Ali, and I delete TTPs thinking they're faulty without checking …](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c7622e86a8b43a3603949638f80d7b1f47576ea8 "I am Ali, and I delete TTPs thinking they're faulty without checking if the shellcode I was using was the problem.") | 5 years agoMar 1, 2021 |
| [EnumDesktopW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDesktopW "EnumDesktopW") | [EnumDesktopW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDesktopW "EnumDesktopW") | [Dank in 60 seconds](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2a21a7bb96d601a3a651e09885ff3e9111e7f05c "Dank in 60 seconds") | 5 years agoMar 19, 2021 |
| [EnumDesktopWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDesktopWindows "EnumDesktopWindows") | [EnumDesktopWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDesktopWindows "EnumDesktopWindows") | [A push a day keeps the doctor away](https://github.com/aahmad097/AlternativeShellcodeExec/commit/86aaedc90ae3c08082b96d8db302233c73b558d3 "A push a day keeps the doctor away") | 5 years agoMar 3, 2021 |
| [EnumDirTreeW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDirTreeW "EnumDirTreeW") | [EnumDirTreeW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDirTreeW "EnumDirTreeW") | [Dank in 60 seconds](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2a21a7bb96d601a3a651e09885ff3e9111e7f05c "Dank in 60 seconds") | 5 years agoMar 19, 2021 |
| [EnumDisplayMonitors](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDisplayMonitors "EnumDisplayMonitors") | [EnumDisplayMonitors](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumDisplayMonitors "EnumDisplayMonitors") | [le 10](https://github.com/aahmad097/AlternativeShellcodeExec/commit/6f0b259d7699034ec0008cf5cbd79239da68391e "le 10") | 5 years agoMar 2, 2021 |
| [EnumFontFamiliesExW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontFamiliesExW "EnumFontFamiliesExW") | [EnumFontFamiliesExW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontFamiliesExW "EnumFontFamiliesExW") | [...](https://github.com/aahmad097/AlternativeShellcodeExec/commit/106bddc09ff9ce31d5e6d890580563f9bd8de554 "...") | 5 years agoMay 1, 2021 |
| [EnumFontFamiliesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontFamiliesW "EnumFontFamiliesW") | [EnumFontFamiliesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontFamiliesW "EnumFontFamiliesW") | [Going to be adding a few from WinGDI.h in the next couple of days....…](https://github.com/aahmad097/AlternativeShellcodeExec/commit/60a168387795be9b4d5a90de40ee132cc6e9e669 "Going to be adding a few from WinGDI.h in the next couple of days.... its a gold mine") | 5 years agoApr 30, 2021 |
| [EnumFontsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontsW "EnumFontsW") | [EnumFontsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumFontsW "EnumFontsW") | [EnumFontsW](https://github.com/aahmad097/AlternativeShellcodeExec/commit/dd68d8fc9f2c03e7dec7515e863751cfffbdcfe6 "EnumFontsW") | 5 years agoApr 28, 2021 |
| [EnumICMProfiles](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumICMProfiles "EnumICMProfiles") | [EnumICMProfiles](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumICMProfiles "EnumICMProfiles") | [MEH](https://github.com/aahmad097/AlternativeShellcodeExec/commit/407afd0e5f4a8654463e3e0bcbf81e3b8cadd8ee "MEH") | 5 years agoJun 12, 2021 |
| [EnumLanguageGroupLocalesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumLanguageGroupLocalesW "EnumLanguageGroupLocalesW") | [EnumLanguageGroupLocalesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumLanguageGroupLocalesW "EnumLanguageGroupLocalesW") | [Been scavenging the windows API since bug bounty hunters started call…](https://github.com/aahmad097/AlternativeShellcodeExec/commit/4717ffca7c22b4396fd9397b135b84c99cdcff68 "Been scavenging the windows API since bug bounty hunters started calling themsleves researchers.") | 5 years agoMar 31, 2021 |
| [EnumObjects](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumObjects "EnumObjects") | [EnumObjects](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumObjects "EnumObjects") | [Getting tired of this project ngl -\_-](https://github.com/aahmad097/AlternativeShellcodeExec/commit/e1de09c5f9113e437ba9330c60636ce98a558463 "Getting tired of this project ngl -_-") | 5 years agoMay 3, 2021 |
| [EnumPageFilesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPageFilesW "EnumPageFilesW") | [EnumPageFilesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPageFilesW "EnumPageFilesW") | [Dank](https://github.com/aahmad097/AlternativeShellcodeExec/commit/d7a0eae7f739746078435cbe555141c017c2679b "Dank") | 5 years agoMar 5, 2021 |
| [EnumPropsEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPropsEx "EnumPropsEx") | [EnumPropsEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPropsEx "EnumPropsEx") | [le 10](https://github.com/aahmad097/AlternativeShellcodeExec/commit/6f0b259d7699034ec0008cf5cbd79239da68391e "le 10") | 5 years agoMar 2, 2021 |
| [EnumPropsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPropsW "EnumPropsW") | [EnumPropsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPropsW "EnumPropsW") | [Anotha One](https://github.com/aahmad097/AlternativeShellcodeExec/commit/127f66746f42f3a0277316480174b6ffc31058c3 "Anotha One") | 5 years agoMar 28, 2021 |
| [EnumPwrSchemes](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPwrSchemes "EnumPwrSchemes") | [EnumPwrSchemes](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumPwrSchemes "EnumPwrSchemes") | [added EnumPwrSchemes](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2a4d6063ba919a72f0ad1bbed71a8ed061c61782 "added EnumPwrSchemes") | 5 years agoApr 11, 2021 |
| [EnumResourceTypesExW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumResourceTypesExW "EnumResourceTypesExW") | [EnumResourceTypesExW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumResourceTypesExW "EnumResourceTypesExW") | [EnumResourceTypesExW added](https://github.com/aahmad097/AlternativeShellcodeExec/commit/805bb460a8946c8f308fd9329b738cc5f49e4aab "EnumResourceTypesExW added") | 5 years agoApr 12, 2021 |
| [EnumResourceTypesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumResourceTypesW "EnumResourceTypesW") | [EnumResourceTypesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumResourceTypesW "EnumResourceTypesW") | [I am Ali, and I delete TTPs thinking they're faulty without checking …](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c7622e86a8b43a3603949638f80d7b1f47576ea8 "I am Ali, and I delete TTPs thinking they're faulty without checking if the shellcode I was using was the problem.") | 5 years agoMar 1, 2021 |
| [EnumSystemLocales](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumSystemLocales "EnumSystemLocales") | [EnumSystemLocales](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumSystemLocales "EnumSystemLocales") | [Just keep on truckin](https://github.com/aahmad097/AlternativeShellcodeExec/commit/bfa2913c26671765134423fd4e0d13befb920bc2 "Just keep on truckin") | 5 years agoApr 9, 2021 |
| [EnumThreadWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumThreadWindows "EnumThreadWindows") | [EnumThreadWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumThreadWindows "EnumThreadWindows") | [i guess im working on this again....](https://github.com/aahmad097/AlternativeShellcodeExec/commit/4a4d8461585e0a3bbab07a1580efb2dd319baa77 "i guess im working on this again....") | 5 years agoDec 5, 2021 |
| [EnumTimeFormatsEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumTimeFormatsEx "EnumTimeFormatsEx") | [EnumTimeFormatsEx](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumTimeFormatsEx "EnumTimeFormatsEx") | [Anotha one](https://github.com/aahmad097/AlternativeShellcodeExec/commit/8b979a421a0b51e9a6360f025e69b387bab64b69 "Anotha one") | 5 years agoMay 7, 2021 |
| [EnumUILanguagesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumUILanguagesW "EnumUILanguagesW") | [EnumUILanguagesW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumUILanguagesW "EnumUILanguagesW") | [Added EnumUILanguagesW](https://github.com/aahmad097/AlternativeShellcodeExec/commit/65170249c1d6e929af8fe80964ea3c380dce03d8 "Added EnumUILanguagesW") | 5 years agoApr 8, 2021 |
| [EnumWindowStationsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumWindowStationsW "EnumWindowStationsW") | [EnumWindowStationsW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumWindowStationsW "EnumWindowStationsW") | [I never CALLBACK :P](https://github.com/aahmad097/AlternativeShellcodeExec/commit/802cfa901fc6bc1c3d75e00927e8572663360802 "I never CALLBACK :P") | 5 years agoMar 7, 2021 |
| [EnumWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumWindows "EnumWindows") | [EnumWindows](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumWindows "EnumWindows") | [I am Ali, and I delete TTPs thinking they're faulty without checking …](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c7622e86a8b43a3603949638f80d7b1f47576ea8 "I am Ali, and I delete TTPs thinking they're faulty without checking if the shellcode I was using was the problem.") | 5 years agoMar 1, 2021 |
| [EnumerateLoadedModules](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumerateLoadedModules "EnumerateLoadedModules") | [EnumerateLoadedModules](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/EnumerateLoadedModules "EnumerateLoadedModules") | [I am running out of things to put here](https://github.com/aahmad097/AlternativeShellcodeExec/commit/65a96c440a8ef6fb0add1edc1145664b84fe942d "I am running out of things to put here") | 5 years agoMar 8, 2021 |
| [FiberContextEdit](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/FiberContextEdit "FiberContextEdit") | [FiberContextEdit](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/FiberContextEdit "FiberContextEdit") | [Adding execution through Fiber Context editing. Not the same as Creat…](https://github.com/aahmad097/AlternativeShellcodeExec/commit/13768dde172ce24ce30a032ecc61d1cb1527083b "Adding execution through Fiber Context editing. Not the same as CreateFiber(PtrToShellcode)") | 5 years agoMar 27, 2021 |
| [FlsAlloc](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/FlsAlloc "FlsAlloc") | [FlsAlloc](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/FlsAlloc "FlsAlloc") | [Dummy values everywhere](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c514775d4fe162545e594239968719fa3d7023c3 "Dummy values everywhere") | 5 years agoMar 28, 2021 |
| [ImageGetDigestStream](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/ImageGetDigestStream "ImageGetDigestStream") | [ImageGetDigestStream](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/ImageGetDigestStream "ImageGetDigestStream") | [I am running out of things to put here](https://github.com/aahmad097/AlternativeShellcodeExec/commit/65a96c440a8ef6fb0add1edc1145664b84fe942d "I am running out of things to put here") | 5 years agoMar 8, 2021 |
| [ImmEnumInputContext](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/ImmEnumInputContext "ImmEnumInputContext") | [ImmEnumInputContext](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/ImmEnumInputContext "ImmEnumInputContext") | [k](https://github.com/aahmad097/AlternativeShellcodeExec/commit/bc26da74db6f0e177d11325602b86d50dab089fe "k") | 5 years agoApr 15, 2021 |
| [InitOnceExecuteOnce](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/InitOnceExecuteOnce "InitOnceExecuteOnce") | [InitOnceExecuteOnce](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/InitOnceExecuteOnce "InitOnceExecuteOnce") | [Cache me outsaaaaaaid how bout that](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2acde74d69a56dd974d2b7f99047ad7f05d7d903 "Cache me outsaaaaaaid how bout that") | 5 years agoMar 27, 2021 |
| [LdrEnumerateLoadedModules](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/LdrEnumerateLoadedModules "LdrEnumerateLoadedModules") | [LdrEnumerateLoadedModules](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/LdrEnumerateLoadedModules "LdrEnumerateLoadedModules") | [removed unnecessary getcurrentprocess op](https://github.com/aahmad097/AlternativeShellcodeExec/commit/af0464c02d7d33de5799486f29c249362ae37d21 "removed unnecessary getcurrentprocess op") | 5 years agoMar 30, 2021 |
| [LdrpCallInitRoutine](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/LdrpCallInitRoutine "LdrpCallInitRoutine") | [LdrpCallInitRoutine](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/LdrpCallInitRoutine "LdrpCallInitRoutine") | [Added LdrpCallInitRoutine](https://github.com/aahmad097/AlternativeShellcodeExec/commit/3a41ab1ee90031fab95a6fb949b8d33a5e442c3d "Added LdrpCallInitRoutine") | 5 years agoMar 30, 2021 |
| [OpenThreadWaitChainSession](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/OpenThreadWaitChainSession "OpenThreadWaitChainSession") | [OpenThreadWaitChainSession](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/OpenThreadWaitChainSession "OpenThreadWaitChainSession") | [I am Ali, and I delete TTPs thinking they're faulty without checking …](https://github.com/aahmad097/AlternativeShellcodeExec/commit/c7622e86a8b43a3603949638f80d7b1f47576ea8 "I am Ali, and I delete TTPs thinking they're faulty without checking if the shellcode I was using was the problem.") | 5 years agoMar 1, 2021 |
| [RtlUserFiberStart](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/RtlUserFiberStart "RtlUserFiberStart") | [RtlUserFiberStart](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/RtlUserFiberStart "RtlUserFiberStart") | [Added RtlUserFiberStart method.](https://github.com/aahmad097/AlternativeShellcodeExec/commit/1419707e77629e418b791502fdb31d700eb9a98b "Added RtlUserFiberStart method.") | 5 years agoMar 28, 2021 |
| [SetTimer](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SetTimer "SetTimer") | [SetTimer](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SetTimer "SetTimer") | [removed unecessary command](https://github.com/aahmad097/AlternativeShellcodeExec/commit/ba37bcf79677a2455ccdc6f52d20348dac3be4f6 "removed unecessary command") | 5 years agoApr 1, 2021 |
| [SetupCommitFileQueueW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SetupCommitFileQueueW "SetupCommitFileQueueW") | [SetupCommitFileQueueW](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SetupCommitFileQueueW "SetupCommitFileQueueW") | [Added SetupCommitFileQueueW](https://github.com/aahmad097/AlternativeShellcodeExec/commit/e78103606470df4675b063cc3073c76eb676c36b "Added SetupCommitFileQueueW") | 5 years agoApr 4, 2021 |
| [SymEnumProcesses](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SymEnumProcesses "SymEnumProcesses") | [SymEnumProcesses](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SymEnumProcesses "SymEnumProcesses") | [I never CALLBACK :P](https://github.com/aahmad097/AlternativeShellcodeExec/commit/802cfa901fc6bc1c3d75e00927e8572663360802 "I never CALLBACK :P") | 5 years agoMar 7, 2021 |
| [SymFindFileInPath](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SymFindFileInPath "SymFindFileInPath") | [SymFindFileInPath](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SymFindFileInPath "SymFindFileInPath") | [Cache me outsaaaaaaid how bout that](https://github.com/aahmad097/AlternativeShellcodeExec/commit/2acde74d69a56dd974d2b7f99047ad7f05d7d903 "Cache me outsaaaaaaid how bout that") | 5 years agoMar 27, 2021 |
| [SysEnumSourceFiles](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SysEnumSourceFiles "SysEnumSourceFiles") | [SysEnumSourceFiles](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/SysEnumSourceFiles "SysEnumSourceFiles") | [O\_o](https://github.com/aahmad097/AlternativeShellcodeExec/commit/1800715fbdd3c54b5c55d4cb6d006bdc296c886b "O_o") | 5 years agoMar 21, 2021 |
| [VerifierEnumerateResource](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/VerifierEnumerateResource "VerifierEnumerateResource") | [VerifierEnumerateResource](https://github.com/aahmad097/AlternativeShellcodeExec/tree/master/VerifierEnumerateResource "VerifierEnumerateResource") | ["Push to github on the DAY-LEE BAYSEAS. Baby PLEASE." -Lui Marco](https://github.com/aahmad097/AlternativeShellcodeExec/commit/698fe793ae80aef294a8ac49e9c38fa87d1a3bfb "\"Push to github on the DAY-LEE BAYSEAS. Baby PLEASE.\" -Lui Marco") | 5 years agoMar 11, 2021 |
| [.gitattributes](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/.gitattributes ".gitattributes") | [Add .gitignore and .gitattributes.](https://github.com/aahmad097/AlternativeShellcodeExec/commit/24c5bf2faab72447f2b9acb976c877428fc98666 "Add .gitignore and .gitattributes.") | 5 years agoFeb 27, 2021 |
| [.gitignore](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/.gitignore ".gitignore") | [Add .gitignore and .gitattributes.](https://github.com/aahmad097/AlternativeShellcodeExec/commit/24c5bf2faab72447f2b9acb976c877428fc98666 "Add .gitignore and .gitattributes.") | 5 years agoFeb 27, 2021 |
| [AlternativeShellcodeExec.sln](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/AlternativeShellcodeExec.sln "AlternativeShellcodeExec.sln") | [AlternativeShellcodeExec.sln](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/AlternativeShellcodeExec.sln "AlternativeShellcodeExec.sln") | [Adding EnumCalendarInfo & EnumCalendarInfoEx functions](https://github.com/aahmad097/AlternativeShellcodeExec/commit/fa503fd97646291c899d05863b7806970b9e01b6 "Adding EnumCalendarInfo & EnumCalendarInfoEx functions") | 4 years agoOct 15, 2022 |
| [LICENSE](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/LICENSE "LICENSE") | [Create LICENSE](https://github.com/aahmad097/AlternativeShellcodeExec/commit/84424c6abd394abd4aae434f709301c5130cce78 "Create LICENSE") | 5 years agoDec 9, 2021 |
| [Readme.md](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/Readme.md "Readme.md") | [Readme.md](https://github.com/aahmad097/AlternativeShellcodeExec/blob/master/Readme.md "Readme.md") | [A push a day keeps the doctor away](https://github.com/aahmad097/AlternativeShellcodeExec/commit/86aaedc90ae3c08082b96d8db302233c73b558d3 "A push a day keeps the doctor away") | 5 years agoMar 3, 2021 |
| View all files |

## Repository files navigation

# Alternative Code Execution

[Permalink: Alternative Code Execution](https://github.com/aahmad097/AlternativeShellcodeExec#alternative-code-execution)

This is gaining more popularity than expected, so I just wanted to give a shoutout to [alfarom256](https://github.com/alfarom256) for informing me about callback functions and showing me the CreateThreadPoolWait technique. I also wanted to give a shoutout to [ch3rn0byl](https://github.com/ch3rn0byl) for encouraging me to get this project going.

According to Microsoft, a callback function is code within a managed application that helps an unmanaged DLL function complete a task. Calls to a callback function pass indirectly from a managed application, through a DLL function, and back to the managed implementation. This repository contains a list of callback functions that can be used to execute position independent shellcode so that CreateThread would be a thing of the past :P.

## About

Alternative Shellcode Execution Via Callbacks


### Resources

[Readme](https://github.com/aahmad097/AlternativeShellcodeExec#readme-ov-file)

### License

[MIT license](https://github.com/aahmad097/AlternativeShellcodeExec#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/aahmad097/AlternativeShellcodeExec).

[Activity](https://github.com/aahmad097/AlternativeShellcodeExec/activity)

### Stars

[**1.7k**\\
stars](https://github.com/aahmad097/AlternativeShellcodeExec/stargazers)

### Watchers

[**43**\\
watching](https://github.com/aahmad097/AlternativeShellcodeExec/watchers)

### Forks

[**330**\\
forks](https://github.com/aahmad097/AlternativeShellcodeExec/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Faahmad097%2FAlternativeShellcodeExec&report=aahmad097+%28user%29)

## [Releases](https://github.com/aahmad097/AlternativeShellcodeExec/releases)

No releases published

## [Packages\  0](https://github.com/users/aahmad097/packages?repo_name=AlternativeShellcodeExec)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/aahmad097/AlternativeShellcodeExec).

## [Contributors\  3](https://github.com/aahmad097/AlternativeShellcodeExec/graphs/contributors)

- [![@aahmad097](https://avatars.githubusercontent.com/u/37748671?s=64&v=4)](https://github.com/aahmad097)[**aahmad097**](https://github.com/aahmad097)
- [![@alfarom256](https://avatars.githubusercontent.com/u/36286171?s=64&v=4)](https://github.com/alfarom256)[**alfarom256** alfarom256](https://github.com/alfarom256)
- [![@danikdanik](https://avatars.githubusercontent.com/u/8233041?s=64&v=4)](https://github.com/danikdanik)[**danikdanik** Dani Kamanovsky](https://github.com/danikdanik)

## Languages

- [C++100.0%](https://github.com/aahmad097/AlternativeShellcodeExec/search?l=c%2B%2B)

You can’t perform that action at this time.