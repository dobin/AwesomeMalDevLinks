# https://github.com/S3cur3Th1sSh1t/Caro-Kann

[Skip to content](https://github.com/S3cur3Th1sSh1t/Caro-Kann#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/S3cur3Th1sSh1t/Caro-Kann) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/S3cur3Th1sSh1t/Caro-Kann) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/S3cur3Th1sSh1t/Caro-Kann) to refresh your session.Dismiss alert

{{ message }}

[S3cur3Th1sSh1t](https://github.com/S3cur3Th1sSh1t)/ **[Caro-Kann](https://github.com/S3cur3Th1sSh1t/Caro-Kann)** Public

- [Notifications](https://github.com/login?return_to=%2FS3cur3Th1sSh1t%2FCaro-Kann) You must be signed in to change notification settings
- [Fork\\
44](https://github.com/login?return_to=%2FS3cur3Th1sSh1t%2FCaro-Kann)
- [Star\\
407](https://github.com/login?return_to=%2FS3cur3Th1sSh1t%2FCaro-Kann)


Encrypted shellcode Injection to avoid Kernel triggered memory scans


[407\\
stars](https://github.com/S3cur3Th1sSh1t/Caro-Kann/stargazers) [44\\
forks](https://github.com/S3cur3Th1sSh1t/Caro-Kann/forks) [Branches](https://github.com/S3cur3Th1sSh1t/Caro-Kann/branches) [Tags](https://github.com/S3cur3Th1sSh1t/Caro-Kann/tags) [Activity](https://github.com/S3cur3Th1sSh1t/Caro-Kann/activity)

[Star](https://github.com/login?return_to=%2FS3cur3Th1sSh1t%2FCaro-Kann)

[Notifications](https://github.com/login?return_to=%2FS3cur3Th1sSh1t%2FCaro-Kann) You must be signed in to change notification settings

# S3cur3Th1sSh1t/Caro-Kann

main

[**1** Branch](https://github.com/S3cur3Th1sSh1t/Caro-Kann/branches) [**0** Tags](https://github.com/S3cur3Th1sSh1t/Caro-Kann/tags)

[Go to Branches page](https://github.com/S3cur3Th1sSh1t/Caro-Kann/branches)[Go to Tags page](https://github.com/S3cur3Th1sSh1t/Caro-Kann/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![S3cur3Th1sSh1t](https://avatars.githubusercontent.com/u/27858067?v=4&size=40)](https://github.com/S3cur3Th1sSh1t)[S3cur3Th1sSh1t](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commits?author=S3cur3Th1sSh1t)<br>[Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519)<br>3 years agoSep 12, 2023<br>[1a340fe](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519) · 3 years agoSep 12, 2023<br>## History<br>[2 Commits](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commits/main/) 2 Commits |
| [images](https://github.com/S3cur3Th1sSh1t/Caro-Kann/tree/main/images "images") | [images](https://github.com/S3cur3Th1sSh1t/Caro-Kann/tree/main/images "images") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [.gitattributes](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/.gitattributes ".gitattributes") | [Initial commit](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/7c57c7244f7f9d9aecc9d79be17614c77aafbc22 "Initial commit") | 3 years agoSep 12, 2023 |
| [APIResolve.h](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/APIResolve.h "APIResolve.h") | [APIResolve.h](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/APIResolve.h "APIResolve.h") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [ApiResolve.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/ApiResolve.c "ApiResolve.c") | [ApiResolve.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/ApiResolve.c "ApiResolve.c") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [CaroKann.nim](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/CaroKann.nim "CaroKann.nim") | [CaroKann.nim](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/CaroKann.nim "CaroKann.nim") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [DecryptProtect.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/DecryptProtect.c "DecryptProtect.c") | [DecryptProtect.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/DecryptProtect.c "DecryptProtect.c") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [Encrypt.cpp](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/Encrypt.cpp "Encrypt.cpp") | [Encrypt.cpp](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/Encrypt.cpp "Encrypt.cpp") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [README.md](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/README.md "README.md") | [README.md](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/README.md "README.md") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [adjuststack.asm](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/adjuststack.asm "adjuststack.asm") | [adjuststack.asm](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/adjuststack.asm "adjuststack.asm") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [adjuststack\_as.asm](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/adjuststack_as.asm "adjuststack_as.asm") | [adjuststack\_as.asm](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/adjuststack_as.asm "adjuststack_as.asm") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [extract.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/extract.c "extract.c") | [extract.c](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/extract.c "extract.c") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [extract.sh](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/extract.sh "extract.sh") | [extract.sh](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/extract.sh "extract.sh") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [makefile](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/makefile "makefile") | [makefile](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/makefile "makefile") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| [messageenc.bin](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/messageenc.bin "messageenc.bin") | [messageenc.bin](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/messageenc.bin "messageenc.bin") | [Initial release](https://github.com/S3cur3Th1sSh1t/Caro-Kann/commit/1a340fedbd7e06c66fb38e29dfbacd6d3ea8f519 "Initial release") | 3 years agoSep 12, 2023 |
| View all files |

## Repository files navigation

# Caro Kann

[Permalink: Caro Kann](https://github.com/S3cur3Th1sSh1t/Caro-Kann#caro-kann)

[![Caro Kann defense](https://github.com/S3cur3Th1sSh1t/Caro-Kann/raw/main/images/CaroKann.jpg?raw=true)](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/images/CaroKann.jpg?raw=true)

Encrypted shellcode Injection to avoid memory scans triggered from Kernel (ETWti / Kernel Callbacks). Specific combinations of Windows APIs, e.g. for injection into a remote process can lead to a memory scan:

[![ScanTrigger](https://github.com/S3cur3Th1sSh1t/Caro-Kann/raw/main/images/ScanTrigger.png?raw=true)](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/images/ScanTrigger.png?raw=true)

Typically, the scan can be triggered from Userland via hooks on the execute primitive such as `NtCreateThreadEx`. But more and more EDR vendors also tend to trigger scans from Kernel, for example after the Kernel Callback `PsSetCreateThreadNotifyRoutine()` a scan could be triggered. But what if there is no executable memory section with known malicious code? Well, no alert for an detection I guess.

The idea is as follows:

- Inject encrypted known malicious payload into an `RW` section
- Inject custom non known malicious shellcode into an `RX` section
- Create a remote Thread on the second shellcode

[![Inject](https://github.com/S3cur3Th1sSh1t/Caro-Kann/raw/main/images/Inject.png?raw=true)](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/images/Inject.png?raw=true)

The custom shellcode will than:

- Sleep for an amount x (to avoid memory scans triggered by the execute primitive of Thread creation)
- Decrypt the first known malicious shellcode
- Protect the section from `RW` to `RX`
- Make a direct `JMP` to the known malicious shellcode

[![Shellcode](https://github.com/S3cur3Th1sSh1t/Caro-Kann/raw/main/images/Shellcode.png?raw=true)](https://github.com/S3cur3Th1sSh1t/Caro-Kann/blob/main/images/Shellcode.png?raw=true)

## Setup

[Permalink: Setup](https://github.com/S3cur3Th1sSh1t/Caro-Kann#setup)

On linux, the PIC-Code was found to be compiled correctly with `mingw-w64` version `version 10-win32 20220324 (GCC)`. With that version installed, the shellcode can be compiled with a simple `make` and extracted from the `.text` section via `bash extract.sh`.

If you'd like to compile from Windows, you can use the following commands:

```
as -o adjuststack.o adjuststack_as.asm
gcc ApiResolve.c -Wall -m64 -ffunction-sections -fno-asynchronous-unwind-tables -nostdlib -fno-ident -O2 -c -o ApiResolve.o -Wl,--no-seh
gcc DecryptProtect.c -Wall -m64 -masm=intel -ffunction-sections -fno-asynchronous-unwind-tables -nostdlib -fno-ident -O2 -c -o decryptprotect.o -Wl,--no-seh
ld -s adjuststack.o ApiResolve.o decryptprotect.o -o decryptprotect.exe
gcc extract.c -o extract.exe
extract.exe
```

You also need to have [Nim](https://nim-lang.org/) installed for this PoC.

After installation, the dependencies can be installed via the following oneliner:

```
nimble install winim ptr_math
```

The PoC can than be compiled with:

```
nim c -d:release -d=mingw -d:noRes CaroKann.nim # Cross compile
nim c -d:release CaroKann.nim # Windows
```

Any payload can be XOR encrypted with the given `encrypt.cpp` code:

```
Usage: encrypter.exe input_file output_file
```

The encrypted payload can than be embedded in the PoC via the following line:

```
const shellcode = slurp"<encrypted.bin>"
```

## OPSec improvement ideas

[Permalink: OPSec improvement ideas](https://github.com/S3cur3Th1sSh1t/Caro-Kann#opsec-improvement-ideas)

- Bypass Userland-Hooks for Injection (although not really needed, but for fun)
- Back Payload(s) by legitimate DLL (Module Stomping)
- Load C2-Dlls via the first Shellcode - which can avoid memory scans triggered by module loads
- Use ThreadlessInject or DLLNotificationInjection instead of Remote Thread Creation

## OPSec considerations for C2-Payloads

[Permalink: OPSec considerations for C2-Payloads](https://github.com/S3cur3Th1sSh1t/Caro-Kann#opsec-considerations-for-c2-payloads)

- Should use Sleep encryption, otherwise the payload will get flagged later
- Should use Unhooking first or (in)direct Syscalls
- Should use Proxy module loading

## About

Encrypted shellcode Injection to avoid Kernel triggered memory scans


### Resources

[Readme](https://github.com/S3cur3Th1sSh1t/Caro-Kann#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/S3cur3Th1sSh1t/Caro-Kann).

[Activity](https://github.com/S3cur3Th1sSh1t/Caro-Kann/activity)

### Stars

[**407**\\
stars](https://github.com/S3cur3Th1sSh1t/Caro-Kann/stargazers)

### Watchers

[**5**\\
watching](https://github.com/S3cur3Th1sSh1t/Caro-Kann/watchers)

### Forks

[**44**\\
forks](https://github.com/S3cur3Th1sSh1t/Caro-Kann/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FS3cur3Th1sSh1t%2FCaro-Kann&report=S3cur3Th1sSh1t+%28user%29)

## [Releases](https://github.com/S3cur3Th1sSh1t/Caro-Kann/releases)

No releases published

## [Packages\  0](https://github.com/users/S3cur3Th1sSh1t/packages?repo_name=Caro-Kann)

No packages published

## Languages

- [C72.9%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=c)
- [Nim18.3%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=nim)
- [C++4.9%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=c%2B%2B)
- [Assembly2.2%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=assembly)
- [Makefile1.4%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=makefile)
- [Shell0.3%](https://github.com/S3cur3Th1sSh1t/Caro-Kann/search?l=shell)

You can’t perform that action at this time.