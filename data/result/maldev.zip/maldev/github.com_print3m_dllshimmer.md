# https://github.com/Print3M/DllShimmer

[Skip to content](https://github.com/Print3M/DllShimmer#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Print3M/DllShimmer) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Print3M/DllShimmer) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Print3M/DllShimmer) to refresh your session.Dismiss alert

{{ message }}

[Print3M](https://github.com/Print3M)/ **[DllShimmer](https://github.com/Print3M/DllShimmer)** Public

- [Notifications](https://github.com/login?return_to=%2FPrint3M%2FDllShimmer) You must be signed in to change notification settings
- [Fork\\
84](https://github.com/login?return_to=%2FPrint3M%2FDllShimmer)
- [Star\\
707](https://github.com/login?return_to=%2FPrint3M%2FDllShimmer)


Weaponize DLL hijacking easily. Backdoor any function in any DLL.


[707\\
stars](https://github.com/Print3M/DllShimmer/stargazers) [84\\
forks](https://github.com/Print3M/DllShimmer/forks) [Branches](https://github.com/Print3M/DllShimmer/branches) [Tags](https://github.com/Print3M/DllShimmer/tags) [Activity](https://github.com/Print3M/DllShimmer/activity)

[Star](https://github.com/login?return_to=%2FPrint3M%2FDllShimmer)

[Notifications](https://github.com/login?return_to=%2FPrint3M%2FDllShimmer) You must be signed in to change notification settings

# Print3M/DllShimmer

main

[**2** Branches](https://github.com/Print3M/DllShimmer/branches) [**8** Tags](https://github.com/Print3M/DllShimmer/tags)

[Go to Branches page](https://github.com/Print3M/DllShimmer/branches)[Go to Tags page](https://github.com/Print3M/DllShimmer/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Print3M](https://avatars.githubusercontent.com/u/92022497?v=4&size=40)](https://github.com/Print3M)[Print3M](https://github.com/Print3M/DllShimmer/commits?author=Print3M)<br>[Merge pull request](https://github.com/Print3M/DllShimmer/commit/fe2348859286533fb1f26b1a78ecec8c031451be) [#6](https://github.com/Print3M/DllShimmer/pull/6) [from Print3M/dev](https://github.com/Print3M/DllShimmer/commit/fe2348859286533fb1f26b1a78ecec8c031451be)<br>Open commit detailssuccess<br>6 months agoAug 26, 2025<br>[fe23488](https://github.com/Print3M/DllShimmer/commit/fe2348859286533fb1f26b1a78ecec8c031451be) · 6 months agoAug 26, 2025<br>## History<br>[29 Commits](https://github.com/Print3M/DllShimmer/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Print3M/DllShimmer/commits/main/) 29 Commits |
| [.github/workflows](https://github.com/Print3M/DllShimmer/tree/main/.github/workflows "This path skips through empty directories") | [.github/workflows](https://github.com/Print3M/DllShimmer/tree/main/.github/workflows "This path skips through empty directories") | [Debug cannot be disabled bug fixed](https://github.com/Print3M/DllShimmer/commit/2e6de47e5cf2868cc0122e7a86f05772d8ce36b6 "Debug cannot be disabled bug fixed") | 6 months agoAug 26, 2025 |
| [.vscode](https://github.com/Print3M/DllShimmer/tree/main/.vscode ".vscode") | [.vscode](https://github.com/Print3M/DllShimmer/tree/main/.vscode ".vscode") | [Update README, better debug handling, timestamp added](https://github.com/Print3M/DllShimmer/commit/1c64b0788c2d59d4afc3293e27357f51495a0967 "Update README, better debug handling, timestamp added") | 6 months agoAug 23, 2025 |
| [\_img](https://github.com/Print3M/DllShimmer/tree/main/_img "_img") | [\_img](https://github.com/Print3M/DllShimmer/tree/main/_img "_img") | [indentation fix](https://github.com/Print3M/DllShimmer/commit/baa6708d0fe3af409abcf4271c21d9cb36093db6 "indentation fix") | 6 months agoAug 23, 2025 |
| [cli](https://github.com/Print3M/DllShimmer/tree/main/cli "cli") | [cli](https://github.com/Print3M/DllShimmer/tree/main/cli "cli") | [Version flag implemented](https://github.com/Print3M/DllShimmer/commit/1dce132583a41267c033d4d19755559fc340ba4d "Version flag implemented") | 6 months agoAug 24, 2025 |
| [def](https://github.com/Print3M/DllShimmer/tree/main/def "def") | [def](https://github.com/Print3M/DllShimmer/tree/main/def "def") | [Huge refactor, +compile script](https://github.com/Print3M/DllShimmer/commit/9ac684aab24de7c1ba4acdb10cf06f7bfc65293e "Huge refactor, +compile script") | 6 months agoAug 17, 2025 |
| [dist](https://github.com/Print3M/DllShimmer/tree/main/dist "dist") | [dist](https://github.com/Print3M/DllShimmer/tree/main/dist "dist") | [workflow](https://github.com/Print3M/DllShimmer/commit/e6e9604006dca123e591eceff529ee5745799faf "workflow") | 6 months agoAug 17, 2025 |
| [dll](https://github.com/Print3M/DllShimmer/tree/main/dll "dll") | [dll](https://github.com/Print3M/DllShimmer/tree/main/dll "dll") | [Debug to file param added](https://github.com/Print3M/DllShimmer/commit/89528c302336faf9c7518eafbd8161e4372f0bc9 "Debug to file param added") | 6 months agoAug 23, 2025 |
| [output](https://github.com/Print3M/DllShimmer/tree/main/output "output") | [output](https://github.com/Print3M/DllShimmer/tree/main/output "output") | [Debug to file param added](https://github.com/Print3M/DllShimmer/commit/89528c302336faf9c7518eafbd8161e4372f0bc9 "Debug to file param added") | 6 months agoAug 23, 2025 |
| [templates](https://github.com/Print3M/DllShimmer/tree/main/templates "templates") | [templates](https://github.com/Print3M/DllShimmer/tree/main/templates "templates") | [Debug cannot be disabled bug fixed](https://github.com/Print3M/DllShimmer/commit/2e6de47e5cf2868cc0122e7a86f05772d8ce36b6 "Debug cannot be disabled bug fixed") | 6 months agoAug 26, 2025 |
| [.gitignore](https://github.com/Print3M/DllShimmer/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/Print3M/DllShimmer/blob/main/.gitignore ".gitignore") | [+fancy banner & backslash bug fix & better instruction](https://github.com/Print3M/DllShimmer/commit/aa8e2d857ace41d5e460a9407762bba918e51713 "+fancy banner & backslash bug fix & better instruction") | 6 months agoAug 18, 2025 |
| [README.md](https://github.com/Print3M/DllShimmer/blob/main/README.md "README.md") | [README.md](https://github.com/Print3M/DllShimmer/blob/main/README.md "README.md") | [Debug cannot be disabled bug fixed](https://github.com/Print3M/DllShimmer/commit/2e6de47e5cf2868cc0122e7a86f05772d8ce36b6 "Debug cannot be disabled bug fixed") | 6 months agoAug 26, 2025 |
| [go.mod](https://github.com/Print3M/DllShimmer/blob/main/go.mod "go.mod") | [go.mod](https://github.com/Print3M/DllShimmer/blob/main/go.mod "go.mod") | [init](https://github.com/Print3M/DllShimmer/commit/ceae65b44414d975fcf26953b3593e02b680084a "init") | 6 months agoAug 15, 2025 |
| [go.sum](https://github.com/Print3M/DllShimmer/blob/main/go.sum "go.sum") | [go.sum](https://github.com/Print3M/DllShimmer/blob/main/go.sum "go.sum") | [init](https://github.com/Print3M/DllShimmer/commit/ceae65b44414d975fcf26953b3593e02b680084a "init") | 6 months agoAug 15, 2025 |
| [main.go](https://github.com/Print3M/DllShimmer/blob/main/main.go "main.go") | [main.go](https://github.com/Print3M/DllShimmer/blob/main/main.go "main.go") | [Debug to file param added](https://github.com/Print3M/DllShimmer/commit/89528c302336faf9c7518eafbd8161e4372f0bc9 "Debug to file param added") | 6 months agoAug 23, 2025 |
| View all files |

## Repository files navigation

# DllShimmer

[Permalink: DllShimmer](https://github.com/Print3M/DllShimmer#dllshimmer)

Weaponize DLL hijacking easily. Backdoor any function in any DLL without disrupting normal process operation.

[![DllShimmer flowchart](https://github.com/Print3M/DllShimmer/raw/main/_img/img-1.jpg)](https://github.com/Print3M/DllShimmer/blob/main/_img/img-1.jpg)

## How it works

[Permalink: How it works](https://github.com/Print3M/DllShimmer#how-it-works)

DllShimmer parses the original DLL and extracts information about exported functions (name, ordinal number, and forwarder info). Based on this information, DllShimmer creates a boilerplate C++ file (`.cpp`). **The generated file allows you to add your own code to each function exported from the original DLL without disrupting the normal operation of the program.** No reverse engineering or instrumentation is required, because DllShimmer does not rely on function signatures (see more in “Limitations”).

The second file generated is a `.def` file, which ensures that all DLLs exported from the proxy after compilation will have the same names and ordinal numbers as in the original DLL.

**After compilation, the EAT in the proxy DLL is an exact copy of the EAT in the original DLL. All names and ordinal numbers of exported functions match, and forwarded functions are forwarded as well.** DllShimmer does not explicitly forward all functions (like most tools), creating a completely new and suspicious EAT structure.

## Installation

[Permalink: Installation](https://github.com/Print3M/DllShimmer#installation)

Compile Go source code or [download the compiled binary](https://github.com/Print3M/DllShimmer/releases).

**Dependencies**:

- `x86_64-w64-mingw32-g++`
- `x86_64-w64-mingw32-dlltool`

## Usage

[Permalink: Usage](https://github.com/Print3M/DllShimmer#usage)

Example:

```
# Backdoor version.dll (proxy to absolute path)
./DllShimmer -i version.dll -o project/ -x "C:/Windows/System32/version.dll" -m

# Backdoor random chat.dll (proxy to relative path)
./DllShimmer -i chat.dll -o project/ -x "lib/chat2.dll" -m

# Backdoor random app.dll (static linking to the original DLL)
./DllShimmer -i app.dll -o project/ -x "app2.dll" -m --static
```

Parameters:

**`-i / --input <path>`** \[required\]

The original DLL that you want to backdoor.

**`-o / --output <path>`** \[required\]

The path to the directory where DllShimmer will save all generated files.

**`-x / --original <path>`** \[required\]

In case of dynamic linking (default) provide the path where the proxy DLL will find the original DLL on the target system.

In the case of static linking (`--static`), specify only the name of the original DLL. It will be searched for according to the default loading order on Windows.

**`-m / --mutex`** \[optional\]

Enabling this option will add a mutex to the source file, which prevents your backdoor from being executed more than once during a single program run. All original functions will continue to work normally.

**`--static`** \[optional\]

Enable static linking between the proxy DLL (IAT) and the original DLL (EAT). This generates an additional `.lib` file in the output directory, which acts as the original DLL for static compilation.

This technique has some serious limitations compared to dynamic linking:

- You cannot define a full or relative path to the original DLL. The system loader only uses the DLL name form proxy IAT and searches in the default paths.
- Limited debugging information. If the original DLL fails to load, the program will usually crash without additional information.

However, static linking may be more stealthy and natural in some scenarios.

Default: DllShimmer always uses dynamic linking with the `LoadLibraryA()` and `GetProcAddress()` functions.

**`--debug-file <path>`** \[optional\]

Save debug logs to a file. Logs are written to a file on an ongoing basis while the program is running. If selected, logs are not printed to STDOUT.

Default: DllShimmer always writes debug logs to STDOUT.

Example debug output:

[![Example debug output](https://github.com/Print3M/DllShimmer/raw/main/_img/img-2.png)](https://github.com/Print3M/DllShimmer/blob/main/_img/img-2.png)

## Limitations

[Permalink: Limitations](https://github.com/Print3M/DllShimmer#limitations)

- Only x86-64 / AMD64 architecture is supported.
- Most likely, the generic proxy code will not work for functions with floating-point parameters, as they use different registers than integer ones utilized by DllShimmer. If you know the function signature, you can manually adjust it in the generated file.
- Functions with more than 12 arguments will not work because this number has been hardcoded into DllShimmer templates.
- There are some huge obfuscated DLLs with weird name mangling, calling conventions and tricks (e.g. compiled Qt framework DLL). I don't recommend to use them as a proxy DLL. DllShimmer most probably will generate some garbage in this case.

## Troubleshooting

[Permalink: Troubleshooting](https://github.com/Print3M/DllShimmer#troubleshooting)

Before you start troubleshooting:

1. Read "Limitations".
2. Make sure you don't use static linking (`--static`). It's easier to debug with dynamic linking (default).
3. Save debug output to file (`--debug-file`).

### _In the generated `.cpp` file, I don't see all the exported functions from the original DLL._

[Permalink: In the generated .cpp file, I don't see all the exported functions from the original DLL.](https://github.com/Print3M/DllShimmer#in-the-generated-cpp-file-i-dont-see-all-the-exported-functions-from-the-original-dll)

Functions defined in the original DLL as “forwarded” are not included in the `.cpp` file. However, they are visible in the `.def` file. They will also be exported after compilation, exactly as in the original DLL.

### _Strange loader error (126) while loading original DLL_

[Permalink: Strange loader error (126) while loading original DLL](https://github.com/Print3M/DllShimmer#strange-loader-error-126-while-loading-original-dll)

Sometimes, your proxy DLL displays an error when loading the original DLL, and the error code is 126, even though you theoretically specified the correct relative path in the `-x` parameter. Why isn't it working?!?

DLLs are searched for in the `Current Directory`. In 98% of cases, this is simply the location of the main EXE file, but there are programs (mostly old legacy ones) that arbitrarily change the `Current Directory` using, for example, `SetCurrentDirectoryW()`. The main program is aware of this change, so it loads your proxy DLL correctly, but you are unaware of this and try to load the original DLL relatively, while the program searches for it in the changed `Current Directory`.

This rule applies to both static and dynamic loading of the original DLL. Unfortunately, with static linking, this problem is much harder to detect because we don't have debug information. System loader just fails and it's over. This is why I always recommend using the default dynamic linking first.

In the case of dynamic linking, we have two options:

1. Adjust the path in the `-x` parameter to the new `Current Directory` situation.
2. Change the `Current Directory` dynamically to search for DLLs where we want.

In case of static linking, we really only have one option:

1. Move the original DLL to the `Current Directory`.

## TODO

[Permalink: TODO](https://github.com/Print3M/DllShimmer#todo)

- Support C++ mangled function names

## About

Weaponize DLL hijacking easily. Backdoor any function in any DLL.


### Topics

[windows](https://github.com/topics/windows "Topic: windows") [golang](https://github.com/topics/golang "Topic: golang") [security](https://github.com/topics/security "Topic: security") [backdoor](https://github.com/topics/backdoor "Topic: backdoor") [persistence](https://github.com/topics/persistence "Topic: persistence") [malware](https://github.com/topics/malware "Topic: malware") [pentesting](https://github.com/topics/pentesting "Topic: pentesting") [security-tools](https://github.com/topics/security-tools "Topic: security-tools") [dll-hijacking](https://github.com/topics/dll-hijacking "Topic: dll-hijacking") [redteam](https://github.com/topics/redteam "Topic: redteam") [windows-security](https://github.com/topics/windows-security "Topic: windows-security") [initial-access](https://github.com/topics/initial-access "Topic: initial-access") [dll-sideloading](https://github.com/topics/dll-sideloading "Topic: dll-sideloading")

### Resources

[Readme](https://github.com/Print3M/DllShimmer#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Print3M/DllShimmer).

[Activity](https://github.com/Print3M/DllShimmer/activity)

### Stars

[**707**\\
stars](https://github.com/Print3M/DllShimmer/stargazers)

### Watchers

[**6**\\
watching](https://github.com/Print3M/DllShimmer/watchers)

### Forks

[**84**\\
forks](https://github.com/Print3M/DllShimmer/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FPrint3M%2FDllShimmer&report=Print3M+%28user%29)

## [Releases\  8](https://github.com/Print3M/DllShimmer/releases)

[DllShimmer 1.1.1\\
Latest\\
\\
on Aug 26, 2025Aug 26, 2025](https://github.com/Print3M/DllShimmer/releases/tag/1.1.1)

[\+ 7 releases](https://github.com/Print3M/DllShimmer/releases)

## [Contributors\  2](https://github.com/Print3M/DllShimmer/graphs/contributors)

- [![@Print3M](https://avatars.githubusercontent.com/u/92022497?s=64&v=4)](https://github.com/Print3M)[**Print3M**](https://github.com/Print3M)
- [![@chainski](https://avatars.githubusercontent.com/u/96607632?s=64&v=4)](https://github.com/chainski)[**chainski** chainskimo](https://github.com/chainski)

## Languages

- [Go96.6%](https://github.com/Print3M/DllShimmer/search?l=go)
- [Shell3.4%](https://github.com/Print3M/DllShimmer/search?l=shell)

You can’t perform that action at this time.