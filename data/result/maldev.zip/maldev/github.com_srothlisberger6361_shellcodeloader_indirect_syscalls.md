# https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls

[Skip to content](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls) to refresh your session.Dismiss alert

{{ message }}

[srothlisberger6361](https://github.com/srothlisberger6361)/ **[ShellCodeLoader\_Indirect\_Syscalls](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls)** Public

forked from [0xcf80/ShellCodeLoader\_Indirect\_Syscalls](https://github.com/0xcf80/ShellCodeLoader_Indirect_Syscalls)

- [Notifications](https://github.com/login?return_to=%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls) You must be signed in to change notification settings
- [Fork\\
0](https://github.com/login?return_to=%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls)
- [Star\\
3](https://github.com/login?return_to=%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls)


Shellcode Loader using indirect syscalls


### License

[MIT license](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/LICENSE)

[3\\
stars](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/stargazers) [4\\
forks](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/forks) [Branches](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/branches) [Tags](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/tags) [Activity](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/activity)

[Star](https://github.com/login?return_to=%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls)

[Notifications](https://github.com/login?return_to=%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls) You must be signed in to change notification settings

# srothlisberger6361/ShellCodeLoader\_Indirect\_Syscalls

main

[**1** Branch](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/branches) [**0** Tags](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/tags)

[Go to Branches page](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/branches)[Go to Tags page](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/tags)

Go to file

Code

Open more actions menu

This branch is [3 commits ahead of](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/compare/0xcf80%3AShellCodeLoader_Indirect_Syscalls%3Amain...main) 0xcf80/ShellCodeLoader\_Indirect\_Syscalls:main.

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![srothlisberger6361](https://avatars.githubusercontent.com/u/39919375?v=4&size=40)](https://github.com/srothlisberger6361)[srothlisberger6361](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commits?author=srothlisberger6361)<br>[Create shellcode.h](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/56ad512cdf0531b1099bbc63bade96ca33fc1300)<br>2 years agoMar 29, 2024<br>[56ad512](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/56ad512cdf0531b1099bbc63bade96ca33fc1300) · 2 years agoMar 29, 2024<br>## History<br>[11 Commits](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commits/main/) 11 Commits |
| [ShellcodeLoader](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/tree/main/ShellcodeLoader "ShellcodeLoader") | [ShellcodeLoader](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/tree/main/ShellcodeLoader "ShellcodeLoader") | [Create shellcode.h](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/56ad512cdf0531b1099bbc63bade96ca33fc1300 "Create shellcode.h") | 2 years agoMar 29, 2024 |
| [.gitignore](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/4741115012608766751259dadabb37c44799c27b "Initial commit") | 2 years agoJan 13, 2024 |
| [LICENSE](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/LICENSE "LICENSE") | [Create LICENSE](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/d838cd0840f3c7c714d60a7d8b387dd981d9867d "Create LICENSE") | 2 years agoJan 13, 2024 |
| [README.md](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/README.md "README.md") | [README.md](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/README.md "README.md") | [update readme](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/2de60b4c3f23a82a9d0cd1172e7808d1ecbfd97a "update readme") | 2 years agoJan 13, 2024 |
| [ShellcodeLoader\_Indirect\_Syscalls.sln](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/ShellcodeLoader_Indirect_Syscalls.sln "ShellcodeLoader_Indirect_Syscalls.sln") | [ShellcodeLoader\_Indirect\_Syscalls.sln](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/ShellcodeLoader_Indirect_Syscalls.sln "ShellcodeLoader_Indirect_Syscalls.sln") | [initial commit](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/9a5944d6b4ee521af12aea9cacedeb104084cb65 "initial commit") | 2 years agoJan 13, 2024 |
| [create\_api\_hashes.py](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/create_api_hashes.py "create_api_hashes.py") | [create\_api\_hashes.py](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/blob/main/create_api_hashes.py "create_api_hashes.py") | [add GetModuleHandleByHash](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/commit/f940f693c8549a4ac02a2d2f6c38447f462a6895 "add GetModuleHandleByHash") | 2 years agoJan 21, 2024 |
| View all files |

## Repository files navigation

# ShellCodeLoader\_Indirect\_Syscalls

[Permalink: ShellCodeLoader_Indirect_Syscalls](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#shellcodeloader_indirect_syscalls)

Shellcode Loader using indirect syscalls

Highly inspired (read: "stolen") from the following projects:

- BokuLoader: [https://github.com/boku7/BokuLoader/tree/main](https://github.com/boku7/BokuLoader/tree/main)
- HellsGate: [https://github.com/am0nsec/HellsGate/tree/master](https://github.com/am0nsec/HellsGate/tree/master)

Make sure to also read the following article by MalwareTech: [https://malwaretech.com/2023/12/an-introduction-to-bypassing-user-mode-edr-hooks.html](https://malwaretech.com/2023/12/an-introduction-to-bypassing-user-mode-edr-hooks.html)

Created during my preperation for CRTO2 ( [https://training.zeropointsecurity.co.uk/courses/red-team-ops-ii](https://training.zeropointsecurity.co.uk/courses/red-team-ops-ii)). Will eventually be used as a basis to create a User Defined Reflective Loader for Cobalt Strike (see [https://www.cobaltstrike.com/blog/user-defined-reflective-loader-udrl-update-in-cobalt-strike-4-5](https://www.cobaltstrike.com/blog/user-defined-reflective-loader-udrl-update-in-cobalt-strike-4-5)). I decided to create a standalone shellcode loader, as this is simply easier to debug and does not need a Cobalt Strike license to play around.

At a high level the loader re-implements HellsGate but uses indirect instead of direct syscalls to make the Callstack look less suspcicious. No secrets in here and nothing new. I just wanted to implement the stuff by myself ;)

# TBD

[Permalink: TBD](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#tbd)

- replace GetModuleHandle, GetProcAddress \\w custom implementations
- API Hashing
- more sophisticated shellcode loading routines
- probably more
- (manually map ntdll)

# NB

[Permalink: NB](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#nb)

- This was developed for educational purposes only, use at your own risk

## About

Shellcode Loader using indirect syscalls


### Resources

[Readme](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#readme-ov-file)

### License

[MIT license](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls).

[Activity](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/activity)

### Stars

[**3**\\
stars](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/stargazers)

### Watchers

[**0**\\
watching](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/watchers)

### Forks

[**0**\\
forks](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fsrothlisberger6361%2FShellCodeLoader_Indirect_Syscalls&report=srothlisberger6361+%28user%29)

## [Releases](https://github.com/srothlisberger6361/ShellCodeLoader_Indirect_Syscalls/releases)

No releases published

## [Packages\  0](https://github.com/users/srothlisberger6361/packages?repo_name=ShellCodeLoader_Indirect_Syscalls)

No packages published

## Languages

- C94.7%
- Assembly2.9%
- Python2.4%

You can’t perform that action at this time.