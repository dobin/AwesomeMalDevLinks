# https://github.com/rasta-mouse/process-inject-kit

[Skip to content](https://github.com/rasta-mouse/process-inject-kit#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/rasta-mouse/process-inject-kit) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/rasta-mouse/process-inject-kit) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/rasta-mouse/process-inject-kit) to refresh your session.Dismiss alert

{{ message }}

[rasta-mouse](https://github.com/rasta-mouse)/ **[process-inject-kit](https://github.com/rasta-mouse/process-inject-kit)** Public

- [Notifications](https://github.com/login?return_to=%2Frasta-mouse%2Fprocess-inject-kit) You must be signed in to change notification settings
- [Fork\\
32](https://github.com/login?return_to=%2Frasta-mouse%2Fprocess-inject-kit)
- [Star\\
190](https://github.com/login?return_to=%2Frasta-mouse%2Fprocess-inject-kit)


Port of Cobalt Strike's Process Inject Kit


[190\\
stars](https://github.com/rasta-mouse/process-inject-kit/stargazers) [32\\
forks](https://github.com/rasta-mouse/process-inject-kit/forks) [Branches](https://github.com/rasta-mouse/process-inject-kit/branches) [Tags](https://github.com/rasta-mouse/process-inject-kit/tags) [Activity](https://github.com/rasta-mouse/process-inject-kit/activity)

[Star](https://github.com/login?return_to=%2Frasta-mouse%2Fprocess-inject-kit)

[Notifications](https://github.com/login?return_to=%2Frasta-mouse%2Fprocess-inject-kit) You must be signed in to change notification settings

# rasta-mouse/process-inject-kit

main

[**1** Branch](https://github.com/rasta-mouse/process-inject-kit/branches) [**0** Tags](https://github.com/rasta-mouse/process-inject-kit/tags)

[Go to Branches page](https://github.com/rasta-mouse/process-inject-kit/branches)[Go to Tags page](https://github.com/rasta-mouse/process-inject-kit/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![rasta-mouse](https://avatars.githubusercontent.com/u/7346521?v=4&size=40)](https://github.com/rasta-mouse)[rasta-mouse](https://github.com/rasta-mouse/process-inject-kit/commits?author=rasta-mouse)<br>[Update to latest template](https://github.com/rasta-mouse/process-inject-kit/commit/6b2267177be5ffb6bb569c20f4141900b27c84a1)<br>2 years agoDec 1, 2024<br>[6b22671](https://github.com/rasta-mouse/process-inject-kit/commit/6b2267177be5ffb6bb569c20f4141900b27c84a1) · 2 years agoDec 1, 2024<br>## History<br>[3 Commits](https://github.com/rasta-mouse/process-inject-kit/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/rasta-mouse/process-inject-kit/commits/main/) 3 Commits |
| [process-inject-explicit](https://github.com/rasta-mouse/process-inject-kit/tree/main/process-inject-explicit "process-inject-explicit") | [process-inject-explicit](https://github.com/rasta-mouse/process-inject-kit/tree/main/process-inject-explicit "process-inject-explicit") | [Update to latest template](https://github.com/rasta-mouse/process-inject-kit/commit/6b2267177be5ffb6bb569c20f4141900b27c84a1 "Update to latest template") | 2 years agoDec 1, 2024 |
| [process-inject-spawn](https://github.com/rasta-mouse/process-inject-kit/tree/main/process-inject-spawn "process-inject-spawn") | [process-inject-spawn](https://github.com/rasta-mouse/process-inject-kit/tree/main/process-inject-spawn "process-inject-spawn") | [Update to latest template](https://github.com/rasta-mouse/process-inject-kit/commit/6b2267177be5ffb6bb569c20f4141900b27c84a1 "Update to latest template") | 2 years agoDec 1, 2024 |
| [.gitattributes](https://github.com/rasta-mouse/process-inject-kit/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/rasta-mouse/process-inject-kit/blob/main/.gitattributes ".gitattributes") | [Initial commit](https://github.com/rasta-mouse/process-inject-kit/commit/1bdf5d9108a53fcd0ca07e28b7f0b3d507d2975e "Initial commit") | 2 years agoDec 1, 2024 |
| [.gitignore](https://github.com/rasta-mouse/process-inject-kit/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/rasta-mouse/process-inject-kit/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/rasta-mouse/process-inject-kit/commit/1bdf5d9108a53fcd0ca07e28b7f0b3d507d2975e "Initial commit") | 2 years agoDec 1, 2024 |
| [README.md](https://github.com/rasta-mouse/process-inject-kit/blob/main/README.md "README.md") | [README.md](https://github.com/rasta-mouse/process-inject-kit/blob/main/README.md "README.md") | [Push](https://github.com/rasta-mouse/process-inject-kit/commit/cf882176ebc9c380fc9a48c86bc195b6ce0361ee "Push") | 2 years agoDec 1, 2024 |
| [process-inject-kit.sln](https://github.com/rasta-mouse/process-inject-kit/blob/main/process-inject-kit.sln "process-inject-kit.sln") | [process-inject-kit.sln](https://github.com/rasta-mouse/process-inject-kit/blob/main/process-inject-kit.sln "process-inject-kit.sln") | [Update to latest template](https://github.com/rasta-mouse/process-inject-kit/commit/6b2267177be5ffb6bb569c20f4141900b27c84a1 "Update to latest template") | 2 years agoDec 1, 2024 |
| [process-inject.cna](https://github.com/rasta-mouse/process-inject-kit/blob/main/process-inject.cna "process-inject.cna") | [process-inject.cna](https://github.com/rasta-mouse/process-inject-kit/blob/main/process-inject.cna "process-inject.cna") | [Push](https://github.com/rasta-mouse/process-inject-kit/commit/cf882176ebc9c380fc9a48c86bc195b6ce0361ee "Push") | 2 years agoDec 1, 2024 |
| View all files |

## Repository files navigation

# Process Inject Kit

[Permalink: Process Inject Kit](https://github.com/rasta-mouse/process-inject-kit#process-inject-kit)

This is a port of Cobalt Strike's Process Inject Kit from C to the C++ BOF template.

## How it works

[Permalink: How it works](https://github.com/rasta-mouse/process-inject-kit#how-it-works)

The built in fork and run process injection techniques can be change with
the `PROCESS_INJECT_SPAWN` and `PROCESS_INJECT_EXPLICIT` hooks.

This repo provides the following:

- Source code implementing the built-in techniques.
- Aggressor script to implement the hooks.
- Visual Studio solution to compile and generate a distribution directory.

### PROCESS\_INJECT\_SPAWN

[Permalink: PROCESS_INJECT_SPAWN](https://github.com/rasta-mouse/process-inject-kit#process_inject_spawn)

Allow users to define how the `spawn` process injection technique is implemented.

### PROCESS\_INJECT\_EXPLICIT

[Permalink: PROCESS_INJECT_EXPLICIT](https://github.com/rasta-mouse/process-inject-kit#process_inject_explicit)

Allow users to define how the `explicit` process injection technique is implemented.

## References

[Permalink: References](https://github.com/rasta-mouse/process-inject-kit#references)

- [https://www.cobaltstrike.com/blog/process-injection-update-in-cobalt-strike-4-5/](https://www.cobaltstrike.com/blog/process-injection-update-in-cobalt-strike-4-5/)
- [https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics\_aggressor-scripts/as-resources\_hooks.htm#PROCESS\_INJECT\_EXPLICIT](https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics_aggressor-scripts/as-resources_hooks.htm#PROCESS_INJECT_EXPLICIT)
- [https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics\_aggressor-scripts/as-resources\_hooks.htm#PROCESS\_INJECT\_SPAWN](https://hstechdocs.helpsystems.com/manuals/cobaltstrike/current/userguide/content/topics_aggressor-scripts/as-resources_hooks.htm#PROCESS_INJECT_SPAWN)

## Usage

[Permalink: Usage](https://github.com/rasta-mouse/process-inject-kit#usage)

To use the Process Inject Kit:

- Build the VS solution in Release mode, as both x64 and x86.
- Load `process-inject.cna` into Cobalt Strike.

## Modifications

[Permalink: Modifications](https://github.com/rasta-mouse/process-inject-kit#modifications)

You're encouraged to make modifications to this code and use them in your engagements.

## License

[Permalink: License](https://github.com/rasta-mouse/process-inject-kit#license)

This code is not subject to the end user license agreement for Cobalt Strike.

## About

Port of Cobalt Strike's Process Inject Kit


### Resources

[Readme](https://github.com/rasta-mouse/process-inject-kit#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/rasta-mouse/process-inject-kit).

[Activity](https://github.com/rasta-mouse/process-inject-kit/activity)

### Stars

[**190**\\
stars](https://github.com/rasta-mouse/process-inject-kit/stargazers)

### Watchers

[**2**\\
watching](https://github.com/rasta-mouse/process-inject-kit/watchers)

### Forks

[**32**\\
forks](https://github.com/rasta-mouse/process-inject-kit/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Frasta-mouse%2Fprocess-inject-kit&report=rasta-mouse+%28user%29)

## [Releases](https://github.com/rasta-mouse/process-inject-kit/releases)

No releases published

## [Packages\  0](https://github.com/users/rasta-mouse/packages?repo_name=process-inject-kit)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/rasta-mouse/process-inject-kit).

## Languages

- [C++69.3%](https://github.com/rasta-mouse/process-inject-kit/search?l=c%2B%2B)
- [C28.6%](https://github.com/rasta-mouse/process-inject-kit/search?l=c)
- [Makefile2.1%](https://github.com/rasta-mouse/process-inject-kit/search?l=makefile)

You can’t perform that action at this time.