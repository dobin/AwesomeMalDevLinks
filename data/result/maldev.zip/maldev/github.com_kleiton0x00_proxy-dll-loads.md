# https://github.com/kleiton0x00/Proxy-DLL-Loads

[Skip to content](https://github.com/kleiton0x00/Proxy-DLL-Loads#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/kleiton0x00/Proxy-DLL-Loads) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/kleiton0x00/Proxy-DLL-Loads) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/kleiton0x00/Proxy-DLL-Loads) to refresh your session.Dismiss alert

{{ message }}

[kleiton0x00](https://github.com/kleiton0x00)/ **[Proxy-DLL-Loads](https://github.com/kleiton0x00/Proxy-DLL-Loads)** Public

- [Notifications](https://github.com/login?return_to=%2Fkleiton0x00%2FProxy-DLL-Loads) You must be signed in to change notification settings
- [Fork\\
55](https://github.com/login?return_to=%2Fkleiton0x00%2FProxy-DLL-Loads)
- [Star\\
408](https://github.com/login?return_to=%2Fkleiton0x00%2FProxy-DLL-Loads)


A proof of concept demonstrating the DLL-load proxying using undocumented Syscalls.


### License

[MIT license](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/LICENSE)

[408\\
stars](https://github.com/kleiton0x00/Proxy-DLL-Loads/stargazers) [55\\
forks](https://github.com/kleiton0x00/Proxy-DLL-Loads/forks) [Branches](https://github.com/kleiton0x00/Proxy-DLL-Loads/branches) [Tags](https://github.com/kleiton0x00/Proxy-DLL-Loads/tags) [Activity](https://github.com/kleiton0x00/Proxy-DLL-Loads/activity)

[Star](https://github.com/login?return_to=%2Fkleiton0x00%2FProxy-DLL-Loads)

[Notifications](https://github.com/login?return_to=%2Fkleiton0x00%2FProxy-DLL-Loads) You must be signed in to change notification settings

# kleiton0x00/Proxy-DLL-Loads

main

[**2** Branches](https://github.com/kleiton0x00/Proxy-DLL-Loads/branches) [**0** Tags](https://github.com/kleiton0x00/Proxy-DLL-Loads/tags)

[Go to Branches page](https://github.com/kleiton0x00/Proxy-DLL-Loads/branches)[Go to Tags page](https://github.com/kleiton0x00/Proxy-DLL-Loads/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![kleiton0x00](https://avatars.githubusercontent.com/u/37262788?v=4&size=40)](https://github.com/kleiton0x00)[kleiton0x00](https://github.com/kleiton0x00/Proxy-DLL-Loads/commits?author=kleiton0x00)<br>[Added Tp Function PoC with call gadget](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/574a4216257593dc3407f187f4bf83bb48c7b95a)<br>last monthJan 11, 2026<br>[574a421](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/574a4216257593dc3407f187f4bf83bb48c7b95a) · last monthJan 11, 2026<br>## History<br>[19 Commits](https://github.com/kleiton0x00/Proxy-DLL-Loads/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/kleiton0x00/Proxy-DLL-Loads/commits/main/) 19 Commits |
| [TpGadget](https://github.com/kleiton0x00/Proxy-DLL-Loads/tree/main/TpGadget "TpGadget") | [TpGadget](https://github.com/kleiton0x00/Proxy-DLL-Loads/tree/main/TpGadget "TpGadget") | [Added Tp Function PoC with call gadget](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/574a4216257593dc3407f187f4bf83bb48c7b95a "Added Tp Function PoC with call gadget") | last monthJan 11, 2026 |
| [LICENSE](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/74b239e65d89cd52c3a7e1f547a32352acccf1f1 "Initial commit") | 3 years agoOct 23, 2023 |
| [README.md](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/README.md "README.md") | [README.md](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/README.md "README.md") | [Added Tp Function PoC with call gadget](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/574a4216257593dc3407f187f4bf83bb48c7b95a "Added Tp Function PoC with call gadget") | last monthJan 11, 2026 |
| [TpAllocTimer.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/TpAllocTimer.c "TpAllocTimer.c") | [TpAllocTimer.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/TpAllocTimer.c "TpAllocTimer.c") | [Add files via upload](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/e6be2a9d0e1760e453bc36319acb46423fac30ff "Add files via upload") | 3 years agoOct 23, 2023 |
| [TpAllocWait.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/TpAllocWait.c "TpAllocWait.c") | [TpAllocWait.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/TpAllocWait.c "TpAllocWait.c") | [Add files via upload](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/f233e5ee164bc06d317cf51757986e3758fe250d "Add files via upload") | 2 years agoMar 23, 2024 |
| [ninja-guard-proxy-load.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/ninja-guard-proxy-load.c "ninja-guard-proxy-load.c") | [ninja-guard-proxy-load.c](https://github.com/kleiton0x00/Proxy-DLL-Loads/blob/main/ninja-guard-proxy-load.c "ninja-guard-proxy-load.c") | [Updated code](https://github.com/kleiton0x00/Proxy-DLL-Loads/commit/f2966001e458250322fac4279abaa841e5866087 "Updated code") | last yearFeb 10, 2025 |
| View all files |

## Repository files navigation

# Proxy DLL Loads

[Permalink: Proxy DLL Loads](https://github.com/kleiton0x00/Proxy-DLL-Loads#proxy-dll-loads)

A repository with different scripts to demonstrate the DLL-load proxying using undocumented Functions and VEH. This repo is not about teaching you what DLL Load proxying is and how it works, it is greatly explained on [this blogpost](https://0xdarkvortex.dev/proxying-dll-loads-for-hiding-etwti-stack-tracing/). Instead, the main focus is on explaining how the DLL be loaded using VEH and on finding undocumented callback functions by reversing the DLLs and creating your own version. Below are the two methods used to proxy DLL Load:

## 1\. VEH

[Permalink: 1. VEH](https://github.com/kleiton0x00/Proxy-DLL-Loads#1-veh)

We'll leverage the **VEH (Vectored Exception Handler)** to modify the context, especially RIP register to take us to the LoadLibraryA, and the RCX to hold the function's argument (module name) of `LoadLibraryA`. To trigger our exception, VirtualProtect is used to set the page to `PAGE_GUARD`, thus triggering the `STATUS_GUARD_PAGE_VIOLATION`.

## 2\. Tp\* Functions

[Permalink: 2. Tp* Functions](https://github.com/kleiton0x00/Proxy-DLL-Loads#2-tp-functions)

### Hunting for undocumented functions

[Permalink: Hunting for undocumented functions](https://github.com/kleiton0x00/Proxy-DLL-Loads#hunting-for-undocumented-functions)

Before getting in directly to reversing the DLLs, we need to first know what to look for. We can start by looking at the Microsoft documentation (MSDN), which provides an excellent [example](https://learn.microsoft.com/en-us/windows/win32/procthread/using-the-thread-pool-functions?source=recommendations) of a custom thread pool, which creates a work item and a thread pool timer. The code alone is also suitable for archiving the execution of `LoadLibrary` via callback functions, but as already known, the userland functions are prone to hooking. So using their respective function would be a better approach. Looking at the MSDN documentation, the example code uses the following Win32API functions:

```
CreateThreadpool
SetThreadpoolThreadMaximum
SetThreadpoolThreadMinimum
CreateThreadpoolCleanupGroup
CreateThreadpoolTimer
SetThreadpoolTimer
CloseThreadpoolCleanupGroupMembers
```

If you use [IDA](https://hex-rays.com/ida-free/), open kernel32.dll, go to "Exports" and search for the mentioned Win32 APIs, in this case `CreateThreadpool`. Double-clicking the function redirect us to its dissassembled code:

[![Screenshot from 2023-10-23 10-33-17](https://private-user-images.githubusercontent.com/37262788/277288779-8422c046-13df-45fd-8c48-1371f52e9f43.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI4NTksIm5iZiI6MTc3MTQxMjU1OSwicGF0aCI6Ii8zNzI2Mjc4OC8yNzcyODg3NzktODQyMmMwNDYtMTNkZi00NWZkLThjNDgtMTM3MWY1MmU5ZjQzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTM3NmFlNDVkM2Q4YzIwMWY0NjZiNzVmNzhiOTY4NTk5ZjY0YmNkNGQ4NTAzNmYwYjM1MjQ4ODg1NjU4YTMzM2QmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.-lhDTF0VoXANWsyMib7i-vbL6jMQ4wOarVOH8BXAiPQ)](https://private-user-images.githubusercontent.com/37262788/277288779-8422c046-13df-45fd-8c48-1371f52e9f43.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI4NTksIm5iZiI6MTc3MTQxMjU1OSwicGF0aCI6Ii8zNzI2Mjc4OC8yNzcyODg3NzktODQyMmMwNDYtMTNkZi00NWZkLThjNDgtMTM3MWY1MmU5ZjQzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTM3NmFlNDVkM2Q4YzIwMWY0NjZiNzVmNzhiOTY4NTk5ZjY0YmNkNGQ4NTAzNmYwYjM1MjQ4ODg1NjU4YTMzM2QmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.-lhDTF0VoXANWsyMib7i-vbL6jMQ4wOarVOH8BXAiPQ)

Through the assembly instructions, we see the `TpAllocPool` function being executed: `call    cs:__imp_TpAllocPool`

If you repeat the process with the other functions, you will end up with the following functions:

```
Ntdll!TpAllocPool
Ntdll!TpSetPoolMaxThreads
Ntdll!TpSetPoolMinThreads
Ntdll!TpAllocCleanupGroup
Ntdll!TpAllocTimer
Ntdll!TpSetTimer
Ntdll!TpReleaseCleanupGroupMembers
```

Now you have everything you need to start creating your own version of proxying the DLL Loads. You can look at [this documentation](https://processhacker.sourceforge.io/doc/nttp_8h.html#adad18de6710381f08cf36a0fa72e7529) from Process Hacker to help you implement the undocumented functions in your code.

### Debugging

[Permalink: Debugging](https://github.com/kleiton0x00/Proxy-DLL-Loads#debugging)

Set a breakpoint before the assembly code in Callbackstub get's executed. Look at right tab of [x64dbg](https://x64dbg.com/) as the registers are being populated.

demo\_dbg.mp4

```
RAX -> pointer to LoadLibraryA
RCX -> library name string
```

### Result

[Permalink: Result](https://github.com/kleiton0x00/Proxy-DLL-Loads#result)

[![Screenshot from 2023-10-21 20-21-05](https://private-user-images.githubusercontent.com/37262788/277288485-2db0e36d-53e9-4697-b976-b1260f5bfcdd.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI4NTksIm5iZiI6MTc3MTQxMjU1OSwicGF0aCI6Ii8zNzI2Mjc4OC8yNzcyODg0ODUtMmRiMGUzNmQtNTNlOS00Njk3LWI5NzYtYjEyNjBmNWJmY2RkLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWFlOWI5NTBjZDRjMWY4MGZjMDg4NTdhNjQzYzJhOWIzZjE4OTgzMzdiMDY0N2VmY2Y2MWFkODQxYjQ0OGUxNzEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.nOiUaKZWNRTPqeELHxN5SSiIUZypT1R6oTiMFdg5u5w)](https://private-user-images.githubusercontent.com/37262788/277288485-2db0e36d-53e9-4697-b976-b1260f5bfcdd.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI4NTksIm5iZiI6MTc3MTQxMjU1OSwicGF0aCI6Ii8zNzI2Mjc4OC8yNzcyODg0ODUtMmRiMGUzNmQtNTNlOS00Njk3LWI5NzYtYjEyNjBmNWJmY2RkLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWFlOWI5NTBjZDRjMWY4MGZjMDg4NTdhNjQzYzJhOWIzZjE4OTgzMzdiMDY0N2VmY2Y2MWFkODQxYjQ0OGUxNzEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.nOiUaKZWNRTPqeELHxN5SSiIUZypT1R6oTiMFdg5u5w)

## 3\. Tp\* Functions with Call Gadget

[Permalink: 3. Tp* Functions with Call Gadget](https://github.com/kleiton0x00/Proxy-DLL-Loads#3-tp-functions-with-call-gadget)

This is the same as the Tp\* PoC, but additionally uses call gadgets from `AuthenticateFAM_SecureFP.dll` to insert arbitrary modules in the call stack during module load, breaking signatures used in detection rules.

Below is the dissassembled part where the call gadget and ret is located:

```
AuthenticateFAM_SecureFP.dll:
   1800041db:   ff d0                   call   rax
   1800041dd:   33 c0                   xor    eax,eax
   1800041df:   48 83 c4 28             add    rsp,0x28
   1800041e3:   c3                      ret
```

The use of gadgets was introduced to bypass [Elastic callstack detection rule](https://github.com/elastic/protections-artifacts/blob/6e9ee22c5a7f57b85b0cb063adba9a3c72eca348/behavior/rules/windows/defense_evasion_library_loaded_via_a_callback_function.toml). For more technical information on how this works, please refer to the initial [research](https://offsec.almond.consulting/evading-elastic-callstack-signatures.html) by [@SAERXCIT](https://github.com/SAERXCIT).

## Resources

[Permalink: Resources](https://github.com/kleiton0x00/Proxy-DLL-Loads#resources)

[https://0xdarkvortex.dev/proxying-dll-loads-for-hiding-etwti-stack-tracing/](https://0xdarkvortex.dev/proxying-dll-loads-for-hiding-etwti-stack-tracing/)

[https://github.com/hlldz/misc/tree/main/proxy\_calls](https://github.com/hlldz/misc/tree/main/proxy_calls)

[https://processhacker.sourceforge.io/doc/nttp\_8h.html#adad18de6710381f08cf36a0fa72e7529](https://processhacker.sourceforge.io/doc/nttp_8h.html#adad18de6710381f08cf36a0fa72e7529)

[https://offsec.almond.consulting/evading-elastic-callstack-signatures.html](https://offsec.almond.consulting/evading-elastic-callstack-signatures.html)

## OPSEC Considerations

[Permalink: OPSEC Considerations](https://github.com/kleiton0x00/Proxy-DLL-Loads#opsec-considerations)

- Custom implmentation of GetModuleHandleA/GetProcAddress
- Don't use VirtualProtect to trigger the VEH

## Detections

[Permalink: Detections](https://github.com/kleiton0x00/Proxy-DLL-Loads#detections)

[https://github.com/elastic/protections-artifacts/blob/main/behavior/rules/defense\_evasion\_library\_loaded\_via\_a\_callback\_function.toml](https://github.com/elastic/protections-artifacts/blob/main/behavior/rules/defense_evasion_library_loaded_via_a_callback_function.toml)

## About

A proof of concept demonstrating the DLL-load proxying using undocumented Syscalls.


### Resources

[Readme](https://github.com/kleiton0x00/Proxy-DLL-Loads#readme-ov-file)

### License

[MIT license](https://github.com/kleiton0x00/Proxy-DLL-Loads#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/kleiton0x00/Proxy-DLL-Loads).

[Activity](https://github.com/kleiton0x00/Proxy-DLL-Loads/activity)

### Stars

[**408**\\
stars](https://github.com/kleiton0x00/Proxy-DLL-Loads/stargazers)

### Watchers

[**7**\\
watching](https://github.com/kleiton0x00/Proxy-DLL-Loads/watchers)

### Forks

[**55**\\
forks](https://github.com/kleiton0x00/Proxy-DLL-Loads/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fkleiton0x00%2FProxy-DLL-Loads&report=kleiton0x00+%28user%29)

## [Releases](https://github.com/kleiton0x00/Proxy-DLL-Loads/releases)

No releases published

## [Packages\  0](https://github.com/users/kleiton0x00/packages?repo_name=Proxy-DLL-Loads)

No packages published

## Languages

- [C72.0%](https://github.com/kleiton0x00/Proxy-DLL-Loads/search?l=c)
- [C++21.9%](https://github.com/kleiton0x00/Proxy-DLL-Loads/search?l=c%2B%2B)
- [Assembly6.1%](https://github.com/kleiton0x00/Proxy-DLL-Loads/search?l=assembly)

You can’t perform that action at this time.