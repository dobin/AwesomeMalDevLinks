# https://github.com/ProcessusT/Venoma

[Skip to content](https://github.com/ProcessusT/Venoma#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ProcessusT/Venoma) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ProcessusT/Venoma) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ProcessusT/Venoma) to refresh your session.Dismiss alert

{{ message }}

[ProcessusT](https://github.com/ProcessusT)/ **[Venoma](https://github.com/ProcessusT/Venoma)** Public

- [Notifications](https://github.com/login?return_to=%2FProcessusT%2FVenoma) You must be signed in to change notification settings
- [Fork\\
41](https://github.com/login?return_to=%2FProcessusT%2FVenoma)
- [Star\\
198](https://github.com/login?return_to=%2FProcessusT%2FVenoma)


Yet another C++ Cobalt Strike beacon dropper with Compile-Time API hashing and custom indirect syscalls execution


[processus.site](https://processus.site/ "https://processus.site")

[198\\
stars](https://github.com/ProcessusT/Venoma/stargazers) [41\\
forks](https://github.com/ProcessusT/Venoma/forks) [Branches](https://github.com/ProcessusT/Venoma/branches) [Tags](https://github.com/ProcessusT/Venoma/tags) [Activity](https://github.com/ProcessusT/Venoma/activity)

[Star](https://github.com/login?return_to=%2FProcessusT%2FVenoma)

[Notifications](https://github.com/login?return_to=%2FProcessusT%2FVenoma) You must be signed in to change notification settings

# ProcessusT/Venoma

main

[**1** Branch](https://github.com/ProcessusT/Venoma/branches) [**0** Tags](https://github.com/ProcessusT/Venoma/tags)

[Go to Branches page](https://github.com/ProcessusT/Venoma/branches)[Go to Tags page](https://github.com/ProcessusT/Venoma/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![ProcessusT](https://avatars.githubusercontent.com/u/13833925?v=4&size=40)](https://github.com/ProcessusT)[ProcessusT](https://github.com/ProcessusT/Venoma/commits?author=ProcessusT)<br>[Update README.md](https://github.com/ProcessusT/Venoma/commit/787d87015f8a5be6857b9c702049648a20e4de21)<br>9 months agoMay 29, 2025<br>[787d870](https://github.com/ProcessusT/Venoma/commit/787d87015f8a5be6857b9c702049648a20e4de21) · 9 months agoMay 29, 2025<br>## History<br>[36 Commits](https://github.com/ProcessusT/Venoma/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ProcessusT/Venoma/commits/main/) 36 Commits |
| [.vs/Venomma](https://github.com/ProcessusT/Venoma/tree/main/.vs/Venomma "This path skips through empty directories") | [.vs/Venomma](https://github.com/ProcessusT/Venoma/tree/main/.vs/Venomma "This path skips through empty directories") | [add perun's fart](https://github.com/ProcessusT/Venoma/commit/ca58239f533df7a7945a59feee26bb49eb71638a "add perun's fart") | 2 years agoMar 19, 2024 |
| [Kobra](https://github.com/ProcessusT/Venoma/tree/main/Kobra "Kobra") | [Kobra](https://github.com/ProcessusT/Venoma/tree/main/Kobra "Kobra") | [add perun's fart](https://github.com/ProcessusT/Venoma/commit/ca58239f533df7a7945a59feee26bb49eb71638a "add perun's fart") | 2 years agoMar 19, 2024 |
| [assets](https://github.com/ProcessusT/Venoma/tree/main/assets "assets") | [assets](https://github.com/ProcessusT/Venoma/tree/main/assets "assets") | [bypass demo 2](https://github.com/ProcessusT/Venoma/commit/c638d3656930e3f1f5c7a4eb1f037585dc0976f7 "bypass demo 2") | 2 years agoMar 19, 2024 |
| [README.md](https://github.com/ProcessusT/Venoma/blob/main/README.md "README.md") | [README.md](https://github.com/ProcessusT/Venoma/blob/main/README.md "README.md") | [Update README.md](https://github.com/ProcessusT/Venoma/commit/787d87015f8a5be6857b9c702049648a20e4de21 "Update README.md") | 9 months agoMay 29, 2025 |
| [Venomma.sln](https://github.com/ProcessusT/Venoma/blob/main/Venomma.sln "Venomma.sln") | [Venomma.sln](https://github.com/ProcessusT/Venoma/blob/main/Venomma.sln "Venomma.sln") | [v2](https://github.com/ProcessusT/Venoma/commit/7ba41f07600c9af2d13f4d55d5273b26e50f39f2 "v2") | 2 years agoJan 25, 2024 |
| [aes.py](https://github.com/ProcessusT/Venoma/blob/main/aes.py "aes.py") | [aes.py](https://github.com/ProcessusT/Venoma/blob/main/aes.py "aes.py") | [add apc exec](https://github.com/ProcessusT/Venoma/commit/6c6ed6aa623272a920b3c4f316b91db86c868cc5 "add apc exec") | 2 years agoFeb 1, 2024 |
| View all files |

## Repository files navigation

# Venoma

[Permalink: Venoma](https://github.com/ProcessusT/Venoma#venoma)

[![](https://camo.githubusercontent.com/33fc3a6bcf2e3df118cfad8caddc3760a4c50f10193dcd5a4deb25da6c282449/68747470733a2f2f696d672e736869656c64732e696f2f747769747465722f666f6c6c6f772f50726f636573737573543f6c6162656c3d50726f63657373757354267374796c653d736f6369616c)](https://twitter.com/intent/follow?screen_name=ProcessusT "Follow")

# Yet another ☠️ Cobalt Strike ☠️ beacon dropper

[Permalink:\
    Yet another ☠️ Cobalt Strike ☠️ beacon dropper](https://github.com/ProcessusT/Venoma#----yet-another-%EF%B8%8F-cobalt-strike-%EF%B8%8F-beacon-dropper--)

> A custom C++ raw beacon dropper with :
>
> **Compile Time API Hashing**
>
> **Run-Time Dynamic Linking**
>
> **PPID spoofing**
>
> **DLL Unhooking (Fresh + Perun's fart)**
>
> **ETW Patching**
>
> **EnumPageFilesW execution**
>
> **Local & remote APC Execution**
>
> **Indirect syscall execution**
>
> **Cobalt Strike Artifact kit integration**
>
> **Self deletion**

#### All functions are included, choose what you need and remove anything else before compiling.

[Permalink: All functions are included, choose what you need and remove anything else before compiling.](https://github.com/ProcessusT/Venoma#all-functions-are-included-choose-what-you-need-and-remove-anything-else-before-compiling)

[![](https://github.com/ProcessusT/Venoma/raw/main/assets/bypass2.png)](https://github.com/ProcessusT/Venoma/raw/main/assets/bypass2.png)

[![](https://github.com/ProcessusT/Venoma/raw/main/assets/demo.jpg)](https://github.com/ProcessusT/Venoma/raw/main/assets/demo.jpg)

[![](https://github.com/ProcessusT/Venoma/raw/main/assets/IAT%20obfuscation.jpg)](https://github.com/ProcessusT/Venoma/raw/main/assets/IAT%20obfuscation.jpg)

[![](https://github.com/ProcessusT/Venoma/raw/main/assets/strings.jpg)](https://github.com/ProcessusT/Venoma/raw/main/assets/strings.jpg)

## Cobalt Strike artifact kit integration

[Permalink: Cobalt Strike artifact kit integration](https://github.com/ProcessusT/Venoma#cobalt-strike-artifact-kit-integration)

\> Compile the project and rename the binary to artifact64big.exe

\> Add your own artifact.cna in the same folder

\> Load your cna into Cobalt Strike and generate a stageless Windows payload

\> Enjoy

Video tutorial here : [https://www.youtube.com/watch?v=tGa3xJymEfY](https://youtu.be/lFO2bPzxLGI?si=RmvFmliroacXW6Sk)

## What da fuck is this ?

[Permalink: What da fuck is this ?](https://github.com/ProcessusT/Venoma#what-da-fuck-is-this-)

I would learn more about antivirus evasion so I made a video on Youtube :

[https://www.youtube.com/watch?v=lFO2bPzxLGI](https://www.youtube.com/watch?v=lFO2bPzxLGI)

## About

Yet another C++ Cobalt Strike beacon dropper with Compile-Time API hashing and custom indirect syscalls execution


[processus.site](https://processus.site/ "https://processus.site")

### Topics

[red](https://github.com/topics/red "Topic: red") [cobalt](https://github.com/topics/cobalt "Topic: cobalt") [malware](https://github.com/topics/malware "Topic: malware") [antivirus](https://github.com/topics/antivirus "Topic: antivirus") [syscalls](https://github.com/topics/syscalls "Topic: syscalls") [team](https://github.com/topics/team "Topic: team") [pentest](https://github.com/topics/pentest "Topic: pentest") [bypass](https://github.com/topics/bypass "Topic: bypass") [payload](https://github.com/topics/payload "Topic: payload") [dropper](https://github.com/topics/dropper "Topic: dropper") [strike](https://github.com/topics/strike "Topic: strike") [c2](https://github.com/topics/c2 "Topic: c2") [edr](https://github.com/topics/edr "Topic: edr") [indirect](https://github.com/topics/indirect "Topic: indirect")

### Resources

[Readme](https://github.com/ProcessusT/Venoma#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ProcessusT/Venoma).

[Activity](https://github.com/ProcessusT/Venoma/activity)

### Stars

[**198**\\
stars](https://github.com/ProcessusT/Venoma/stargazers)

### Watchers

[**9**\\
watching](https://github.com/ProcessusT/Venoma/watchers)

### Forks

[**41**\\
forks](https://github.com/ProcessusT/Venoma/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FProcessusT%2FVenoma&report=ProcessusT+%28user%29)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ProcessusT/Venoma).

## Languages

- [C++100.0%](https://github.com/ProcessusT/Venoma/search?l=c%2B%2B)

You can’t perform that action at this time.