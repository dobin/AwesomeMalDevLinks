# https://github.com/rasta-mouse/Crystal-Kit

[Skip to content](https://github.com/rasta-mouse/Crystal-Kit#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/rasta-mouse/Crystal-Kit) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/rasta-mouse/Crystal-Kit) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/rasta-mouse/Crystal-Kit) to refresh your session.Dismiss alert

{{ message }}

[rasta-mouse](https://github.com/rasta-mouse)/ **[Crystal-Kit](https://github.com/rasta-mouse/Crystal-Kit)** Public

- [Notifications](https://github.com/login?return_to=%2Frasta-mouse%2FCrystal-Kit) You must be signed in to change notification settings
- [Fork\\
45](https://github.com/login?return_to=%2Frasta-mouse%2FCrystal-Kit)
- [Star\\
379](https://github.com/login?return_to=%2Frasta-mouse%2FCrystal-Kit)


Evasion kit for Cobalt Strike


### License

[MIT license](https://github.com/rasta-mouse/Crystal-Kit/blob/main/LICENSE)

[379\\
stars](https://github.com/rasta-mouse/Crystal-Kit/stargazers) [45\\
forks](https://github.com/rasta-mouse/Crystal-Kit/forks) [Branches](https://github.com/rasta-mouse/Crystal-Kit/branches) [Tags](https://github.com/rasta-mouse/Crystal-Kit/tags) [Activity](https://github.com/rasta-mouse/Crystal-Kit/activity)

[Star](https://github.com/login?return_to=%2Frasta-mouse%2FCrystal-Kit)

[Notifications](https://github.com/login?return_to=%2Frasta-mouse%2FCrystal-Kit) You must be signed in to change notification settings

# rasta-mouse/Crystal-Kit

main

[**2** Branches](https://github.com/rasta-mouse/Crystal-Kit/branches) [**0** Tags](https://github.com/rasta-mouse/Crystal-Kit/tags)

[Go to Branches page](https://github.com/rasta-mouse/Crystal-Kit/branches)[Go to Tags page](https://github.com/rasta-mouse/Crystal-Kit/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![rasta-mouse](https://avatars.githubusercontent.com/u/7346521?v=4&size=40)](https://github.com/rasta-mouse)[rasta-mouse](https://github.com/rasta-mouse/Crystal-Kit/commits?author=rasta-mouse)<br>[Merge pull request](https://github.com/rasta-mouse/Crystal-Kit/commit/e234f9adafda01b36ec6443e0912a16a1819a980) [#2](https://github.com/rasta-mouse/Crystal-Kit/pull/2) [from gsmith257-cyber/add-hook-for-HttpSendRequestA](https://github.com/rasta-mouse/Crystal-Kit/commit/e234f9adafda01b36ec6443e0912a16a1819a980)<br>Open commit details<br>last monthJan 17, 2026<br>[e234f9a](https://github.com/rasta-mouse/Crystal-Kit/commit/e234f9adafda01b36ec6443e0912a16a1819a980) · last monthJan 17, 2026<br>## History<br>[26 Commits](https://github.com/rasta-mouse/Crystal-Kit/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/rasta-mouse/Crystal-Kit/commits/main/) 26 Commits |
| [loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/loader "loader") | [loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/loader "loader") | [fix: Add hook for HttpSendRequestA](https://github.com/rasta-mouse/Crystal-Kit/commit/c9ccae3cfa21d4ab40c999bb1736ff1695845e99 "fix: Add hook for HttpSendRequestA") | last monthJan 15, 2026 |
| [local-loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/local-loader "local-loader") | [local-loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/local-loader "local-loader") | [fix: Add hook for HttpSendRequestA](https://github.com/rasta-mouse/Crystal-Kit/commit/c9ccae3cfa21d4ab40c999bb1736ff1695845e99 "fix: Add hook for HttpSendRequestA") | last monthJan 15, 2026 |
| [postex-loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/postex-loader "postex-loader") | [postex-loader](https://github.com/rasta-mouse/Crystal-Kit/tree/main/postex-loader "postex-loader") | [update sleep mask](https://github.com/rasta-mouse/Crystal-Kit/commit/57cf7439470ef8570dde41c293e58fa029ed014d "update sleep mask") | 2 months agoDec 30, 2025 |
| [.gitattributes](https://github.com/rasta-mouse/Crystal-Kit/blob/main/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/rasta-mouse/Crystal-Kit/blob/main/.gitattributes ".gitattributes") | [Initial commit](https://github.com/rasta-mouse/Crystal-Kit/commit/2a4da97c4e45ea453ee03b3b933668598e42c5be "Initial commit") | 4 months agoOct 12, 2025 |
| [.gitignore](https://github.com/rasta-mouse/Crystal-Kit/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/rasta-mouse/Crystal-Kit/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/rasta-mouse/Crystal-Kit/commit/2a4da97c4e45ea453ee03b3b933668598e42c5be "Initial commit") | 4 months agoOct 12, 2025 |
| [LICENSE](https://github.com/rasta-mouse/Crystal-Kit/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/rasta-mouse/Crystal-Kit/blob/main/LICENSE "LICENSE") | [Update LICENSE](https://github.com/rasta-mouse/Crystal-Kit/commit/3205c7b3d823dfb552bd04a8234ee42a863e66f0 "Update LICENSE") | 4 months agoOct 30, 2025 |
| [Makefile](https://github.com/rasta-mouse/Crystal-Kit/blob/main/Makefile "Makefile") | [Makefile](https://github.com/rasta-mouse/Crystal-Kit/blob/main/Makefile "Makefile") | [big update](https://github.com/rasta-mouse/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| [README.md](https://github.com/rasta-mouse/Crystal-Kit/blob/main/README.md "README.md") | [README.md](https://github.com/rasta-mouse/Crystal-Kit/blob/main/README.md "README.md") | [big update](https://github.com/rasta-mouse/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| [crystalkit.cna](https://github.com/rasta-mouse/Crystal-Kit/blob/main/crystalkit.cna "crystalkit.cna") | [crystalkit.cna](https://github.com/rasta-mouse/Crystal-Kit/blob/main/crystalkit.cna "crystalkit.cna") | [big update](https://github.com/rasta-mouse/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| [libtcg.x64.zip](https://github.com/rasta-mouse/Crystal-Kit/blob/main/libtcg.x64.zip "libtcg.x64.zip") | [libtcg.x64.zip](https://github.com/rasta-mouse/Crystal-Kit/blob/main/libtcg.x64.zip "libtcg.x64.zip") | [big update](https://github.com/rasta-mouse/Crystal-Kit/commit/defeef68df6e95440a6cd8559d4459bf1606d598 "big update") | 2 months agoDec 3, 2025 |
| View all files |

## Repository files navigation

# Crystal Kit

[Permalink: Crystal Kit](https://github.com/rasta-mouse/Crystal-Kit#crystal-kit)

This repo is a technical and social experiment to explore whether replacing Cobalt Strike's evasion primitives (Sleepmask/BeaconGate) with a [Crystal Palace](https://tradecraftgarden.org/) PICO is feasible (or even desirable) for advanced evasion scenarios.

## Usage

[Permalink: Usage](https://github.com/rasta-mouse/Crystal-Kit#usage)

1. Disable the sleepmask and stage obfuscations in Malleable C2.

```
stage {
    set sleep_mask "false";
    set cleanup "true";
    transform-obfuscate { }
}

post-ex {
    set cleanup "true";
    set smartinject "true";
}
```

2. Copy `crystalpalace.jar` to your Cobalt Strike client directory.
3. Load `crystalkit.cna`.

### Notes

[Permalink: Notes](https://github.com/rasta-mouse/Crystal-Kit#notes)

- Tested on Cobalt Strike 4.12.
- Can work with any post-ex DLL capability.

## About

Evasion kit for Cobalt Strike


### Resources

[Readme](https://github.com/rasta-mouse/Crystal-Kit#readme-ov-file)

### License

[MIT license](https://github.com/rasta-mouse/Crystal-Kit#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/rasta-mouse/Crystal-Kit).

[Activity](https://github.com/rasta-mouse/Crystal-Kit/activity)

### Stars

[**379**\\
stars](https://github.com/rasta-mouse/Crystal-Kit/stargazers)

### Watchers

[**3**\\
watching](https://github.com/rasta-mouse/Crystal-Kit/watchers)

### Forks

[**45**\\
forks](https://github.com/rasta-mouse/Crystal-Kit/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Frasta-mouse%2FCrystal-Kit&report=rasta-mouse+%28user%29)

## [Contributors\  2](https://github.com/rasta-mouse/Crystal-Kit/graphs/contributors)

- [![@rasta-mouse](https://avatars.githubusercontent.com/u/7346521?s=64&v=4)](https://github.com/rasta-mouse)[**rasta-mouse** Rasta Mouse](https://github.com/rasta-mouse)
- [![@gsmith257-cyber](https://avatars.githubusercontent.com/u/55564824?s=64&v=4)](https://github.com/gsmith257-cyber)[**gsmith257-cyber** S1n1st3r](https://github.com/gsmith257-cyber)

## Languages

- [C82.3%](https://github.com/rasta-mouse/Crystal-Kit/search?l=c)
- [Assembly10.7%](https://github.com/rasta-mouse/Crystal-Kit/search?l=assembly)
- [Ruby5.2%](https://github.com/rasta-mouse/Crystal-Kit/search?l=ruby)
- [Makefile1.6%](https://github.com/rasta-mouse/Crystal-Kit/search?l=makefile)
- [Python0.2%](https://github.com/rasta-mouse/Crystal-Kit/search?l=python)

You can’t perform that action at this time.