# https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution

[Skip to content](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution) to refresh your session.Dismiss alert

{{ message }}

[andreisss](https://github.com/andreisss)/ **[Remote-DLL-Injection-with-Timer-based-Shellcode-Execution](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution)** Public

- [Notifications](https://github.com/login?return_to=%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution) You must be signed in to change notification settings
- [Fork\\
37](https://github.com/login?return_to=%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution)
- [Star\\
154](https://github.com/login?return_to=%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution)


Remote DLL Injection with Timer-based Shellcode Execution


### License

[GPL-3.0 license](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/LICENSE)

[154\\
stars](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/stargazers) [37\\
forks](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/forks) [Branches](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/branches) [Tags](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/tags) [Activity](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/activity)

[Star](https://github.com/login?return_to=%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution)

[Notifications](https://github.com/login?return_to=%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution) You must be signed in to change notification settings

# andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution

main

[**1** Branch](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/branches) [**0** Tags](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/tags)

[Go to Branches page](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/branches)[Go to Tags page](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![andreisss](https://avatars.githubusercontent.com/u/10872139?v=4&size=40)](https://github.com/andreisss)[andreisss](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commits?author=andreisss)<br>[Update README.md](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/75aae206184b41c46bdaecaf0580f074084cd729)<br>7 months agoJul 18, 2025<br>[75aae20](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/75aae206184b41c46bdaecaf0580f074084cd729) · 7 months agoJul 18, 2025<br>## History<br>[19 Commits](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commits/main/) 19 Commits |
| [ConsoleApplication5.cpp](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/ConsoleApplication5.cpp "ConsoleApplication5.cpp") | [ConsoleApplication5.cpp](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/ConsoleApplication5.cpp "ConsoleApplication5.cpp") | [Add files via upload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/e8e56764ed5e64708493ee0061035d4eb961fd0c "Add files via upload") | 7 months agoJul 16, 2025 |
| [ConsoleApplication5.exe](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/ConsoleApplication5.exe "ConsoleApplication5.exe") | [ConsoleApplication5.exe](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/ConsoleApplication5.exe "ConsoleApplication5.exe") | [Add files via upload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/e8e56764ed5e64708493ee0061035d4eb961fd0c "Add files via upload") | 7 months agoJul 16, 2025 |
| [Dll1.dll](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/Dll1.dll "Dll1.dll") | [Dll1.dll](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/Dll1.dll "Dll1.dll") | [Add files via upload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/e8e56764ed5e64708493ee0061035d4eb961fd0c "Add files via upload") | 7 months agoJul 16, 2025 |
| [LICENSE](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/0ef60388cbaf391d421ad1a92a25eeffd6a559a7 "Initial commit") | 7 months agoJul 16, 2025 |
| [README.md](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/README.md "README.md") | [README.md](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/README.md "README.md") | [Update README.md](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/75aae206184b41c46bdaecaf0580f074084cd729 "Update README.md") | 7 months agoJul 18, 2025 |
| [dllmain.cpp](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/dllmain.cpp "dllmain.cpp") | [dllmain.cpp](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/blob/main/dllmain.cpp "dllmain.cpp") | [Add files via upload](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/commit/e8e56764ed5e64708493ee0061035d4eb961fd0c "Add files via upload") | 7 months agoJul 16, 2025 |
| View all files |

## Repository files navigation

# Remote DLL Injection with Timer-based Shellcode Execution

[Permalink: Remote DLL Injection with Timer-based Shellcode Execution](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#remote-dll-injection-with-timer-based-shellcode-execution)

### Documentation updated from previous mistake proces injection title!

[Permalink: Documentation updated from previous mistake proces injection title!](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#documentation-updated-from-previous-mistake-proces-injection-title)

> ⚠ **Educational Research Only**
>
> This repository contains security research for **educational purposes** and **authorized use only**.
>
> Use responsibly and in accordance with all applicable laws and regulations.

* * *

## Overview

[Permalink: Overview](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#overview)

**Remote DLL Injection with Timer-based Shellcode Execution** is a technique that leverages the Windows thread pool to execute shellcode. Using the classic DLL injection with CreateThreadpoolTimer to run shellcode in-memory using legit system threads, stealthy, and likely to slip past modern defenses

This approach introduces a stealthy execution using Timer-based Shellcode Execution

* * *

[![Recording 2025-07-16 1317152323](https://private-user-images.githubusercontent.com/10872139/467098118-fe7d0f6f-a1e0-4198-8e06-dec994e42bd6.gif?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTgxMTgtZmU3ZDBmNmYtYTFlMC00MTk4LThlMDYtZGVjOTk0ZTQyYmQ2LmdpZj9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTIxMTI5MWI5OWM4MTNjYmI1M2Q0MWIwMTUwMmY1Y2U4MTRkY2YwMWYyMDY3ZDUwMzIxMmQ3NWMyYWFkYjg1OTQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.XdFxhT2vISyWu6MH-zOKAvqlRB8o_wcvL62RLY64_Ik)](https://private-user-images.githubusercontent.com/10872139/467098118-fe7d0f6f-a1e0-4198-8e06-dec994e42bd6.gif?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTgxMTgtZmU3ZDBmNmYtYTFlMC00MTk4LThlMDYtZGVjOTk0ZTQyYmQ2LmdpZj9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTIxMTI5MWI5OWM4MTNjYmI1M2Q0MWIwMTUwMmY1Y2U4MTRkY2YwMWYyMDY3ZDUwMzIxMmQ3NWMyYWFkYjg1OTQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.XdFxhT2vISyWu6MH-zOKAvqlRB8o_wcvL62RLY64_Ik)[![Recording 2025-07-16 1317152323](https://private-user-images.githubusercontent.com/10872139/467098118-fe7d0f6f-a1e0-4198-8e06-dec994e42bd6.gif?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTgxMTgtZmU3ZDBmNmYtYTFlMC00MTk4LThlMDYtZGVjOTk0ZTQyYmQ2LmdpZj9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTIxMTI5MWI5OWM4MTNjYmI1M2Q0MWIwMTUwMmY1Y2U4MTRkY2YwMWYyMDY3ZDUwMzIxMmQ3NWMyYWFkYjg1OTQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.XdFxhT2vISyWu6MH-zOKAvqlRB8o_wcvL62RLY64_Ik)](https://private-user-images.githubusercontent.com/10872139/467098118-fe7d0f6f-a1e0-4198-8e06-dec994e42bd6.gif?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTgxMTgtZmU3ZDBmNmYtYTFlMC00MTk4LThlMDYtZGVjOTk0ZTQyYmQ2LmdpZj9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTIxMTI5MWI5OWM4MTNjYmI1M2Q0MWIwMTUwMmY1Y2U4MTRkY2YwMWYyMDY3ZDUwMzIxMmQ3NWMyYWFkYjg1OTQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.XdFxhT2vISyWu6MH-zOKAvqlRB8o_wcvL62RLY64_Ik)[Open Recording 2025-07-16 1317152323 in new window](https://private-user-images.githubusercontent.com/10872139/467098118-fe7d0f6f-a1e0-4198-8e06-dec994e42bd6.gif?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTgxMTgtZmU3ZDBmNmYtYTFlMC00MTk4LThlMDYtZGVjOTk0ZTQyYmQ2LmdpZj9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTIxMTI5MWI5OWM4MTNjYmI1M2Q0MWIwMTUwMmY1Y2U4MTRkY2YwMWYyMDY3ZDUwMzIxMmQ3NWMyYWFkYjg1OTQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.XdFxhT2vISyWu6MH-zOKAvqlRB8o_wcvL62RLY64_Ik)

* * *

* * *

🛠️ Technical Implementation

[![image](https://private-user-images.githubusercontent.com/10872139/467098652-60df6f0d-b2e9-4d88-88c1-da88a3d1217a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTg2NTItNjBkZjZmMGQtYjJlOS00ZDg4LTg4YzEtZGE4OGEzZDEyMTdhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQ0NzdhNWJmZjE4OTJjZjE4NTUyODQzZTJlMzAyZGY1NmY4Mjc4MDUyNzJjMDQxYWU4YmE0YjNhM2VkOGNiNTcmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.cIRDWMOEU9ig5Z3ufBd8FSWp5ld3BliA89VNyIFIZh0)](https://private-user-images.githubusercontent.com/10872139/467098652-60df6f0d-b2e9-4d88-88c1-da88a3d1217a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI5MTQsIm5iZiI6MTc3MTE0MjYxNCwicGF0aCI6Ii8xMDg3MjEzOS80NjcwOTg2NTItNjBkZjZmMGQtYjJlOS00ZDg4LTg4YzEtZGE4OGEzZDEyMTdhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTUlMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE1VDA4MDMzNFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQ0NzdhNWJmZjE4OTJjZjE4NTUyODQzZTJlMzAyZGY1NmY4Mjc4MDUyNzJjMDQxYWU4YmE0YjNhM2VkOGNiNTcmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.cIRDWMOEU9ig5Z3ufBd8FSWp5ld3BliA89VNyIFIZh0)

* * *

## 🧩 Core Components

[Permalink: 🧩 Core Components](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#-core-components)

### 🛠 Main Injector (`ConsoleApplication5.cpp`)

[Permalink: 🛠 Main Injector (ConsoleApplication5.cpp)](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#-main-injector-consoleapplication5cpp)

- Process enumeration and targeting logic
- DLL injection using `CreateRemoteThread` and `LoadLibraryW`
- Error handling and execution status reporting

### ⏲ Timer DLL (`Dll1.cpp`)

[Permalink: ⏲ Timer DLL (Dll1.cpp)](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#-timer-dll-dll1cpp)

- Timer-based shellcode execution implementation
- `TP_CALLBACK_ENVIRON` structure setup for thread pool configuration
- Execution of shellcode via the timer callback

## About

Remote DLL Injection with Timer-based Shellcode Execution


### Resources

[Readme](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution).

[Activity](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/activity)

### Stars

[**154**\\
stars](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/stargazers)

### Watchers

[**1**\\
watching](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/watchers)

### Forks

[**37**\\
forks](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fandreisss%2FRemote-DLL-Injection-with-Timer-based-Shellcode-Execution&report=andreisss+%28user%29)

## [Releases](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/releases)

No releases published

## [Packages\  0](https://github.com/users/andreisss/packages?repo_name=Remote-DLL-Injection-with-Timer-based-Shellcode-Execution)

No packages published

## Languages

- [C++100.0%](https://github.com/andreisss/Remote-DLL-Injection-with-Timer-based-Shellcode-Execution/search?l=c%2B%2B)

You can’t perform that action at this time.