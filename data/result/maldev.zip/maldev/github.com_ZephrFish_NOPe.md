# https://github.com/ZephrFish/NOPe

[Skip to content](https://github.com/ZephrFish/NOPe#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ZephrFish/NOPe) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ZephrFish/NOPe) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ZephrFish/NOPe) to refresh your session.Dismiss alert

{{ message }}

[ZephrFish](https://github.com/ZephrFish)/ **[NOPe](https://github.com/ZephrFish/NOPe)** Public

forked from [Xenov-X/NOPe](https://github.com/Xenov-X/NOPe)

- [Notifications](https://github.com/login?return_to=%2FZephrFish%2FNOPe) You must be signed in to change notification settings
- [Fork\\
1](https://github.com/login?return_to=%2FZephrFish%2FNOPe)
- [Star\\
8](https://github.com/login?return_to=%2FZephrFish%2FNOPe)


NOPe - Testing some alternate NOP opcodes


[8\\
stars](https://github.com/ZephrFish/NOPe/stargazers) [2\\
forks](https://github.com/ZephrFish/NOPe/forks) [Branches](https://github.com/ZephrFish/NOPe/branches) [Tags](https://github.com/ZephrFish/NOPe/tags) [Activity](https://github.com/ZephrFish/NOPe/activity)

[Star](https://github.com/login?return_to=%2FZephrFish%2FNOPe)

[Notifications](https://github.com/login?return_to=%2FZephrFish%2FNOPe) You must be signed in to change notification settings

# ZephrFish/NOPe

main

[**1** Branch](https://github.com/ZephrFish/NOPe/branches) [**0** Tags](https://github.com/ZephrFish/NOPe/tags)

[Go to Branches page](https://github.com/ZephrFish/NOPe/branches)[Go to Tags page](https://github.com/ZephrFish/NOPe/tags)

Go to file

Code

Open more actions menu

This branch is up to date with Xenov-X/NOPe:main.

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Xenov-X](https://avatars.githubusercontent.com/u/62152036?v=4&size=40)](https://github.com/Xenov-X)[Xenov-X](https://github.com/ZephrFish/NOPe/commits?author=Xenov-X)<br>[Merge pull request](https://github.com/ZephrFish/NOPe/commit/17d0e6dcf11fd984cf9c5aac5ea8807ad54cfef2) [Xenov-X#2](https://github.com/Xenov-X/NOPe/pull/2) [from ZephrFish/main](https://github.com/ZephrFish/NOPe/commit/17d0e6dcf11fd984cf9c5aac5ea8807ad54cfef2)<br>Open commit details<br>10 months agoApr 18, 2025<br>[17d0e6d](https://github.com/ZephrFish/NOPe/commit/17d0e6dcf11fd984cf9c5aac5ea8807ad54cfef2) · 10 months agoApr 18, 2025<br>## History<br>[12 Commits](https://github.com/ZephrFish/NOPe/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ZephrFish/NOPe/commits/main/) 12 Commits |
| [old](https://github.com/ZephrFish/NOPe/tree/main/old "old") | [old](https://github.com/ZephrFish/NOPe/tree/main/old "old") | [cleaned up NOPs in x86 to remove duplicates](https://github.com/ZephrFish/NOPe/commit/a8e456f5333b06e0d0fdc0b90eb515e6c2b79c8a "cleaned up NOPs in x86 to remove duplicates") | 11 months agoMar 29, 2025 |
| [.gitignore](https://github.com/ZephrFish/NOPe/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/ZephrFish/NOPe/blob/main/.gitignore ".gitignore") | [updated readme to match `NOPe.py`](https://github.com/ZephrFish/NOPe/commit/bb6d33bdf7cd8a8b0941807033c2994f0cf0e2df "updated readme to match `NOPe.py`") | 11 months agoMar 29, 2025 |
| [NOPe.py](https://github.com/ZephrFish/NOPe/blob/main/NOPe.py "NOPe.py") | [NOPe.py](https://github.com/ZephrFish/NOPe/blob/main/NOPe.py "NOPe.py") | [Combined arches, added some better help functions](https://github.com/ZephrFish/NOPe/commit/132f00728f40f9c44b95b7172c90d8c9a9ffa16a "Combined arches, added some better help functions") | 11 months agoMar 29, 2025 |
| [README.md](https://github.com/ZephrFish/NOPe/blob/main/README.md "README.md") | [README.md](https://github.com/ZephrFish/NOPe/blob/main/README.md "README.md") | [Fixed " characters](https://github.com/ZephrFish/NOPe/commit/1deb3bc1045c82ce45c94a896c15b00785fec441 "Fixed \" characters") | 10 months agoApr 18, 2025 |
| [bin2sc.py](https://github.com/ZephrFish/NOPe/blob/main/bin2sc.py "bin2sc.py") | [bin2sc.py](https://github.com/ZephrFish/NOPe/blob/main/bin2sc.py "bin2sc.py") | [added additional options for other langs to bin2sc](https://github.com/ZephrFish/NOPe/commit/13f0157d4fd0262f623518db22699f8b7190f369 "added additional options for other langs to bin2sc") | 11 months agoMar 29, 2025 |
| [msgbox.x64.bin](https://github.com/ZephrFish/NOPe/blob/main/msgbox.x64.bin "msgbox.x64.bin") | [msgbox.x64.bin](https://github.com/ZephrFish/NOPe/blob/main/msgbox.x64.bin "msgbox.x64.bin") | [init](https://github.com/ZephrFish/NOPe/commit/a6c2fdfee708503a7f5b4079d34bce610b735c34 "init") | 11 months agoMar 10, 2025 |
| [msgbox.x86.bin](https://github.com/ZephrFish/NOPe/blob/main/msgbox.x86.bin "msgbox.x86.bin") | [msgbox.x86.bin](https://github.com/ZephrFish/NOPe/blob/main/msgbox.x86.bin "msgbox.x86.bin") | [init](https://github.com/ZephrFish/NOPe/commit/a6c2fdfee708503a7f5b4079d34bce610b735c34 "init") | 11 months agoMar 10, 2025 |
| View all files |

## Repository files navigation

# NOPe

[Permalink: NOPe](https://github.com/ZephrFish/NOPe#nope)

A quick and hacky script to test alternatives to traditional NOP sleds by prepending various x86 or x64 "NOP-like" instructions to shellcode and executing it in memory.

Note: You must use the correct architecture of Python for the type of shellcode you're testing.

- Use 32-bit Python for x86 shellcode
- Use 64-bit Python for x64 shellcode

## Usage

[Permalink: Usage](https://github.com/ZephrFish/NOPe#usage)

Run with the default payload (x64 message box shellcode):

```
python NOPe.py
```

Run with your own shellcode binary:

```
python NOPe.py -f my_shellcode.bin
```

Specify architecture:

```
python NOPe.py -f msgbox.x86.bin –arch x86
```

Enable verbose output:

```
python NOPe.py -f msgbox.x64.bin –arch x64 –verbose
```

List supported NOP variants for a given architecture:

```
python NOPe.py –arch x86 –list-nops
```

## Generating Shellcode

[Permalink: Generating Shellcode](https://github.com/ZephrFish/NOPe#generating-shellcode)

To regenerate the message box payloads using `MSFVenom`:

x64 shellcode

```
msfvenom -p windows/x64/messagebox TEXT="NOPe64" TITLE="Hello" -f raw > msgbox.x64.bin
```

x86 shellcode

```
msfvenom -p windows/messagebox TEXT="NOPe32" TITLE="Hello" -f raw > msgbox.x86.bin
```

# bin2sc

[Permalink: bin2sc](https://github.com/ZephrFish/NOPe#bin2sc)

A simple script for converting raw `.bin` shellcode files into formatted C or Rust source code.

## Usage

[Permalink: Usage](https://github.com/ZephrFish/NOPe#usage-1)

Convert and print shellcode in C-style hex array format:

```
python bin2sc.py shellcode.bin
```

Write the output to a file:

```
python bin2sc.py shellcode.bin -o output.h
```

Change output format:

```
python bin2sc.py shellcode.bin -s c-array      # Default
python bin2sc.py shellcode.bin -s c-string     # “\x90\x90…” style
python bin2sc.py shellcode.bin -s rust         # Rust-style byte array
```

Customise the variable name and bytes per line:

```
python bin2sc.py shellcode.bin –name my_shellcode –bytes-per-line 8
```

## Example Output (C Array)

[Permalink: Example Output (C Array)](https://github.com/ZephrFish/NOPe#example-output-c-array)

```
unsigned char payload[] = {
    0x90, 0x90, 0xCC, 0xCC, 0xEB, 0xFE
};
```

## About

NOPe - Testing some alternate NOP opcodes


### Resources

[Readme](https://github.com/ZephrFish/NOPe#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ZephrFish/NOPe).

[Activity](https://github.com/ZephrFish/NOPe/activity)

### Stars

[**8**\\
stars](https://github.com/ZephrFish/NOPe/stargazers)

### Watchers

[**0**\\
watching](https://github.com/ZephrFish/NOPe/watchers)

### Forks

[**1**\\
fork](https://github.com/ZephrFish/NOPe/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FZephrFish%2FNOPe&report=ZephrFish+%28user%29)

## [Releases](https://github.com/ZephrFish/NOPe/releases)

No releases published

## [Packages\  0](https://github.com/users/ZephrFish/packages?repo_name=NOPe)

No packages published

## Languages

- Python100.0%

You can’t perform that action at this time.