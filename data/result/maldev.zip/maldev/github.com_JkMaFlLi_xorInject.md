# https://github.com/JkMaFlLi/xorInject

[Skip to content](https://github.com/JkMaFlLi/xorInject#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/JkMaFlLi/xorInject) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/JkMaFlLi/xorInject) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/JkMaFlLi/xorInject) to refresh your session.Dismiss alert

{{ message }}

[JkMaFlLi](https://github.com/JkMaFlLi)/ **[xorInject](https://github.com/JkMaFlLi/xorInject)** Public

- [Notifications](https://github.com/login?return_to=%2FJkMaFlLi%2FxorInject) You must be signed in to change notification settings
- [Fork\\
6](https://github.com/login?return_to=%2FJkMaFlLi%2FxorInject)
- [Star\\
21](https://github.com/login?return_to=%2FJkMaFlLi%2FxorInject)


[21\\
stars](https://github.com/JkMaFlLi/xorInject/stargazers) [6\\
forks](https://github.com/JkMaFlLi/xorInject/forks) [Branches](https://github.com/JkMaFlLi/xorInject/branches) [Tags](https://github.com/JkMaFlLi/xorInject/tags) [Activity](https://github.com/JkMaFlLi/xorInject/activity)

[Star](https://github.com/login?return_to=%2FJkMaFlLi%2FxorInject)

[Notifications](https://github.com/login?return_to=%2FJkMaFlLi%2FxorInject) You must be signed in to change notification settings

# JkMaFlLi/xorInject

main

[**1** Branch](https://github.com/JkMaFlLi/xorInject/branches) [**0** Tags](https://github.com/JkMaFlLi/xorInject/tags)

[Go to Branches page](https://github.com/JkMaFlLi/xorInject/branches)[Go to Tags page](https://github.com/JkMaFlLi/xorInject/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![JkMaFlLi](https://avatars.githubusercontent.com/u/76661292?v=4&size=40)](https://github.com/JkMaFlLi)[JkMaFlLi](https://github.com/JkMaFlLi/xorInject/commits?author=JkMaFlLi)<br>[Add files via upload](https://github.com/JkMaFlLi/xorInject/commit/a83e394c60ee0827a9b60024250d8e10d6c1a451)<br>2 years agoNov 5, 2024<br>[a83e394](https://github.com/JkMaFlLi/xorInject/commit/a83e394c60ee0827a9b60024250d8e10d6c1a451) · 2 years agoNov 5, 2024<br>## History<br>[5 Commits](https://github.com/JkMaFlLi/xorInject/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/JkMaFlLi/xorInject/commits/main/) 5 Commits |
| [2024-11-04 18\_25\_57-VirusTotal - File - 9328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png](https://github.com/JkMaFlLi/xorInject/blob/main/2024-11-04%2018_25_57-VirusTotal%20-%20File%20-%209328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png "2024-11-04 18_25_57-VirusTotal - File - 9328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png") | [2024-11-04 18\_25\_57-VirusTotal - File - 9328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png](https://github.com/JkMaFlLi/xorInject/blob/main/2024-11-04%2018_25_57-VirusTotal%20-%20File%20-%209328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png "2024-11-04 18_25_57-VirusTotal - File - 9328b2ae120b02c31f4348b3b895ae728230363c98b4e1a9d51687abdffc.png") | [Add files via upload](https://github.com/JkMaFlLi/xorInject/commit/6b2b5fe5b9f5f53e4151b6fba03f2ad2279da831 "Add files via upload") | 2 years agoNov 4, 2024 |
| [README.md](https://github.com/JkMaFlLi/xorInject/blob/main/README.md "README.md") | [README.md](https://github.com/JkMaFlLi/xorInject/blob/main/README.md "README.md") | [Update README.md](https://github.com/JkMaFlLi/xorInject/commit/bf43d9c6b41fbe305d86d56c9caa7c0ab8cefbf6 "Update README.md") | 2 years agoNov 4, 2024 |
| [hashxorInject.boo](https://github.com/JkMaFlLi/xorInject/blob/main/hashxorInject.boo "hashxorInject.boo") | [hashxorInject.boo](https://github.com/JkMaFlLi/xorInject/blob/main/hashxorInject.boo "hashxorInject.boo") | [Add files via upload](https://github.com/JkMaFlLi/xorInject/commit/a83e394c60ee0827a9b60024250d8e10d6c1a451 "Add files via upload") | 2 years agoNov 5, 2024 |
| [xorInject.boo](https://github.com/JkMaFlLi/xorInject/blob/main/xorInject.boo "xorInject.boo") | [xorInject.boo](https://github.com/JkMaFlLi/xorInject/blob/main/xorInject.boo "xorInject.boo") | [Add files via upload](https://github.com/JkMaFlLi/xorInject/commit/f7963ae688210c46e11b974087380fb3771ec597 "Add files via upload") | 2 years agoNov 4, 2024 |
| View all files |

## Repository files navigation

# XOR Encrypted Shellcode Execution via Desktop Enumeration

[Permalink: XOR Encrypted Shellcode Execution via Desktop Enumeration](https://github.com/JkMaFlLi/xorInject#xor-encrypted-shellcode-execution-via-desktop-enumeration)

## Description

[Permalink: Description](https://github.com/JkMaFlLi/xorInject#description)

This Boo language script demonstrates an alternative method for shellcode execution using Windows desktop enumeration callbacks. The implementation includes XOR encryption for additional obfuscation and leverages the .NET framework through Boo's Python-inspired syntax.

## Features

[Permalink: Features](https://github.com/JkMaFlLi/xorInject#features)

- **XOR Decryption**: Runtime decryption of shellcode using XOR operation
- **Desktop Enumeration**: Utilizes `EnumDesktopWindows` for execution
- **Memory Management**: Implements proper memory allocation and protection
- **Callback Implementation**: Uses delegate-based callback mechanism

## Technical Details

[Permalink: Technical Details](https://github.com/JkMaFlLi/xorInject#technical-details)

#### Components

[Permalink: Components](https://github.com/JkMaFlLi/xorInject#components)

- **Memory Allocation**: Uses `VirtualAlloc` with `PAGE_EXECUTE_READWRITE` protection
- **Desktop Handling**: Leverages `GetThreadDesktop` for current desktop context
- **Shellcode Processing**: Converts MAC-address formatted encrypted bytes to executable code
- **Execution Method**: Implements callback-based execution through desktop window enumeration

## Prerequisites

[Permalink: Prerequisites](https://github.com/JkMaFlLi/xorInject#prerequisites)

- Boo compiler
- .NET Framework
- Windows environment
- Python (for shellcode encryption)

## Usage

[Permalink: Usage](https://github.com/JkMaFlLi/xorInject#usage)

1. Encrypt your shellcode using the provided Python script
2. Insert the encrypted shellcode into the Boo script
3. Compile and execute the Boo script

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/JkMaFlLi/xorInject#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/JkMaFlLi/xorInject).

[Activity](https://github.com/JkMaFlLi/xorInject/activity)

### Stars

[**21**\\
stars](https://github.com/JkMaFlLi/xorInject/stargazers)

### Watchers

[**1**\\
watching](https://github.com/JkMaFlLi/xorInject/watchers)

### Forks

[**6**\\
forks](https://github.com/JkMaFlLi/xorInject/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FJkMaFlLi%2FxorInject&report=JkMaFlLi+%28user%29)

## [Releases](https://github.com/JkMaFlLi/xorInject/releases)

No releases published

## [Packages\  0](https://github.com/users/JkMaFlLi/packages?repo_name=xorInject)

No packages published

## Languages

- [Boo100.0%](https://github.com/JkMaFlLi/xorInject/search?l=boo)

You can’t perform that action at this time.