# https://github.com/lem0nSec/ShellGhost

[Skip to content](https://github.com/lem0nSec/ShellGhost#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/lem0nSec/ShellGhost) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/lem0nSec/ShellGhost) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/lem0nSec/ShellGhost) to refresh your session.Dismiss alert

{{ message }}

[lem0nSec](https://github.com/lem0nSec)/ **[ShellGhost](https://github.com/lem0nSec/ShellGhost)** Public

- [Notifications](https://github.com/login?return_to=%2Flem0nSec%2FShellGhost) You must be signed in to change notification settings
- [Fork\\
142](https://github.com/login?return_to=%2Flem0nSec%2FShellGhost)
- [Star\\
1.2k](https://github.com/login?return_to=%2Flem0nSec%2FShellGhost)


A memory-based evasion technique which makes shellcode invisible from process start to end.


### License

[GPL-3.0 license](https://github.com/lem0nSec/ShellGhost/blob/master/LICENSE)

[1.2k\\
stars](https://github.com/lem0nSec/ShellGhost/stargazers) [142\\
forks](https://github.com/lem0nSec/ShellGhost/forks) [Branches](https://github.com/lem0nSec/ShellGhost/branches) [Tags](https://github.com/lem0nSec/ShellGhost/tags) [Activity](https://github.com/lem0nSec/ShellGhost/activity)

[Star](https://github.com/login?return_to=%2Flem0nSec%2FShellGhost)

[Notifications](https://github.com/login?return_to=%2Flem0nSec%2FShellGhost) You must be signed in to change notification settings

# lem0nSec/ShellGhost

master

[**1** Branch](https://github.com/lem0nSec/ShellGhost/branches) [**0** Tags](https://github.com/lem0nSec/ShellGhost/tags)

[Go to Branches page](https://github.com/lem0nSec/ShellGhost/branches)[Go to Tags page](https://github.com/lem0nSec/ShellGhost/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![lem0nSec](https://avatars.githubusercontent.com/u/98479572?v=4&size=40)](https://github.com/lem0nSec)[lem0nSec](https://github.com/lem0nSec/ShellGhost/commits?author=lem0nSec)<br>[Minor adjustments.](https://github.com/lem0nSec/ShellGhost/commit/178a95ce8224f734112831f7b6e1e62f816561f2)<br>3 years agoOct 16, 2023<br>[178a95c](https://github.com/lem0nSec/ShellGhost/commit/178a95ce8224f734112831f7b6e1e62f816561f2) · 3 years agoOct 16, 2023<br>## History<br>[45 Commits](https://github.com/lem0nSec/ShellGhost/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/lem0nSec/ShellGhost/commits/master/) 45 Commits |
| [pictures](https://github.com/lem0nSec/ShellGhost/tree/master/pictures "pictures") | [pictures](https://github.com/lem0nSec/ShellGhost/tree/master/pictures "pictures") | [Add files via upload](https://github.com/lem0nSec/ShellGhost/commit/f6f90fad8e99f338a56acf4a7d31a0cd58f34687 "Add files via upload") | 3 years agoJul 10, 2023 |
| [scripts](https://github.com/lem0nSec/ShellGhost/tree/master/scripts "scripts") | [scripts](https://github.com/lem0nSec/ShellGhost/tree/master/scripts "scripts") | ['scripts' directory added.](https://github.com/lem0nSec/ShellGhost/commit/6b3c5d75572e8f39f114231992fb1023698e76c5 "'scripts' directory added.") | 3 years agoJul 24, 2023 |
| [src](https://github.com/lem0nSec/ShellGhost/tree/master/src "src") | [src](https://github.com/lem0nSec/ShellGhost/tree/master/src "src") | [Minor adjustments.](https://github.com/lem0nSec/ShellGhost/commit/178a95ce8224f734112831f7b6e1e62f816561f2 "Minor adjustments.") | 3 years agoOct 16, 2023 |
| [.gitattributes](https://github.com/lem0nSec/ShellGhost/blob/master/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/lem0nSec/ShellGhost/blob/master/.gitattributes ".gitattributes") | [Add .gitattributes, .gitignore, and README.md.](https://github.com/lem0nSec/ShellGhost/commit/167a3e4dbf06139bd47b05ea4f4bdd0d4d1a86a0 "Add .gitattributes, .gitignore, and README.md.") | 3 years agoJul 1, 2023 |
| [.gitignore](https://github.com/lem0nSec/ShellGhost/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/lem0nSec/ShellGhost/blob/master/.gitignore ".gitignore") | [Add .gitattributes, .gitignore, and README.md.](https://github.com/lem0nSec/ShellGhost/commit/167a3e4dbf06139bd47b05ea4f4bdd0d4d1a86a0 "Add .gitattributes, .gitignore, and README.md.") | 3 years agoJul 1, 2023 |
| [LICENSE](https://github.com/lem0nSec/ShellGhost/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/lem0nSec/ShellGhost/blob/master/LICENSE "LICENSE") | [Create LICENSE](https://github.com/lem0nSec/ShellGhost/commit/278e0fac052790b97087c4185f77a980e22f76c0 "Create LICENSE") | 3 years agoJul 3, 2023 |
| [README.md](https://github.com/lem0nSec/ShellGhost/blob/master/README.md "README.md") | [README.md](https://github.com/lem0nSec/ShellGhost/blob/master/README.md "README.md") | [Minor adjustments.](https://github.com/lem0nSec/ShellGhost/commit/178a95ce8224f734112831f7b6e1e62f816561f2 "Minor adjustments.") | 3 years agoOct 16, 2023 |
| [ShellGhost.sln](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.sln "ShellGhost.sln") | [ShellGhost.sln](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.sln "ShellGhost.sln") | [Add project files.](https://github.com/lem0nSec/ShellGhost/commit/9afcc68a95a20fec29b91dca4d38c3589b9c0a8f "Add project files.") | 3 years agoJul 1, 2023 |
| [ShellGhost.vcxproj](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.vcxproj "ShellGhost.vcxproj") | [ShellGhost.vcxproj](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.vcxproj "ShellGhost.vcxproj") | [edited README.md](https://github.com/lem0nSec/ShellGhost/commit/2deb9dd9570b6dfd8f8bc2d59aec712b0f594760 "edited README.md") | 3 years agoJul 6, 2023 |
| [ShellGhost.vcxproj.filters](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.vcxproj.filters "ShellGhost.vcxproj.filters") | [ShellGhost.vcxproj.filters](https://github.com/lem0nSec/ShellGhost/blob/master/ShellGhost.vcxproj.filters "ShellGhost.vcxproj.filters") | [edited README.md](https://github.com/lem0nSec/ShellGhost/commit/2deb9dd9570b6dfd8f8bc2d59aec712b0f594760 "edited README.md") | 3 years agoJul 6, 2023 |
| View all files |

## Repository files navigation

# ShellGhost

[Permalink: ShellGhost](https://github.com/lem0nSec/ShellGhost#shellghost)

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/logo.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/logo.png)

**A memory-based evasion technique which makes shellcode invisible from process start to end.**

* * *

## Motivation

[Permalink: Motivation](https://github.com/lem0nSec/ShellGhost#motivation)

I wanted to share this shellcode self-injection POC to showcase some AV/EDR evasion concepts that may turn useful for Red Teaming. Just a few weeks ago I came up with a custom in-memory evasion technique which I named ShellGhost. This technique stems from the need for having **a code that executes an 'invisible' shellcode from process start to finish**.

* * *

## Handling the Thread Execution Flow

[Permalink: Handling the Thread Execution Flow](https://github.com/lem0nSec/ShellGhost#handling-the-thread-execution-flow)

**ShellGhost relies on Vectored Exception Handling in combination with software breakpoints** to cyclically stop thread execution, replace the executed breakpoint with a RC4-encrypted shellcode instruction, decrypt the instruction and resume execution after restoring memory protection to RX. When the subsequent EXCEPTION\_BREAKPOINT is raised, the exception handler replaces the previous shellcode instruction with a new breakpoint so that the allocation will never disclose the complete shellcode in an unencrypted state. This happens inside a private memory page which is initially marked as READ/WRITE.
Having a RW PRV allocation will not be considered an 'Indicator of Compromise' by memory scanners such as PE-Sieve and Moneta. When the allocation becomes RX and the page is scanned, nothing but breakpoints will be found. This happens while the shellcode is actually under execution. The following picture shows that a reverse shell is running, but no IOC is found by Moneta (other than the binary being unsigned).

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/moneta_detection.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/moneta_detection.png)

Trying to scan the process with Pe-Sieve has an even better outcome:

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/pe-sieve.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/pe-sieve.png)

* * *

## Shellcode Mapping

[Permalink: Shellcode Mapping](https://github.com/lem0nSec/ShellGhost#shellcode-mapping)

Shellcode Mapping is the core functionality of ShellGhost. This tactic enables the thread to intermittently execute instructions while never exposing the entire shellcode in memory. This is possible because the position of each single shellcode instruction that the thread executes corresponds to the position of a certain breakpoint inside the allocated memory page. ShellGhost resolves this position by calculating the Relative Virtual Address (RVA) from the thread RIP to the base address of the allocated memory page and adds it to the base address of the encrypted shellcode / encrypted instructions. The number of breakpoints that will be replaced is not always the same, but it varies depending on the number of opcodes that each instruction needs to be correctly generated and interpreted (QUOTA). So for example the instruction 'POP RBP' is equal to '5D', which means only one breakpoint will be replaced. By contrast, the instruction 'JMP RAX' requires opcodes 'FF E0', so two breakpoints will be replaced. For this reason I created the following C data structure.

```
typedef struct CRYPT_BYTES_QUOTA {

	DWORD RVA;		// offset to encrypted instruction
	DWORD quota;	// number of opcodes that generate the instruction

} CRYPT_BYTES_QUOTA, * PCRYPT_BYTES_QUOTA;
```

Breakpoints are not immediately replaced with their instruction counterparts. This is because instructions need to undergo a decryption routine before being executed. This is where the `DWORD quota` comes into play. ShellGhost relies on the now popular 'SystemFunction032' to perform RC4 decryption. Unlike XOR, RC4 is not a single-byte encryption scheme. This means that the shellcode cannot be encrypted and decrypted all at once. This is also another reason why each instruction is treated separately. After the breakpoints are replaced, the buffer length that SystemFunction032 needs will be equal to the 'instruction quota', which again represents the number of opcodes the specific instruction is composed of. So for example, consider the following snippet.

```
CRYPT_BYTES_QUOTA instruction[200];
instruction[5].quota = 2

USTRING buf = { 0 }; 	// will contain the buffer to be decrypted and its length
USTRING key = { 0 }; 	// will contain the RC4 key and length

buf.Length = 2 		// buffer length, or length of the instruction to be decrypted
```

We know that shellcode instruction number 5 is composed of 2 opcodes, so a buffer length of 2 will be passed to SystemFunction032. This is important because trying to decrypt the entire shellcode with a single call to SystemFunction032 will corrupt it entirely.

### How is Shellcode Mapping performed?

[Permalink: How is Shellcode Mapping performed?](https://github.com/lem0nSec/ShellGhost#how-is-shellcode-mapping-performed)

The shellcode needs to be mapped with `ShellGhost_mapping.py` before compilation. The script extracts each single instruction and treats it as a small and independent shellcode. Instructions are encrypted one by one and printed out in C format all together as unsigned char. The result can be hardcoded inside the C code. Below is an example of what an encrypted MSF shellcode instructions for calc.exe looks like.

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/shellcode_mapping_1.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/shellcode_mapping_1.png)

This shellcode has 98 instructions, so 98 CRYPT\_BYTES\_QUOTA structs are declared. When the code executes, these structs have to be populated with the proper instructions RVAs and QUOTAs. The '-1' parameter instructs the mapping script to print out the piece of code that does this.

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/shellcode_mapping_2.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/shellcode_mapping_2.png)

## Adjusting Winapi Parameters

[Permalink: Adjusting Winapi Parameters](https://github.com/lem0nSec/ShellGhost#adjusting-winapi-parameters)

Metasploit x64 shellcodes tipically have winapi string parameters stored between instructions. So to say, a MSF x64 shellcode that calls Winexec does not push a series of bytes with a nullbyte at the end to have the first parameter string on the stack. Rather, the RCX register (first parameter) is a pointer inside the shellcode itself just like the following picture.

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/msf_jmp_rax.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/msf_jmp_rax.png)

This means that the breakpoints whose position relates to the string will never be resolved, because the RIP will never touch that position. As a matter of fact, this code resolves actual shellcode instructions the RIP goes through, not parameters that will never be executed like instructions. To fix this, I noticed that MSF shellcodes always store a pointer to the winapi they are calling inside the RAX register, then make a jump to the register itself. So when ShellGhost VEH detects that the resolved breakpoint is 'JMP RAX' and the RCX register contains a pointer to a position inside the shellcode, it attempts to also resolve what pointed by RCX. Subsequently, execution is not returned to the allocated memory. Rather, RAX (winapi address) is copied into RIP and thread execution is resumed from the winapi, thus overriding the 'JMP RAX' and keeping the allocated memory RW. This is needed for reverse shells calling WaitForSingleObject, which would cause the thread to sleep after the 'JMP RAX' while leaving memory RX for as long as the shell remains alive. The following code snippet contains the two conditions that has to be met in order for ShellGhost to adjust the RCX register when it contains a winapi parameter string and allow the MSF shellcode to correctly issue the function call (WinExec in the example here).

```
<snip>

if (*(PWORD)exceptionData->ContextRecord->Rip == 0xe0ff) // if RIP is 'JMP RAX'

<snip>

if ((contextRecord->Rcx >= (DWORD_PTR)allocation_base) && (contextRecord->Rcx <= ((DWORD_PTR)allocation_base + sizeof(sh)))) // if RCX is inside the allocation

<snip>
```

RDX, R8 and R9 (second, third, and fourth parameters) are not covered yet.

## Differences and Similarities with other Techniques

[Permalink: Differences and Similarities with other Techniques](https://github.com/lem0nSec/ShellGhost#differences-and-similarities-with-other-techniques)

[ShellcodeFluctuation](https://github.com/mgeeky/ShellcodeFluctuation) is a very similar in-memory evasion concept. Just like it, the allocated memory here 'fluctuates' from RW to RX. In contrast, ShellGhost introduces the following improvements:

- RC4 encryption plus 'Shellcode Mapping' rather than single-byte XOR
- No need to hook functions
- Support for Metasploit shellcodes

ShellGhost is far from being a perfect technique though. It still suffers from the biggest downside all these techniques have, namely **the need to have private executable memory at some point during execution**. More advanced techniques like Foliage already found a way around this. In addition, a memory allocation full of software breakpoints can be detected by a YARA rule. The following picture shows Moneta correctly detecting an IOC for the RX PRV allocation.

[![](https://github.com/lem0nSec/ShellGhost/raw/master/pictures/moneta_detection_2.png)](https://github.com/lem0nSec/ShellGhost/blob/master/pictures/moneta_detection_2.png)

When it comes to evading an EDR solution, memory scanning is just part of a bigger picture. The complete absence of IOCs does not necessarily mean that a binary using this technique will prove effective against a given EDR. As far as I can tell, I experienced situations when the solution does not even allow you to launch the binary the way you're doing it. The other side of the medal is that IOCs are not always precise indicators, and some of them may turn out to be false positives. With that being said, this is just a raw technique and an inspiration which I hope the reader appreciates. The Red Teamer knows that just like the components of an EDR, in-memory evasion is only one component of the engine.

## Notes

[Permalink: Notes](https://github.com/lem0nSec/ShellGhost#notes)

Compilation requires disabling incremental linking. This VS project has all compiler/linker options already set.

## About

A memory-based evasion technique which makes shellcode invisible from process start to end.


### Resources

[Readme](https://github.com/lem0nSec/ShellGhost#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/lem0nSec/ShellGhost#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/lem0nSec/ShellGhost).

[Activity](https://github.com/lem0nSec/ShellGhost/activity)

### Stars

[**1.2k**\\
stars](https://github.com/lem0nSec/ShellGhost/stargazers)

### Watchers

[**8**\\
watching](https://github.com/lem0nSec/ShellGhost/watchers)

### Forks

[**142**\\
forks](https://github.com/lem0nSec/ShellGhost/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Flem0nSec%2FShellGhost&report=lem0nSec+%28user%29)

## [Releases](https://github.com/lem0nSec/ShellGhost/releases)

No releases published

## [Packages\  0](https://github.com/users/lem0nSec/packages?repo_name=ShellGhost)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/lem0nSec/ShellGhost).

## Languages

- [C67.2%](https://github.com/lem0nSec/ShellGhost/search?l=c)
- [Python32.8%](https://github.com/lem0nSec/ShellGhost/search?l=python)

You can’t perform that action at this time.