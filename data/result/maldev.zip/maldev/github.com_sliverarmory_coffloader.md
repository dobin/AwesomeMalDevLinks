# https://github.com/sliverarmory/COFFLoader/

[Skip to content](https://github.com/sliverarmory/COFFLoader/#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/sliverarmory/COFFLoader/) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/sliverarmory/COFFLoader/) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/sliverarmory/COFFLoader/) to refresh your session.Dismiss alert

{{ message }}

[sliverarmory](https://github.com/sliverarmory)/ **[COFFLoader](https://github.com/sliverarmory/COFFLoader)** Public

forked from [trustedsec/COFFLoader](https://github.com/trustedsec/COFFLoader)

- [Notifications](https://github.com/login?return_to=%2Fsliverarmory%2FCOFFLoader) You must be signed in to change notification settings
- [Fork\\
8](https://github.com/login?return_to=%2Fsliverarmory%2FCOFFLoader)
- [Star\\
50](https://github.com/login?return_to=%2Fsliverarmory%2FCOFFLoader)


### License

[View license](https://github.com/sliverarmory/COFFLoader/blob/main/LICENSE.txt)

[50\\
stars](https://github.com/sliverarmory/COFFLoader/stargazers) [90\\
forks](https://github.com/sliverarmory/COFFLoader/forks) [Branches](https://github.com/sliverarmory/COFFLoader/branches) [Tags](https://github.com/sliverarmory/COFFLoader/tags) [Activity](https://github.com/sliverarmory/COFFLoader/activity)

[Star](https://github.com/login?return_to=%2Fsliverarmory%2FCOFFLoader)

[Notifications](https://github.com/login?return_to=%2Fsliverarmory%2FCOFFLoader) You must be signed in to change notification settings

# sliverarmory/COFFLoader

main

[**3** Branches](https://github.com/sliverarmory/COFFLoader/branches) [**17** Tags](https://github.com/sliverarmory/COFFLoader/tags)

[Go to Branches page](https://github.com/sliverarmory/COFFLoader/branches)[Go to Tags page](https://github.com/sliverarmory/COFFLoader/tags)

Go to file

Code

Open more actions menu

This branch is [28 commits ahead of](https://github.com/sliverarmory/COFFLoader/compare/trustedsec%3ACOFFLoader%3Amain...main) trustedsec/COFFLoader:main.

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![c2biz](https://avatars.githubusercontent.com/u/94481756?v=4&size=40)](https://github.com/c2biz)[c2biz](https://github.com/sliverarmory/COFFLoader/commits?author=c2biz)<br>[merge upstream](https://github.com/sliverarmory/COFFLoader/commit/28e49814641e34b2e38f50f7c49316473750198d)<br>success<br>2 months agoDec 15, 2025<br>[28e4981](https://github.com/sliverarmory/COFFLoader/commit/28e49814641e34b2e38f50f7c49316473750198d) · 2 months agoDec 15, 2025<br>## History<br>[70 Commits](https://github.com/sliverarmory/COFFLoader/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/sliverarmory/COFFLoader/commits/main/) 70 Commits |
| [.github/workflows](https://github.com/sliverarmory/COFFLoader/tree/main/.github/workflows "This path skips through empty directories") | [.github/workflows](https://github.com/sliverarmory/COFFLoader/tree/main/.github/workflows "This path skips through empty directories") | [Update artifact name](https://github.com/sliverarmory/COFFLoader/commit/dff97cc405855426830fa9d79edb72fb3d633e8f "Update artifact name") | 5 years agoDec 29, 2021 |
| [.gitignore](https://github.com/sliverarmory/COFFLoader/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/sliverarmory/COFFLoader/blob/main/.gitignore ".gitignore") | [DLL implementation](https://github.com/sliverarmory/COFFLoader/commit/e0cbf99dacd7b111286a2b49feb699d322e7ba4c "DLL implementation") | 5 years agoJul 29, 2021 |
| [COFFLoader.c](https://github.com/sliverarmory/COFFLoader/blob/main/COFFLoader.c "COFFLoader.c") | [COFFLoader.c](https://github.com/sliverarmory/COFFLoader/blob/main/COFFLoader.c "COFFLoader.c") | [merge upstream](https://github.com/sliverarmory/COFFLoader/commit/28e49814641e34b2e38f50f7c49316473750198d "merge upstream") | 2 months agoDec 15, 2025 |
| [COFFLoader.h](https://github.com/sliverarmory/COFFLoader/blob/main/COFFLoader.h "COFFLoader.h") | [COFFLoader.h](https://github.com/sliverarmory/COFFLoader/blob/main/COFFLoader.h "COFFLoader.h") | [update coffloader core](https://github.com/sliverarmory/COFFLoader/commit/7019742edb0ee602477a29a15c0c70c0b7c38331 "update coffloader core") | 10 months agoApr 11, 2025 |
| [LICENSE.txt](https://github.com/sliverarmory/COFFLoader/blob/main/LICENSE.txt "LICENSE.txt") | [LICENSE.txt](https://github.com/sliverarmory/COFFLoader/blob/main/LICENSE.txt "LICENSE.txt") | [Initial commit](https://github.com/sliverarmory/COFFLoader/commit/626956ecf5ae26bd2b0301eccf37d37054f19d6d "Initial commit") | 5 years agoFeb 19, 2021 |
| [Makefile](https://github.com/sliverarmory/COFFLoader/blob/main/Makefile "Makefile") | [Makefile](https://github.com/sliverarmory/COFFLoader/blob/main/Makefile "Makefile") | [Update autorelease](https://github.com/sliverarmory/COFFLoader/commit/8d471a6cbc6155fb2ef58d783b121f9e0c4a8283 "Update autorelease") | 5 years agoDec 27, 2021 |
| [README.md](https://github.com/sliverarmory/COFFLoader/blob/main/README.md "README.md") | [README.md](https://github.com/sliverarmory/COFFLoader/blob/main/README.md "README.md") | [update coffloader core](https://github.com/sliverarmory/COFFLoader/commit/7019742edb0ee602477a29a15c0c70c0b7c38331 "update coffloader core") | 10 months agoApr 11, 2025 |
| [beacon.h](https://github.com/sliverarmory/COFFLoader/blob/main/beacon.h "beacon.h") | [beacon.h](https://github.com/sliverarmory/COFFLoader/blob/main/beacon.h "beacon.h") | [Initial commit](https://github.com/sliverarmory/COFFLoader/commit/626956ecf5ae26bd2b0301eccf37d37054f19d6d "Initial commit") | 5 years agoFeb 19, 2021 |
| [beacon\_compatibility.c](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_compatibility.c "beacon_compatibility.c") | [beacon\_compatibility.c](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_compatibility.c "beacon_compatibility.c") | [Fix buffer overflow in BeaconFormatPrintf causing last character trun…](https://github.com/sliverarmory/COFFLoader/commit/545958f2a83203d04b62b62810e3878c93b5e87a "Fix buffer overflow in BeaconFormatPrintf causing last character truncation") | 7 months agoJul 19, 2025 |
| [beacon\_compatibility.h](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_compatibility.h "beacon_compatibility.h") | [beacon\_compatibility.h](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_compatibility.h "beacon_compatibility.h") | [update coffloader core](https://github.com/sliverarmory/COFFLoader/commit/7019742edb0ee602477a29a15c0c70c0b7c38331 "update coffloader core") | 10 months agoApr 11, 2025 |
| [beacon\_generate.py](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_generate.py "beacon_generate.py") | [beacon\_generate.py](https://github.com/sliverarmory/COFFLoader/blob/main/beacon_generate.py "beacon_generate.py") | [Initial commit](https://github.com/sliverarmory/COFFLoader/commit/626956ecf5ae26bd2b0301eccf37d37054f19d6d "Initial commit") | 5 years agoFeb 19, 2021 |
| [dll.c](https://github.com/sliverarmory/COFFLoader/blob/main/dll.c "dll.c") | [dll.c](https://github.com/sliverarmory/COFFLoader/blob/main/dll.c "dll.c") | [Add DLL file](https://github.com/sliverarmory/COFFLoader/commit/02b9e170f01c24c2d0d2d0b3ccfea5009bde6929 "Add DLL file") | 5 years agoJul 29, 2021 |
| [extension.json](https://github.com/sliverarmory/COFFLoader/blob/main/extension.json "extension.json") | [extension.json](https://github.com/sliverarmory/COFFLoader/blob/main/extension.json "extension.json") | [Tweak manifest](https://github.com/sliverarmory/COFFLoader/commit/2be56242206216e48b48c14b574a9ed6870a7c5d "Tweak manifest") | 4 years agoMay 30, 2022 |
| [test.c](https://github.com/sliverarmory/COFFLoader/blob/main/test.c "test.c") | [test.c](https://github.com/sliverarmory/COFFLoader/blob/main/test.c "test.c") | [update coffloader core](https://github.com/sliverarmory/COFFLoader/commit/7019742edb0ee602477a29a15c0c70c0b7c38331 "update coffloader core") | 10 months agoApr 11, 2025 |
| View all files |

## Repository files navigation

# COFF Loader

[Permalink: COFF Loader](https://github.com/sliverarmory/COFFLoader/#coff-loader)

This is a quick and dirty COFF loader (AKA Beacon Object Files). Currently can run un-modified BOF's so it can be used for testing without a CS agent running it. The only exception is that the injection related beacon compatibility functions are just empty.

The main goal is to provide a working example and maybe be useful to someone.

## Parts

[Permalink: Parts](https://github.com/sliverarmory/COFFLoader/#parts)

There are a few parts to it they are listed below.

- beacon\_compatibility: This is the beacon internal functions so that you can load BOF files and run them.
- COFFLoader: This is the actual coff loader, and when built for nix just loads the 64 bit object file and parses it.
- test: This is the example "COFF" file, will build to the COFF file for you when make is called.
- beacon\_generate: This is a helper script to build strings/arguments compatible with the beacon\_compatibility functions.

## Beacon Generate

[Permalink: Beacon Generate](https://github.com/sliverarmory/COFFLoader/#beacon-generate)

This is used to generate arguments for the COFFLoader code, if the BOF takes arguments simply add the arguments with the type expected with this and generate the hex string for use.

Example usage here:

```
COFFLoader % python3 beacon_generate.py
Beacon Argument Generator
Beacon>help

Documented commands (type help <topic>):
========================================
addString  addWString  addint  addshort  exit  generate  help  reset

Beacon>addWString test
Beacon>addint 4
Beacon>generate
b'120000000a0000007400650073007400000004000000'
Beacon>reset
Beacon>addint 5
Beacon>generate
b'0400000005000000'
Beacon>exit
```

## BOF Arguments

[Permalink: BOF Arguments](https://github.com/sliverarmory/COFFLoader/#bof-arguments)

You can find what arguments are required by each BOF by viewing the source code. Using the Net User BOF as an example, you would view the `src/SA/netuser/entry.c` file found in the `CS-Situational-Awareness-BOF` Github and then view the arguments found in the `void go()` function.

```
VOID go(IN PCHAR Buffer, IN ULONG Length)
{
    datap parser;
    wchar_t *username = NULL;
    wchar_t *domain = NULL;

    BeaconDataParse(&parser, Buffer, Length);
    username = (wchar_t *)BeaconDataExtract(&parser, NULL);
    domain = (wchar_t *)BeaconDataExtract(&parser, NULL);
    domain = *domain == 0 ? NULL : domain;
    netuserinfo(username, domain);

    printoutput(TRUE);
};
```

We can see that our Net User BOF requires a "username" and "domain" ( _which we can get by running the whoami BOF_). Using the `beacon_generate.py` helper script, we would generate the arguments like this:

```
COFFLoader % python3 beacon_generate.py
Beacon Argument Generator
Beacon>addWString Administrator
Beacon>addWString client2
Beacon>generate
b'340000001c000000410064006d0069006e006900730074007200610074006f00720000001000000063006c00690065006e00740032000000'
Beacon>exit
```

Lastly, copy the hexified numeric values (just the numbers) into your execution command

```
COFFLoader64.exe go ..\CS-Situational-Awareness-BOF\SA\netuser\netuser.x64.o 340000001c000000410064006d0069006e006900730074007200610074006f00720000001000000063006c00690065006e00740032000000
```

You can find more detailed examples at this link:

[https://trustedsec.com/blog/situational-awareness-bofs-for-script-kiddies](https://trustedsec.com/blog/situational-awareness-bofs-for-script-kiddies)

## Running

[Permalink: Running](https://github.com/sliverarmory/COFFLoader/#running)

An example of how to run a BOF is below.

```
COFFLoader64.exe go test64.out
COFFLoader64.exe go ..\CS-Situational-Awareness-BOF\SA\whoami\whoami.x64.o
```

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/sliverarmory/COFFLoader/#readme-ov-file)

### License

[View license](https://github.com/sliverarmory/COFFLoader/#License-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/sliverarmory/COFFLoader/).

[Activity](https://github.com/sliverarmory/COFFLoader/activity)

[Custom properties](https://github.com/sliverarmory/COFFLoader/custom-properties)

### Stars

[**50**\\
stars](https://github.com/sliverarmory/COFFLoader/stargazers)

### Watchers

[**0**\\
watching](https://github.com/sliverarmory/COFFLoader/watchers)

### Forks

[**8**\\
forks](https://github.com/sliverarmory/COFFLoader/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fsliverarmory%2FCOFFLoader&report=sliverarmory+%28user%29)

## [Releases\  14](https://github.com/sliverarmory/COFFLoader/releases)

[v1.0.16\\
Latest\\
\\
on Dec 15, 2025Dec 15, 2025](https://github.com/sliverarmory/COFFLoader/releases/tag/v1.0.16)

[\+ 13 releases](https://github.com/sliverarmory/COFFLoader/releases)

## [Packages\  0](https://github.com/orgs/sliverarmory/packages?repo_name=COFFLoader)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/sliverarmory/COFFLoader/).

## Languages

- C93.7%
- Python4.2%
- Makefile2.1%

You can’t perform that action at this time.