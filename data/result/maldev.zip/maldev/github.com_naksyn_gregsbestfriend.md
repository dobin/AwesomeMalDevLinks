# https://github.com/naksyn/GregsBestFriend

[Skip to content](https://github.com/naksyn/GregsBestFriend#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/naksyn/GregsBestFriend) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/naksyn/GregsBestFriend) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/naksyn/GregsBestFriend) to refresh your session.Dismiss alert

{{ message }}

[naksyn](https://github.com/naksyn)/ **[GregsBestFriend](https://github.com/naksyn/GregsBestFriend)** Public

forked from [WKL-Sec/GregsBestFriend](https://github.com/WKL-Sec/GregsBestFriend)

- [Notifications](https://github.com/login?return_to=%2Fnaksyn%2FGregsBestFriend) You must be signed in to change notification settings
- [Fork\\
0](https://github.com/login?return_to=%2Fnaksyn%2FGregsBestFriend)
- [Star\\
1](https://github.com/login?return_to=%2Fnaksyn%2FGregsBestFriend)


GregsBestFriend process injection code created from the White Knight Labs Offensive Development course


### License

[MIT license](https://github.com/naksyn/GregsBestFriend/blob/main/LICENSE)

[1\\
star](https://github.com/naksyn/GregsBestFriend/stargazers) [35\\
forks](https://github.com/naksyn/GregsBestFriend/forks) [Branches](https://github.com/naksyn/GregsBestFriend/branches) [Tags](https://github.com/naksyn/GregsBestFriend/tags) [Activity](https://github.com/naksyn/GregsBestFriend/activity)

[Star](https://github.com/login?return_to=%2Fnaksyn%2FGregsBestFriend)

[Notifications](https://github.com/login?return_to=%2Fnaksyn%2FGregsBestFriend) You must be signed in to change notification settings

# naksyn/GregsBestFriend

main

[**2** Branches](https://github.com/naksyn/GregsBestFriend/branches) [**0** Tags](https://github.com/naksyn/GregsBestFriend/tags)

[Go to Branches page](https://github.com/naksyn/GregsBestFriend/branches)[Go to Tags page](https://github.com/naksyn/GregsBestFriend/tags)

Go to file

Code

Open more actions menu

This branch is up to date with WKL-Sec/GregsBestFriend:main.

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![WKL-Sec](https://avatars.githubusercontent.com/u/97109724?v=4&size=40)](https://github.com/WKL-Sec)[WKL-Sec](https://github.com/naksyn/GregsBestFriend/commits?author=WKL-Sec)<br>[Update README.md](https://github.com/naksyn/GregsBestFriend/commit/7c97e99e4c580aa34728bb5e62317154c8a45b63)<br>3 years agoMay 1, 2023<br>[7c97e99](https://github.com/naksyn/GregsBestFriend/commit/7c97e99e4c580aa34728bb5e62317154c8a45b63) · 3 years agoMay 1, 2023<br>## History<br>[34 Commits](https://github.com/naksyn/GregsBestFriend/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/naksyn/GregsBestFriend/commits/main/) 34 Commits |
| [CL](https://github.com/naksyn/GregsBestFriend/tree/main/CL "CL") | [CL](https://github.com/naksyn/GregsBestFriend/tree/main/CL "CL") | [Create GregsBestFriend.cpp](https://github.com/naksyn/GregsBestFriend/commit/bd9314c1fe9febe4c69ff2fc60cdd5fb125cfa63 "Create GregsBestFriend.cpp") | 3 years agoApr 30, 2023 |
| [Clang++](https://github.com/naksyn/GregsBestFriend/tree/main/Clang%2B%2B "Clang++") | [Clang++](https://github.com/naksyn/GregsBestFriend/tree/main/Clang%2B%2B "Clang++") | [Update README.md](https://github.com/naksyn/GregsBestFriend/commit/e312d720639f3bdbe1e2d89fa6dc79ca41782c4a "Update README.md") | 3 years agoApr 30, 2023 |
| [Clang-LLVM](https://github.com/naksyn/GregsBestFriend/tree/main/Clang-LLVM "Clang-LLVM") | [Clang-LLVM](https://github.com/naksyn/GregsBestFriend/tree/main/Clang-LLVM "Clang-LLVM") | [Create GregsBestFriend.cpp](https://github.com/naksyn/GregsBestFriend/commit/208b1438ec743c98eb06864fedbb636f82221d74 "Create GregsBestFriend.cpp") | 3 years agoMay 1, 2023 |
| [G++](https://github.com/naksyn/GregsBestFriend/tree/main/G%2B%2B "G++") | [G++](https://github.com/naksyn/GregsBestFriend/tree/main/G%2B%2B "G++") | [Create README.md](https://github.com/naksyn/GregsBestFriend/commit/18a35494a3bb486fe8ba381e980778a5c348b31d "Create README.md") | 3 years agoApr 30, 2023 |
| [Visual Studio](https://github.com/naksyn/GregsBestFriend/tree/main/Visual%20Studio "Visual Studio") | [Visual Studio](https://github.com/naksyn/GregsBestFriend/tree/main/Visual%20Studio "Visual Studio") | [Update README.md](https://github.com/naksyn/GregsBestFriend/commit/b9fd01acfbf37f7ea1b4e5534df54530e14062dd "Update README.md") | 3 years agoMay 1, 2023 |
| [images](https://github.com/naksyn/GregsBestFriend/tree/main/images "images") | [images](https://github.com/naksyn/GregsBestFriend/tree/main/images "images") | [Add files via upload](https://github.com/naksyn/GregsBestFriend/commit/c1a4fde40ea886ee56b18025e29719df44bef5e9 "Add files via upload") | 3 years agoApr 30, 2023 |
| [LICENSE](https://github.com/naksyn/GregsBestFriend/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/naksyn/GregsBestFriend/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/naksyn/GregsBestFriend/commit/4fde72d1da9f106a76539990bf35c9afefb7058b "Initial commit") | 3 years agoApr 30, 2023 |
| [README.md](https://github.com/naksyn/GregsBestFriend/blob/main/README.md "README.md") | [README.md](https://github.com/naksyn/GregsBestFriend/blob/main/README.md "README.md") | [Update README.md](https://github.com/naksyn/GregsBestFriend/commit/7c97e99e4c580aa34728bb5e62317154c8a45b63 "Update README.md") | 3 years agoMay 1, 2023 |
| View all files |

## Repository files navigation

# GregsBestFriend - Bypassing AV/EDR and Building with Different Compilers

[Permalink: GregsBestFriend - Bypassing AV/EDR and Building with Different Compilers](https://github.com/naksyn/GregsBestFriend#gregsbestfriend---bypassing-avedr-and-building-with-different-compilers)

GregsBestFriend is a tool designed to bypass AV/EDR systems, and can be built using different compilers to achieve better results. Each compiler produces a different executable, and using different compilers can help break away from using the Microsoft Visual C++ compiler (cl.exe), which is often used and can lead to detections.

## Introduction

[Permalink: Introduction](https://github.com/naksyn/GregsBestFriend#introduction)

GregsBestFriend was created for the [White Knight Labs Offensive Development Course](https://www.antisyphontraining.com/offensive-development-w-greg-hatcher-john-stigerwalt/) to demonstrate how easy it is to bypass AV/EDR systems. The tool serves as a starting point and can be used as a base for developers to build upon. The course creators have shown that GregsBestFriend can be successful in bypassing every AV/EDR system that exists today, provided it is used correctly.

The use of AV and EDR systems is crucial in detecting and preventing malware and other malicious software from infecting a system. However, as demonstrated by GregsBestFriend, these systems can be bypassed if not properly configured or if an attacker has access to a system.

The development of tools like GregsBestFriend highlights the importance of constantly updating and improving AV and EDR systems to ensure their effectiveness against evolving threats. By understanding how these systems can be bypassed, security professionals can better protect against potential attacks and mitigate risks.

## Building with Different Compilers

[Permalink: Building with Different Compilers](https://github.com/naksyn/GregsBestFriend#building-with-different-compilers)

Different compilers have their own set of optimizations and flags that can be used to tailor the output for specific use cases. By experimenting with different compilers, users can achieve better performance and potentially bypass more AV/EDR systems.

For example, Clang++ provides several optimization flags that can help reduce the size of the compiled code, while GCC (G++) is known for its high-performance optimization capabilities. By using different compilers, users can achieve a unique executable that can evade detection.

Building GregsBestFriend with different compilers ensures that the tool remains versatile and adaptable to different systems and environments. Users can choose the compiler that best suits their needs and build the tool accordingly.

In conclusion, building GregsBestFriend with different compilers allows users to achieve better results in bypassing AV/EDR systems. Each compiler produces a unique executable, which can help evade detection. By using different compilers, users can tailor the output to their specific needs, ensuring the versatility and adaptability of the tool.

## Building

[Permalink: Building](https://github.com/naksyn/GregsBestFriend#building)

To build GregsBestFriend, follow these steps:

1. Navigate to the appropriate folder for your desired compiler.
2. Follow the instructions provided in the README file to build the tool with your desired compiler.

## Details on the C++ Code

[Permalink: Details on the C++ Code](https://github.com/naksyn/GregsBestFriend#details-on-the-c-code)

The GregsBestFriend C++ code includes a loop that runs `MAX_OP` times, where `MAX_OP` is defined as a large number. This loop is intended to waste CPU cycles and help prevent sandbox execution. Additionally, the code checks the name of the executable to ensure that it includes the string "GregsBestFriend". This is done to help prevent sandbox execution, as many sandboxes rename the executable when running it.

## VirusTotal Analysis

[Permalink: VirusTotal Analysis](https://github.com/naksyn/GregsBestFriend#virustotal-analysis)

We do not recommend uploading the final executable to VirusTotal, as this could result in the tool being detected by antivirus software.

Instead, we recommend uploading the tool to [antiscan.me](https://antiscan.me/) or [kleenscan.com](https://kleenscan.com/) for analysis.

Please note that uploading the tool to any online virus scanner or malware analysis service is done at your own risk and could potentially result in your tool being detected by antivirus software.

Below is an example result of uploading GregsBestFriend to VirusTotal (for demonstration purposes only):

[![VirusTotal Results](https://github.com/naksyn/GregsBestFriend/raw/main/images/VT1.png)](https://www.virustotal.com/)

## References

[Permalink: References](https://github.com/naksyn/GregsBestFriend#references)

- [Different flavors of the Clang compiler for Windows](https://blog.conan.io/2022/10/13/Different-flavors-Clang-compiler-Windows.html)
- [Embedded Linux Conference](https://static.sched.com/hosted_files/ossna2020/f9/OSSEmbeddedLinuxConference.pdf)

## About

GregsBestFriend process injection code created from the White Knight Labs Offensive Development course


### Resources

[Readme](https://github.com/naksyn/GregsBestFriend#readme-ov-file)

### License

[MIT license](https://github.com/naksyn/GregsBestFriend#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/naksyn/GregsBestFriend).

[Activity](https://github.com/naksyn/GregsBestFriend/activity)

### Stars

[**1**\\
star](https://github.com/naksyn/GregsBestFriend/stargazers)

### Watchers

[**0**\\
watching](https://github.com/naksyn/GregsBestFriend/watchers)

### Forks

[**0**\\
forks](https://github.com/naksyn/GregsBestFriend/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fnaksyn%2FGregsBestFriend&report=naksyn+%28user%29)

## [Releases](https://github.com/naksyn/GregsBestFriend/releases)

No releases published

## [Packages\  0](https://github.com/users/naksyn/packages?repo_name=GregsBestFriend)

No packages published

## Languages

- C++100.0%

You can’t perform that action at this time.