# https://github.com/tijme/kong-loader

[Skip to content](https://github.com/tijme/kong-loader#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/tijme/kong-loader) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/tijme/kong-loader) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/tijme/kong-loader) to refresh your session.Dismiss alert

{{ message }}

[tijme](https://github.com/tijme)/ **[kong-loader](https://github.com/tijme/kong-loader)** Public

- Sponsor







# Sponsor tijme/kong-loader























##### GitHub Sponsors

[Learn more about Sponsors](https://github.com/sponsors)







[![@tijme](https://avatars.githubusercontent.com/u/5873573?s=80&v=4)](https://github.com/tijme)



[tijme](https://github.com/tijme)



[tijme](https://github.com/tijme)



[Sponsor](https://github.com/sponsors/tijme)









##### External links









[paypal.me/tijmegommers](http://paypal.me/tijmegommers)









[Learn more about funding links in repositories](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/displaying-a-sponsor-button-in-your-repository).




[Report abuse](https://github.com/contact/report-abuse?report=tijme%2Fkong-loader+%28Repository+Funding+Links%29)

- [Notifications](https://github.com/login?return_to=%2Ftijme%2Fkong-loader) You must be signed in to change notification settings
- [Fork\\
5](https://github.com/login?return_to=%2Ftijme%2Fkong-loader)
- [Star\\
63](https://github.com/login?return_to=%2Ftijme%2Fkong-loader)


Using Just In Time (JIT) instruction decryption, this shellcode loader ensures that only the currently executing instruction is visible in memory.


### License

[MPL-2.0 license](https://github.com/tijme/kong-loader/blob/master/LICENSE.md)

[63\\
stars](https://github.com/tijme/kong-loader/stargazers) [5\\
forks](https://github.com/tijme/kong-loader/forks) [Branches](https://github.com/tijme/kong-loader/branches) [Tags](https://github.com/tijme/kong-loader/tags) [Activity](https://github.com/tijme/kong-loader/activity)

[Star](https://github.com/login?return_to=%2Ftijme%2Fkong-loader)

[Notifications](https://github.com/login?return_to=%2Ftijme%2Fkong-loader) You must be signed in to change notification settings

# tijme/kong-loader

master

[**1** Branch](https://github.com/tijme/kong-loader/branches) [**6** Tags](https://github.com/tijme/kong-loader/tags)

[Go to Branches page](https://github.com/tijme/kong-loader/branches)[Go to Tags page](https://github.com/tijme/kong-loader/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![tijme](https://avatars.githubusercontent.com/u/5873573?v=4&size=40)](https://github.com/tijme)[tijme](https://github.com/tijme/kong-loader/commits?author=tijme)<br>[Added Relocatable reference to README.md](https://github.com/tijme/kong-loader/commit/6b911e94fc2b2213333f1f5bce4ea72ab2d3dea8)<br>success<br>11 months agoApr 2, 2025<br>[6b911e9](https://github.com/tijme/kong-loader/commit/6b911e94fc2b2213333f1f5bce4ea72ab2d3dea8) · 11 months agoApr 2, 2025<br>## History<br>[6 Commits](https://github.com/tijme/kong-loader/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/tijme/kong-loader/commits/master/) 6 Commits |
| [.github](https://github.com/tijme/kong-loader/tree/master/.github ".github") | [.github](https://github.com/tijme/kong-loader/tree/master/.github ".github") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [dst](https://github.com/tijme/kong-loader/tree/master/dst "dst") | [dst](https://github.com/tijme/kong-loader/tree/master/dst "dst") | [Added template shellcode.](https://github.com/tijme/kong-loader/commit/d908c0bb9cdf963045909d1153510e9beaef5301 "Added template shellcode.") | 11 months agoMar 24, 2025 |
| [inc](https://github.com/tijme/kong-loader/tree/master/inc "inc") | [inc](https://github.com/tijme/kong-loader/tree/master/inc "inc") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [lib](https://github.com/tijme/kong-loader/tree/master/lib "lib") | [lib](https://github.com/tijme/kong-loader/tree/master/lib "lib") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [sig](https://github.com/tijme/kong-loader/tree/master/sig "sig") | [sig](https://github.com/tijme/kong-loader/tree/master/sig "sig") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [src](https://github.com/tijme/kong-loader/tree/master/src "src") | [src](https://github.com/tijme/kong-loader/tree/master/src "src") | [Added template shellcode.](https://github.com/tijme/kong-loader/commit/d908c0bb9cdf963045909d1153510e9beaef5301 "Added template shellcode.") | 11 months agoMar 24, 2025 |
| [.gitignore](https://github.com/tijme/kong-loader/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/tijme/kong-loader/blob/master/.gitignore ".gitignore") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [LICENSE.md](https://github.com/tijme/kong-loader/blob/master/LICENSE.md "LICENSE.md") | [LICENSE.md](https://github.com/tijme/kong-loader/blob/master/LICENSE.md "LICENSE.md") | [Initial commit](https://github.com/tijme/kong-loader/commit/e0a4f4ca7de3704c7ab688f8afb8aa8487d7ea3c "Initial commit") | 2 years agoOct 14, 2024 |
| [README.md](https://github.com/tijme/kong-loader/blob/master/README.md "README.md") | [README.md](https://github.com/tijme/kong-loader/blob/master/README.md "README.md") | [Added Relocatable reference to README.md](https://github.com/tijme/kong-loader/commit/6b911e94fc2b2213333f1f5bce4ea72ab2d3dea8 "Added Relocatable reference to README.md") | 11 months agoApr 2, 2025 |
| [makefile](https://github.com/tijme/kong-loader/blob/master/makefile "makefile") | [makefile](https://github.com/tijme/kong-loader/blob/master/makefile "makefile") | [Added explicit checks to crash on direct syscalls, as these are not s…](https://github.com/tijme/kong-loader/commit/765a42834ec9b01565bcda70308e56740eb833e7 "Added explicit checks to crash on direct syscalls, as these are not supported yet.") | 2 years agoOct 14, 2024 |
| View all files |

## Repository files navigation

[![Kong Loader Banner](https://gist.githubusercontent.com/tijme/ce0ad845cfaaa0fb9a1897dca8dcc4e8/raw/20a617fed67d0f0f1d05f1d079704b6965fe9fc5/KongLoaderBanner.svg)](https://gist.githubusercontent.com/tijme/ce0ad845cfaaa0fb9a1897dca8dcc4e8/raw/20a617fed67d0f0f1d05f1d079704b6965fe9fc5/KongLoaderBanner.svg)

[![](https://camo.githubusercontent.com/3baf3005802d8389da19b65f65b894a00fe12b4ff8b1972907f1631234952528/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4c6963656e73652d4d504c25323056322e302d3532376335303f7374796c653d666f722d7468652d6261646765266c6162656c436f6c6f723d326234653334)](https://github.com/tijme/kong-loader/blob/master/LICENSE.md)[![](https://camo.githubusercontent.com/a11e0563084f7b92b4b447319799cd68b258f8cc4dc76d1ae5f010014a84596b/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f762f72656c656173652f74696a6d652f6b6f6e672d6c6f616465723f7374796c653d666f722d7468652d6261646765266c6162656c436f6c6f723d32623465333426636f6c6f723d3532376335302663616368653d31)](https://github.com/tijme/kong-loader/releases)[![](https://camo.githubusercontent.com/06c5fee63b1ac2eb8e3939bcd4729da84d2d8eced5d21c792403298318dd1385/68747470733a2f2f696d672e736869656c64732e696f2f6769746875622f616374696f6e732f776f726b666c6f772f7374617475732f74696a6d652f6b6f6e672d6c6f616465722f636f6d70696c652e796d6c3f7374796c653d666f722d7468652d6261646765266c6162656c436f6c6f723d32623465333426636f6c6f723d353237633530)](https://github.com/tijme/kong-loader/actions)

**The hidden ART of rolling shellcode decryption.**

Built with ♥ by [Tijme Gommers](https://x.com/tijme) – Buy me a coffee via [PayPal](https://www.paypal.me/tijmegommers).

[Abstract](https://github.com/tijme/kong-loader#abstract)
•
[Getting started](https://github.com/tijme/kong-loader#getting-started)
•
[Caveats](https://github.com/tijme/kong-loader#caveats)
•
[Future work](https://github.com/tijme/kong-loader#future-work)
•
[Issues & requests](https://github.com/tijme/kong-loader#issues--requests)
•
[License & copyright](https://github.com/tijme/kong-loader#license--copyright)

* * *

## Abstract

[Permalink: Abstract](https://github.com/tijme/kong-loader#abstract)

Executing malicious shellcode may trigger memory scans by EDR, leading to detection of your malware. Sleep masks were introduced to ensure that your malware is encrypted in memory while it's idle (sleeping), aiming to prevent that detection. Using sleep masks, your malware is decrypted after sleeping, executes commands, and is then encrypted and instructed to sleep again. This ensures that your malware is only briefly visible in memory.

**Kong Loader** prevents your malware from being visible in memory _entirely_ and _whatsoever_, even while executing commands. It uses rolling decryption, terminology I'm likely misusing, but which _does_ represent how Kong Loader works. For each assembly instruction, Kong Loader decrypts that specific assembly instruction, executes it, and encrypts it again. This means only the currently executing instruction is visible in memory, which is insufficient for EDR to trigger detection on.

## Getting started

[Permalink: Getting started](https://github.com/tijme/kong-loader#getting-started)

Clone this repository first. Install the dependencies, then [review the code](https://github.com/tijme/kong-loader/blob/master/.github/laughing.gif) and compile it from source. The steps below were tested on MacOS x64 and arm64.

**Dependencies**

- [MinGW](https://formulae.brew.sh/formula/mingw-w64)

**Compiling**

```
make
```

**Usage**

Execute `./dst/KongLoader.x64.exe` on your Windows target machine.

## Caveats

[Permalink: Caveats](https://github.com/tijme/kong-loader#caveats)

There are various caveats, for both offensive & defensive cyber security. Some examples:

- Memory corruptions might occur if the shellcode tries to alter itself during runtime.
- Kong Loader's native code can be signatured and thus easily detected.
- The execution is extremely slow, and can currently only be used for tiny first stage malware.
  - Use [Relocatable](https://github.com/tijme/relocatable) to develop your tiny & truly Position Independent Code (PIC).
- Malware that runs using Kong Loader can be hardly debugged.
  - Exceptions trigger in your debugger, for every single instruction.
  - Exceptions can't be dismissed, as they decrypt the instruction to be executed.
  - Ignoring the exceptions using `sxi sse` (windbg) adds millions of instructions per instruction to be executed.
- Multi-threading is not supported as encryption race conditions would occur.

## Detection

[Permalink: Detection](https://github.com/tijme/kong-loader#detection)

At this moment, it is quite easy to detect Kong Loader because Kong Loader's native code is static and can therefore be signatured. There is no polymorphic engine yet that modifies the static code during each build. The following files contains rules that allows you to detect Kong Loader:

- [`kong_loader_native_code.yara` (Yara)](https://github.com/tijme/kong-loader/blob/master/sig/kong_loader_native_code.yara)

## Future work

[Permalink: Future work](https://github.com/tijme/kong-loader#future-work)

- Write a shellcode transpiler that transpiles to a interpretable format that prevents the need of a disassembler.
  - This essentialy moves the Kong Loader funcionality from runtime to compile time.
- Possibly decrypt full basic blocks instead of single instructions, to improve speed.
- Make use of a polymorphic engine to ensure that the native code does not contain static signatures.

## Issues & requests

[Permalink: Issues & requests](https://github.com/tijme/kong-loader#issues--requests)

Issues or new feature requests can be reported via the [issue tracker](https://github.com/tijme/kong-loader/issues). Please make sure your issue or feature has not yet been reported by anyone else before submitting a new one.

## License & copyright

[Permalink: License & copyright](https://github.com/tijme/kong-loader#license--copyright)

Copyright (c) 2024 Tijme Gommers. Kong Loader is released under the Mozilla Public License Version 2.0. View [LICENSE.md](https://github.com/tijme/kong-loader/blob/master/LICENSE.md) for the full license. Kong Loader depends on [Zydis](https://zydis.re/), which is licenced under the [MIT Licence](https://github.com/zyantific/zydis/blob/master/LICENSE).

## About

Using Just In Time (JIT) instruction decryption, this shellcode loader ensures that only the currently executing instruction is visible in memory.


### Topics

[memory](https://github.com/topics/memory "Topic: memory") [loader](https://github.com/topics/loader "Topic: loader") [shellcode](https://github.com/topics/shellcode "Topic: shellcode") [evasion](https://github.com/topics/evasion "Topic: evasion") [scanning](https://github.com/topics/scanning "Topic: scanning") [redteam](https://github.com/topics/redteam "Topic: redteam") [cobaltstrike](https://github.com/topics/cobaltstrike "Topic: cobaltstrike")

### Resources

[Readme](https://github.com/tijme/kong-loader#readme-ov-file)

### License

[MPL-2.0 license](https://github.com/tijme/kong-loader#MPL-2.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/tijme/kong-loader).

[Activity](https://github.com/tijme/kong-loader/activity)

### Stars

[**63**\\
stars](https://github.com/tijme/kong-loader/stargazers)

### Watchers

[**1**\\
watching](https://github.com/tijme/kong-loader/watchers)

### Forks

[**5**\\
forks](https://github.com/tijme/kong-loader/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Ftijme%2Fkong-loader&report=tijme+%28user%29)

## [Releases\  6](https://github.com/tijme/kong-loader/releases)

[Release 6b911e94\\
Latest\\
\\
on Apr 2, 2025Apr 2, 2025](https://github.com/tijme/kong-loader/releases/tag/tag-6b911e94)

[\+ 5 releases](https://github.com/tijme/kong-loader/releases)

## Sponsor this project

- [![@tijme](https://avatars.githubusercontent.com/u/5873573?s=64&v=4)](https://github.com/tijme)[**tijme** Tijme Gommers](https://github.com/tijme)[Sponsor @tijme](https://github.com/sponsors/tijme)

- [paypal.me/tijmegommers](http://paypal.me/tijmegommers)

[Learn more about GitHub Sponsors](https://github.com/sponsors)

## Languages

- [C99.9%](https://github.com/tijme/kong-loader/search?l=c)
- Other0.1%

You can’t perform that action at this time.