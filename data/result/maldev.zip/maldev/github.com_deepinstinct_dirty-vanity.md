# https://github.com/deepinstinct/Dirty-Vanity

[Skip to content](https://github.com/deepinstinct/Dirty-Vanity#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/deepinstinct/Dirty-Vanity) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/deepinstinct/Dirty-Vanity) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/deepinstinct/Dirty-Vanity) to refresh your session.Dismiss alert

{{ message }}

[deepinstinct](https://github.com/deepinstinct)/ **[Dirty-Vanity](https://github.com/deepinstinct/Dirty-Vanity)** Public

- [Notifications](https://github.com/login?return_to=%2Fdeepinstinct%2FDirty-Vanity) You must be signed in to change notification settings
- [Fork\\
89](https://github.com/login?return_to=%2Fdeepinstinct%2FDirty-Vanity)
- [Star\\
675](https://github.com/login?return_to=%2Fdeepinstinct%2FDirty-Vanity)


A POC for the new injection technique, abusing windows fork API to evade EDRs. [https://www.blackhat.com/eu-22/briefings/schedule/index.html#dirty-vanity-a-new-approach-to-code-injection--edr-bypass-28417](https://www.blackhat.com/eu-22/briefings/schedule/index.html#dirty-vanity-a-new-approach-to-code-injection--edr-bypass-28417)

[675\\
stars](https://github.com/deepinstinct/Dirty-Vanity/stargazers) [89\\
forks](https://github.com/deepinstinct/Dirty-Vanity/forks) [Branches](https://github.com/deepinstinct/Dirty-Vanity/branches) [Tags](https://github.com/deepinstinct/Dirty-Vanity/tags) [Activity](https://github.com/deepinstinct/Dirty-Vanity/activity)

[Star](https://github.com/login?return_to=%2Fdeepinstinct%2FDirty-Vanity)

[Notifications](https://github.com/login?return_to=%2Fdeepinstinct%2FDirty-Vanity) You must be signed in to change notification settings

# deepinstinct/Dirty-Vanity

main

[**1** Branch](https://github.com/deepinstinct/Dirty-Vanity/branches) [**0** Tags](https://github.com/deepinstinct/Dirty-Vanity/tags)

[Go to Branches page](https://github.com/deepinstinct/Dirty-Vanity/branches)[Go to Tags page](https://github.com/deepinstinct/Dirty-Vanity/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![SecurityResearchDeepInstinct](https://avatars.githubusercontent.com/u/75027859?v=4&size=40)](https://github.com/SecurityResearchDeepInstinct)[SecurityResearchDeepInstinct](https://github.com/deepinstinct/Dirty-Vanity/commits?author=SecurityResearchDeepInstinct)<br>[Update DirtyVanity.cpp](https://github.com/deepinstinct/Dirty-Vanity/commit/30c2ba7c1caa35378403b75b8caee3e5eb18614c)<br>4 years agoDec 7, 2022<br>[30c2ba7](https://github.com/deepinstinct/Dirty-Vanity/commit/30c2ba7c1caa35378403b75b8caee3e5eb18614c) · 4 years agoDec 7, 2022<br>## History<br>[3 Commits](https://github.com/deepinstinct/Dirty-Vanity/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/deepinstinct/Dirty-Vanity/commits/main/) 3 Commits |
| [DirtyVanity](https://github.com/deepinstinct/Dirty-Vanity/tree/main/DirtyVanity "DirtyVanity") | [DirtyVanity](https://github.com/deepinstinct/Dirty-Vanity/tree/main/DirtyVanity "DirtyVanity") | [Update DirtyVanity.cpp](https://github.com/deepinstinct/Dirty-Vanity/commit/30c2ba7c1caa35378403b75b8caee3e5eb18614c "Update DirtyVanity.cpp") | 4 years agoDec 7, 2022 |
| [shellcode\_template](https://github.com/deepinstinct/Dirty-Vanity/tree/main/shellcode_template "shellcode_template") | [shellcode\_template](https://github.com/deepinstinct/Dirty-Vanity/tree/main/shellcode_template "shellcode_template") | [Base commit](https://github.com/deepinstinct/Dirty-Vanity/commit/0c9b0da812b9167359c2b1cc70bddcf0f54e271a "Base commit") | 4 years agoDec 4, 2022 |
| [.gitignore](https://github.com/deepinstinct/Dirty-Vanity/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/deepinstinct/Dirty-Vanity/blob/main/.gitignore ".gitignore") | [VS git ignore](https://github.com/deepinstinct/Dirty-Vanity/commit/2da90dcc43f9da91cf2dfc7b700e14ad563589db "VS git ignore") | 4 years agoDec 4, 2022 |
| [DirtyVanity.sln](https://github.com/deepinstinct/Dirty-Vanity/blob/main/DirtyVanity.sln "DirtyVanity.sln") | [DirtyVanity.sln](https://github.com/deepinstinct/Dirty-Vanity/blob/main/DirtyVanity.sln "DirtyVanity.sln") | [Base commit](https://github.com/deepinstinct/Dirty-Vanity/commit/0c9b0da812b9167359c2b1cc70bddcf0f54e271a "Base commit") | 4 years agoDec 4, 2022 |
| [NtCreateUserProcessShellcode.txt](https://github.com/deepinstinct/Dirty-Vanity/blob/main/NtCreateUserProcessShellcode.txt "NtCreateUserProcessShellcode.txt") | [NtCreateUserProcessShellcode.txt](https://github.com/deepinstinct/Dirty-Vanity/blob/main/NtCreateUserProcessShellcode.txt "NtCreateUserProcessShellcode.txt") | [Base commit](https://github.com/deepinstinct/Dirty-Vanity/commit/0c9b0da812b9167359c2b1cc70bddcf0f54e271a "Base commit") | 4 years agoDec 4, 2022 |
| [README.md](https://github.com/deepinstinct/Dirty-Vanity/blob/main/README.md "README.md") | [README.md](https://github.com/deepinstinct/Dirty-Vanity/blob/main/README.md "README.md") | [Base commit](https://github.com/deepinstinct/Dirty-Vanity/commit/0c9b0da812b9167359c2b1cc70bddcf0f54e271a "Base commit") | 4 years agoDec 4, 2022 |
| View all files |

## Repository files navigation

# Dirty Vanity

[Permalink: Dirty Vanity](https://github.com/deepinstinct/Dirty-Vanity#dirty-vanity)

A POC for the new injection technique, abusing windows fork API to evade EDRs.

### Usage

[Permalink: Usage](https://github.com/deepinstinct/Dirty-Vanity#usage)

DirtyVanity.exe \[TARGET\_PID\_TO\_REFLECT\]

### Runtime steps

[Permalink: Runtime steps](https://github.com/deepinstinct/Dirty-Vanity#runtime-steps)

- Allocate and write shellcode to \[TARGET\_PID\_TO\_REFLECT\]
- Fork \[TARGET\_PID\_TO\_REFLECT\] to a new process
- Set the forked process's start address to the cloned shellcode

### Shellcode

[Permalink: Shellcode](https://github.com/deepinstinct/Dirty-Vanity#shellcode)

The reflected shellcode works with ntdll API. It is generated from the included generation project `shellcode_template`,
curtesy of [https://github.com/rainerzufalldererste/windows\_x64\_shellcode\_template](https://github.com/rainerzufalldererste/windows_x64_shellcode_template)

### Shellcode customization

[Permalink: Shellcode customization](https://github.com/deepinstinct/Dirty-Vanity#shellcode-customization)

To customize the shellcode with ease:

- Edit the `shellcode_template` function inside the `shellcode_template` project, according to the instructions in [https://github.com/rainerzufalldererste/windows\_x64\_shellcode\_template](https://github.com/rainerzufalldererste/windows_x64_shellcode_template)
- Compile it
- Crop the `shellcode_template` function bytes using your faivorite PE parsing tool (eg IDA)
- Those bytes are position independet shellcode. place them in `DirtyVanity.cpp`
- Execute DirtyVanity to watch them get Reflected

## About

A POC for the new injection technique, abusing windows fork API to evade EDRs. [https://www.blackhat.com/eu-22/briefings/schedule/index.html#dirty-vanity-a-new-approach-to-code-injection--edr-bypass-28417](https://www.blackhat.com/eu-22/briefings/schedule/index.html#dirty-vanity-a-new-approach-to-code-injection--edr-bypass-28417)

### Resources

[Readme](https://github.com/deepinstinct/Dirty-Vanity#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/deepinstinct/Dirty-Vanity).

[Activity](https://github.com/deepinstinct/Dirty-Vanity/activity)

[Custom properties](https://github.com/deepinstinct/Dirty-Vanity/custom-properties)

### Stars

[**675**\\
stars](https://github.com/deepinstinct/Dirty-Vanity/stargazers)

### Watchers

[**3**\\
watching](https://github.com/deepinstinct/Dirty-Vanity/watchers)

### Forks

[**89**\\
forks](https://github.com/deepinstinct/Dirty-Vanity/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fdeepinstinct%2FDirty-Vanity&report=deepinstinct+%28user%29)

## [Releases](https://github.com/deepinstinct/Dirty-Vanity/releases)

No releases published

## [Packages\  0](https://github.com/orgs/deepinstinct/packages?repo_name=Dirty-Vanity)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/deepinstinct/Dirty-Vanity).

## Languages

- [C91.0%](https://github.com/deepinstinct/Dirty-Vanity/search?l=c)
- [C++9.0%](https://github.com/deepinstinct/Dirty-Vanity/search?l=c%2B%2B)

You can’t perform that action at this time.