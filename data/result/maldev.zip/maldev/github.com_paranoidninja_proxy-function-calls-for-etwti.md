# https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI

[Skip to content](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI) to refresh your session.Dismiss alert

{{ message }}

[paranoidninja](https://github.com/paranoidninja)/ **[Proxy-Function-Calls-For-ETwTI](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI)** Public

- [Notifications](https://github.com/login?return_to=%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI) You must be signed in to change notification settings
- [Fork\\
40](https://github.com/login?return_to=%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI)
- [Star\\
210](https://github.com/login?return_to=%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI)


The code is a pingback to the Dark Vortex blog: [https://0xdarkvortex.dev/hiding-memory-allocations-from-mdatp-etwti-stack-tracing/](https://0xdarkvortex.dev/hiding-memory-allocations-from-mdatp-etwti-stack-tracing/)

### License

[GPL-3.0 license](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/LICENSE)

[210\\
stars](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/stargazers) [40\\
forks](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/forks) [Branches](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/branches) [Tags](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/tags) [Activity](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/activity)

[Star](https://github.com/login?return_to=%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI)

[Notifications](https://github.com/login?return_to=%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI) You must be signed in to change notification settings

# paranoidninja/Proxy-Function-Calls-For-ETwTI

main

[**1** Branch](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/branches) [**0** Tags](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/tags)

[Go to Branches page](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/branches)[Go to Tags page](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![paranoidninja](https://avatars.githubusercontent.com/u/21009111?v=4&size=40)](https://github.com/paranoidninja)[paranoidninja](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commits?author=paranoidninja)<br>[Update README.md](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/aff7b44e61cb7eae83a6218db492327f7d263300)<br>3 years agoJan 29, 2023<br>[aff7b44](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/aff7b44e61cb7eae83a6218db492327f7d263300) · 3 years agoJan 29, 2023<br>## History<br>[8 Commits](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commits/main/) 8 Commits |
| [LICENSE](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/247dfcce9babbf64eb3f3218929c6b96c463e95c "Initial commit") | 3 years agoJan 29, 2023 |
| [README.md](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/README.md "README.md") | [README.md](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/README.md "README.md") | [Update README.md](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/aff7b44e61cb7eae83a6218db492327f7d263300 "Update README.md") | 3 years agoJan 29, 2023 |
| [proxyAPICall.c](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/proxyAPICall.c "proxyAPICall.c") | [proxyAPICall.c](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/proxyAPICall.c "proxyAPICall.c") | [Ba Dum Tss](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/36ca3897f6972cca65711e29ff08e300c527a5ee "Ba Dum Tss") | 3 years agoJan 29, 2023 |
| [proxyHelper.asm](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/proxyHelper.asm "proxyHelper.asm") | [proxyHelper.asm](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/blob/main/proxyHelper.asm "proxyHelper.asm") | [Rename proxyHelper to proxyHelper.asm](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/commit/06dcc0d0cc54c190321bd279b69cd5810b2d59ec "Rename proxyHelper to proxyHelper.asm") | 3 years agoJan 29, 2023 |
| View all files |

## Repository files navigation

# Proxy-Function-Calls-For-ETwTI

[Permalink: Proxy-Function-Calls-For-ETwTI](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI#proxy-function-calls-for-etwti)

The code is a pingback to the Dark Vortex blog: [https://0xdarkvortex.dev/hiding-in-plainsight/](https://0xdarkvortex.dev/hiding-in-plainsight/)

```
nasm -f win64 proxyHelper.asm -o proxyHelper.o
x86_64-w64-mingw32-gcc proxyAPICall.c proxyHelper.o -o proxyAPICall.exe
```

## About

The code is a pingback to the Dark Vortex blog: [https://0xdarkvortex.dev/hiding-memory-allocations-from-mdatp-etwti-stack-tracing/](https://0xdarkvortex.dev/hiding-memory-allocations-from-mdatp-etwti-stack-tracing/)

### Resources

[Readme](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI).

[Activity](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/activity)

### Stars

[**210**\\
stars](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/stargazers)

### Watchers

[**5**\\
watching](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/watchers)

### Forks

[**40**\\
forks](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fparanoidninja%2FProxy-Function-Calls-For-ETwTI&report=paranoidninja+%28user%29)

## [Releases](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/releases)

No releases published

## [Packages\  0](https://github.com/users/paranoidninja/packages?repo_name=Proxy-Function-Calls-For-ETwTI)

No packages published

## Languages

- [C77.0%](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/search?l=c)
- [Assembly23.0%](https://github.com/paranoidninja/Proxy-Function-Calls-For-ETwTI/search?l=assembly)

You can’t perform that action at this time.