# https://github.com/JJK96/PIClin

[Skip to content](https://github.com/JJK96/PIClin#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/JJK96/PIClin) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/JJK96/PIClin) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/JJK96/PIClin) to refresh your session.Dismiss alert

{{ message }}

[JJK96](https://github.com/JJK96)/ **[PIClin](https://github.com/JJK96/PIClin)** Public

- [Notifications](https://github.com/login?return_to=%2FJJK96%2FPIClin) You must be signed in to change notification settings
- [Fork\\
2](https://github.com/login?return_to=%2FJJK96%2FPIClin)
- [Star\\
53](https://github.com/login?return_to=%2FJJK96%2FPIClin)


From C, Rust or Zig to binary shellcode compiler based on Mingw gcc. It allows using Win32 APIs and standard libraries without any changes to the source code.


### License

[MIT license](https://github.com/JJK96/PIClin/blob/main/LICENSE)

[53\\
stars](https://github.com/JJK96/PIClin/stargazers) [2\\
forks](https://github.com/JJK96/PIClin/forks) [Branches](https://github.com/JJK96/PIClin/branches) [Tags](https://github.com/JJK96/PIClin/tags) [Activity](https://github.com/JJK96/PIClin/activity)

[Star](https://github.com/login?return_to=%2FJJK96%2FPIClin)

[Notifications](https://github.com/login?return_to=%2FJJK96%2FPIClin) You must be signed in to change notification settings

# JJK96/PIClin

main

[**1** Branch](https://github.com/JJK96/PIClin/branches) [**0** Tags](https://github.com/JJK96/PIClin/tags)

[Go to Branches page](https://github.com/JJK96/PIClin/branches)[Go to Tags page](https://github.com/JJK96/PIClin/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![JJK96](https://avatars.githubusercontent.com/u/11193274?v=4&size=40)](https://github.com/JJK96)[JJK96](https://github.com/JJK96/PIClin/commits?author=JJK96)<br>[Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b)<br>5 months agoSep 4, 2025<br>[b999811](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b) · 5 months agoSep 4, 2025<br>## History<br>[39 Commits](https://github.com/JJK96/PIClin/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/JJK96/PIClin/commits/main/) 39 Commits |
| [.github](https://github.com/JJK96/PIClin/tree/main/.github ".github") | [.github](https://github.com/JJK96/PIClin/tree/main/.github ".github") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [.vscode](https://github.com/JJK96/PIClin/tree/main/.vscode ".vscode") | [.vscode](https://github.com/JJK96/PIClin/tree/main/.vscode ".vscode") | [init](https://github.com/JJK96/PIClin/commit/b123735be5ad9f9a89a8804968611e5f4f8805db "init") | 2 years agoSep 15, 2024 |
| [assets](https://github.com/JJK96/PIClin/tree/main/assets "assets") | [assets](https://github.com/JJK96/PIClin/tree/main/assets "assets") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [piclin](https://github.com/JJK96/PIClin/tree/main/piclin "piclin") | [piclin](https://github.com/JJK96/PIClin/tree/main/piclin "piclin") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [tests](https://github.com/JJK96/PIClin/tree/main/tests "tests") | [tests](https://github.com/JJK96/PIClin/tree/main/tests "tests") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [.coveragerc](https://github.com/JJK96/PIClin/blob/main/.coveragerc ".coveragerc") | [.coveragerc](https://github.com/JJK96/PIClin/blob/main/.coveragerc ".coveragerc") | [Create a CLI interface and use Make for building](https://github.com/JJK96/PIClin/commit/d7758cd9123d732427a804cab240c350e7ad553b "Create a CLI interface and use Make for building") | 8 months agoJul 1, 2025 |
| [.gitignore](https://github.com/JJK96/PIClin/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/JJK96/PIClin/blob/main/.gitignore ".gitignore") | [Create a CLI interface and use Make for building](https://github.com/JJK96/PIClin/commit/d7758cd9123d732427a804cab240c350e7ad553b "Create a CLI interface and use Make for building") | 8 months agoJul 1, 2025 |
| [.gitmodules](https://github.com/JJK96/PIClin/blob/main/.gitmodules ".gitmodules") | [.gitmodules](https://github.com/JJK96/PIClin/blob/main/.gitmodules ".gitmodules") | [Merge branch 'rust'](https://github.com/JJK96/PIClin/commit/11e6bff1d7cf9d7544ec19ce410a195091e33a9f "Merge branch 'rust'") | 6 months agoAug 19, 2025 |
| [LICENSE](https://github.com/JJK96/PIClin/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/JJK96/PIClin/blob/main/LICENSE "LICENSE") | [Create a CLI interface and use Make for building](https://github.com/JJK96/PIClin/commit/d7758cd9123d732427a804cab240c350e7ad553b "Create a CLI interface and use Make for building") | 8 months agoJul 1, 2025 |
| [Makefile](https://github.com/JJK96/PIClin/blob/main/Makefile "Makefile") | [Makefile](https://github.com/JJK96/PIClin/blob/main/Makefile "Makefile") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [README.md](https://github.com/JJK96/PIClin/blob/main/README.md "README.md") | [README.md](https://github.com/JJK96/PIClin/blob/main/README.md "README.md") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [payload.c](https://github.com/JJK96/PIClin/blob/main/payload.c "payload.c") | [payload.c](https://github.com/JJK96/PIClin/blob/main/payload.c "payload.c") | [Allow usage of standard library functions](https://github.com/JJK96/PIClin/commit/66b1e28e956e7c55c1357728769bce7a32face78 "Allow usage of standard library functions") | 7 months agoJul 6, 2025 |
| [payload.rs](https://github.com/JJK96/PIClin/blob/main/payload.rs "payload.rs") | [payload.rs](https://github.com/JJK96/PIClin/blob/main/payload.rs "payload.rs") | [Use libc crate](https://github.com/JJK96/PIClin/commit/a7507fb3f141fd9c2464ad867752e5caaf6752cb "Use libc crate") | 6 months agoAug 19, 2025 |
| [payload.zig](https://github.com/JJK96/PIClin/blob/main/payload.zig "payload.zig") | [payload.zig](https://github.com/JJK96/PIClin/blob/main/payload.zig "payload.zig") | [Payload.zig compiles and works with Win32 API](https://github.com/JJK96/PIClin/commit/7fe9bceba54d4ca1836072111938b9388473e564 "Payload.zig compiles and works with Win32 API") | 6 months agoSep 1, 2025 |
| [pyproject.toml](https://github.com/JJK96/PIClin/blob/main/pyproject.toml "pyproject.toml") | [pyproject.toml](https://github.com/JJK96/PIClin/blob/main/pyproject.toml "pyproject.toml") | [Rename to PIClin](https://github.com/JJK96/PIClin/commit/b9998113b4f2d0c532c8b2df751aefd97b17db4b "Rename to PIClin") | 5 months agoSep 4, 2025 |
| [settings.example.toml](https://github.com/JJK96/PIClin/blob/main/settings.example.toml "settings.example.toml") | [settings.example.toml](https://github.com/JJK96/PIClin/blob/main/settings.example.toml "settings.example.toml") | [Use mingw LD as linker](https://github.com/JJK96/PIClin/commit/9bdd8f7bfc8fe9c8233bb7d1ef58fdcb4b8850c5 "Use mingw LD as linker") | 7 months agoAug 3, 2025 |
| View all files |

## Repository files navigation

[![](https://github.com/JJK96/PIClin/raw/main/.github/logo.png)](https://github.com/JJK96/PIClin/blob/main/.github/logo.png)

PIClin, short for Position Independent Code Linker. Allows compiling C, Rust or Zig code to shellcode while allowing the use of Win32 APIs without changes to the source code. In addition, strings and other data can be used without special encoding like stack strings.

The Win32 APIs and standard library functions that you use are automatically detected at link time, after which a `winlib.c` file is generated containing definitions for these functions. Currently only functions in `kernel32.dll`, `ntdll.dll` and `msvcrt.dll` are supported, because these DLLs can reasonably be expected in every process. However, if you need other DLLs, you need to load your required DLL using `LoadLibrary`, change `piclin/winlib.py` to include functions from your required DLL and extend [win32-db](https://github.com/JJK96/win32-db) to generate a function definition database for your DLL.

## Install

[Permalink: Install](https://github.com/JJK96/PIClin#install)

```
git clone --recurse-submodules https://github.com/jjk96/piclin
cd piclin
```

```
pip install -e .
```

or

```
make install
```

Copy `settings.example.toml` to `settings.toml` and fill the necessary values.
You can also install a settings file in ~/.config/piclin/settings.toml

## Usage

[Permalink: Usage](https://github.com/JJK96/PIClin#usage)

```
piclin compile payload.c
```

This will compile the payload in the `build` directory. The resulting files are:

- `payload.bin`: The shellcode.
- `loader.exe`: A trivial loader to test the shellcode.

### Output format

[Permalink: Output format](https://github.com/JJK96/PIClin#output-format)

The output format is shellcode by default. You can also change the format to PE to generate a PE file that can be executed directly.

```
piclin compile -f PE payload.c
```

### Rust

[Permalink: Rust](https://github.com/JJK96/PIClin#rust)

Ensure that you have a Rust toolchain installed. You can use `rustup` to install the toolchain.

```
piclin compile payload.rs
piclin compile -f PE payload.rs
```

## Caveats

[Permalink: Caveats](https://github.com/JJK96/PIClin#caveats)

I have to be honest, I have not tested every edge-case and I might have taken some shortcuts here and there. Below follows a list of caveats that I can think of at the moment:

- The shellcode (mainly the loader in `winlib.c`) assumes that all used DLLs are already loaded in the process. If your DLL is not loaded, you can load it manually using `LoadLibrary`. You can also resolve this generally by including the logic for loading missing DLLs from [BOF2Shellcode](https://github.com/FalconForceTeam/BOF2shellcode). The reason I did not do that here is that I want to avoid storing unnecessary strings in the shellcode.
- My parsing logic for C headers is very ad-hoc, it might parse some function headers incorrectly, resulting in incorrect code in `winlib.c`. This might be fixed in the future by including an actual C parser.
- I only tested a very limited set of Windows API and Standard library functions (`WinExec`, `CreateProcessA`, `ExpandEnvironmentStringsA`, `VirtualAlloc`, `VirtualProtect` and `printf`). I'm assuming my code works for any other Windows API function, but I might be wrong. If you encounter anything, it should not be too hard to fix.
- The library uses Windows API functions in a trivial way. For more OPSEC, you probably want to use indirect syscalls or something else. It should not be hard to fork and modify the project to support this.
- I use `Mingw` headers and libraries. These might have subtle differences with Windows SDK headers. If you run into such issues, you can adapt the [win32-db](https://github.com/JJK96/win32-db) project to use the Windows SDK headers or generate similar JSON output yourself.
- For compiling rust, you have to ensure that you don't use the standard library, because it will generate linking errors. I did not include the `#![no_std]` attribute because that requires manually implementing a `panic` handler, which results in extra boiler-plate code.

## Tests

[Permalink: Tests](https://github.com/JJK96/PIClin#tests)

Not implemented yet. Test your shellcode before deloyment!

```
make tests
```

## Credits

[Permalink: Credits](https://github.com/JJK96/PIClin#credits)

- [c-to-shellcode](https://github.com/Print3M/c-to-shellcode) for the initial idea and framework.
- Michael Schrijver for providing me with a nice linker script that enabled me to use normal strings and data in shellcode.
- [BOF2Shellcode](https://github.com/FalconForceTeam/BOF2shellcode) for the implementation of hash-based dynamic API resolving.

## About

From C, Rust or Zig to binary shellcode compiler based on Mingw gcc. It allows using Win32 APIs and standard libraries without any changes to the source code.


### Topics

[rust](https://github.com/topics/rust "Topic: rust") [linker](https://github.com/topics/linker "Topic: linker") [zig](https://github.com/topics/zig "Topic: zig") [mingw](https://github.com/topics/mingw "Topic: mingw") [shellcode](https://github.com/topics/shellcode "Topic: shellcode") [windows-api](https://github.com/topics/windows-api "Topic: windows-api") [win32api](https://github.com/topics/win32api "Topic: win32api") [mingw-w64](https://github.com/topics/mingw-w64 "Topic: mingw-w64") [linker-script](https://github.com/topics/linker-script "Topic: linker-script") [shellcode-development](https://github.com/topics/shellcode-development "Topic: shellcode-development") [win32-api](https://github.com/topics/win32-api "Topic: win32-api") [mingw64](https://github.com/topics/mingw64 "Topic: mingw64")

### Resources

[Readme](https://github.com/JJK96/PIClin#readme-ov-file)

### License

[MIT license](https://github.com/JJK96/PIClin#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/JJK96/PIClin).

[Activity](https://github.com/JJK96/PIClin/activity)

### Stars

[**53**\\
stars](https://github.com/JJK96/PIClin/stargazers)

### Watchers

[**0**\\
watching](https://github.com/JJK96/PIClin/watchers)

### Forks

[**2**\\
forks](https://github.com/JJK96/PIClin/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FJJK96%2FPIClin&report=JJK96+%28user%29)

## [Releases](https://github.com/JJK96/PIClin/releases)

No releases published

## [Contributors\  2](https://github.com/JJK96/PIClin/graphs/contributors)

- [![@JJK96](https://avatars.githubusercontent.com/u/11193274?s=64&v=4)](https://github.com/JJK96)[**JJK96** Jan-Jaap Korpershoek](https://github.com/JJK96)
- [![@Print3M](https://avatars.githubusercontent.com/u/92022497?s=64&v=4)](https://github.com/Print3M)[**Print3M**](https://github.com/Print3M)

## Languages

- [Python50.4%](https://github.com/JJK96/PIClin/search?l=python)
- [C22.4%](https://github.com/JJK96/PIClin/search?l=c)
- [Jinja14.9%](https://github.com/JJK96/PIClin/search?l=jinja)
- [Zig7.3%](https://github.com/JJK96/PIClin/search?l=zig)
- [Shell1.5%](https://github.com/JJK96/PIClin/search?l=shell)
- [Rust1.4%](https://github.com/JJK96/PIClin/search?l=rust)
- Other2.1%

You can’t perform that action at this time.