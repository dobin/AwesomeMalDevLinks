# https://github.com/Octoberfest7/DropSpawn_BOF

[Skip to content](https://github.com/Octoberfest7/DropSpawn_BOF#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/Octoberfest7/DropSpawn_BOF) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/Octoberfest7/DropSpawn_BOF) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/Octoberfest7/DropSpawn_BOF) to refresh your session.Dismiss alert

{{ message }}

[Octoberfest7](https://github.com/Octoberfest7)/ **[DropSpawn\_BOF](https://github.com/Octoberfest7/DropSpawn_BOF)** Public

- [Notifications](https://github.com/login?return_to=%2FOctoberfest7%2FDropSpawn_BOF) You must be signed in to change notification settings
- [Fork\\
35](https://github.com/login?return_to=%2FOctoberfest7%2FDropSpawn_BOF)
- [Star\\
285](https://github.com/login?return_to=%2FOctoberfest7%2FDropSpawn_BOF)


CobaltStrike BOF to spawn Beacons using DLL Application Directory Hijacking


[285\\
stars](https://github.com/Octoberfest7/DropSpawn_BOF/stargazers) [35\\
forks](https://github.com/Octoberfest7/DropSpawn_BOF/forks) [Branches](https://github.com/Octoberfest7/DropSpawn_BOF/branches) [Tags](https://github.com/Octoberfest7/DropSpawn_BOF/tags) [Activity](https://github.com/Octoberfest7/DropSpawn_BOF/activity)

[Star](https://github.com/login?return_to=%2FOctoberfest7%2FDropSpawn_BOF)

[Notifications](https://github.com/login?return_to=%2FOctoberfest7%2FDropSpawn_BOF) You must be signed in to change notification settings

# Octoberfest7/DropSpawn\_BOF

main

[**1** Branch](https://github.com/Octoberfest7/DropSpawn_BOF/branches) [**0** Tags](https://github.com/Octoberfest7/DropSpawn_BOF/tags)

[Go to Branches page](https://github.com/Octoberfest7/DropSpawn_BOF/branches)[Go to Tags page](https://github.com/Octoberfest7/DropSpawn_BOF/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![Octoberfest7](https://avatars.githubusercontent.com/u/91164728?v=4&size=40)](https://github.com/Octoberfest7)[Octoberfest7](https://github.com/Octoberfest7/DropSpawn_BOF/commits?author=Octoberfest7)<br>[Update README.md](https://github.com/Octoberfest7/DropSpawn_BOF/commit/bbd0b1140d12cf389e8a97fa39c1beae354afc85)<br>3 years agoJun 7, 2023<br>[bbd0b11](https://github.com/Octoberfest7/DropSpawn_BOF/commit/bbd0b1140d12cf389e8a97fa39c1beae354afc85) · 3 years agoJun 7, 2023<br>## History<br>[5 Commits](https://github.com/Octoberfest7/DropSpawn_BOF/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/Octoberfest7/DropSpawn_BOF/commits/main/) 5 Commits |
| [dist](https://github.com/Octoberfest7/DropSpawn_BOF/tree/main/dist "dist") | [dist](https://github.com/Octoberfest7/DropSpawn_BOF/tree/main/dist "dist") | [Initial commit](https://github.com/Octoberfest7/DropSpawn_BOF/commit/7628187b37bc7b3e112365a9c08ac59f5b0dbb9c "Initial commit  Fix current directory detection  Update README.md  Fixes  Update README.md  Update README.md  Update README.md  Update README.md  Fixes  Fixes") | 3 years agoJun 7, 2023 |
| [src](https://github.com/Octoberfest7/DropSpawn_BOF/tree/main/src "src") | [src](https://github.com/Octoberfest7/DropSpawn_BOF/tree/main/src "src") | [Initial commit](https://github.com/Octoberfest7/DropSpawn_BOF/commit/7628187b37bc7b3e112365a9c08ac59f5b0dbb9c "Initial commit  Fix current directory detection  Update README.md  Fixes  Update README.md  Update README.md  Update README.md  Update README.md  Fixes  Fixes") | 3 years agoJun 7, 2023 |
| [Makefile](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/Makefile "Makefile") | [Makefile](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/Makefile "Makefile") | [Initial commit](https://github.com/Octoberfest7/DropSpawn_BOF/commit/7628187b37bc7b3e112365a9c08ac59f5b0dbb9c "Initial commit  Fix current directory detection  Update README.md  Fixes  Update README.md  Update README.md  Update README.md  Update README.md  Fixes  Fixes") | 3 years agoJun 7, 2023 |
| [README.md](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/README.md "README.md") | [README.md](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/README.md "README.md") | [Update README.md](https://github.com/Octoberfest7/DropSpawn_BOF/commit/bbd0b1140d12cf389e8a97fa39c1beae354afc85 "Update README.md") | 3 years agoJun 7, 2023 |
| [generate\_dll.py](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/generate_dll.py "generate_dll.py") | [generate\_dll.py](https://github.com/Octoberfest7/DropSpawn_BOF/blob/main/generate_dll.py "generate_dll.py") | [Initial commit](https://github.com/Octoberfest7/DropSpawn_BOF/commit/7628187b37bc7b3e112365a9c08ac59f5b0dbb9c "Initial commit  Fix current directory detection  Update README.md  Fixes  Update README.md  Update README.md  Update README.md  Update README.md  Fixes  Fixes") | 3 years agoJun 7, 2023 |
| View all files |

## Repository files navigation

# DropSpawn

[Permalink: DropSpawn](https://github.com/Octoberfest7/DropSpawn_BOF#dropspawn)

## Introduction

[Permalink: Introduction](https://github.com/Octoberfest7/DropSpawn_BOF#introduction)

DropSpawn is a CobaltStrike BOF used to spawn additional Beacons via a relatively unknown method of DLL hijacking. Works x86-x86, x64-x64, and x86-x64/vice versa. Use as an alternative to process injection.

[Windows executables will follow the DLL search order](https://dmcxblue.gitbook.io/red-team-notes/persistence/dll-search-order-hijacking) when trying to load DLL's whose absolute paths were not specified:

[![image](https://private-user-images.githubusercontent.com/91164728/244058157-c4251d34-f7ba-45bc-84b4-27536c757324.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgxNTctYzQyNTFkMzQtZjdiYS00NWJjLTg0YjQtMjc1MzZjNzU3MzI0LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTNiZDY2NjVhZGMzNDliM2NmMzZhOGQ1ODdkYzQ4NDJiMzVkMTI4ZTVkZDI4MGYzN2M3NDFlYmMyYzQ3MzJkNTAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.oGhANkCftO6tjamS7bnJO3yMGUtql0yIW1l24ykHIOY)](https://private-user-images.githubusercontent.com/91164728/244058157-c4251d34-f7ba-45bc-84b4-27536c757324.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgxNTctYzQyNTFkMzQtZjdiYS00NWJjLTg0YjQtMjc1MzZjNzU3MzI0LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTNiZDY2NjVhZGMzNDliM2NmMzZhOGQ1ODdkYzQ4NDJiMzVkMTI4ZTVkZDI4MGYzN2M3NDFlYmMyYzQ3MzJkNTAmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.oGhANkCftO6tjamS7bnJO3yMGUtql0yIW1l24ykHIOY)

DLL hijacking typically requires that either:

_**A.**_ A user has write permissions in a folder with a higher search order precedence than where the real DLL resides

or

_**B.**_ That the DLL in question doesn't exist anywhere on the system, in which case it can be placed in a user-writable folder in the user's %PATH% variable (like %USERPROFILE%\\appdata\\local\\microsoft\\windowsapps).

These requirements rule out DLL hijacking for executables residing in C:\\Windows\\System32 because almost all DLL's that these executables load also reside in System32. Copying a System32 executable to a user-writable location and executing it there is an option, but isn't very OPSEC safe because System32 binaries running from alternate locations are easy to identify.

_**DropSpawn enables DLL hijacking using System32 executables (and others found in additional non-user-writable folders) by spoofing the "The directory from which the application is loaded" to an arbitrary user-specified one.**_

### Note:

[Permalink: Note:](https://github.com/Octoberfest7/DropSpawn_BOF#note)

The public release of DropSpawn differs slightly from the non-public one. The non-public release leverages a proprietary payload generator, making the experience much more seamless for the operator. The public release has been altered slightly to account for the fact that users will have their own ways of generating DLL hijack compatible payloads. A Python3 script as well as source code for a demonstration DLL have been included to assist users in integrating and weaponizing dropspawn.

## How to Use

[Permalink: How to Use](https://github.com/Octoberfest7/DropSpawn_BOF#how-to-use)

### 1.

[Permalink: 1.](https://github.com/Octoberfest7/DropSpawn_BOF#1)

Identify some target executables that try to load DLL's without specifying their absolute paths. You can do this by copying the exe into a user-writable directory and executing it while monitoring it with [Procmon](https://learn.microsoft.com/en-us/sysinternals/downloads/procmon). In this example we'll use WerFault.exe which normally resides at C:\\Windows\\System32\\WerFault.exe
[![image](https://private-user-images.githubusercontent.com/91164728/244058240-e4c88036-0018-41d4-88a1-cd429669e39b.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgyNDAtZTRjODgwMzYtMDAxOC00MWQ0LTg4YTEtY2Q0Mjk2NjllMzliLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTUyYmU5YzRjMDIwMWU4NWExZmNmMTFiZmVlOGNhMGRkOWVjNGE1MGRhYjk0NjQ5MWI3NTkxOTdkNDdmZGU5NjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.mKTM0L455v9xppVfWSBWsI8XGHkWzKqNRMgMSVoV544)](https://private-user-images.githubusercontent.com/91164728/244058240-e4c88036-0018-41d4-88a1-cd429669e39b.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgyNDAtZTRjODgwMzYtMDAxOC00MWQ0LTg4YTEtY2Q0Mjk2NjllMzliLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTUyYmU5YzRjMDIwMWU4NWExZmNmMTFiZmVlOGNhMGRkOWVjNGE1MGRhYjk0NjQ5MWI3NTkxOTdkNDdmZGU5NjUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.mKTM0L455v9xppVfWSBWsI8XGHkWzKqNRMgMSVoV544)

In the above example cryptsp.dll, wer.dll, dbghelp.dll, and bcrypt.dll are all viable candidates because their absolute paths were not specified within WerFault; as a result, WerFault will attempt to load them from its application directory first before resorting to the rest of the DLL search order. Note that this typically isn't a concern because WerFault's application directory IS System32.

### 2.

[Permalink: 2.](https://github.com/Octoberfest7/DropSpawn_BOF#2)

Download one of the hijackable DLL's from the target system.

[![image](https://private-user-images.githubusercontent.com/91164728/244058369-2938bd57-90ff-450f-b82a-0704292f30f7.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgzNjktMjkzOGJkNTctOTBmZi00NTBmLWI4MmEtMDcwNDI5MmYzMGY3LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTkyM2E4MDEyNzVmMTE1Mjk1ZTdmZGIwODJhNTJiOTY1NTNjZDhlOGQxYWNjZWJmMGE5OWFmYzk1ZjkyMjIzZWYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Bd7Rf1ulHMLjBUoxOXqyt77CiahGCYo5_2VzE7aKk-Y)](https://private-user-images.githubusercontent.com/91164728/244058369-2938bd57-90ff-450f-b82a-0704292f30f7.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTgzNjktMjkzOGJkNTctOTBmZi00NTBmLWI4MmEtMDcwNDI5MmYzMGY3LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTkyM2E4MDEyNzVmMTE1Mjk1ZTdmZGIwODJhNTJiOTY1NTNjZDhlOGQxYWNjZWJmMGE5OWFmYzk1ZjkyMjIzZWYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.Bd7Rf1ulHMLjBUoxOXqyt77CiahGCYo5_2VzE7aKk-Y)
This is necessary so that we can extract its exports and include them in our payload DLL. It is important to grab the hijackable DLL from the same machine you wish you use DropSpawn on, as DLL's change between Windows versions. Additionally, if you are running a x86 beacon and want to spawn an x64 beacon using DropSpawn, make sure you download the x64 version of the real DLL by specifying 'C:\\windows\\sysnative...' instead of 'C:\\windows\\system32...'.

### 3.

[Permalink: 3.](https://github.com/Octoberfest7/DropSpawn_BOF#3)

Run generate\_dll.py, passing in the downloaded DLL and the desired payload architecture. Generate\_dll.py is a modified version of [this script](https://github.com/tothi/dll-hijack-by-proxying). It will parse the supplied DLL, create a .def file containing the DLL's exports, and call MingW to compile our demonstration payload DLL. When the spawned process tries to call a real function within the spoofed DLL, our payload DLL will forward the call to the real DLL located in System32 so that the host process doesn't crash.
[![image](https://private-user-images.githubusercontent.com/91164728/244058417-eb9f10d9-4775-4ea1-8de5-ff6a8ec5ded6.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg0MTctZWI5ZjEwZDktNDc3NS00ZWExLThkZTUtZmY2YThlYzVkZWQ2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY2N2RhNTlhYjFiYzUxYmVmZGU1ZTRmNTEyNzU3YTdjNmU4ODAwZDQ3OGU1NGNmNDdmMWM0NTEzOTNhNzZiODYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.iT9nU-UrchOMQffB7pX545CsH4SINKdLNE6HBYWHEfg)](https://private-user-images.githubusercontent.com/91164728/244058417-eb9f10d9-4775-4ea1-8de5-ff6a8ec5ded6.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg0MTctZWI5ZjEwZDktNDc3NS00ZWExLThkZTUtZmY2YThlYzVkZWQ2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY2N2RhNTlhYjFiYzUxYmVmZGU1ZTRmNTEyNzU3YTdjNmU4ODAwZDQ3OGU1NGNmNDdmMWM0NTEzOTNhNzZiODYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.iT9nU-UrchOMQffB7pX545CsH4SINKdLNE6HBYWHEfg)

### 4.

[Permalink: 4.](https://github.com/Octoberfest7/DropSpawn_BOF#4)

Call dropspawn using the generated payload DLL.

_**dropspawn <payload DLL> <x86\|x64> <program to spawn> \[writable target folder\] \[parent\]**_

**payload DLL** \- the full path to the generated DLL payload.

**architecture** \- the architecture of the process you wish to spawn

**program to spawn** \- the name/path of the process you wish to spawn. If this process resides in System32(or syswow64), you can just specify the name. Otherwise, specify the full path. You can also supply arguments command line arguments to the process. If there are spaces in the path/if you use arguments, wrap the whole thing in quotes.

**writable target folder** \- Optional. If left blank, dropspawn will try to use the Beacon's current directory. Use quotes if there are spaces in the path.

**parent** \- Optional. The name of the process to use for PPID spoofing with the newly spawned process. If a process is specified that has multiple running instances of difference privilege levels (i.e. svchost.exe), dropspawn will try and identify one that can be used for PPID spoofing.

Example: dropspawn /root/gitlab/DropSpawn\_BOF/dist/dbgcore.dll x64 "WerFault.exe -u -p 4352 -s 160" C:\\users\\user\\appdata\\local\\temp explorer.exe

This will drop the payload DLL 'dbgcore.dll' to disk at 'c:\\users\\user\\appdata\\local\\temp\\dbgcore.dll' and spawn a x64 WerFault.exe process with the commandline arguments '-u -p 4352 -s 160' and explorer.exe as the parent process.

[![image](https://private-user-images.githubusercontent.com/91164728/244058472-1d1da108-9603-4bd0-8cff-4f47960a5b8c.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg0NzItMWQxZGExMDgtOTYwMy00YmQwLThjZmYtNGY0Nzk2MGE1YjhjLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWVjOWRiYjFiMzE2ZmYwOWI3OTJlNzhhZGZlYWUxMjA5NjkyMzIxMmU0NDU0ZWY1YWIzZTM3NjE0MjViNjczMTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.81z2DI7s3tL_ny-gHfS6w7uLTxxzV9DZC7JS3PR8l6Q)](https://private-user-images.githubusercontent.com/91164728/244058472-1d1da108-9603-4bd0-8cff-4f47960a5b8c.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg0NzItMWQxZGExMDgtOTYwMy00YmQwLThjZmYtNGY0Nzk2MGE1YjhjLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWVjOWRiYjFiMzE2ZmYwOWI3OTJlNzhhZGZlYWUxMjA5NjkyMzIxMmU0NDU0ZWY1YWIzZTM3NjE0MjViNjczMTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.81z2DI7s3tL_ny-gHfS6w7uLTxxzV9DZC7JS3PR8l6Q)

[![image](https://private-user-images.githubusercontent.com/91164728/244058520-730bfe59-9808-413c-8e70-9e8f3788f856.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg1MjAtNzMwYmZlNTktOTgwOC00MTNjLThlNzAtOWU4ZjM3ODhmODU2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY4ZmFiZjliMjZiMDMzM2Q5NzFkNTkyNjVlMWUxZDkwMzMyYTA1ZGMzNTA1ZGJmZjhkYzU2YTRkYTVmM2QwNjImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.kZcvPfD2t3npYnw7t5o-5KQ8oxknx6WsnoXcpgZjtiA)](https://private-user-images.githubusercontent.com/91164728/244058520-730bfe59-9808-413c-8e70-9e8f3788f856.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg1MjAtNzMwYmZlNTktOTgwOC00MTNjLThlNzAtOWU4ZjM3ODhmODU2LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWY4ZmFiZjliMjZiMDMzM2Q5NzFkNTkyNjVlMWUxZDkwMzMyYTA1ZGMzNTA1ZGJmZjhkYzU2YTRkYTVmM2QwNjImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.kZcvPfD2t3npYnw7t5o-5KQ8oxknx6WsnoXcpgZjtiA)

### 5.

[Permalink: 5.](https://github.com/Octoberfest7/DropSpawn_BOF#5)

Cleanup is easy. By including the [Self-Deletion](https://github.com/LloydLabs/delete-self-poc) function in the payload DLL that is dropped to disk, it will be deleted as soon as our new process spawns and loads it. This is a game changer, as typically the DLL would be locked on disk so long as our process that loaded it continues to run. If the Self-Deletion technique fails for some reason (or the process fails to spawn), DropSpawn will attempt to delete the payload DLL from disk and will inform the user of the result of the operation either way.

## Detection

[Permalink: Detection](https://github.com/Octoberfest7/DropSpawn_BOF#detection)

Process injection typically follows the open remote process -> allocate remote memory -> write remote memory -> execute remote memory chain, with an option to spawn a new process at the beginning instead of using an existing one. DropSpawn only creates a new process; the newly spawned process is responsible for allocating, writing, and executing shellcode, so we can avoid a lot of the IOC's typically associated with remote process injection.

This technique is of course at the mercy of how good your DLL payloads are. But we can take a look at what Windows sees (this next section using the private version of DropSpawn and spawning Beacons).

As far as Event Viewer is concerned, everything looks normal:
[![image](https://private-user-images.githubusercontent.com/91164728/244058571-bf68fd99-b673-470a-8d51-b379ceca4769.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg1NzEtYmY2OGZkOTktYjY3My00NzBhLThkNTEtYjM3OWNlY2E0NzY5LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTJhZmI4MzE2ZGRlYjBlNzVjZTFjMWY1MDE5NDFkNWM2ODNlNzg1MTE2MGVlZTQwMmU4OTMzMDgxNjM2Mzk3NDMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.t4PUIVuoryyepI5Lz6I04Lvmr1SozJO9mmmZs29iBmw)](https://private-user-images.githubusercontent.com/91164728/244058571-bf68fd99-b673-470a-8d51-b379ceca4769.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg1NzEtYmY2OGZkOTktYjY3My00NzBhLThkNTEtYjM3OWNlY2E0NzY5LnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTJhZmI4MzE2ZGRlYjBlNzVjZTFjMWY1MDE5NDFkNWM2ODNlNzg1MTE2MGVlZTQwMmU4OTMzMDgxNjM2Mzk3NDMmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.t4PUIVuoryyepI5Lz6I04Lvmr1SozJO9mmmZs29iBmw)

In MDE there is very little to see.

Running dropspawn:

[![image](https://private-user-images.githubusercontent.com/91164728/244058619-4baa07ff-def4-4aff-a4e9-5b756e3ba6c3.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg2MTktNGJhYTA3ZmYtZGVmNC00YWZmLWE0ZTktNWI3NTZlM2JhNmMzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWYyNjJmNTdjNDU5YzI0YWVkNTg0ZWQzNjFkYjUyOTQ3YzNjNTc2MzVhMmNhNDBiYmIxOWM4ZmNiOGVlNjgxOWEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.i1Ww1axsaAPY9JX4jHhxwwW9Ic6DyS5wfSarHm95xMw)](https://private-user-images.githubusercontent.com/91164728/244058619-4baa07ff-def4-4aff-a4e9-5b756e3ba6c3.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg2MTktNGJhYTA3ZmYtZGVmNC00YWZmLWE0ZTktNWI3NTZlM2JhNmMzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWYyNjJmNTdjNDU5YzI0YWVkNTg0ZWQzNjFkYjUyOTQ3YzNjNTc2MzVhMmNhNDBiYmIxOWM4ZmNiOGVlNjgxOWEmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.i1Ww1axsaAPY9JX4jHhxwwW9Ic6DyS5wfSarHm95xMw)

MDE Logs:

With PPID spoofing:

[![image](https://private-user-images.githubusercontent.com/91164728/244058810-d10f3ceb-4a75-4826-9b22-8fbf0f53a11b.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg4MTAtZDEwZjNjZWItNGE3NS00ODI2LTliMjItOGZiZjBmNTNhMTFiLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTlhMjcxYjE2MWVmMDM4OTAzMDU3Nzg2ZTVhYTRhMGMyYTRmYmFhMWQ3YWQyOTc5N2FhMTE4NTI1Y2FhOGJhNWImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.IhYHbjkkuwNiYVb2eclTq1bT0o4zDOuXI7FheaG6t3g)](https://private-user-images.githubusercontent.com/91164728/244058810-d10f3ceb-4a75-4826-9b22-8fbf0f53a11b.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg4MTAtZDEwZjNjZWItNGE3NS00ODI2LTliMjItOGZiZjBmNTNhMTFiLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTlhMjcxYjE2MWVmMDM4OTAzMDU3Nzg2ZTVhYTRhMGMyYTRmYmFhMWQ3YWQyOTc5N2FhMTE4NTI1Y2FhOGJhNWImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.IhYHbjkkuwNiYVb2eclTq1bT0o4zDOuXI7FheaG6t3g)

Without PPID spoofing:
[![image](https://private-user-images.githubusercontent.com/91164728/244058852-32b8cd5d-d967-466d-b105-eea04c304b8c.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg4NTItMzJiOGNkNWQtZDk2Ny00NjZkLWIxMDUtZWVhMDRjMzA0YjhjLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTU5ZGEwMTNjMmYwYWIzOWU1NDlkZDZiYWJjYmJmNDZmMWMwY2QzZmU0OGFlYmRiMmY2ZDc4NDBjY2JmNDFmNTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.kwmGNVcwHssFU_C25aSu-fjC9PYswRwg_BGF6uhemJ8)](https://private-user-images.githubusercontent.com/91164728/244058852-32b8cd5d-d967-466d-b105-eea04c304b8c.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTI3NjMsIm5iZiI6MTc3MTQxMjQ2MywicGF0aCI6Ii85MTE2NDcyOC8yNDQwNTg4NTItMzJiOGNkNWQtZDk2Ny00NjZkLWIxMDUtZWVhMDRjMzA0YjhjLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDExMDEwM1omWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTU5ZGEwMTNjMmYwYWIzOWU1NDlkZDZiYWJjYmJmNDZmMWMwY2QzZmU0OGFlYmRiMmY2ZDc4NDBjY2JmNDFmNTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.kwmGNVcwHssFU_C25aSu-fjC9PYswRwg_BGF6uhemJ8)

In both cases we see our original beacon process (also a werfault) drop dbgcore.dll to disk, create a new WerFault.exe process, the newly spawned process loading dbgcore.dll, and then renaming (deleting) it. Critically there is no extra scrutiny of dbgcore.dll that often comes with DLL hijacks because we aren't writing it to any often hijacked location, and WerFault.exe (or whatever process you choose to use) isn't really associated with DLL hijacks in the way that things like WmiPrvSE.exe are.

Interestingly it is almost more visible to do this with PPID spoofing than without. This may vary depending on the security product however.

## Limitations

[Permalink: Limitations](https://github.com/Octoberfest7/DropSpawn_BOF#limitations)

As mentioned, it is essential that users download the real DLL's from the target machine they plan to use DropSpawn on. Using the wrong version of a DLL can result in the spawned process crashing if it tries to call a function that doesn't exist.

DropSpawn can be used with executables outside System32; be warned however that issues can arise if the process tries to load additional DLL's from the processes true application directory. Because we have spoofed the application directory elswhere, if the real application directory isn't also reachable via the DLL search order otherwise, the process will crash/fail to start because it cannot locate essential DLL's. Always test potential hijacks on development machines before using them in production!

## Credits

[Permalink: Credits](https://github.com/Octoberfest7/DropSpawn_BOF#credits)

This research first came about as I was exploring how processes assemble their final DLL search order (as it must be determined at runtime due to executables residing in different directories, the current directory being part of the search path, etc). My research led me to [this](http://www.rohitab.com/discuss/topic/41379-running-native-applications-with-rtlcreateuserprocess/) forum post, which served as the origin of the two critical undocumented API's that are central to this technique.

They are linked earlier already, but [this post concerning avoiding loader lock](https://www.netspi.com/blog/technical/adversary-simulation/adaptive-dll-hijacking/), [this script for generating a .def file for DLL proxying](https://github.com/tothi/dll-hijack-by-proxying), and [this research on enabling self-deletion of running executables](https://github.com/LloydLabs/delete-self-poc) are essential to producing effective, weaponized DLL payloads suitable for DropSpawn.

When I first published this technique on [Twitter](https://twitter.com/Octoberfest73/status/1642165975805050881?s=20), several others joined the conversation and produced POC's. [SecurityAndStuff produced this one](https://github.com/SecurityAndStuff/DllLoadPath), while [Snovvcrash has his here](https://gist.github.com/snovvcrash/3d5008d7e46d1cc60f0f8bdc8cdb66a5)

## About

CobaltStrike BOF to spawn Beacons using DLL Application Directory Hijacking


### Resources

[Readme](https://github.com/Octoberfest7/DropSpawn_BOF#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Octoberfest7/DropSpawn_BOF).

[Activity](https://github.com/Octoberfest7/DropSpawn_BOF/activity)

### Stars

[**285**\\
stars](https://github.com/Octoberfest7/DropSpawn_BOF/stargazers)

### Watchers

[**5**\\
watching](https://github.com/Octoberfest7/DropSpawn_BOF/watchers)

### Forks

[**35**\\
forks](https://github.com/Octoberfest7/DropSpawn_BOF/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FOctoberfest7%2FDropSpawn_BOF&report=Octoberfest7+%28user%29)

## [Releases](https://github.com/Octoberfest7/DropSpawn_BOF/releases)

No releases published

## [Packages\  0](https://github.com/users/Octoberfest7/packages?repo_name=DropSpawn_BOF)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/Octoberfest7/DropSpawn_BOF).

## Languages

- [C89.3%](https://github.com/Octoberfest7/DropSpawn_BOF/search?l=c)
- [Python10.1%](https://github.com/Octoberfest7/DropSpawn_BOF/search?l=python)
- [Makefile0.6%](https://github.com/Octoberfest7/DropSpawn_BOF/search?l=makefile)

You can’t perform that action at this time.