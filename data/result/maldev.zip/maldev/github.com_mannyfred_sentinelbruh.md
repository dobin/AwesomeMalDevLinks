# https://github.com/mannyfred/SentinelBruh

[Skip to content](https://github.com/mannyfred/SentinelBruh#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/mannyfred/SentinelBruh) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/mannyfred/SentinelBruh) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/mannyfred/SentinelBruh) to refresh your session.Dismiss alert

{{ message }}

This repository was archived by the owner on Oct 11, 2025. It is now read-only.


[mannyfred](https://github.com/mannyfred)/ **[SentinelBruh](https://github.com/mannyfred/SentinelBruh)** Public archive

- [Notifications](https://github.com/login?return_to=%2Fmannyfred%2FSentinelBruh) You must be signed in to change notification settings
- [Fork\\
6](https://github.com/login?return_to=%2Fmannyfred%2FSentinelBruh)
- [Star\\
43](https://github.com/login?return_to=%2Fmannyfred%2FSentinelBruh)


Dirty PoC on how to abuse S1's VEH for Vectored Syscalls and Local Execution


### License

[GPL-2.0 license](https://github.com/mannyfred/SentinelBruh/blob/main/LICENSE)

[43\\
stars](https://github.com/mannyfred/SentinelBruh/stargazers) [6\\
forks](https://github.com/mannyfred/SentinelBruh/forks) [Branches](https://github.com/mannyfred/SentinelBruh/branches) [Tags](https://github.com/mannyfred/SentinelBruh/tags) [Activity](https://github.com/mannyfred/SentinelBruh/activity)

[Star](https://github.com/login?return_to=%2Fmannyfred%2FSentinelBruh)

[Notifications](https://github.com/login?return_to=%2Fmannyfred%2FSentinelBruh) You must be signed in to change notification settings

# mannyfred/SentinelBruh

main

[**1** Branch](https://github.com/mannyfred/SentinelBruh/branches) [**0** Tags](https://github.com/mannyfred/SentinelBruh/tags)

[Go to Branches page](https://github.com/mannyfred/SentinelBruh/branches)[Go to Tags page](https://github.com/mannyfred/SentinelBruh/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![mannyfred](https://avatars.githubusercontent.com/u/113118336?v=4&size=40)](https://github.com/mannyfred)[mannyfred](https://github.com/mannyfred/SentinelBruh/commits?author=mannyfred)<br>[Update README.md](https://github.com/mannyfred/SentinelBruh/commit/cab4195e0e04f7091156f16919a089abbac005c7)<br>4 months agoOct 11, 2025<br>[cab4195](https://github.com/mannyfred/SentinelBruh/commit/cab4195e0e04f7091156f16919a089abbac005c7) · 4 months agoOct 11, 2025<br>## History<br>[6 Commits](https://github.com/mannyfred/SentinelBruh/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/mannyfred/SentinelBruh/commits/main/) 6 Commits |
| [SentinelBruh](https://github.com/mannyfred/SentinelBruh/tree/main/SentinelBruh "SentinelBruh") | [SentinelBruh](https://github.com/mannyfred/SentinelBruh/tree/main/SentinelBruh "SentinelBruh") | [mmm](https://github.com/mannyfred/SentinelBruh/commit/c13f2b051fbc3c54876cdd443a1d90468e76a0a5 "mmm") | 4 months agoOct 11, 2025 |
| [.gitignore](https://github.com/mannyfred/SentinelBruh/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/mannyfred/SentinelBruh/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/mannyfred/SentinelBruh/commit/3008188efa389e6e4a34b68c4a32f0c3c91dfe84 "Initial commit") | 2 years agoMay 10, 2024 |
| [LICENSE](https://github.com/mannyfred/SentinelBruh/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/mannyfred/SentinelBruh/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/mannyfred/SentinelBruh/commit/3008188efa389e6e4a34b68c4a32f0c3c91dfe84 "Initial commit") | 2 years agoMay 10, 2024 |
| [README.md](https://github.com/mannyfred/SentinelBruh/blob/main/README.md "README.md") | [README.md](https://github.com/mannyfred/SentinelBruh/blob/main/README.md "README.md") | [Update README.md](https://github.com/mannyfred/SentinelBruh/commit/cab4195e0e04f7091156f16919a089abbac005c7 "Update README.md") | 4 months agoOct 11, 2025 |
| View all files |

## Repository files navigation

# SentinelBruh

[Permalink: SentinelBruh](https://github.com/mannyfred/SentinelBruh#sentinelbruh)

- This is an outdated meme repo, please for the love of god don't use code from here

#### Dirty PoC on how to abuse S1's VEH for Vectored Syscalls and Local Execution

[Permalink: Dirty PoC on how to abuse S1's VEH for Vectored Syscalls and Local Execution](https://github.com/mannyfred/SentinelBruh#dirty-poc-on-how-to-abuse-s1s-veh-for-vectored-syscalls-and-local-execution)

[Fun with Exception Handlers](https://mannyfreddy.gitbook.io/ya-boy-manny)

### Acknowledgements

[Permalink: Acknowledgements](https://github.com/mannyfred/SentinelBruh#acknowledgements)

- @DimitriFourny [Dumping VEH on Win10](https://dimitrifourny.github.io/2020/06/11/dumping-veh-win10.html)
- @VirtualAllocEx [Vectored Syscalls](https://redops.at/en/blog/syscalls-via-vectored-exception-handling)
- @Ollie.Whitehouse [Detecting Anomalous VEH Handlers](https://research.nccgroup.com/2022/03/01/detecting-anomalous-vectored-exception-handlers-on-windows/)
- @Maldev-Academy (@mrd0x, @NUL0x4C, @Cracked5pider) [Maldev Academy](https://maldevacademy.com/)
- @l1inear, @0xtriboulet, @kyle41111

## About

Dirty PoC on how to abuse S1's VEH for Vectored Syscalls and Local Execution


### Resources

[Readme](https://github.com/mannyfred/SentinelBruh#readme-ov-file)

### License

[GPL-2.0 license](https://github.com/mannyfred/SentinelBruh#GPL-2.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mannyfred/SentinelBruh).

[Activity](https://github.com/mannyfred/SentinelBruh/activity)

### Stars

[**43**\\
stars](https://github.com/mannyfred/SentinelBruh/stargazers)

### Watchers

[**2**\\
watching](https://github.com/mannyfred/SentinelBruh/watchers)

### Forks

[**6**\\
forks](https://github.com/mannyfred/SentinelBruh/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fmannyfred%2FSentinelBruh&report=mannyfred+%28user%29)

## [Releases](https://github.com/mannyfred/SentinelBruh/releases)

No releases published

## [Packages\  0](https://github.com/users/mannyfred/packages?repo_name=SentinelBruh)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/mannyfred/SentinelBruh).

## Languages

- [C96.3%](https://github.com/mannyfred/SentinelBruh/search?l=c)
- [Assembly3.7%](https://github.com/mannyfred/SentinelBruh/search?l=assembly)

You can’t perform that action at this time.