# https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main

[Skip to content](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main) to refresh your session.Dismiss alert

{{ message }}

[whokilleddb](https://github.com/whokilleddb)/ **[lordran.polymorphic.shellcode](https://github.com/whokilleddb/lordran.polymorphic.shellcode)** Public

- [Notifications](https://github.com/login?return_to=%2Fwhokilleddb%2Flordran.polymorphic.shellcode) You must be signed in to change notification settings
- [Fork\\
11](https://github.com/login?return_to=%2Fwhokilleddb%2Flordran.polymorphic.shellcode)
- [Star\\
57](https://github.com/login?return_to=%2Fwhokilleddb%2Flordran.polymorphic.shellcode)


Things i do because i saw it on twitter on a weekend


[57\\
stars](https://github.com/whokilleddb/lordran.polymorphic.shellcode/stargazers) [11\\
forks](https://github.com/whokilleddb/lordran.polymorphic.shellcode/forks) [Branches](https://github.com/whokilleddb/lordran.polymorphic.shellcode/branches) [Tags](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tags) [Activity](https://github.com/whokilleddb/lordran.polymorphic.shellcode/activity)

[Star](https://github.com/login?return_to=%2Fwhokilleddb%2Flordran.polymorphic.shellcode)

[Notifications](https://github.com/login?return_to=%2Fwhokilleddb%2Flordran.polymorphic.shellcode) You must be signed in to change notification settings

# whokilleddb/lordran.polymorphic.shellcode

main

[**1** Branch](https://github.com/whokilleddb/lordran.polymorphic.shellcode/branches) [**0** Tags](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tags)

[Go to Branches page](https://github.com/whokilleddb/lordran.polymorphic.shellcode/branches)[Go to Tags page](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![DB](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)![DB](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>DB<br>and<br>DB<br>[first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17)<br>7 months agoJul 20, 2025<br>[0588c64](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17) · 7 months agoJul 20, 2025<br>## History<br>[1 Commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commits/main/) 1 Commit |
| [imgs](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main/imgs "imgs") | [imgs](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main/imgs "imgs") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [.gitignore](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/.gitignore ".gitignore") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [Makefile](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/Makefile "Makefile") | [Makefile](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/Makefile "Makefile") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [README.md](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/README.md "README.md") | [README.md](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/README.md "README.md") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [main.c](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/main.c "main.c") | [main.c](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/main.c "main.c") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [main.h](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/main.h "main.h") | [main.h](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/main.h "main.h") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| [runshellcode.py](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/runshellcode.py "runshellcode.py") | [runshellcode.py](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/runshellcode.py "runshellcode.py") | [first commit](https://github.com/whokilleddb/lordran.polymorphic.shellcode/commit/0588c64c3f64f9acfeb816b03bc288ef14fd4f17 "first commit") | 7 months agoJul 20, 2025 |
| View all files |

## Repository files navigation

# lordran.polymorphic.shellcode

[Permalink: lordran.polymorphic.shellcode](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#lordranpolymorphicshellcode)

[!["Buy Me A Coffee"](https://camo.githubusercontent.com/9f44ce2dc3b3eecdd02598900866ffc518801df1932849703dae1e5ce5031070/68747470733a2f2f7777772e6275796d6561636f666665652e636f6d2f6173736574732f696d672f637573746f6d5f696d616765732f6f72616e67655f696d672e706e67)](https://www.buymeacoffee.com/whokilleddb)

This mini project was inspired by the following meme tweeted by [@jamieantisocial](https://x.com/jamieantisocial):

[![](https://github.com/whokilleddb/lordran.polymorphic.shellcode/raw/main/imgs/img.jpeg)](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/imgs/img.jpeg)

And, I found it really interesting so here is a mini PoC of some of the things mentioned in the meme.

## Objectives

[Permalink: Objectives](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#objectives)

I had 3 main objectives with this program - Produce a shellcode which :

- Does normal execution stuff
- Overwrites previously executed stub to prevent forensic analysis
- Reuse the memory segment for executing new shellcode

## Usage:

[Permalink: Usage:](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#usage)

Compile everything with:

```
$ make
```

Running the EXE:

```
$ ./overwrite.exe
```

Running the shellcode:

```
$ python runshellcode.py shellcode.bin
```

## Output

[Permalink: Output](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#output)

First, you should get a `MessageBox` popup with the text: `Bonfire`, which signifies that the first part of the shellcode has run successfully, and then a `Hello World` messagebox as a result of the execution of the second shellcode blob

[![](https://github.com/whokilleddb/lordran.polymorphic.shellcode/raw/main/imgs/works.gif)](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/imgs/works.gif)[![works.gif](https://github.com/whokilleddb/lordran.polymorphic.shellcode/raw/main/imgs/works.gif)](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/imgs/works.gif)[Open works.gif in new window](https://github.com/whokilleddb/lordran.polymorphic.shellcode/blob/main/imgs/works.gif)

## Notes:

[Permalink: Notes:](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#notes)

- The `__attribute__ ((section (".text.A")))` tags on every function except the entrypoint is to make sure the entrypoint is at the beginning of the `.text` section. See: [https://stackoverflow.com/questions/19470666/gcc-how-to-tell-gcc-to-put-the-main-function-at-the-start-of-the-text-sectio](https://stackoverflow.com/questions/19470666/gcc-how-to-tell-gcc-to-put-the-main-function-at-the-start-of-the-text-sectio)
- the `shellcode` variable cannot be placed in the `bonfire()` function because mingw places it in the `.rdata` section
- This project is **NOT** opsec safe and is just a PoC and hence isn't the best code

K. Bye.

[![](https://camo.githubusercontent.com/22b2750a3d01cceef18f74ac2fa42f2faf35ee880cf91c5b09e8689bcc23416a/68747470733a2f2f656e637279707465642d74626e302e677374617469632e636f6d2f696d616765733f713d74626e3a414e64394763547974475a5a72347a507879676f4757614e5f75704a714663503370514a6439666e6a672673)](https://camo.githubusercontent.com/22b2750a3d01cceef18f74ac2fa42f2faf35ee880cf91c5b09e8689bcc23416a/68747470733a2f2f656e637279707465642d74626e302e677374617469632e636f6d2f696d616765733f713d74626e3a414e64394763547974475a5a72347a507879676f4757614e5f75704a714663503370514a6439666e6a672673)

## About

Things i do because i saw it on twitter on a weekend


### Resources

[Readme](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/whokilleddb/lordran.polymorphic.shellcode/tree/main).

[Activity](https://github.com/whokilleddb/lordran.polymorphic.shellcode/activity)

### Stars

[**57**\\
stars](https://github.com/whokilleddb/lordran.polymorphic.shellcode/stargazers)

### Watchers

[**1**\\
watching](https://github.com/whokilleddb/lordran.polymorphic.shellcode/watchers)

### Forks

[**11**\\
forks](https://github.com/whokilleddb/lordran.polymorphic.shellcode/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fwhokilleddb%2Flordran.polymorphic.shellcode&report=whokilleddb+%28user%29)

## [Releases](https://github.com/whokilleddb/lordran.polymorphic.shellcode/releases)

No releases published

## [Packages\  0](https://github.com/users/whokilleddb/packages?repo_name=lordran.polymorphic.shellcode)

No packages published

## Languages

- [C83.5%](https://github.com/whokilleddb/lordran.polymorphic.shellcode/search?l=c)
- [Python13.7%](https://github.com/whokilleddb/lordran.polymorphic.shellcode/search?l=python)
- [Makefile2.8%](https://github.com/whokilleddb/lordran.polymorphic.shellcode/search?l=makefile)

You can’t perform that action at this time.