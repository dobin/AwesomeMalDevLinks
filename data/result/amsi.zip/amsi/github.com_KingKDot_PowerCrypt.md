# https://github.com/KingKDot/PowerCrypt

[Skip to content](https://github.com/KingKDot/PowerCrypt#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/KingKDot/PowerCrypt) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/KingKDot/PowerCrypt) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/KingKDot/PowerCrypt) to refresh your session.Dismiss alert

{{ message }}

[KingKDot](https://github.com/KingKDot)/ **[PowerCrypt](https://github.com/KingKDot/PowerCrypt)** Public

- [Notifications](https://github.com/login?return_to=%2FKingKDot%2FPowerCrypt) You must be signed in to change notification settings
- [Fork\\
13](https://github.com/login?return_to=%2FKingKDot%2FPowerCrypt)
- [Star\\
120](https://github.com/login?return_to=%2FKingKDot%2FPowerCrypt)


The best powershell obfuscator ever made


### License

[Apache-2.0 license](https://github.com/KingKDot/PowerCrypt/blob/master/LICENSE.txt)

[120\\
stars](https://github.com/KingKDot/PowerCrypt/stargazers) [13\\
forks](https://github.com/KingKDot/PowerCrypt/forks) [Branches](https://github.com/KingKDot/PowerCrypt/branches) [Tags](https://github.com/KingKDot/PowerCrypt/tags) [Activity](https://github.com/KingKDot/PowerCrypt/activity)

[Star](https://github.com/login?return_to=%2FKingKDot%2FPowerCrypt)

[Notifications](https://github.com/login?return_to=%2FKingKDot%2FPowerCrypt) You must be signed in to change notification settings

# KingKDot/PowerCrypt

master

[**1** Branch](https://github.com/KingKDot/PowerCrypt/branches) [**1** Tag](https://github.com/KingKDot/PowerCrypt/tags)

[Go to Branches page](https://github.com/KingKDot/PowerCrypt/branches)[Go to Tags page](https://github.com/KingKDot/PowerCrypt/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>![author](https://github.githubassets.com/images/gravatars/gravatar-user-420.png?size=40)<br>KingKDot<br>[add settings to obfuscator so people can use it easier.](https://github.com/KingKDot/PowerCrypt/commit/6c0ee017209f1a4ab87130a58f934e66eb03726b)<br>success<br>7 months agoJul 31, 2025<br>[6c0ee01](https://github.com/KingKDot/PowerCrypt/commit/6c0ee017209f1a4ab87130a58f934e66eb03726b) · 7 months agoJul 31, 2025<br>## History<br>[12 Commits](https://github.com/KingKDot/PowerCrypt/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/KingKDot/PowerCrypt/commits/master/) 12 Commits |
| [.github/workflows](https://github.com/KingKDot/PowerCrypt/tree/master/.github/workflows "This path skips through empty directories") | [.github/workflows](https://github.com/KingKDot/PowerCrypt/tree/master/.github/workflows "This path skips through empty directories") | [Update dotnet.yml](https://github.com/KingKDot/PowerCrypt/commit/34537b1cf4ac42badbd78fe801fbd03f2e18ac74 "Update dotnet.yml") | last yearFeb 12, 2025 |
| [PowerCrypt](https://github.com/KingKDot/PowerCrypt/tree/master/PowerCrypt "PowerCrypt") | [PowerCrypt](https://github.com/KingKDot/PowerCrypt/tree/master/PowerCrypt "PowerCrypt") | [add settings to obfuscator so people can use it easier.](https://github.com/KingKDot/PowerCrypt/commit/6c0ee017209f1a4ab87130a58f934e66eb03726b "add settings to obfuscator so people can use it easier.") | 7 months agoJul 31, 2025 |
| [.gitattributes](https://github.com/KingKDot/PowerCrypt/blob/master/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/KingKDot/PowerCrypt/blob/master/.gitattributes ".gitattributes") | [Add project files.](https://github.com/KingKDot/PowerCrypt/commit/caee3acaad00c03de1871ecd2e908df65d2a215e "Add project files.") | last yearFeb 10, 2025 |
| [.gitignore](https://github.com/KingKDot/PowerCrypt/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/KingKDot/PowerCrypt/blob/master/.gitignore ".gitignore") | [Add project files.](https://github.com/KingKDot/PowerCrypt/commit/caee3acaad00c03de1871ecd2e908df65d2a215e "Add project files.") | last yearFeb 10, 2025 |
| [LICENSE.txt](https://github.com/KingKDot/PowerCrypt/blob/master/LICENSE.txt "LICENSE.txt") | [LICENSE.txt](https://github.com/KingKDot/PowerCrypt/blob/master/LICENSE.txt "LICENSE.txt") | [Add project files.](https://github.com/KingKDot/PowerCrypt/commit/caee3acaad00c03de1871ecd2e908df65d2a215e "Add project files.") | last yearFeb 10, 2025 |
| [PowerCrypt.sln](https://github.com/KingKDot/PowerCrypt/blob/master/PowerCrypt.sln "PowerCrypt.sln") | [PowerCrypt.sln](https://github.com/KingKDot/PowerCrypt/blob/master/PowerCrypt.sln "PowerCrypt.sln") | [Add project files.](https://github.com/KingKDot/PowerCrypt/commit/caee3acaad00c03de1871ecd2e908df65d2a215e "Add project files.") | last yearFeb 10, 2025 |
| [README.md](https://github.com/KingKDot/PowerCrypt/blob/master/README.md "README.md") | [README.md](https://github.com/KingKDot/PowerCrypt/blob/master/README.md "README.md") | [Update README.md](https://github.com/KingKDot/PowerCrypt/commit/17ccf5f8f018fd5548f5ff170fe13fc30551daa3 "Update README.md") | last yearFeb 12, 2025 |
| View all files |

## Repository files navigation

# PowerCrypt

[Permalink: PowerCrypt](https://github.com/KingKDot/PowerCrypt#powercrypt)

The greatest powershell obfuscator ever made.

## Quick Start

[Permalink: Quick Start](https://github.com/KingKDot/PowerCrypt#quick-start)

#### First Method

[Permalink: First Method](https://github.com/KingKDot/PowerCrypt#first-method)

Download from github release [![here](https://github.com/KingKDot/PowerCrypt/releases/tag/AutoBuild)](https://github.com/KingKDot/PowerCrypt/releases/tag/AutoBuild)

#### Second Method (Source)

[Permalink: Second Method (Source)](https://github.com/KingKDot/PowerCrypt#second-method-source)

Install visual studio.

Clone project in visual studio or download it as zip and import it.

This project does support AOT building so you can either publish it (which is what the releases does) or build it as you would any other c# project.

### How to use after building/downloading

[Permalink: How to use after building/downloading](https://github.com/KingKDot/PowerCrypt#how-to-use-after-buildingdownloading)

Using this tool is extremely easy. Either just put in the path of the file after double clicking, or put in the path of the file as an argument via the command line.

## Features

[Permalink: Features](https://github.com/KingKDot/PowerCrypt#features)

- Extremely fast (.5 miliseconds for a 21kb powershell script)
- Protects exceptionaly well
- At time of writing it isn't detected statically by a single antivirus
- Cross platform
- Supports AOT building
- Exclusively uses and parses the powershell AST to do proper obfuscation

## Before and after output

[Permalink: Before and after output](https://github.com/KingKDot/PowerCrypt#before-and-after-output)

Before:

[![before_image](https://private-user-images.githubusercontent.com/110929758/412635183-69557614-4eea-4b80-bf68-c0ef3c2d7263.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI0MjIsIm5iZiI6MTc3MTE0MjEyMiwicGF0aCI6Ii8xMTA5Mjk3NTgvNDEyNjM1MTgzLTY5NTU3NjE0LTRlZWEtNGI4MC1iZjY4LWMwZWYzYzJkNzI2My5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE1JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxNVQwNzU1MjJaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT03MmIyODBjMmE5Y2QxNjgyZGU0NGU4MWNkNGMwNzBjZGRmMDg5OWRlNDQ2MTJjMDdjNjFjZmY4NmMzNDA5MjJmJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.gxJXCXKsMt9SqUPGQyAovcPHHu-xI_XVPIrvxsIsNNU)](https://private-user-images.githubusercontent.com/110929758/412635183-69557614-4eea-4b80-bf68-c0ef3c2d7263.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI0MjIsIm5iZiI6MTc3MTE0MjEyMiwicGF0aCI6Ii8xMTA5Mjk3NTgvNDEyNjM1MTgzLTY5NTU3NjE0LTRlZWEtNGI4MC1iZjY4LWMwZWYzYzJkNzI2My5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE1JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxNVQwNzU1MjJaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT03MmIyODBjMmE5Y2QxNjgyZGU0NGU4MWNkNGMwNzBjZGRmMDg5OWRlNDQ2MTJjMDdjNjFjZmY4NmMzNDA5MjJmJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.gxJXCXKsMt9SqUPGQyAovcPHHu-xI_XVPIrvxsIsNNU)
After:

[![after_image](https://private-user-images.githubusercontent.com/110929758/412636004-09868a6e-3ada-4adf-b524-23baf9d8fc71.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI0MjIsIm5iZiI6MTc3MTE0MjEyMiwicGF0aCI6Ii8xMTA5Mjk3NTgvNDEyNjM2MDA0LTA5ODY4YTZlLTNhZGEtNGFkZi1iNTI0LTIzYmFmOWQ4ZmM3MS5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE1JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxNVQwNzU1MjJaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0xODdiODJiNTNhMjAxMTQ2MTZmZGQ0ZTk5ZmE0YThiNDhkOTAzODM0YzBjNjI2MTk1YTcxMTkwYWM5ZDlkNjU4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.z6sp1dnQiQBAp9qsUQG7HngPcScohrS2eI-Oqx-GPjE)](https://private-user-images.githubusercontent.com/110929758/412636004-09868a6e-3ada-4adf-b524-23baf9d8fc71.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzExNDI0MjIsIm5iZiI6MTc3MTE0MjEyMiwicGF0aCI6Ii8xMTA5Mjk3NTgvNDEyNjM2MDA0LTA5ODY4YTZlLTNhZGEtNGFkZi1iNTI0LTIzYmFmOWQ4ZmM3MS5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjYwMjE1JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI2MDIxNVQwNzU1MjJaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0xODdiODJiNTNhMjAxMTQ2MTZmZGQ0ZTk5ZmE0YThiNDhkOTAzODM0YzBjNjI2MTk1YTcxMTkwYWM5ZDlkNjU4JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.z6sp1dnQiQBAp9qsUQG7HngPcScohrS2eI-Oqx-GPjE)

## Authors

[Permalink: Authors](https://github.com/KingKDot/PowerCrypt#authors)

- [@KingKDot](https://www.github.com/KingKDot)

## About

The best powershell obfuscator ever made


### Resources

[Readme](https://github.com/KingKDot/PowerCrypt#readme-ov-file)

### License

[Apache-2.0 license](https://github.com/KingKDot/PowerCrypt#Apache-2.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/KingKDot/PowerCrypt).

[Activity](https://github.com/KingKDot/PowerCrypt/activity)

### Stars

[**120**\\
stars](https://github.com/KingKDot/PowerCrypt/stargazers)

### Watchers

[**3**\\
watching](https://github.com/KingKDot/PowerCrypt/watchers)

### Forks

[**13**\\
forks](https://github.com/KingKDot/PowerCrypt/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FKingKDot%2FPowerCrypt&report=KingKDot+%28user%29)

## [Releases\  1](https://github.com/KingKDot/PowerCrypt/releases)

[AutoBuild\\
Latest\\
\\
on Jul 31, 2025Aug 1, 2025](https://github.com/KingKDot/PowerCrypt/releases/tag/AutoBuild)

## [Packages\  0](https://github.com/users/KingKDot/packages?repo_name=PowerCrypt)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/KingKDot/PowerCrypt).

## Languages

- [C#100.0%](https://github.com/KingKDot/PowerCrypt/search?l=c%23)

You can’t perform that action at this time.