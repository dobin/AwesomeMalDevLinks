# https://github.com/bananabr/CLRInjector

[Skip to content](https://github.com/bananabr/CLRInjector#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/bananabr/CLRInjector) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/bananabr/CLRInjector) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/bananabr/CLRInjector) to refresh your session.Dismiss alert

{{ message }}

[bananabr](https://github.com/bananabr)/ **[CLRInjector](https://github.com/bananabr/CLRInjector)** Public

- [Notifications](https://github.com/login?return_to=%2Fbananabr%2FCLRInjector) You must be signed in to change notification settings
- [Fork\\
14](https://github.com/login?return_to=%2Fbananabr%2FCLRInjector)
- [Star\\
57](https://github.com/login?return_to=%2Fbananabr%2FCLRInjector)


A PoC .NET-specific process injection tool


### License

[MIT license](https://github.com/bananabr/CLRInjector/blob/main/LICENSE.md)

[57\\
stars](https://github.com/bananabr/CLRInjector/stargazers) [14\\
forks](https://github.com/bananabr/CLRInjector/forks) [Branches](https://github.com/bananabr/CLRInjector/branches) [Tags](https://github.com/bananabr/CLRInjector/tags) [Activity](https://github.com/bananabr/CLRInjector/activity)

[Star](https://github.com/login?return_to=%2Fbananabr%2FCLRInjector)

[Notifications](https://github.com/login?return_to=%2Fbananabr%2FCLRInjector) You must be signed in to change notification settings

# bananabr/CLRInjector

main

[**1** Branch](https://github.com/bananabr/CLRInjector/branches) [**0** Tags](https://github.com/bananabr/CLRInjector/tags)

[Go to Branches page](https://github.com/bananabr/CLRInjector/branches)[Go to Tags page](https://github.com/bananabr/CLRInjector/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![bananabr](https://avatars.githubusercontent.com/u/9096933?v=4&size=40)](https://github.com/bananabr)[bananabr](https://github.com/bananabr/CLRInjector/commits?author=bananabr)<br>[Create LICENSE.md](https://github.com/bananabr/CLRInjector/commit/9ce9fb15a521b52482627f5a1c9ea4d32ce525d9)<br>2 years agoMar 16, 2024<br>[9ce9fb1](https://github.com/bananabr/CLRInjector/commit/9ce9fb15a521b52482627f5a1c9ea4d32ce525d9) · 2 years agoMar 16, 2024<br>## History<br>[6 Commits](https://github.com/bananabr/CLRInjector/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/bananabr/CLRInjector/commits/main/) 6 Commits |
| [CLRInjector](https://github.com/bananabr/CLRInjector/tree/main/CLRInjector "CLRInjector") | [CLRInjector](https://github.com/bananabr/CLRInjector/tree/main/CLRInjector "CLRInjector") | [Update help](https://github.com/bananabr/CLRInjector/commit/68177ac90b09f2a6274872bd7f44c99f3ebd06d8 "Update help") | 2 years agoFeb 18, 2024 |
| [images](https://github.com/bananabr/CLRInjector/tree/main/images "images") | [images](https://github.com/bananabr/CLRInjector/tree/main/images "images") | [Update README](https://github.com/bananabr/CLRInjector/commit/c1be6e6ab041e91a1f6b12c061ad9f7b21c577c8 "Update README") | 2 years agoFeb 18, 2024 |
| [.gitignore](https://github.com/bananabr/CLRInjector/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/bananabr/CLRInjector/blob/main/.gitignore ".gitignore") | [Initial commit](https://github.com/bananabr/CLRInjector/commit/9befc8fc7674c86158b219150ab94ee6d85a1352 "Initial commit") | 3 years agoJan 12, 2024 |
| [CLRInjector.sln](https://github.com/bananabr/CLRInjector/blob/main/CLRInjector.sln "CLRInjector.sln") | [CLRInjector.sln](https://github.com/bananabr/CLRInjector/blob/main/CLRInjector.sln "CLRInjector.sln") | [Initial commit](https://github.com/bananabr/CLRInjector/commit/9befc8fc7674c86158b219150ab94ee6d85a1352 "Initial commit") | 3 years agoJan 12, 2024 |
| [LICENSE.md](https://github.com/bananabr/CLRInjector/blob/main/LICENSE.md "LICENSE.md") | [LICENSE.md](https://github.com/bananabr/CLRInjector/blob/main/LICENSE.md "LICENSE.md") | [Create LICENSE.md](https://github.com/bananabr/CLRInjector/commit/9ce9fb15a521b52482627f5a1c9ea4d32ce525d9 "Create LICENSE.md") | 2 years agoMar 16, 2024 |
| [README.md](https://github.com/bananabr/CLRInjector/blob/main/README.md "README.md") | [README.md](https://github.com/bananabr/CLRInjector/blob/main/README.md "README.md") | [sponsorship link](https://github.com/bananabr/CLRInjector/commit/594664c973c0cd6fd2bcb6f726cc86a5713ad95b "sponsorship link") | 2 years agoFeb 18, 2024 |
| View all files |

## Repository files navigation

## Disclaimer

[Permalink: Disclaimer](https://github.com/bananabr/CLRInjector#disclaimer)

This tool is provided for educational purposes only. Any actions and activities related to the material contained within this repository are solely your responsibility. Misusing this tool can result in criminal charges against the persons in question. The author will not be held responsible if any criminal charges are brought against any individuals misusing the provided tool to break the law.

## What is this?

[Permalink: What is this?](https://github.com/bananabr/CLRInjector#what-is-this)

A proof-of-concept process injection tool that mixes Adam Chester's ( [@XPN](https://twitter.com/_xpn_)) "Weird Ways to Run Unmanaged Code in .NET" and Ceri Coburn's ( [@ _EthicalChaos_](https://twitter.com/_ethicalchaos_)) "Needles Without The Thread: Threadless Process Injection - Ceri Coburn".

## How does it work?

[Permalink: How does it work?](https://github.com/bananabr/CLRInjector#how-does-it-work)

- List target processes

```
CLRInjector.exe --ps
```

- Dump GC heap (similar to SOS.dll !dumpheap)

```
CLRInjector.exe <pid|process_name> --dump-obj
```

- Dump method tables (similar to SOS.dll !dumpmt)

```
CLRInjector.exe <pid|process_name> --dump-mt 0x1122334455667788
```

- Dump method descriptor (similar to SOS.dll !dumpmd)

```
CLRInjector.exe <pid|process_name> --dump-md 0x1122334455667788
```

- Dump trampolines (injection targets)

```
CLRInjector.exe <pid|process_name> --dump-trampolines
```

- Hook Jitted method and loads shellcode into preexisting RWX segment

```
CLRInjector.exe <pid|process_name> --inject <payload path> <method_desc>
```

### Usage example

[Permalink: Usage example](https://github.com/bananabr/CLRInjector#usage-example)

[![Usage example](https://github.com/bananabr/CLRInjector/raw/main/images/CLRInjector.gif)](https://github.com/bananabr/CLRInjector/blob/main/images/CLRInjector.gif)[![Usage example](https://github.com/bananabr/CLRInjector/raw/main/images/CLRInjector.gif)](https://github.com/bananabr/CLRInjector/blob/main/images/CLRInjector.gif)[Open Usage example in new window](https://github.com/bananabr/CLRInjector/blob/main/images/CLRInjector.gif)

## Known issues

[Permalink: Known issues](https://github.com/bananabr/CLRInjector#known-issues)

- To reserve space for the shellcode, the tool updates the JIT Manager loader code heap m\_pAllocPtr. This keeps future JIT allocations from overwriting the payload. There is a chance of a race condition if m\_pAllocPtr is updated by the JIT manager after its read but before its patched by the tool.
- For now, the shellcode must support being called as a function and return, otherwise it may crash the target process. A generic stub that loads the shellcode on its own thread would most likely solve this.

## References

[Permalink: References](https://github.com/bananabr/CLRInjector#references)

- [https://blog.xpnsec.com/weird-ways-to-execute-dotnet/](https://blog.xpnsec.com/weird-ways-to-execute-dotnet/)
- [https://www.youtube.com/watch?v=z8GIjk0rfbI&t=1388s](https://www.youtube.com/watch?v=z8GIjk0rfbI&t=1388s)
- [https://learn.microsoft.com/en-us/archive/msdn-magazine/2005/may/net-framework-internals-how-the-clr-creates-runtime-objects](https://learn.microsoft.com/en-us/archive/msdn-magazine/2005/may/net-framework-internals-how-the-clr-creates-runtime-objects)
- [https://www.codeproject.com/articles/37549/clr-injection-runtime-method-replacer?fid=1542682&df=90&mpp=25&prof=True&sort=Position&view=Normal&spc=Relaxed&fr=26](https://www.codeproject.com/articles/37549/clr-injection-runtime-method-replacer?fid=1542682&df=90&mpp=25&prof=True&sort=Position&view=Normal&spc=Relaxed&fr=26)
- [https://blog.maartenballiauw.be/post/2017/01/03/exploring-.net-managed-heap-with-clrmd.html](https://blog.maartenballiauw.be/post/2017/01/03/exploring-.net-managed-heap-with-clrmd.html)
- [https://mattwarren.org/2016/09/06/Analysing-.NET-Memory-Dumps-with-CLR-MD/](https://mattwarren.org/2016/09/06/Analysing-.NET-Memory-Dumps-with-CLR-MD/)

## Todo

[Permalink: Todo](https://github.com/bananabr/CLRInjector#todo)

PRs are always welcome!

- [ ]  Support to x86 targets
- [ ]  Generic shellcode support
- [ ]  Migrate p/invoke calls to d/invoke
- [ ]  Cleanup code
- [x]  Support real slot in MethodTable

[!["Buy Me A Coffee"](https://camo.githubusercontent.com/9f44ce2dc3b3eecdd02598900866ffc518801df1932849703dae1e5ce5031070/68747470733a2f2f7777772e6275796d6561636f666665652e636f6d2f6173736574732f696d672f637573746f6d5f696d616765732f6f72616e67655f696d672e706e67)](https://www.buymeacoffee.com/bananabr)

## About

A PoC .NET-specific process injection tool


### Resources

[Readme](https://github.com/bananabr/CLRInjector#readme-ov-file)

### License

[MIT license](https://github.com/bananabr/CLRInjector#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/bananabr/CLRInjector).

[Activity](https://github.com/bananabr/CLRInjector/activity)

### Stars

[**57**\\
stars](https://github.com/bananabr/CLRInjector/stargazers)

### Watchers

[**2**\\
watching](https://github.com/bananabr/CLRInjector/watchers)

### Forks

[**14**\\
forks](https://github.com/bananabr/CLRInjector/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fbananabr%2FCLRInjector&report=bananabr+%28user%29)

## [Releases](https://github.com/bananabr/CLRInjector/releases)

No releases published

## [Packages\  0](https://github.com/users/bananabr/packages?repo_name=CLRInjector)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/bananabr/CLRInjector).

## Languages

- [C#100.0%](https://github.com/bananabr/CLRInjector/search?l=c%23)

You can’t perform that action at this time.