# https://github.com/iss4cf0ng/dotNetPELoader

[Skip to content](https://github.com/iss4cf0ng/dotNetPELoader#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/iss4cf0ng/dotNetPELoader) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/iss4cf0ng/dotNetPELoader) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/iss4cf0ng/dotNetPELoader) to refresh your session.Dismiss alert

{{ message }}

[iss4cf0ng](https://github.com/iss4cf0ng)/ **[dotNetPELoader](https://github.com/iss4cf0ng/dotNetPELoader)** Public

- [Notifications](https://github.com/login?return_to=%2Fiss4cf0ng%2FdotNetPELoader) You must be signed in to change notification settings
- [Fork\\
4](https://github.com/login?return_to=%2Fiss4cf0ng%2FdotNetPELoader)
- [Star\\
43](https://github.com/login?return_to=%2Fiss4cf0ng%2FdotNetPELoader)


A C# PE loader for x64 and x86 PE files.


[iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/](https://iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/ "https://iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/")

[43\\
stars](https://github.com/iss4cf0ng/dotNetPELoader/stargazers) [4\\
forks](https://github.com/iss4cf0ng/dotNetPELoader/forks) [Branches](https://github.com/iss4cf0ng/dotNetPELoader/branches) [Tags](https://github.com/iss4cf0ng/dotNetPELoader/tags) [Activity](https://github.com/iss4cf0ng/dotNetPELoader/activity)

[Star](https://github.com/login?return_to=%2Fiss4cf0ng%2FdotNetPELoader)

[Notifications](https://github.com/login?return_to=%2Fiss4cf0ng%2FdotNetPELoader) You must be signed in to change notification settings

# iss4cf0ng/dotNetPELoader

master

[**2** Branches](https://github.com/iss4cf0ng/dotNetPELoader/branches) [**1** Tag](https://github.com/iss4cf0ng/dotNetPELoader/tags)

[Go to Branches page](https://github.com/iss4cf0ng/dotNetPELoader/branches)[Go to Tags page](https://github.com/iss4cf0ng/dotNetPELoader/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![iss4cf0ng](https://avatars.githubusercontent.com/u/110074064?v=4&size=40)](https://github.com/iss4cf0ng)[iss4cf0ng](https://github.com/iss4cf0ng/dotNetPELoader/commits?author=iss4cf0ng)<br>[Update README.md](https://github.com/iss4cf0ng/dotNetPELoader/commit/ea234e0d91b9c7ca03a1a9489369ee066069ed6f)<br>2 weeks agoFeb 5, 2026<br>[ea234e0](https://github.com/iss4cf0ng/dotNetPELoader/commit/ea234e0d91b9c7ca03a1a9489369ee066069ed6f) · 2 weeks agoFeb 5, 2026<br>## History<br>[14 Commits](https://github.com/iss4cf0ng/dotNetPELoader/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/iss4cf0ng/dotNetPELoader/commits/master/) 14 Commits |
| [dotNetPELoader](https://github.com/iss4cf0ng/dotNetPELoader/tree/master/dotNetPELoader "dotNetPELoader") | [dotNetPELoader](https://github.com/iss4cf0ng/dotNetPELoader/tree/master/dotNetPELoader "dotNetPELoader") | [update](https://github.com/iss4cf0ng/dotNetPELoader/commit/92ab42ea2efccc110ce4875ea3a1c9a0ce7194b5 "update") | 2 weeks agoFeb 5, 2026 |
| [.gitattributes](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/.gitattributes ".gitattributes") | [.gitattributes](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/.gitattributes ".gitattributes") | [Add .gitattributes, .gitignore, and README.md.](https://github.com/iss4cf0ng/dotNetPELoader/commit/eb9ec0beda39783cea20af1075680c5c663cdb74 "Add .gitattributes, .gitignore, and README.md.") | 2 weeks agoFeb 5, 2026 |
| [.gitignore](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/.gitignore ".gitignore") | [Add .gitattributes, .gitignore, and README.md.](https://github.com/iss4cf0ng/dotNetPELoader/commit/eb9ec0beda39783cea20af1075680c5c663cdb74 "Add .gitattributes, .gitignore, and README.md.") | 2 weeks agoFeb 5, 2026 |
| [README.md](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/README.md "README.md") | [README.md](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/README.md "README.md") | [Update README.md](https://github.com/iss4cf0ng/dotNetPELoader/commit/ea234e0d91b9c7ca03a1a9489369ee066069ed6f "Update README.md") | 2 weeks agoFeb 5, 2026 |
| [dotNetPELoader.sln](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/dotNetPELoader.sln "dotNetPELoader.sln") | [dotNetPELoader.sln](https://github.com/iss4cf0ng/dotNetPELoader/blob/master/dotNetPELoader.sln "dotNetPELoader.sln") | [Add project files.](https://github.com/iss4cf0ng/dotNetPELoader/commit/376a6bf63f5525195ec3313c1e6d28c85728287c "Add project files.") | 2 weeks agoFeb 5, 2026 |
| View all files |

## Repository files navigation

# dotNetPELoader

[Permalink: dotNetPELoader](https://github.com/iss4cf0ng/dotNetPELoader#dotnetpeloader)

A C# PE loader for x64 and x86 PE files.

Recently, when I was developing a fileless execution method for [DuplexSpy RAT](https://github.com/iss4cf0ng/DuplexSpyCS) version 2, I could hardly find a C#-based x86 PE loader.

Most existing implementations I found were x64-only, such as the one developed by [Casey Smith](https://github.com/S3cur3Th1sSh1t/Creds/blob/master/Csharp/PEloader.cs)
.
Therefore, I decided to develop a C#-based x86 PE loader myself.

This console application allows you to load either x86 or x64 PE files into memory.
First, it reads the file bytes from the specified file path, then determines the architecture of both the loader and the target PE file.

An x64 PE cannot be loaded by an x86 loader, and vice versa.

## Features

[Permalink: Features](https://github.com/iss4cf0ng/dotNetPELoader#features)

- Load **x86 PE in x86 process**
- Load **x64 PE in x64 process**
- Handles relocation and import resolving
- Fully written in C#

If you find this project useful, a ⭐ would be appreciated.

[![](https://camo.githubusercontent.com/5b61ec2aec49bba226c26f76b6ca74e9f4b23b0bfec41c7ecf3b8f6ccf993b53/68747470733a2f2f697373346366306e672e6769746875622e696f2f696d616765732f6d656d652f6d696b615f637574652e6a7067)](https://camo.githubusercontent.com/5b61ec2aec49bba226c26f76b6ca74e9f4b23b0bfec41c7ecf3b8f6ccf993b53/68747470733a2f2f697373346366306e672e6769746875622e696f2f696d616765732f6d656d652f6d696b615f637574652e6a7067)

# Usage

[Permalink: Usage](https://github.com/iss4cf0ng/dotNetPELoader#usage)

```
dotNetPELoader.exe --x64 x64_file.exe
dotNetPELoader.exe --x86 x86_file.exe
dotNetPELoader.exe --coffee
```

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/hello.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/hello.png)

# Demonstration

[Permalink: Demonstration](https://github.com/iss4cf0ng/dotNetPELoader#demonstration)

## x64 - mimikatz

[Permalink: x64 - mimikatz](https://github.com/iss4cf0ng/dotNetPELoader#x64---mimikatz)

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/anycpu.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/anycpu.png)

If you try to load an x86 PE while the loader is an x64 loader, an exception will be thrown:

```
dotNetPELoader.exe --x64 mimikatz
```

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x64.1.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x64.1.png)

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x64.2.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x64.2.png)

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x64.3.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x64.3.png)

## x86 - mimikatz

[Permalink: x86 - mimikatz](https://github.com/iss4cf0ng/dotNetPELoader#x86---mimikatz)

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x86_cpu.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x86_cpu.png)

```
dotNetPELoader.exe --x86 mimikatz
```

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x86.1.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x86.1.png)

[![](https://github.com/iss4cf0ng/dotNetPELoader/raw/main/screenshots/x86.2.png)](https://github.com/iss4cf0ng/dotNetPELoader/blob/main/screenshots/x86.2.png)

## About

A C# PE loader for x64 and x86 PE files.


[iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/](https://iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/ "https://iss4cf0ng.github.io/2026/02/06/2026-2-6-ToolDotNetPELoader/")

### Topics

[csharp](https://github.com/topics/csharp "Topic: csharp") [dotnet](https://github.com/topics/dotnet "Topic: dotnet") [x64](https://github.com/topics/x64 "Topic: x64") [x86](https://github.com/topics/x86 "Topic: x86") [csharp-code](https://github.com/topics/csharp-code "Topic: csharp-code") [pe-file](https://github.com/topics/pe-file "Topic: pe-file") [fileless](https://github.com/topics/fileless "Topic: fileless") [peloader](https://github.com/topics/peloader "Topic: peloader") [fileless-attack](https://github.com/topics/fileless-attack "Topic: fileless-attack") [fileless-malware](https://github.com/topics/fileless-malware "Topic: fileless-malware") [fileless-pe-injector](https://github.com/topics/fileless-pe-injector "Topic: fileless-pe-injector") [fileless-injection](https://github.com/topics/fileless-injection "Topic: fileless-injection") [x86loader](https://github.com/topics/x86loader "Topic: x86loader") [x64loader](https://github.com/topics/x64loader "Topic: x64loader")

### Resources

[Readme](https://github.com/iss4cf0ng/dotNetPELoader#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/iss4cf0ng/dotNetPELoader).

[Activity](https://github.com/iss4cf0ng/dotNetPELoader/activity)

### Stars

[**43**\\
stars](https://github.com/iss4cf0ng/dotNetPELoader/stargazers)

### Watchers

[**0**\\
watching](https://github.com/iss4cf0ng/dotNetPELoader/watchers)

### Forks

[**4**\\
forks](https://github.com/iss4cf0ng/dotNetPELoader/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fiss4cf0ng%2FdotNetPELoader&report=iss4cf0ng+%28user%29)

## [Releases\  1](https://github.com/iss4cf0ng/dotNetPELoader/releases)

[dotNetPELoader-v1.0.0\\
Latest\\
\\
2 weeks agoFeb 5, 2026](https://github.com/iss4cf0ng/dotNetPELoader/releases/tag/v1.0.0)

## [Packages\  0](https://github.com/users/iss4cf0ng/packages?repo_name=dotNetPELoader)

No packages published

## Languages

- [C#100.0%](https://github.com/iss4cf0ng/dotNetPELoader/search?l=c%23)

You can’t perform that action at this time.