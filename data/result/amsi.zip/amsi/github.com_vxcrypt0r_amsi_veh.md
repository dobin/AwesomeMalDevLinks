# https://github.com/vxCrypt0r/AMSI_VEH

[Skip to content](https://github.com/vxCrypt0r/AMSI_VEH#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/vxCrypt0r/AMSI_VEH) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/vxCrypt0r/AMSI_VEH) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/vxCrypt0r/AMSI_VEH) to refresh your session.Dismiss alert

{{ message }}

[vxCrypt0r](https://github.com/vxCrypt0r)/ **[AMSI\_VEH](https://github.com/vxCrypt0r/AMSI_VEH)** Public

- [Notifications](https://github.com/login?return_to=%2FvxCrypt0r%2FAMSI_VEH) You must be signed in to change notification settings
- [Fork\\
25](https://github.com/login?return_to=%2FvxCrypt0r%2FAMSI_VEH)
- [Star\\
167](https://github.com/login?return_to=%2FvxCrypt0r%2FAMSI_VEH)


A Powershell AMSI Bypass technique via Vectored Exception Handler (VEH). This technique does not perform assembly instruction patching, function hooking or Import Address Table (IAT) modification.


### License

[BSD-3-Clause license](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/LICENSE)

[167\\
stars](https://github.com/vxCrypt0r/AMSI_VEH/stargazers) [25\\
forks](https://github.com/vxCrypt0r/AMSI_VEH/forks) [Branches](https://github.com/vxCrypt0r/AMSI_VEH/branches) [Tags](https://github.com/vxCrypt0r/AMSI_VEH/tags) [Activity](https://github.com/vxCrypt0r/AMSI_VEH/activity)

[Star](https://github.com/login?return_to=%2FvxCrypt0r%2FAMSI_VEH)

[Notifications](https://github.com/login?return_to=%2FvxCrypt0r%2FAMSI_VEH) You must be signed in to change notification settings

# vxCrypt0r/AMSI\_VEH

master

[**1** Branch](https://github.com/vxCrypt0r/AMSI_VEH/branches) [**0** Tags](https://github.com/vxCrypt0r/AMSI_VEH/tags)

[Go to Branches page](https://github.com/vxCrypt0r/AMSI_VEH/branches)[Go to Tags page](https://github.com/vxCrypt0r/AMSI_VEH/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![vxCrypt0r](https://avatars.githubusercontent.com/u/76695257?v=4&size=40)](https://github.com/vxCrypt0r)[vxCrypt0r](https://github.com/vxCrypt0r/AMSI_VEH/commits?author=vxCrypt0r)<br>[Changed comment typo](https://github.com/vxCrypt0r/AMSI_VEH/commit/97d0abb695be282354c71cdd6a72d1af4a7e4cd3)<br>2 years agoMay 30, 2024<br>[97d0abb](https://github.com/vxCrypt0r/AMSI_VEH/commit/97d0abb695be282354c71cdd6a72d1af4a7e4cd3) · 2 years agoMay 30, 2024<br>## History<br>[6 Commits](https://github.com/vxCrypt0r/AMSI_VEH/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/vxCrypt0r/AMSI_VEH/commits/master/) 6 Commits |
| [AMSI\_VEH](https://github.com/vxCrypt0r/AMSI_VEH/tree/master/AMSI_VEH "AMSI_VEH") | [AMSI\_VEH](https://github.com/vxCrypt0r/AMSI_VEH/tree/master/AMSI_VEH "AMSI_VEH") | [Changed comment typo](https://github.com/vxCrypt0r/AMSI_VEH/commit/97d0abb695be282354c71cdd6a72d1af4a7e4cd3 "Changed comment typo") | 2 years agoMay 30, 2024 |
| [DLL\_Injector](https://github.com/vxCrypt0r/AMSI_VEH/tree/master/DLL_Injector "DLL_Injector") | [DLL\_Injector](https://github.com/vxCrypt0r/AMSI_VEH/tree/master/DLL_Injector "DLL_Injector") | [My first commit](https://github.com/vxCrypt0r/AMSI_VEH/commit/561b6e6cc6b58c10fdef75d124ac3abc113c7348 "My first commit") | 2 years agoMay 24, 2024 |
| [.gitignore](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/.gitignore ".gitignore") | [My first commit](https://github.com/vxCrypt0r/AMSI_VEH/commit/561b6e6cc6b58c10fdef75d124ac3abc113c7348 "My first commit") | 2 years agoMay 24, 2024 |
| [AMSI\_VEH.sln](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/AMSI_VEH.sln "AMSI_VEH.sln") | [AMSI\_VEH.sln](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/AMSI_VEH.sln "AMSI_VEH.sln") | [My first commit](https://github.com/vxCrypt0r/AMSI_VEH/commit/561b6e6cc6b58c10fdef75d124ac3abc113c7348 "My first commit") | 2 years agoMay 24, 2024 |
| [LICENSE](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/LICENSE "LICENSE") | [LICENSE](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/LICENSE "LICENSE") | [Create LICENSE](https://github.com/vxCrypt0r/AMSI_VEH/commit/c922770a09bf1886af3e58b1eaad5e6e817d778e "Create LICENSE") | 2 years agoMay 24, 2024 |
| [README.md](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/README.md "README.md") | [README.md](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/README.md "README.md") | [Update README.md](https://github.com/vxCrypt0r/AMSI_VEH/commit/4ca021a96e93d74d1c9c3294ae0b318b796b7a72 "Update README.md") | 2 years agoMay 24, 2024 |
| [poc.gif](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/poc.gif "poc.gif") | [poc.gif](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/poc.gif "poc.gif") | [Add files via upload](https://github.com/vxCrypt0r/AMSI_VEH/commit/951bc8667be13e83df90eb1bca6dcb2403473053 "Add files via upload") | 2 years agoMay 24, 2024 |
| View all files |

## Repository files navigation

# AMSI Bypass via VEH

[Permalink: AMSI Bypass via VEH](https://github.com/vxCrypt0r/AMSI_VEH#amsi-bypass-via-veh)

### Description:

[Permalink: Description:](https://github.com/vxCrypt0r/AMSI_VEH#description)

A PowerShell AMSI Bypass technique via Vectored Exception Handler (VEH). This technique does not perform assembly instruction patching, function hooking or Import Address Table (IAT) modification.

* * *

### How it works:

[Permalink: How it works:](https://github.com/vxCrypt0r/AMSI_VEH#how-it-works)

For this technique to work, you must first inject the VEH DLL into the PowerShell process. This can be done either by injecting the DLL or via DLL hijacking .

This technique works by setting up a hardware breakpoint on the function `AmsiScanBuffer` on all PowerShell process threads, then installing a VEH to handle the trigger of this breakpoint.

When a thread calls `AmsiScanBuffer`, the VEH will make the thread to exit the function without executing anything and setting the result of the function to `AMSI_RESULT_CLEAN`. This is all done inside the VEH, without modifying the code of the process or without any PE modifications.

* * *

### Usage:

[Permalink: Usage:](https://github.com/vxCrypt0r/AMSI_VEH#usage)

For demonstration purposes, this repository contains a very basic DLL injector. Use it this way:

- 1.) Compile the DLL Injector and VEH DLL.
- 2.) Open an instance of PowerShell.
- 3.) Run the DLL injector by providing the FULL PATH to the DLL. Example:

```
./DLL_Injector.exe C:\Windows\Temp\AMSI_VEH.DLL
```

- 4.) PowerShell will open a MessageBox window to confirm the VEH installation.

* * *

### Demo:

[Permalink: Demo:](https://github.com/vxCrypt0r/AMSI_VEH#demo)

[![](https://github.com/vxCrypt0r/AMSI_VEH/raw/master/poc.gif)](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/poc.gif)[![poc.gif](https://github.com/vxCrypt0r/AMSI_VEH/raw/master/poc.gif)](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/poc.gif)[Open poc.gif in new window](https://github.com/vxCrypt0r/AMSI_VEH/blob/master/poc.gif)

* * *

### Disclaimer

[Permalink: Disclaimer](https://github.com/vxCrypt0r/AMSI_VEH#disclaimer)

This repository is for academic purposes, the use of this software is your responsibility.

## About

A Powershell AMSI Bypass technique via Vectored Exception Handler (VEH). This technique does not perform assembly instruction patching, function hooking or Import Address Table (IAT) modification.


### Resources

[Readme](https://github.com/vxCrypt0r/AMSI_VEH#readme-ov-file)

### License

[BSD-3-Clause license](https://github.com/vxCrypt0r/AMSI_VEH#BSD-3-Clause-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxCrypt0r/AMSI_VEH).

[Activity](https://github.com/vxCrypt0r/AMSI_VEH/activity)

### Stars

[**167**\\
stars](https://github.com/vxCrypt0r/AMSI_VEH/stargazers)

### Watchers

[**3**\\
watching](https://github.com/vxCrypt0r/AMSI_VEH/watchers)

### Forks

[**25**\\
forks](https://github.com/vxCrypt0r/AMSI_VEH/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FvxCrypt0r%2FAMSI_VEH&report=vxCrypt0r+%28user%29)

## [Releases](https://github.com/vxCrypt0r/AMSI_VEH/releases)

No releases published

## [Packages\  0](https://github.com/users/vxCrypt0r/packages?repo_name=AMSI_VEH)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxCrypt0r/AMSI_VEH).

## Languages

- [C++94.1%](https://github.com/vxCrypt0r/AMSI_VEH/search?l=c%2B%2B)
- [C5.9%](https://github.com/vxCrypt0r/AMSI_VEH/search?l=c)

You can’t perform that action at this time.