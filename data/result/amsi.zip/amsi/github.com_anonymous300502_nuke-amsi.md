# https://github.com/anonymous300502/Nuke-AMSI/

[Skip to content](https://github.com/anonymous300502/Nuke-AMSI/#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/anonymous300502/Nuke-AMSI/) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/anonymous300502/Nuke-AMSI/) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/anonymous300502/Nuke-AMSI/) to refresh your session.Dismiss alert

{{ message }}

[anonymous300502](https://github.com/anonymous300502)/ **[Nuke-AMSI](https://github.com/anonymous300502/Nuke-AMSI)** Public

- [Notifications](https://github.com/login?return_to=%2Fanonymous300502%2FNuke-AMSI) You must be signed in to change notification settings
- [Fork\\
40](https://github.com/login?return_to=%2Fanonymous300502%2FNuke-AMSI)
- [Star\\
174](https://github.com/login?return_to=%2Fanonymous300502%2FNuke-AMSI)


NukeAMSI is a powerful tool designed to neutralize the Antimalware Scan Interface (AMSI) in Windows environments.


### License

[GPL-3.0 license](https://github.com/anonymous300502/Nuke-AMSI/blob/main/LICENSE)

[174\\
stars](https://github.com/anonymous300502/Nuke-AMSI/stargazers) [40\\
forks](https://github.com/anonymous300502/Nuke-AMSI/forks) [Branches](https://github.com/anonymous300502/Nuke-AMSI/branches) [Tags](https://github.com/anonymous300502/Nuke-AMSI/tags) [Activity](https://github.com/anonymous300502/Nuke-AMSI/activity)

[Star](https://github.com/login?return_to=%2Fanonymous300502%2FNuke-AMSI)

[Notifications](https://github.com/login?return_to=%2Fanonymous300502%2FNuke-AMSI) You must be signed in to change notification settings

# anonymous300502/Nuke-AMSI

main

[**1** Branch](https://github.com/anonymous300502/Nuke-AMSI/branches) [**0** Tags](https://github.com/anonymous300502/Nuke-AMSI/tags)

[Go to Branches page](https://github.com/anonymous300502/Nuke-AMSI/branches)[Go to Tags page](https://github.com/anonymous300502/Nuke-AMSI/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![anonymous300502](https://avatars.githubusercontent.com/u/68034448?v=4&size=40)](https://github.com/anonymous300502)[anonymous300502](https://github.com/anonymous300502/Nuke-AMSI/commits?author=anonymous300502)<br>[Update README.md](https://github.com/anonymous300502/Nuke-AMSI/commit/4a3c575c2d2eaaaec76095cc0c5737eb65d232b1)<br>2 months agoDec 19, 2025<br>[4a3c575](https://github.com/anonymous300502/Nuke-AMSI/commit/4a3c575c2d2eaaaec76095cc0c5737eb65d232b1) · 2 months agoDec 19, 2025<br>## History<br>[9 Commits](https://github.com/anonymous300502/Nuke-AMSI/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/anonymous300502/Nuke-AMSI/commits/main/) 9 Commits |
| [LICENSE](https://github.com/anonymous300502/Nuke-AMSI/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/anonymous300502/Nuke-AMSI/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/anonymous300502/Nuke-AMSI/commit/5bc54a2a99e008be17e0bc570b2a0297fdfc2c24 "Initial commit") | 2 years agoAug 11, 2024 |
| [NukeAMSI.ps1](https://github.com/anonymous300502/Nuke-AMSI/blob/main/NukeAMSI.ps1 "NukeAMSI.ps1") | [NukeAMSI.ps1](https://github.com/anonymous300502/Nuke-AMSI/blob/main/NukeAMSI.ps1 "NukeAMSI.ps1") | [Add files via upload](https://github.com/anonymous300502/Nuke-AMSI/commit/36aec703b80577231f5cc79743c6943fc8f92608 "Add files via upload") | 2 years agoAug 11, 2024 |
| [README.md](https://github.com/anonymous300502/Nuke-AMSI/blob/main/README.md "README.md") | [README.md](https://github.com/anonymous300502/Nuke-AMSI/blob/main/README.md "README.md") | [Update README.md](https://github.com/anonymous300502/Nuke-AMSI/commit/4a3c575c2d2eaaaec76095cc0c5737eb65d232b1 "Update README.md") | 2 months agoDec 19, 2025 |
| View all files |

## Repository files navigation

[![banner](https://camo.githubusercontent.com/9214c036110e8e3c81880c0a836be12f88469e650da8a39b8cc649fc9382f64d/68747470733a2f2f7331312e67696679752e636f6d2f696d616765732f53797353482e676966)](https://camo.githubusercontent.com/9214c036110e8e3c81880c0a836be12f88469e650da8a39b8cc649fc9382f64d/68747470733a2f2f7331312e67696679752e636f6d2f696d616765732f53797353482e676966)[![banner](https://camo.githubusercontent.com/9214c036110e8e3c81880c0a836be12f88469e650da8a39b8cc649fc9382f64d/68747470733a2f2f7331312e67696679752e636f6d2f696d616765732f53797353482e676966)](https://camo.githubusercontent.com/9214c036110e8e3c81880c0a836be12f88469e650da8a39b8cc649fc9382f64d/68747470733a2f2f7331312e67696679752e636f6d2f696d616765732f53797353482e676966)[Open in new window](https://camo.githubusercontent.com/9214c036110e8e3c81880c0a836be12f88469e650da8a39b8cc649fc9382f64d/68747470733a2f2f7331312e67696679752e636f6d2f696d616765732f53797353482e676966)

## Disclaimer

[Permalink: Disclaimer](https://github.com/anonymous300502/Nuke-AMSI/#disclaimer)

**Please note that this program is for educational purposes only** and should not be used for any malicious activities. The primary goal of this README is to explain the functionality of the program and provide information about the imported modules and functions used in the code.
The Developers will not be liable to any damage caused by the unethical use of this code.

Note: The current script is now being detected. In order to use it, please use some cryptor or obfuscator. Do not use on systems you don't have explicit permission to use on.

The AMSI Nuke Script is a PowerShell-based utility designed to modify the Anti-Malware Scan Interface (AMSI) in running PowerShell processes. This script exploits Windows API functions to alter the memory of the amsi.dll, effectively disabling its malware scanning capabilities. It serves as an educational tool for security researchers and penetration testers to understand AMSI's role in malware defense and the implications of circumventing such mechanisms.

#This version is now being flagged, contact for a obfuscated working version.

### Concepts utilized

[Permalink: Concepts utilized](https://github.com/anonymous300502/Nuke-AMSI/#concepts-utilized)

- Anti-Malware Scan Interface (AMSI) : The Windows Antimalware Scan Interface (AMSI) is a pivotal component in Microsoft’s security architecture, designed to enhance the detection of malicious scripts and behaviors by providing applications and services with a standardized interface to request content scans. As cyber threats evolve, so do the techniques employed by attackers to evade such defenses.




AMSI in action when it catches a malicious script being executed



[![Amsi in action](https://camo.githubusercontent.com/32abec0caacb7e124f2a637e07ce0fef1d4fc36e1a8dbf6e35b2aca952bcc4be/68747470733a2f2f73656e7365706f73742e636f6d2f696d672f70616765732f626c6f672f323032302f726573757272656374696e672d616e2d6f6c642d616d73692d6279706173732f322e302d616d73692d646574656374696f6e2d6578616d706c652e706e67)](https://camo.githubusercontent.com/32abec0caacb7e124f2a637e07ce0fef1d4fc36e1a8dbf6e35b2aca952bcc4be/68747470733a2f2f73656e7365706f73742e636f6d2f696d672f70616765732f626c6f672f323032302f726573757272656374696e672d616e2d6f6c642d616d73692d6279706173732f322e302d616d73692d646574656374696f6e2d6578616d706c652e706e67)

- Windows API Functions:
Utilized to manipulate process memory and load dynamic link libraries (NTDll.dll & Kernel32.dll).
Functions include NtOpenProcess, NtWriteVirtualMemory, VirtualProtectEx, and others.


### Key Features

[Permalink: Key Features](https://github.com/anonymous300502/Nuke-AMSI/#key-features)

- _Direct Memory Manipulation_: NukeAMSI utilizes direct memory manipulation techniques to disable AMSI, leveraging the ntdll library and other critical Windows APIs. This ensures that AMSI is effectively bypassed without raising alerts or triggering additional security measures.

- _Stealth Operations_: The tool operates in-memory, meaning it leaves no trace on disk. This makes it particularly useful in scenarios where maintaining operational security is paramount.


### Technical Breakdown

[Permalink: Technical Breakdown](https://github.com/anonymous300502/Nuke-AMSI/#technical-breakdown)

NukeAMSI uses several advanced techniques to achieve its goals:

- _Process Injection_: By injecting code into the memory space of the PowerShell process, NukeAMSI can alter the behavior of critical security functions.

- _Utilization of NTDLL_: The script makes use of ntdll, a core Windows library, to access low-level system functions. This allows NukeAMSI to manipulate the system's memory directly, making its operations more effective and harder to detect.

- _Advanced Error Handling_: NukeAMSI includes robust error handling to ensure smooth operation even in complex environments. It carefully checks for and handles potential failures, reducing the likelihood of detection or script failure.


### Usage Steps

[Permalink: Usage Steps](https://github.com/anonymous300502/Nuke-AMSI/#usage-steps)

1. First lets try running mimikatz in our powershell shell
[![mimikatz amsi trigger](https://private-user-images.githubusercontent.com/68034448/356866558-0003e944-34a8-477f-b900-fc6b67a3041f.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY1NTgtMDAwM2U5NDQtMzRhOC00NzdmLWI5MDAtZmM2YjY3YTMwNDFmLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTg1ZmNkNzgwY2E3ZDYyNGE4MDY0ZTA1ZjkwMGNmZGJlZjU3ZTNjOGIzNzkwZTc3NWVlNjBlMzY1YjJkMmVmMDkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.9B6AdK05jx3LFTHfUg_JGgEzxKjswUKquj-1fFm5NWI)](https://private-user-images.githubusercontent.com/68034448/356866558-0003e944-34a8-477f-b900-fc6b67a3041f.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY1NTgtMDAwM2U5NDQtMzRhOC00NzdmLWI5MDAtZmM2YjY3YTMwNDFmLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTg1ZmNkNzgwY2E3ZDYyNGE4MDY0ZTA1ZjkwMGNmZGJlZjU3ZTNjOGIzNzkwZTc3NWVlNjBlMzY1YjJkMmVmMDkmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.9B6AdK05jx3LFTHfUg_JGgEzxKjswUKquj-1fFm5NWI)
As we can see amsi Triggered.

2. Now, let's run our tool
You will be prompted to confirm your intent before the script proceeds to neutralize AMSI within the session.
[![Running nukeamsi](https://private-user-images.githubusercontent.com/68034448/356866676-ce380592-5b7f-4521-ac55-3b503eb1c62d.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY2NzYtY2UzODA1OTItNWI3Zi00NTIxLWFjNTUtM2I1MDNlYjFjNjJkLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWNiMTQwNDhlZjNiOTE0OGU0NzcxNmYyYjAyZWEyYWQwYmQ5Y2MzYWM5MjBmMTNkMjRjZjYxZDgxYmQzY2I1YjImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.DFUifop-4ohl35S5ZtekO2wLNf9S281ZA4vmKHelQ58)](https://private-user-images.githubusercontent.com/68034448/356866676-ce380592-5b7f-4521-ac55-3b503eb1c62d.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY2NzYtY2UzODA1OTItNWI3Zi00NTIxLWFjNTUtM2I1MDNlYjFjNjJkLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPWNiMTQwNDhlZjNiOTE0OGU0NzcxNmYyYjAyZWEyYWQwYmQ5Y2MzYWM5MjBmMTNkMjRjZjYxZDgxYmQzY2I1YjImWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.DFUifop-4ohl35S5ZtekO2wLNf9S281ZA4vmKHelQ58)

3. Now we can run mimikatz without worrying about windows defender bothering us.
[![nukeamsi2](https://private-user-images.githubusercontent.com/68034448/356866803-8bff87d5-797b-4a53-89ad-4a7978ec6833.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY4MDMtOGJmZjg3ZDUtNzk3Yi00YTUzLTg5YWQtNGE3OTc4ZWM2ODMzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTg3MDllMDcwNGE2ZTU2YWUwM2UxMjYzZGE4OTZiYzBkYWVjMDNkMjRhNjRmMzc4MWU1ZjhiMzFhNTdkMzRmZTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.6roG0kwc42LjiG1cjLxPJVR0cGJNV0X7WsexNVI3OOE)](https://private-user-images.githubusercontent.com/68034448/356866803-8bff87d5-797b-4a53-89ad-4a7978ec6833.png?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NzE0MTIwMzEsIm5iZiI6MTc3MTQxMTczMSwicGF0aCI6Ii82ODAzNDQ0OC8zNTY4NjY4MDMtOGJmZjg3ZDUtNzk3Yi00YTUzLTg5YWQtNGE3OTc4ZWM2ODMzLnBuZz9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNjAyMTglMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjYwMjE4VDEwNDg1MVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTg3MDllMDcwNGE2ZTU2YWUwM2UxMjYzZGE4OTZiYzBkYWVjMDNkMjRhNjRmMzc4MWU1ZjhiMzFhNTdkMzRmZTUmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.6roG0kwc42LjiG1cjLxPJVR0cGJNV0X7WsexNVI3OOE)


### Conclusion

[Permalink: Conclusion](https://github.com/anonymous300502/Nuke-AMSI/#conclusion)

NukeAMSI represents the cutting edge of AMSI bypass techniques, offering a powerful, reliable, and stealthy solution for professionals who need to execute scripts in environments where AMSI is active. Whether you're conducting penetration testing, research, or learning more about Windows security internals, NukeAMSI provides the tools you need to operate effectively and securely.

> Note: This tool is intended for \* _educational purposes only_. It should be used responsibly and in compliance with all relevant laws and regulations. Unauthorized use of this tool on systems you do not own or have explicit permission to test can result in severe legal consequences.

## About

NukeAMSI is a powerful tool designed to neutralize the Antimalware Scan Interface (AMSI) in Windows environments.


### Resources

[Readme](https://github.com/anonymous300502/Nuke-AMSI/#readme-ov-file)

### License

[GPL-3.0 license](https://github.com/anonymous300502/Nuke-AMSI/#GPL-3.0-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/anonymous300502/Nuke-AMSI/).

[Activity](https://github.com/anonymous300502/Nuke-AMSI/activity)

### Stars

[**174**\\
stars](https://github.com/anonymous300502/Nuke-AMSI/stargazers)

### Watchers

[**5**\\
watching](https://github.com/anonymous300502/Nuke-AMSI/watchers)

### Forks

[**40**\\
forks](https://github.com/anonymous300502/Nuke-AMSI/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fanonymous300502%2FNuke-AMSI&report=anonymous300502+%28user%29)

## [Releases](https://github.com/anonymous300502/Nuke-AMSI/releases)

No releases published

## [Packages\  0](https://github.com/users/anonymous300502/packages?repo_name=Nuke-AMSI)

No packages published

## Languages

- [PowerShell100.0%](https://github.com/anonymous300502/Nuke-AMSI/search?l=powershell)

You can’t perform that action at this time.