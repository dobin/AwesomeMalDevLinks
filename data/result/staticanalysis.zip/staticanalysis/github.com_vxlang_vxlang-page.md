# https://github.com/vxlang/vxlang-page

[Skip to content](https://github.com/vxlang/vxlang-page#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/vxlang/vxlang-page) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/vxlang/vxlang-page) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/vxlang/vxlang-page) to refresh your session.Dismiss alert

{{ message }}

[vxlang](https://github.com/vxlang)/ **[vxlang-page](https://github.com/vxlang/vxlang-page)** Public

- [Notifications](https://github.com/login?return_to=%2Fvxlang%2Fvxlang-page) You must be signed in to change notification settings
- [Fork\\
46](https://github.com/login?return_to=%2Fvxlang%2Fvxlang-page)
- [Star\\
678](https://github.com/login?return_to=%2Fvxlang%2Fvxlang-page)


protector & obfuscator & code virtualizer


[vxlang.github.io/](https://vxlang.github.io/ "https://vxlang.github.io/")

[678\\
stars](https://github.com/vxlang/vxlang-page/stargazers) [46\\
forks](https://github.com/vxlang/vxlang-page/forks) [Branches](https://github.com/vxlang/vxlang-page/branches) [Tags](https://github.com/vxlang/vxlang-page/tags) [Activity](https://github.com/vxlang/vxlang-page/activity)

[Star](https://github.com/login?return_to=%2Fvxlang%2Fvxlang-page)

[Notifications](https://github.com/login?return_to=%2Fvxlang%2Fvxlang-page) You must be signed in to change notification settings

# vxlang/vxlang-page

main

[**1** Branch](https://github.com/vxlang/vxlang-page/branches) [**3** Tags](https://github.com/vxlang/vxlang-page/tags)

[Go to Branches page](https://github.com/vxlang/vxlang-page/branches)[Go to Tags page](https://github.com/vxlang/vxlang-page/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![0a777h](https://avatars.githubusercontent.com/u/17895543?v=4&size=40)](https://github.com/0a777h)[0a777h](https://github.com/vxlang/vxlang-page/commits?author=0a777h)<br>[Update latest version to ver.2.3.0.0](https://github.com/vxlang/vxlang-page/commit/b5b19b69cb1d2934f4dfbc4f8b9763c68c5f7ed8)<br>4 days agoFeb 14, 2026<br>[b5b19b6](https://github.com/vxlang/vxlang-page/commit/b5b19b69cb1d2934f4dfbc4f8b9763c68c5f7ed8) · 4 days agoFeb 14, 2026<br>## History<br>[362 Commits](https://github.com/vxlang/vxlang-page/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/vxlang/vxlang-page/commits/main/) 362 Commits |
| [image](https://github.com/vxlang/vxlang-page/tree/main/image "image") | [image](https://github.com/vxlang/vxlang-page/tree/main/image "image") | [update](https://github.com/vxlang/vxlang-page/commit/94e5b2e106cc5a081e1162ccd78f21b6522fbb1d "update") | 8 months agoJul 3, 2025 |
| [src](https://github.com/vxlang/vxlang-page/tree/main/src "src") | [src](https://github.com/vxlang/vxlang-page/tree/main/src "src") | [update](https://github.com/vxlang/vxlang-page/commit/3d51e293aac5115728ea80c62b123d6147b0483b "update") | 2 weeks agoFeb 2, 2026 |
| [.gitignore](https://github.com/vxlang/vxlang-page/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/vxlang/vxlang-page/blob/main/.gitignore ".gitignore") | [first-commit](https://github.com/vxlang/vxlang-page/commit/a2089a7f1d962ab379fe8b1a7ad603f4cec2776e "first-commit") | 3 years agoOct 14, 2023 |
| [README.md](https://github.com/vxlang/vxlang-page/blob/main/README.md "README.md") | [README.md](https://github.com/vxlang/vxlang-page/blob/main/README.md "README.md") | [Update latest version to ver.2.3.0.0](https://github.com/vxlang/vxlang-page/commit/b5b19b69cb1d2934f4dfbc4f8b9763c68c5f7ed8 "Update latest version to ver.2.3.0.0") | 4 days agoFeb 14, 2026 |
| [special-thanks.md](https://github.com/vxlang/vxlang-page/blob/main/special-thanks.md "special-thanks.md") | [special-thanks.md](https://github.com/vxlang/vxlang-page/blob/main/special-thanks.md "special-thanks.md") | [Create special-thanks.md](https://github.com/vxlang/vxlang-page/commit/6a1f67b19ff733bc5f24547b3890a5eb777719c7 "Create special-thanks.md") | 2 years agoDec 20, 2024 |
| View all files |

## Repository files navigation

# VxLang

[Permalink: VxLang](https://github.com/vxlang/vxlang-page#vxlang)

[![](https://camo.githubusercontent.com/618bc08518b3ee1672a5f652b02e52cdde45b582dcbc18c7f51008e8adf59a96/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f56784c616e675f322e706e67)](https://vxlang.github.io/)

- Contents
  - [Docs](https://vxlang.github.io/)
    - [What is VxLang?](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#what-is-vxlang)
    - [Supported File Formats](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#supported-file-formats)
  - Preview
    - [Virtualization Preview](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#virtualization-preview)
    - [Dual-Mode Preview](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#dual-modeobfuscation--virtualization-preview)
    - [Obfuscation Preview](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#obfuscation-preview)
    - [Code-Flattening Preview](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#code-flattening-preview)
  - Tutorial
    - [Usage & Guide-Code](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#usage--guide-code)
    - [Precautions](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#precautions)
  - [How to get the full version](https://github.com/vxlang/vxlang-page/tree/main?tab=readme-ov-file#how-to-get-the-full-version)
  - Donate and Subscription
    - Patreon
      - [Link](https://www.patreon.com/c/vxlang/shop)
      - Event
        - [Year-End Discount Event for VxLang Long-Term Subscription Cards](https://www.patreon.com/c/vxlang/shop)
  - Extension-Codes and Plug-in modules.
    - Axion: Extension code that performs additional anti-tampering functions.
    - ExtsDN: Extension code for packing and protecting .NET (EXE only) modules.

* * *

## What is VxLang?

[Permalink: What is VxLang?](https://github.com/vxlang/vxlang-page#what-is-vxlang)

**VxLang** is a project designed to prevent reverse-engineering behaviors such as static or dynamic analysis, file tampering, and unauthorized access to memory by attackers.

The VxLang project currently targets x86-64 system and .NET binaries, native binary files for the Microsoft Windows operating system, including executables with the ".exe" extension, dynamic link library files with the ".dll" extension, and kernel driver files with the ".sys" extension. (The types of target binaries supported by vxlang will be expanded in future updates).

- Added beta code for the `ELF` file format.

  - The beta version only supports general `code-flattening`.
  - Beta features require users to specify target code.
  - VxLang recommends using the `-fno-pic` option in ELF 32bit binary builds.

## Supported File Formats

[Permalink: Supported File Formats](https://github.com/vxlang/vxlang-page#supported-file-formats)

|     |     |     |     |
| --- | --- | --- | --- |
| **Windows EXE/DLL** | **Windows Kernel Drive** |
| Obfuscator | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) | Obfuscator | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) |
| Virtualizer | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) | Virtualizer | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) |
| Protector | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) | Protector | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) |

|     |     |     |     |
| --- | --- | --- | --- |
| **Windows UEFI Modules** | **Windows .NET** |
| Obfuscator | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) | Obfuscator | [![](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667)](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667) |
| Virtualizer | [![](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667)](https://camo.githubusercontent.com/3bb870938282133a8d1398f95507527ec624fdf48f46d38b6fe61f4e4d1090e7/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f537570706f727465642d627269676874677265656e2e737667) | Virtualizer | [![](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667)](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667) |
| Protector | [![](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667)](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667) | Protector | [![](https://camo.githubusercontent.com/41bebd1a2816f127d0607da2ff285da9e1da484d35af5e580010de6228b61397/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f576f726b696e672d79656c6c6f772e737667)](https://camo.githubusercontent.com/41bebd1a2816f127d0607da2ff285da9e1da484d35af5e580010de6228b61397/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f576f726b696e672d79656c6c6f772e737667) |

|     |     |
| --- | --- |
| **Linux ELF** |
| Obfuscator | [![](https://camo.githubusercontent.com/12d0a94ccb66c04e3013e08bbce1ea1ab9360cb94b4514b45d51a1e5bc561bc0/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f424554412d627269676874677265656e2e737667)](https://camo.githubusercontent.com/12d0a94ccb66c04e3013e08bbce1ea1ab9360cb94b4514b45d51a1e5bc561bc0/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f424554412d627269676874677265656e2e737667) |
| Virtualizer | [![](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667)](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667) |
| Protector | [![](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667)](https://camo.githubusercontent.com/26801d3a54b8f7014b3e7defe9056eed02a2191dd6c4b6e3d8bae799c7f04f41/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5363686564756c65642d7265642e737667) |

## GUI

[Permalink: GUI](https://github.com/vxlang/vxlang-page#gui)

[![](https://github.com/vxlang/vxlang-page/raw/main/image/obs1.png?raw=true)](https://vxlang.github.io/)[![](https://github.com/vxlang/vxlang-page/raw/main/image/obs2.png?raw=true)](https://vxlang.github.io/)[![](https://github.com/vxlang/vxlang-page/raw/main/image/obs3.png?raw=true)](https://vxlang.github.io/)[![](https://github.com/vxlang/vxlang-page/raw/main/image/o3.png?raw=true)](https://vxlang.github.io/)[![](https://github.com/vxlang/vxlang-page/raw/main/image/o4.png?raw=true)](https://vxlang.github.io/)

## Virtualization Preview

[Permalink: Virtualization Preview](https://github.com/vxlang/vxlang-page#virtualization-preview)

```
; x86-64 asm
cmp         qword ptr [rsp + 0x20], rax
jae         0x140001bf5
mov         rax, qword ptr [rsp + 0x20]
movzx       eax, byte ptr [rsp + rax + 0x50]
```

```
; to v-asm
movi   exr_0, ${RANDOM}
movi   r7, ${RANDOM}
xorr   r7, exr_0
movi   exr_0, ${RANDOM}
movi   exr_1, ${RANDOM}
xorr   exr_0, exr_1
mulr   r7, exr_0
addr   r6, r7
movi   exr_0, ${RANDOM}
movi   r7, ${RANDOM}
xorr   r7, exr_0
addr   r6, r7
movr   r0, r6
movr   r1, rax
ldrr   r2, r0
cmpr   r2, r1
be     0x2c59
movr   r0, rax
movr   r6, rsp
movi   exr_0, ${RANDOM}
movi   r7, ${RANDOM}
xorr   r7, exr_0
movi   exr_0, ${RANDOM}
movi   exr_1, ${RANDOM}
xorr   exr_0, exr_1
mulr   r7, exr_0
addr   r6, r7
movi   exr_0, ${RANDOM}
movi   r7, ${RANDOM}
xorr   r7, exr_0
addr   r6, r7
movr   r1, r6
ldrr   r2, r1
movr   rax, r2
```

```
; compile
e7 f8 f1 e5 01 e1 a2 9a 22 87 c3 93 61 e5 06 e1
a2 9a 22 87 c3 93 61 eb 06 01 e6 01 e0 a2 9a 22
e6 0a e1 a2 9a 22 ec 01 0a d6 06 01 da 07 06 e5
01 e1 a2 9a 22 87 c3 93 61 e5 06 c1 a2 9a 22 87
c3 93 61 eb 06 01 da 07 06 e7 f7 f8 e7 fc e5 c6
00 08 a9 00 03 bb c6 01 00 00 e7 f7 e5 e7 f8 f1
e5 01 6d 86 d3 6d 7f 86 9d a2 e5 06 6d 86 d3 6d
7f 86 9d a2 eb 06 01 e6 01 6c 86 d3 6d e6 0a 6d
86 d3 6d ec 01 0a d6 06 01 da 07 06 e5 01 6d 86
d3 6d 7f 86 9d a2 e5 06 4d 86 d3 6d 7f 86 9d a2
```

Before

[![](https://camo.githubusercontent.com/fbfe2dbba734d6d1879331c5e8ad45439895705a2a86e0e7454b8b53d8669792/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f564d426567696e2e706e67)](https://camo.githubusercontent.com/fbfe2dbba734d6d1879331c5e8ad45439895705a2a86e0e7454b8b53d8669792/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f564d426567696e2e706e67)

After

[![](https://camo.githubusercontent.com/188e6d59057254df191652dd54e6c77cdffe88bfaee69ea1ead9de440307af65/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f564d456e642e706e67)](https://camo.githubusercontent.com/188e6d59057254df191652dd54e6c77cdffe88bfaee69ea1ead9de440307af65/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f564d456e642e706e67)

## Dual-Mode(Obfuscation + Virtualization) Preview

[Permalink: Dual-Mode(Obfuscation + Virtualization) Preview](https://github.com/vxlang/vxlang-page#dual-modeobfuscation--virtualization-preview)

## Obfuscation Preview

[Permalink: Obfuscation Preview](https://github.com/vxlang/vxlang-page#obfuscation-preview)

Preview

[![](https://camo.githubusercontent.com/f1f8064220fbb0eb64398c16f581c08d2c50bb2ab7f2fc10c1461b1e36257234/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6f62667573636174652d332e706e67)](https://camo.githubusercontent.com/f1f8064220fbb0eb64398c16f581c08d2c50bb2ab7f2fc10c1461b1e36257234/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6f62667573636174652d332e706e67)

## Code-Flattening Preview

[Permalink: Code-Flattening Preview](https://github.com/vxlang/vxlang-page#code-flattening-preview)

Before

[![](https://camo.githubusercontent.com/9d71d010fa133697681be1e0316c0ef3d98debdc1c726ff9d2b2011e4d8f7449/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6265662e504e47)](https://camo.githubusercontent.com/9d71d010fa133697681be1e0316c0ef3d98debdc1c726ff9d2b2011e4d8f7449/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6265662e504e47)

After

[![](https://camo.githubusercontent.com/8d108b372c5dd6ea5da8875f12f3aa812dc524277102d28b7fc0faa79d88b0ac/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6366662d312d312e706e67)](https://camo.githubusercontent.com/8d108b372c5dd6ea5da8875f12f3aa812dc524277102d28b7fc0faa79d88b0ac/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6366662d312d312e706e67) [![](https://camo.githubusercontent.com/cf18f6ea5ae5f8d743fddfa57f05103f7d153f34d665fd6b8c7f1f384804b78c/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6366675f312e706e67)](https://camo.githubusercontent.com/cf18f6ea5ae5f8d743fddfa57f05103f7d153f34d665fd6b8c7f1f384804b78c/68747470733a2f2f76786c616e672e6769746875622e696f2f696d6167652f6366675f312e706e67)

## How to get the full version

[Permalink: How to get the full version](https://github.com/vxlang/vxlang-page#how-to-get-the-full-version)

The full version of VxLang is developed and operated under donation through Patreon(or Boosty).

The exact usage of VxLang and sharing of extension module code, new features of VxLang, etc. will be shared.

If you have any questions, please send your request to the email below.

- E-Mail: [0x999h@gmail.com](mailto:0x999h@gmail.com)
- Full Version
  - You can control all features of the VxLang protector.
  - Support for virtual CPUs with specialized CPU contexts.
  - **You can use the demo version to see if it's applicable to your program before you commit to the donation and full versions.**
- [Patreon](https://www.patreon.com/vxlang)
  - [VxLang 2025 subscription](https://www.patreon.com/posts/vxlang-2025-1y-1-126040977)
  - [About Patreon subscriptions](https://www.patreon.com/posts/about-patreon-116564758)

## Usage & Guide-Code

[Permalink: Usage & Guide-Code](https://github.com/vxlang/vxlang-page#usage--guide-code)

- [Documentation](https://vxlang.github.io/documentation.html)
  - 01: [SDK Tutorial](https://github.com/vxlang/vxlang-page/tree/main/src/Example/01)
  - 02: [Functional Unit Obfuscation with Map Files](https://github.com/vxlang/vxlang-page/blob/main/src/Example/02/Readme.md)
  - 03: DLL loading checks
  - 04: Rust samples
  - 05: Review behavior speed
  - 06: [Process Anti-Dumping Test](https://github.com/vxlang/vxlang-page/tree/main/src/Example/06)
  - 09: [How to apply the SDK to UEFI](https://github.com/vxlang/vxlang-page/tree/main/src/Example/09)
  - 10: Command-Line Options
    - `--disable-core`: Disable the VxLang core.
    - `--use-multi-vm`: Enable multiple VxLang-VM.
    - `--use-signature`: Enable VM signatures to be searched.

## Latest Version & Update(News)

[Permalink: Latest Version & Update(News)](https://github.com/vxlang/vxlang-page#latest-version--updatenews)

- [Download](https://vxlang.github.io/pages/purchase/)
  - Full: ver.2.3.0.0
    - [Update Note](https://www.patreon.com/posts/vxlang-2-2-9-2-149413753)

* * *

## Special Thanks

[Permalink: Special Thanks](https://github.com/vxlang/vxlang-page#special-thanks)

- [Link](https://github.com/vxlang/vxlang-page/blob/main/special-thanks.md)

## About

protector & obfuscator & code virtualizer


[vxlang.github.io/](https://vxlang.github.io/ "https://vxlang.github.io/")

### Topics

[windows](https://github.com/topics/windows "Topic: windows") [security](https://github.com/topics/security "Topic: security") [packer](https://github.com/topics/packer "Topic: packer") [dotnet](https://github.com/topics/dotnet "Topic: dotnet") [kernel-module](https://github.com/topics/kernel-module "Topic: kernel-module") [virtual-machine](https://github.com/topics/virtual-machine "Topic: virtual-machine") [x86-64](https://github.com/topics/x86-64 "Topic: x86-64") [reverse-engineering](https://github.com/topics/reverse-engineering "Topic: reverse-engineering") [virtualization](https://github.com/topics/virtualization "Topic: virtualization") [obfuscator](https://github.com/topics/obfuscator "Topic: obfuscator") [x86](https://github.com/topics/x86 "Topic: x86") [kernel-driver](https://github.com/topics/kernel-driver "Topic: kernel-driver") [protector](https://github.com/topics/protector "Topic: protector") [virtualizer](https://github.com/topics/virtualizer "Topic: virtualizer") [vmprotect](https://github.com/topics/vmprotect "Topic: vmprotect") [anti-tamper](https://github.com/topics/anti-tamper "Topic: anti-tamper") [themida](https://github.com/topics/themida "Topic: themida") [code-virtualizer](https://github.com/topics/code-virtualizer "Topic: code-virtualizer")

### Resources

[Readme](https://github.com/vxlang/vxlang-page#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxlang/vxlang-page).

[Activity](https://github.com/vxlang/vxlang-page/activity)

[Custom properties](https://github.com/vxlang/vxlang-page/custom-properties)

### Stars

[**678**\\
stars](https://github.com/vxlang/vxlang-page/stargazers)

### Watchers

[**14**\\
watching](https://github.com/vxlang/vxlang-page/watchers)

### Forks

[**46**\\
forks](https://github.com/vxlang/vxlang-page/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fvxlang%2Fvxlang-page&report=vxlang+%28user%29)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxlang/vxlang-page).

## [Contributors\  2](https://github.com/vxlang/vxlang-page/graphs/contributors)

- [![@0a777h](https://avatars.githubusercontent.com/u/17895543?s=64&v=4)](https://github.com/0a777h)[**0a777h** 0x777h](https://github.com/0a777h)
- [![@brunph](https://avatars.githubusercontent.com/u/48178956?s=64&v=4)](https://github.com/brunph)[**brunph**](https://github.com/brunph)

## Languages

- [C++59.7%](https://github.com/vxlang/vxlang-page/search?l=c%2B%2B)
- [C25.0%](https://github.com/vxlang/vxlang-page/search?l=c)
- [Go6.4%](https://github.com/vxlang/vxlang-page/search?l=go)
- [Rust4.8%](https://github.com/vxlang/vxlang-page/search?l=rust)
- [Assembly2.7%](https://github.com/vxlang/vxlang-page/search?l=assembly)
- [Batchfile1.4%](https://github.com/vxlang/vxlang-page/search?l=batchfile)

You can’t perform that action at this time.