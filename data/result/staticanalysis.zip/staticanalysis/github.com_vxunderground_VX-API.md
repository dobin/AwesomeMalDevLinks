# https://github.com/vxunderground/VX-API

[Skip to content](https://github.com/vxunderground/VX-API#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/vxunderground/VX-API) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/vxunderground/VX-API) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/vxunderground/VX-API) to refresh your session.Dismiss alert

{{ message }}

[vxunderground](https://github.com/vxunderground)/ **[VX-API](https://github.com/vxunderground/VX-API)** Public

- [Notifications](https://github.com/login?return_to=%2Fvxunderground%2FVX-API) You must be signed in to change notification settings
- [Fork\\
312](https://github.com/login?return_to=%2Fvxunderground%2FVX-API)
- [Star\\
1.8k](https://github.com/login?return_to=%2Fvxunderground%2FVX-API)


Collection of various malicious functionality to aid in malware development


[twitter.com/vxunderground](https://twitter.com/vxunderground "https://twitter.com/vxunderground")

### License

[MIT license](https://github.com/vxunderground/VX-API/blob/main/LICENSE)

[1.8k\\
stars](https://github.com/vxunderground/VX-API/stargazers) [312\\
forks](https://github.com/vxunderground/VX-API/forks) [Branches](https://github.com/vxunderground/VX-API/branches) [Tags](https://github.com/vxunderground/VX-API/tags) [Activity](https://github.com/vxunderground/VX-API/activity)

[Star](https://github.com/login?return_to=%2Fvxunderground%2FVX-API)

[Notifications](https://github.com/login?return_to=%2Fvxunderground%2FVX-API) You must be signed in to change notification settings

# vxunderground/VX-API

main

[**1** Branch](https://github.com/vxunderground/VX-API/branches) [**0** Tags](https://github.com/vxunderground/VX-API/tags)

[Go to Branches page](https://github.com/vxunderground/VX-API/branches)[Go to Tags page](https://github.com/vxunderground/VX-API/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![vxunderground](https://avatars.githubusercontent.com/u/57078196?v=4&size=40)](https://github.com/vxunderground)[vxunderground](https://github.com/vxunderground/VX-API/commits?author=vxunderground)<br>[2.01.015](https://github.com/vxunderground/VX-API/commit/69e5232de6474a7e698619fe7760dc0e3c292258)<br>Open commit details<br>3 years agoApr 24, 2023<br>[69e5232](https://github.com/vxunderground/VX-API/commit/69e5232de6474a7e698619fe7760dc0e3c292258) · 3 years agoApr 24, 2023<br>## History<br>[321 Commits](https://github.com/vxunderground/VX-API/commits/main/) <br>Open commit details<br>[View commit history for this file.](https://github.com/vxunderground/VX-API/commits/main/) 321 Commits |
| [Process Injection Testing Applications](https://github.com/vxunderground/VX-API/tree/main/Process%20Injection%20Testing%20Applications "Process Injection Testing Applications") | [Process Injection Testing Applications](https://github.com/vxunderground/VX-API/tree/main/Process%20Injection%20Testing%20Applications "Process Injection Testing Applications") | [2.0.505](https://github.com/vxunderground/VX-API/commit/bd5aba026d16039f0c0874e7040bcff717238ea3 "2.0.505  2.0.505") | 4 years agoDec 19, 2022 |
| [VX-API](https://github.com/vxunderground/VX-API/tree/main/VX-API "VX-API") | [VX-API](https://github.com/vxunderground/VX-API/tree/main/VX-API "VX-API") | [2.01.015](https://github.com/vxunderground/VX-API/commit/69e5232de6474a7e698619fe7760dc0e3c292258 "2.01.015  2.01.015") | 3 years agoApr 24, 2023 |
| [.gitignore](https://github.com/vxunderground/VX-API/blob/main/.gitignore ".gitignore") | [.gitignore](https://github.com/vxunderground/VX-API/blob/main/.gitignore ".gitignore") | [2.0.521](https://github.com/vxunderground/VX-API/commit/0f0f9aab4cad1a1e521cdbd7f4196fd2d586515e "2.0.521  2.0.521") | 4 years agoDec 21, 2022 |
| [LICENSE](https://github.com/vxunderground/VX-API/blob/main/LICENSE "LICENSE") | [LICENSE](https://github.com/vxunderground/VX-API/blob/main/LICENSE "LICENSE") | [Initial commit](https://github.com/vxunderground/VX-API/commit/8d85e75cc02bb026598c91145b3152d5cba0514f "Initial commit") | 4 years agoJun 14, 2022 |
| [README.md](https://github.com/vxunderground/VX-API/blob/main/README.md "README.md") | [README.md](https://github.com/vxunderground/VX-API/blob/main/README.md "README.md") | [2.01.015](https://github.com/vxunderground/VX-API/commit/69e5232de6474a7e698619fe7760dc0e3c292258 "2.01.015  2.01.015") | 3 years agoApr 24, 2023 |
| [VX-API.sln](https://github.com/vxunderground/VX-API/blob/main/VX-API.sln "VX-API.sln") | [VX-API.sln](https://github.com/vxunderground/VX-API/blob/main/VX-API.sln "VX-API.sln") | [2.0.505](https://github.com/vxunderground/VX-API/commit/bd5aba026d16039f0c0874e7040bcff717238ea3 "2.0.505  2.0.505") | 4 years agoDec 19, 2022 |
| [logo.png](https://github.com/vxunderground/VX-API/blob/main/logo.png "logo.png") | [logo.png](https://github.com/vxunderground/VX-API/blob/main/logo.png "logo.png") | [Add files via upload](https://github.com/vxunderground/VX-API/commit/6e69353b4c4fbc1d7b6784db349152f0dae3097a "Add files via upload") | 4 years agoJul 15, 2022 |
| View all files |

## Repository files navigation

[![VXUG logo](https://github.com/vxunderground/VX-API/raw/main/logo.png)](https://github.com/vxunderground/VX-API/blob/main/logo.png)
managed by [vx-underground](https://vx-underground.org/) \| follow us on [Twitter](https://twitter.com/vxunderground) \| download malware samples at the [VXUG/samples](https://samples.vx-underground.org/) page

# VX-API

[Permalink: VX-API](https://github.com/vxunderground/VX-API#vx-api)

Version: 2.01.015

Developer: smelly\_\_vx

The VX-API is a collection of malicious functionality to aid in malware development. It is recommended you clone and/or download this entire repo then open the Visual Studio solution file to easily explore functionality and concepts.

Some functions may be dependent on other functions present within the solution file. Using the solution file provided here will make it easier to identify which other functionality and/or header data is required.

You're free to use this in any manner you please. You do not need to use this entire solution for your malware proof-of-concepts or Red Team engagements. Strip, copy, paste, delete, or edit this projects contents as much as you'd like.

# List of features

[Permalink: List of features](https://github.com/vxunderground/VX-API#list-of-features)

## Anti-debug

[Permalink: Anti-debug](https://github.com/vxunderground/VX-API#anti-debug)

| Function Name | Original Author |
| --- | --- |
| AdfCloseHandleOnInvalidAddress | Checkpoint Research |
| AdfIsCreateProcessDebugEventCodeSet | Checkpoint Research |
| AdfOpenProcessOnCsrss | Checkpoint Research |
| CheckRemoteDebuggerPresent2 | ReactOS |
| IsDebuggerPresentEx | smelly\_\_vx |
| IsIntelHardwareBreakpointPresent | Checkpoint Research |

## Cryptography Related

[Permalink: Cryptography Related](https://github.com/vxunderground/VX-API#cryptography-related)

| Function Name | Original Author |
| --- | --- |
| HashStringDjb2 | Dan Bernstein |
| HashStringFowlerNollVoVariant1a | Glenn Fowler, Landon Curt Noll, and Kiem-Phong Vo |
| HashStringJenkinsOneAtATime32Bit | Bob Jenkins |
| HashStringLoseLose | Brian Kernighan and Dennis Ritchie |
| HashStringRotr32 | T. Oshiba (1972) |
| HashStringSdbm | Ozan Yigit |
| HashStringSuperFastHash | Paul Hsieh |
| HashStringUnknownGenericHash1A | Unknown |
| HashStringSipHash | RistBS |
| HashStringMurmur | RistBS |
| CreateMd5HashFromFilePath | Microsoft |
| CreatePseudoRandomInteger | Apple (c) 1999 |
| CreatePseudoRandomString | smelly\_\_vx |
| HashFileByMsiFileHashTable | smelly\_\_vx |
| CreatePseudoRandomIntegerFromNtdll | smelly\_\_vx |
| LzMaximumCompressBuffer | smelly\_\_vx |
| LzMaximumDecompressBuffer | smelly\_\_vx |
| LzStandardCompressBuffer | smelly\_\_vx |
| LzStandardDecompressBuffer | smelly\_\_vx |
| XpressHuffMaximumCompressBuffer | smelly\_\_vx |
| XpressHuffMaximumDecompressBuffer | smelly\_\_vx |
| XpressHuffStandardCompressBuffer | smelly\_\_vx |
| XpressHuffStandardDecompressBuffer | smelly\_\_vx |
| XpressMaximumCompressBuffer | smelly\_\_vx |
| XpressMaximumDecompressBuffer | smelly\_\_vx |
| XpressStandardCompressBuffer | smelly\_\_vx |
| XpressStandardDecompressBuffer | smelly\_\_vx |
| ExtractFilesFromCabIntoTarget | smelly\_\_vx |

## Error Handling

[Permalink: Error Handling](https://github.com/vxunderground/VX-API#error-handling)

| Function Name | Original Author |
| --- | --- |
| GetLastErrorFromTeb | smelly\_\_vx |
| GetLastNtStatusFromTeb | smelly\_\_vx |
| RtlNtStatusToDosErrorViaImport | ReactOS |
| GetLastErrorFromTeb | smelly\_\_vx |
| SetLastErrorInTeb | smelly\_\_vx |
| SetLastNtStatusInTeb | smelly\_\_vx |
| Win32FromHResult | Raymond Chen |

## Evasion

[Permalink: Evasion](https://github.com/vxunderground/VX-API#evasion)

| Function Name | Original Author |
| --- | --- |
| AmsiBypassViaPatternScan | ZeroMemoryEx |
| DelayedExecutionExecuteOnDisplayOff | am0nsec and smelly\_\_vx |
| HookEngineRestoreHeapFree | rad9800 |
| MasqueradePebAsExplorer | smelly\_\_vx |
| RemoveDllFromPeb | rad9800 |
| RemoveRegisterDllNotification | Rad98, Peter Winter-Smith |
| SleepObfuscationViaVirtualProtect | 5pider |
| RtlSetBaseUnicodeCommandLine | TheWover |

## Fingerprinting

[Permalink: Fingerprinting](https://github.com/vxunderground/VX-API#fingerprinting)

| Function Name | Original Author |
| --- | --- |
| GetCurrentLocaleFromTeb | 3xp0rt |
| GetNumberOfLinkedDlls | smelly\_\_vx |
| GetOsBuildNumberFromPeb | smelly\_\_vx |
| GetOsMajorVersionFromPeb | smelly\_\_vx |
| GetOsMinorVersionFromPeb | smelly\_\_vx |
| GetOsPlatformIdFromPeb | smelly\_\_vx |
| IsNvidiaGraphicsCardPresent | smelly\_\_vx |
| IsProcessRunning | smelly\_\_vx |
| IsProcessRunningAsAdmin | Vimal Shekar |
| GetPidFromNtQuerySystemInformation | smelly\_\_vx |
| GetPidFromWindowsTerminalService | modexp |
| GetPidFromWmiComInterface | aalimian and modexp |
| GetPidFromEnumProcesses | smelly\_\_vx |
| GetPidFromPidBruteForcing | modexp |
| GetPidFromNtQueryFileInformation | modexp, Lloyd Davies, Jonas Lyk |
| GetPidFromPidBruteForcingExW | smelly\_\_vx, LLoyd Davies, Jonas Lyk, modexp |

## Helper Functions

[Permalink: Helper Functions](https://github.com/vxunderground/VX-API#helper-functions)

| Function Name | Original Author |
| --- | --- |
| CreateLocalAppDataObjectPath | smelly\_\_vx |
| CreateWindowsObjectPath | smelly\_\_vx |
| GetCurrentDirectoryFromUserProcessParameters | smelly\_\_vx |
| GetCurrentProcessIdFromTeb | ReactOS |
| GetCurrentUserSid | Giovanni Dicanio |
| GetCurrentWindowTextFromUserProcessParameter | smelly\_\_vx |
| GetFileSizeFromPath | smelly\_\_vx |
| GetProcessHeapFromTeb | smelly\_\_vx |
| GetProcessPathFromLoaderLoadModule | smelly\_\_vx |
| GetProcessPathFromUserProcessParameters | smelly\_\_vx |
| GetSystemWindowsDirectory | Geoff Chappell |
| IsPathValid | smelly\_\_vx |
| RecursiveFindFile | Luke |
| SetProcessPrivilegeToken | Microsoft |
| IsDllLoaded | smelly\_\_vx |
| TryLoadDllMultiMethod | smelly\_\_vx |
| CreateThreadAndWaitForCompletion | smelly\_\_vx |
| GetProcessBinaryNameFromHwndW | smelly\_\_vx |
| GetByteArrayFromFile | smelly\_\_vx |
| Ex\_GetHandleOnDeviceHttpCommunication | x86matthew |
| IsRegistryKeyValid | smelly\_\_vx |
| FastcallExecuteBinaryShellExecuteEx | smelly\_\_vx |
| GetCurrentProcessIdFromOffset | RistBS |
| GetPeBaseAddress | smelly\_\_vx |
| LdrLoadGetProcedureAddress | c5pider |
| IsPeSection | smelly\_\_vx |
| AddSectionToPeFile | smelly\_\_vx |
| WriteDataToPeSection | smelly\_\_vx |
| GetPeSectionSizeInByte | smelly\_\_vx |
| ReadDataFromPeSection | smelly\_\_vx |
| GetCurrentProcessNoForward | ReactOS |
| GetCurrentThreadNoForward | ReactOS |

## Library Loading

[Permalink: Library Loading](https://github.com/vxunderground/VX-API#library-loading)

| Function Name | Original Author |
| --- | --- |
| GetKUserSharedData | Geoff Chappell |
| GetModuleHandleEx2 | smelly\_\_vx |
| GetPeb | 29a |
| GetPebFromTeb | ReactOS |
| GetProcAddress | 29a Volume 2, c5pider |
| GetProcAddressDjb2 | smelly\_\_vx |
| GetProcAddressFowlerNollVoVariant1a | smelly\_\_vx |
| GetProcAddressJenkinsOneAtATime32Bit | smelly\_\_vx |
| GetProcAddressLoseLose | smelly\_\_vx |
| GetProcAddressRotr32 | smelly\_\_vx |
| GetProcAddressSdbm | smelly\_\_vx |
| GetProcAddressSuperFastHash | smelly\_\_vx |
| GetProcAddressUnknownGenericHash1 | smelly\_\_vx |
| GetProcAddressSipHash | RistBS |
| GetProcAddressMurmur | RistBS |
| GetRtlUserProcessParameters | ReactOS |
| GetTeb | ReactOS |
| RtlLoadPeHeaders | smelly\_\_vx |
| ProxyWorkItemLoadLibrary | Rad98, Peter Winter-Smith |
| ProxyRegisterWaitLoadLibrary | Rad98, Peter Winter-Smith |

## Lsass Dumping

[Permalink: Lsass Dumping](https://github.com/vxunderground/VX-API#lsass-dumping)

| Function Name | Original Author |
| --- | --- |
| MpfGetLsaPidFromServiceManager | modexp |
| MpfGetLsaPidFromRegistry | modexp |
| MpfGetLsaPidFromNamedPipe | modexp |

## Network Connectivity

[Permalink: Network Connectivity](https://github.com/vxunderground/VX-API#network-connectivity)

| Function Name | Original Author |
| --- | --- |
| UrlDownloadToFileSynchronous | Hans Passant |
| ConvertIPv4IpAddressStructureToString | smelly\_\_vx |
| ConvertIPv4StringToUnsignedLong | smelly\_\_vx |
| SendIcmpEchoMessageToIPv4Host | smelly\_\_vx |
| ConvertIPv4IpAddressUnsignedLongToString | smelly\_\_vx |
| DnsGetDomainNameIPv4AddressAsString | smelly\_\_vx |
| DnsGetDomainNameIPv4AddressUnsignedLong | smelly\_\_vx |
| GetDomainNameFromUnsignedLongIPV4Address | smelly\_\_vx |
| GetDomainNameFromIPV4AddressAsString | smelly\_\_vx |

## Other

[Permalink: Other](https://github.com/vxunderground/VX-API#other)

| Function Name | Original Author |
| --- | --- |
| OleGetClipboardData | Microsoft |
| MpfComVssDeleteShadowVolumeBackups | am0nsec |
| MpfComModifyShortcutTarget | Unknown |
| MpfComMonitorChromeSessionOnce | smelly\_\_vx |
| MpfExtractMaliciousPayloadFromZipFileNoPassword | Codu |

## Process Creation

[Permalink: Process Creation](https://github.com/vxunderground/VX-API#process-creation)

| Function Name | Original Author |
| --- | --- |
| CreateProcessFromIHxHelpPaneServer | James Forshaw |
| CreateProcessFromIHxInteractiveUser | James Forshaw |
| CreateProcessFromIShellDispatchInvoke | Mohamed Fakroud |
| CreateProcessFromShellExecuteInExplorerProcess | Microsoft |
| CreateProcessViaNtCreateUserProcess | CaptMeelo |
| CreateProcessWithCfGuard | smelly\_\_vx and Adam Chester |
| CreateProcessByWindowsRHotKey | smelly\_\_vx |
| CreateProcessByWindowsRHotKeyEx | smelly\_\_vx |
| CreateProcessFromINFSectionInstallStringNoCab | smelly\_\_vx |
| CreateProcessFromINFSetupCommand | smelly\_\_vx |
| CreateProcessFromINFSectionInstallStringNoCab2 | smelly\_\_vx |
| CreateProcessFromIeFrameOpenUrl | smelly\_\_vx |
| CreateProcessFromPcwUtil | smelly\_\_vx |
| CreateProcessFromShdocVwOpenUrl | smelly\_\_vx |
| CreateProcessFromShell32ShellExecRun | smelly\_\_vx |
| MpfExecute64bitPeBinaryInMemoryFromByteArrayNoReloc | aaaddress1 |
| CreateProcessFromWmiWin32\_ProcessW | CIA |
| CreateProcessFromZipfldrRouteCall | smelly\_\_vx |
| CreateProcessFromUrlFileProtocolHandler | smelly\_\_vx |
| CreateProcessFromUrlOpenUrl | smelly\_\_vx |
| CreateProcessFromMsHTMLW | smelly\_\_vx |

## Process Injection

[Permalink: Process Injection](https://github.com/vxunderground/VX-API#process-injection)

| Function Name | Original Author |
| --- | --- |
| MpfPiControlInjection | SafeBreach Labs |
| MpfPiQueueUserAPCViaAtomBomb | SafeBreach Labs |
| MpfPiWriteProcessMemoryCreateRemoteThread | SafeBreach Labs |
| MpfProcessInjectionViaProcessReflection | Deep Instinct |

## Proxied Functions

[Permalink: Proxied Functions](https://github.com/vxunderground/VX-API#proxied-functions)

| Function Name | Original Author |
| --- | --- |
| IeCreateFile | smelly\_\_vx |
| CopyFileViaSetupCopyFile | smelly\_\_vx |
| CreateFileFromDsCopyFromSharedFile | Jonas Lyk |
| DeleteDirectoryAndSubDataViaDelNode | smelly\_\_vx |
| DeleteFileWithCreateFileFlag | smelly\_\_vx |
| IsProcessRunningAsAdmin2 | smelly\_\_vx |
| IeCreateDirectory | smelly\_\_vx |
| IeDeleteFile | smelly\_\_vx |
| IeFindFirstFile | smelly\_\_vx |
| IEGetFileAttributesEx | smelly\_\_vx |
| IeMoveFileEx | smelly\_\_vx |
| IeRemoveDirectory | smelly\_\_vx |

## Shellcode Execution

[Permalink: Shellcode Execution](https://github.com/vxunderground/VX-API#shellcode-execution)

| Function Name | Original Author |
| --- | --- |
| MpfSceViaImmEnumInputContext | alfarom256, aahmad097 |
| MpfSceViaCertFindChainInStore | alfarom256, aahmad097 |
| MpfSceViaEnumPropsExW | alfarom256, aahmad097 |
| MpfSceViaCreateThreadpoolWait | alfarom256, aahmad097 |
| MpfSceViaCryptEnumOIDInfo | alfarom256, aahmad097 |
| MpfSceViaDSA\_EnumCallback | alfarom256, aahmad097 |
| MpfSceViaCreateTimerQueueTimer | alfarom256, aahmad097 |
| MpfSceViaEvtSubscribe | alfarom256, aahmad097 |
| MpfSceViaFlsAlloc | alfarom256, aahmad097 |
| MpfSceViaInitOnceExecuteOnce | alfarom256, aahmad097 |
| MpfSceViaEnumChildWindows | alfarom256, aahmad097, wra7h |
| MpfSceViaCDefFolderMenu\_Create2 | alfarom256, aahmad097, wra7h |
| MpfSceViaCertEnumSystemStore | alfarom256, aahmad097, wra7h |
| MpfSceViaCertEnumSystemStoreLocation | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumDateFormatsW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumDesktopWindows | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumDesktopsW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumDirTreeW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumDisplayMonitors | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumFontFamiliesExW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumFontsW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumLanguageGroupLocalesW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumObjects | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumResourceTypesExW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumSystemCodePagesW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumSystemGeoID | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumSystemLanguageGroupsW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumSystemLocalesEx | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumThreadWindows | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumTimeFormatsEx | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumUILanguagesW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumWindowStationsW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumWindows | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumerateLoadedModules64 | alfarom256, aahmad097, wra7h |
| MpfSceViaK32EnumPageFilesW | alfarom256, aahmad097, wra7h |
| MpfSceViaEnumPwrSchemes | alfarom256, aahmad097, wra7h |
| MpfSceViaMessageBoxIndirectW | alfarom256, aahmad097, wra7h |
| MpfSceViaChooseColorW | alfarom256, aahmad097, wra7h |
| MpfSceViaClusWorkerCreate | alfarom256, aahmad097, wra7h |
| MpfSceViaSymEnumProcesses | alfarom256, aahmad097, wra7h |
| MpfSceViaImageGetDigestStream | alfarom256, aahmad097, wra7h |
| MpfSceViaVerifierEnumerateResource | alfarom256, aahmad097, wra7h |
| MpfSceViaSymEnumSourceFiles | alfarom256, aahmad097, wra7h |

## String Manipulation

[Permalink: String Manipulation](https://github.com/vxunderground/VX-API#string-manipulation)

| Function Name | Original Author |
| --- | --- |
| ByteArrayToCharArray | smelly\_\_vx |
| CharArrayToByteArray | smelly\_\_vx |
| ShlwapiCharStringToWCharString | smelly\_\_vx |
| ShlwapiWCharStringToCharString | smelly\_\_vx |
| CharStringToWCharString | smelly\_\_vx |
| WCharStringToCharString | smelly\_\_vx |
| RtlInitEmptyUnicodeString | ReactOS |
| RtlInitUnicodeString | ReactOS |
| CaplockString | simonc |
| CopyMemoryEx | ReactOS |
| SecureStringCopy | Apple (c) 1999 |
| StringCompare | Apple (c) 1999 |
| StringConcat | Apple (c) 1999 |
| StringCopy | Apple (c) 1999 |
| StringFindSubstring | Apple (c) 1999 |
| StringLength | Apple (c) 1999 |
| StringLocateChar | Apple (c) 1999 |
| StringRemoveSubstring | smelly\_\_vx |
| StringTerminateStringAtChar | smelly\_\_vx |
| StringToken | Apple (c) 1999 |
| ZeroMemoryEx | ReactOS |
| ConvertCharacterStringToIntegerUsingNtdll | smelly\_\_vx |
| MemoryFindMemory | KamilCuk |

## UAC Bypass

[Permalink: UAC Bypass](https://github.com/vxunderground/VX-API#uac-bypass)

| Function Name | Original Author |
| --- | --- |
| UacBypassFodHelperMethod | winscripting.blog |

## Rad98 Hooking Engine

[Permalink: Rad98 Hooking Engine](https://github.com/vxunderground/VX-API#rad98-hooking-engine)

| Function Name | Original Author |
| --- | --- |
| InitHardwareBreakpointEngine | rad98 |
| ShutdownHardwareBreakpointEngine | rad98 |
| ExceptionHandlerCallbackRoutine | rad98 |
| SetHardwareBreakpoint | rad98 |
| InsertDescriptorEntry | rad98 |
| RemoveDescriptorEntry | rad98 |
| SnapshotInsertHardwareBreakpointHookIntoTargetThread | rad98 |

## Generic Shellcode

[Permalink: Generic Shellcode](https://github.com/vxunderground/VX-API#generic-shellcode)

| Function Name | Original Author |
| --- | --- |
| GenericShellcodeHelloWorldMessageBoxA | SafeBreach Labs |
| GenericShellcodeHelloWorldMessageBoxAEbFbLoop | SafeBreach Labs |
| GenericShellcodeOpenCalcExitThread | MsfVenom |

## About

Collection of various malicious functionality to aid in malware development


[twitter.com/vxunderground](https://twitter.com/vxunderground "https://twitter.com/vxunderground")

### Topics

[malware](https://github.com/topics/malware "Topic: malware") [malware-research](https://github.com/topics/malware-research "Topic: malware-research") [malware-development](https://github.com/topics/malware-development "Topic: malware-development")

### Resources

[Readme](https://github.com/vxunderground/VX-API#readme-ov-file)

### License

[MIT license](https://github.com/vxunderground/VX-API#MIT-1-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxunderground/VX-API).

[Activity](https://github.com/vxunderground/VX-API/activity)

### Stars

[**1.8k**\\
stars](https://github.com/vxunderground/VX-API/stargazers)

### Watchers

[**49**\\
watching](https://github.com/vxunderground/VX-API/watchers)

### Forks

[**312**\\
forks](https://github.com/vxunderground/VX-API/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fvxunderground%2FVX-API&report=vxunderground+%28user%29)

## [Releases](https://github.com/vxunderground/VX-API/releases)

No releases published

## [Packages\  0](https://github.com/users/vxunderground/packages?repo_name=VX-API)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/vxunderground/VX-API).

## [Contributors\  9](https://github.com/vxunderground/VX-API/graphs/contributors)

- [![@vxunderground](https://avatars.githubusercontent.com/u/57078196?s=64&v=4)](https://github.com/vxunderground)
- [![@RistBS](https://avatars.githubusercontent.com/u/75935486?s=64&v=4)](https://github.com/RistBS)
- [![@rad9800](https://avatars.githubusercontent.com/u/105589633?s=64&v=4)](https://github.com/rad9800)
- [![@jabra-](https://avatars.githubusercontent.com/u/585965?s=64&v=4)](https://github.com/jabra-)
- [![@aimarket](https://avatars.githubusercontent.com/u/32007930?s=64&v=4)](https://github.com/aimarket)
- [![@NUL0x4C](https://avatars.githubusercontent.com/u/111295429?s=64&v=4)](https://github.com/NUL0x4C)
- [![@mekhalleh](https://avatars.githubusercontent.com/u/5225129?s=64&v=4)](https://github.com/mekhalleh)
- [![@ZeroMemoryEx](https://avatars.githubusercontent.com/u/60795188?s=64&v=4)](https://github.com/ZeroMemoryEx)
- [![@3xp0rt](https://avatars.githubusercontent.com/u/61662492?s=64&v=4)](https://github.com/3xp0rt)

## Languages

- [C++82.1%](https://github.com/vxunderground/VX-API/search?l=c%2B%2B)
- [C17.9%](https://github.com/vxunderground/VX-API/search?l=c)

You can’t perform that action at this time.