# https://github.com/weak1337/Alcatraz

[Skip to content](https://github.com/weak1337/Alcatraz#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/weak1337/Alcatraz) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/weak1337/Alcatraz) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/weak1337/Alcatraz) to refresh your session.Dismiss alert

{{ message }}

[weak1337](https://github.com/weak1337)/ **[Alcatraz](https://github.com/weak1337/Alcatraz)** Public

- [Notifications](https://github.com/login?return_to=%2Fweak1337%2FAlcatraz) You must be signed in to change notification settings
- [Fork\\
270](https://github.com/login?return_to=%2Fweak1337%2FAlcatraz)
- [Star\\
2k](https://github.com/login?return_to=%2Fweak1337%2FAlcatraz)


x64 binary obfuscator


[2k\\
stars](https://github.com/weak1337/Alcatraz/stargazers) [270\\
forks](https://github.com/weak1337/Alcatraz/forks) [Branches](https://github.com/weak1337/Alcatraz/branches) [Tags](https://github.com/weak1337/Alcatraz/tags) [Activity](https://github.com/weak1337/Alcatraz/activity)

[Star](https://github.com/login?return_to=%2Fweak1337%2FAlcatraz)

[Notifications](https://github.com/login?return_to=%2Fweak1337%2FAlcatraz) You must be signed in to change notification settings

# weak1337/Alcatraz

master

[**1** Branch](https://github.com/weak1337/Alcatraz/branches) [**0** Tags](https://github.com/weak1337/Alcatraz/tags)

[Go to Branches page](https://github.com/weak1337/Alcatraz/branches)[Go to Tags page](https://github.com/weak1337/Alcatraz/tags)

Go to file

Code

Open more actions menu

## Folders and files

| Name | Name | Last commit message | Last commit date |
| --- | --- | --- | --- |
| ## Latest commit<br>[![weak1337](https://avatars.githubusercontent.com/u/57501119?v=4&size=40)](https://github.com/weak1337)[weak1337](https://github.com/weak1337/Alcatraz/commits?author=weak1337)<br>[Changed gitignore](https://github.com/weak1337/Alcatraz/commit/739e65ebadaeb3f8206fb2199700725331465abb)<br>3 years agoJul 14, 2023<br>[739e65e](https://github.com/weak1337/Alcatraz/commit/739e65ebadaeb3f8206fb2199700725331465abb) · 3 years agoJul 14, 2023<br>## History<br>[58 Commits](https://github.com/weak1337/Alcatraz/commits/master/) <br>Open commit details<br>[View commit history for this file.](https://github.com/weak1337/Alcatraz/commits/master/) 58 Commits |
| [Alcatraz-gui](https://github.com/weak1337/Alcatraz/tree/master/Alcatraz-gui "Alcatraz-gui") | [Alcatraz-gui](https://github.com/weak1337/Alcatraz/tree/master/Alcatraz-gui "Alcatraz-gui") | [Added support for latest zydis](https://github.com/weak1337/Alcatraz/commit/9bad71ec9ec19bbedc255e229d95c2aa8b114abc "Added support for latest zydis") | 3 years agoJul 14, 2023 |
| [Alcatraz](https://github.com/weak1337/Alcatraz/tree/master/Alcatraz "Alcatraz") | [Alcatraz](https://github.com/weak1337/Alcatraz/tree/master/Alcatraz "Alcatraz") | [Added support for latest zydis](https://github.com/weak1337/Alcatraz/commit/9bad71ec9ec19bbedc255e229d95c2aa8b114abc "Added support for latest zydis") | 3 years agoJul 14, 2023 |
| [images](https://github.com/weak1337/Alcatraz/tree/master/images "images") | [images](https://github.com/weak1337/Alcatraz/tree/master/images "images") | [Gui addition](https://github.com/weak1337/Alcatraz/commit/977352a3c4ddfc063b641818224edd6c74002582 "Gui addition") | 4 years agoJan 4, 2023 |
| [x64/Release](https://github.com/weak1337/Alcatraz/tree/master/x64/Release "This path skips through empty directories") | [x64/Release](https://github.com/weak1337/Alcatraz/tree/master/x64/Release "This path skips through empty directories") | [Added support for latest zydis](https://github.com/weak1337/Alcatraz/commit/9bad71ec9ec19bbedc255e229d95c2aa8b114abc "Added support for latest zydis") | 3 years agoJul 14, 2023 |
| [.gitignore](https://github.com/weak1337/Alcatraz/blob/master/.gitignore ".gitignore") | [.gitignore](https://github.com/weak1337/Alcatraz/blob/master/.gitignore ".gitignore") | [Changed gitignore](https://github.com/weak1337/Alcatraz/commit/739e65ebadaeb3f8206fb2199700725331465abb "Changed gitignore") | 3 years agoJul 14, 2023 |
| [.gitmodules](https://github.com/weak1337/Alcatraz/blob/master/.gitmodules ".gitmodules") | [.gitmodules](https://github.com/weak1337/Alcatraz/blob/master/.gitmodules ".gitmodules") | [added dependencies](https://github.com/weak1337/Alcatraz/commit/773cf6edd95f82a94062dac26619569bd6478cc4 "added dependencies") | 4 years agoDec 21, 2022 |
| [Alcatraz.sln](https://github.com/weak1337/Alcatraz/blob/master/Alcatraz.sln "Alcatraz.sln") | [Alcatraz.sln](https://github.com/weak1337/Alcatraz/blob/master/Alcatraz.sln "Alcatraz.sln") | [Gui addition](https://github.com/weak1337/Alcatraz/commit/2948db589b29dca0bf7d1e8890dd58a2d97e10af "Gui addition") | 4 years agoJan 4, 2023 |
| [README.md](https://github.com/weak1337/Alcatraz/blob/master/README.md "README.md") | [README.md](https://github.com/weak1337/Alcatraz/blob/master/README.md "README.md") | [Update README.md](https://github.com/weak1337/Alcatraz/commit/b7bae6b01288f9784d49315e7b361d0546833cc2 "Update README.md") | 4 years agoJan 6, 2023 |
| View all files |

## Repository files navigation

# Alcatraz

[Permalink: Alcatraz](https://github.com/weak1337/Alcatraz#alcatraz)

Alcatraz is a x64 binary obfuscator that is able to obfuscate various different pe files including:

- .exe
- .dll
- .sys

# Overview

[Permalink: Overview](https://github.com/weak1337/Alcatraz#overview)

- [Alcatraz](https://github.com/weak1337/Alcatraz#alcatraz)
- [Requirements](https://github.com/weak1337/Alcatraz#requirements)
- [Usage](https://github.com/weak1337/Alcatraz#usage)
- [Features](https://github.com/weak1337/Alcatraz#features)
  - [Obfuscation of immediate moves](https://github.com/weak1337/Alcatraz#obfuscation-of-immediate-moves)
  - [Control flow flattening](https://github.com/weak1337/Alcatraz#control-flow-flattening)
  - [ADD mutation](https://github.com/weak1337/Alcatraz#add-mutation)
  - [Entry-point obfuscation](https://github.com/weak1337/Alcatraz#entry-point-obfuscation)
  - [Lea obfuscation](https://github.com/weak1337/Alcatraz#lea-obfuscation)
  - [Anti disassembly](https://github.com/weak1337/Alcatraz#anti-disassembly)
  - [Import obfuscation](https://github.com/weak1337/Alcatraz#import-obfuscation)
  - [Final result](https://github.com/weak1337/Alcatraz#final-result)

# Requirements

[Permalink: Requirements](https://github.com/weak1337/Alcatraz#requirements)

Install: [https://vcpkg.io/en/getting-started.html](https://vcpkg.io/en/getting-started.html)

`asmjit`: vcpkg.exe install asmjit:x64-windows

`Zydis`: vcpkg.exe install zydis:x64-windows

# Usage

[Permalink: Usage](https://github.com/weak1337/Alcatraz#usage)

[![imgbefore](https://github.com/weak1337/Alcatraz/raw/master/images/gui.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/gui.PNG)
1.) Load a binary by clicking `file` in the top left corner.

2.) Add functions by expanding the `Functions` tree. (You can search by putting in the name in the searchbar at the top)

3.) Hit `compile` (note: obfuscating lots of functions might take some seconds)

# Features

[Permalink: Features](https://github.com/weak1337/Alcatraz#features)

In the following showcase all features (besides the one being showcased) are disabled.

### Obfuscation of immediate moves

[Permalink: Obfuscation of immediate moves](https://github.com/weak1337/Alcatraz#obfuscation-of-immediate-moves)

If an immediate value is moved into a register, we obfuscate it by applying multiple bitwise operations. Let's take a look at the popular function `_security_init_cookie`.

Before:
[![imgbefore](https://github.com/weak1337/Alcatraz/raw/master/images/const_before.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/const_before.PNG)
After:
[![imgafter](https://github.com/weak1337/Alcatraz/raw/master/images/const_after.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/const_after.PNG)

### Control flow flattening

[Permalink: Control flow flattening](https://github.com/weak1337/Alcatraz#control-flow-flattening)

By removing the tidy program structure the compiler generated and putting our code into new generated blocks, we increase the complexity of the program. Lets take this simple function `main` as example (optimization for this program is disabled):

[![imgmain](https://github.com/weak1337/Alcatraz/raw/master/images/flatten_function.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/flatten_function.PNG)

If we throw this into IDA 7.6 the decompiler will optimize it:

[![imgmainnoobf](https://github.com/weak1337/Alcatraz/raw/master/images/flatten_func_noobf.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/flatten_func_noobf.PNG)

Now let's flatten its control flow and let IDA analyze it again:

[![imgmainobf](https://github.com/weak1337/Alcatraz/raw/master/images/flatten_func_obf.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/flatten_func_obf.PNG)

As you can see, the complexity increased by a lot even though I only show a small portion of the generated code. If you want to know what the cfg looks like:
[![imgmaincfg](https://github.com/weak1337/Alcatraz/raw/master/images/flatten_func_cfg.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/flatten_func_cfg.PNG)

### ADD mutation

[Permalink: ADD mutation](https://github.com/weak1337/Alcatraz#add-mutation)

If a register (eg. RAX) is added to another register (eg. RCX) we will mutate the instruction. This means that the syntax changes but not the semantic.
The instruction `ADD RCX, RAX` can be mutated to:

```
push rax
not rax
sub rcx, rax
pop rax
sub rcx, 1
```

If you want to learn more about mutation take a look at [perses](https://github.com/mike1k/perses).

### Entry point obfuscation

[Permalink: Entry point obfuscation](https://github.com/weak1337/Alcatraz#entry-point-obfuscation)

If the PE file is a .exe (.dll support will be added) we will create a custom entry point that decrypts the real one on startup (!!! doesn't work when beeing manual mapped).

[![imgmaincfg](https://github.com/weak1337/Alcatraz/raw/master/images/customentry.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/customentry.PNG)

### Lea obfuscation

[Permalink: Lea obfuscation](https://github.com/weak1337/Alcatraz#lea-obfuscation)

The lea obfuscation is quite simple yet effective. We move a different location into the register and decrypt it afterwards. This way, reverse engineers can't cross reference certain data / functions.

Let's say we find the following instruction: `lea rcx, [0xDEAD]`

We will mutate it to:

```
pushf
lea rcx, [1CE54]
sub rcx, EFA7
popf

rcx -> 0xDEAD
```

### Anti disassembly

[Permalink: Anti disassembly](https://github.com/weak1337/Alcatraz#anti-disassembly)

If we find an instruction that starts with the byte 0xFF we will put a 0xEB infront of it.

We do this because 0xEB 0xFF encodes to jmp rip + 1 which, in the end, jumps to our actual first 0xFF. This will throw off tools that decode instructions in a linear way.

Before:

[![imgffbefore](https://github.com/weak1337/Alcatraz/raw/master/images/ffbefore.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/ffbefore.PNG)

After:

[![imgffafter](https://github.com/weak1337/Alcatraz/raw/master/images/ffafter.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/ffafter.PNG)

From time to time we can insert:

```
jz 3
jne 1
0xE8
```

IDA will try to decode the 0xE8 (call) but won't have any success:

[![imgjz](https://github.com/weak1337/Alcatraz/raw/master/images/jzobf.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/jzobf.PNG)

### Import obfuscation

[Permalink: Import obfuscation](https://github.com/weak1337/Alcatraz#import-obfuscation)

There is no "proper" IAT obfuscation at the moment. The 0xFF anti disassembly trick takes care of it for now. Proper implementation is planned here:

[iat.cpp](https://github.com/weak1337/Alcatraz/blob/master/Alcatraz/obfuscator/misc/iat.cpp)

### Final result

[Permalink: Final result](https://github.com/weak1337/Alcatraz#final-result)

This is a snippet of our `main` function with everything except anti disassembly enabled (so IDA can create a function):

[![imgfinal](https://github.com/weak1337/Alcatraz/raw/master/images/final.PNG)](https://github.com/weak1337/Alcatraz/blob/master/images/final.PNG)

## About

x64 binary obfuscator


### Resources

[Readme](https://github.com/weak1337/Alcatraz#readme-ov-file)

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/weak1337/Alcatraz).

[Activity](https://github.com/weak1337/Alcatraz/activity)

### Stars

[**2k**\\
stars](https://github.com/weak1337/Alcatraz/stargazers)

### Watchers

[**24**\\
watching](https://github.com/weak1337/Alcatraz/watchers)

### Forks

[**270**\\
forks](https://github.com/weak1337/Alcatraz/forks)

[Report repository](https://github.com/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2Fweak1337%2FAlcatraz&report=weak1337+%28user%29)

## [Releases](https://github.com/weak1337/Alcatraz/releases)

No releases published

## [Packages\  0](https://github.com/users/weak1337/packages?repo_name=Alcatraz)

No packages published

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/weak1337/Alcatraz).

## [Contributors\  2](https://github.com/weak1337/Alcatraz/graphs/contributors)

- [![@weak1337](https://avatars.githubusercontent.com/u/57501119?s=64&v=4)](https://github.com/weak1337)[**weak1337**](https://github.com/weak1337)
- [![@raigorx](https://avatars.githubusercontent.com/u/10247765?s=64&v=4)](https://github.com/raigorx)[**raigorx** Raigorx Hellscream](https://github.com/raigorx)

## Languages

- [C++90.6%](https://github.com/weak1337/Alcatraz/search?l=c%2B%2B)
- [C9.4%](https://github.com/weak1337/Alcatraz/search?l=c)

You can’t perform that action at this time.